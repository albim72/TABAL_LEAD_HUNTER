"""TABAL v2.3: localhost UI + SMTP outbox, Python 3.10+ standard library."""
import json
import secrets
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit
from server.mailer import Outbox, require

ROOT = Path(__file__).resolve().parent


def make_handler(outbox, token, root=ROOT):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *_):
            pass  # No credentials, payloads or recipient addresses in HTTP logs.

        def reply(self, status, payload, content_type='application/json; charset=utf-8'):
            data = json.dumps(payload, ensure_ascii=False).encode() if isinstance(payload,(dict,list)) else payload
            self.send_response(status)
            self.send_header('Content-Type', content_type)
            self.send_header('Content-Length', str(len(data)))
            self.send_header('Cache-Control', 'no-store')
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.send_header('X-Frame-Options', 'DENY')
            self.send_header('Content-Security-Policy', "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; connect-src 'self'; img-src 'self' data:; base-uri 'none'; frame-ancestors 'none'; form-action 'self'")
            self.end_headers()
            self.wfile.write(data)

        def authorized(self, api=False):
            host = f'127.0.0.1:{self.server.server_port}'
            require(self.headers.get('Host') == host, 'Użyj adresu 127.0.0.1 wyświetlonego przez aplikację.')
            origin = self.headers.get('Origin')
            require(not origin or origin == 'http://'+host, 'Żądanie z innej strony jest zablokowane.')
            require(self.headers.get('Sec-Fetch-Site') not in ('cross-site',), 'Żądanie z innej strony jest zablokowane.')
            if api:
                require(secrets.compare_digest(self.headers.get('X-Tabal-Token',''),token), 'Brak autoryzacji. Otwórz ponownie panel z lokalnego serwera.')

        def do_GET(self):
            try:
                path = urlsplit(self.path).path
                self.authorized(api=path.startswith('/api/'))
                if path == '/api/state':
                    return self.reply(200,outbox.snapshot())
                if path in ('/', '/START.html'):
                    html=(root/'START.html').read_text(encoding='utf-8').replace('/*__MAIL_RUNTIME__*/', 'window.TABAL_MAIL='+json.dumps({'token':token})+';')
                    return self.reply(200,html.encode(),'text/html; charset=utf-8')
                # Explicit allowlist: no directory listing, source code, SQLite or runtime exports.
                if path == '/INSTRUKCJA.html':
                    return self.reply(200,(root/'INSTRUKCJA.html').read_bytes(),'text/html; charset=utf-8')
                return self.reply(404,{'error':'Nie znaleziono zasobu.'})
            except ValueError as exc:
                self.reply(403,{'error':str(exc)})

        def do_POST(self):
            try:
                self.authorized(api=True)
                require(self.headers.get('Content-Type','').split(';')[0]=='application/json','Wymagany JSON.')
                size=int(self.headers.get('Content-Length','0'))
                require(0 < size <= 2000000,'Nieprawidłowy rozmiar żądania.')
                raw=json.loads(self.rfile.read(size))
                require(isinstance(raw,dict),'Wymagany obiekt JSON.')
                path=urlsplit(self.path).path
                if path == '/api/config':
                    data=outbox.configure(raw)
                elif path == '/api/test':
                    data=outbox.test_message(raw.get('owner'))
                elif path == '/api/enqueue':
                    data=outbox.enqueue(raw.get('messages'),raw.get('owner'))
                elif path == '/api/sync':
                    data=outbox.sync(raw.get('owner'),raw.get('allowed'),raw.get('writable') is True,raw.get('observed',[]))
                elif path == '/api/control':
                    data=outbox.control(raw.get('action'),raw.get('id',''),raw.get('owner',''))
                else:
                    return self.reply(404,{'error':'Nieznana operacja.'})
                self.reply(200,data)
            except (ValueError,TypeError,KeyError) as exc:
                self.reply(400,{'error':str(exc) if isinstance(exc,ValueError) else 'Nieprawidłowe dane formularza.'})
            except Exception:
                self.reply(500,{'error':'Błąd lokalnego modułu. Kolejkę wstrzymano; sprawdź stan przed wznowieniem.'})
                with outbox.lock:
                    outbox.paused=True
    return Handler


def main():
    # Bind first. A second launcher must not open/mutate the active outbox database.
    try:
        server=ThreadingHTTPServer(('127.0.0.1',8765),BaseHTTPRequestHandler)
    except OSError:
        print('Port 8765 jest zajety. Zamknij poprzedni serwer Huntera i uruchom ponownie.')
        return
    outbox=Outbox(ROOT/'.runtime'/'mail.sqlite3')
    server.RequestHandlerClass=make_handler(outbox,secrets.token_urlsafe(32))
    worker=threading.Thread(target=outbox.work,daemon=True)
    worker.start()
    address='http://127.0.0.1:8765/START.html'
    print('TABAL Lead Hunter v2.3: '+address)
    print('Pozostaw okno serwera i panel otwarte podczas wysylki. Stop: Ctrl+C.')
    print('Haslo SMTP wpisz w zakladce Wysylka. Jest przechowywane tylko w pamieci.')
    webbrowser.open(address)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        with outbox.lock:
            outbox.paused=True
        outbox.stop.set()
        worker.join(timeout=65)
        server.server_close()
        if not worker.is_alive():
            outbox.close()

if __name__ == '__main__':
    main()
