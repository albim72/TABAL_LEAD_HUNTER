"""Local SMTP outbox. Password is held in memory, never in SQLite or responses."""
import hashlib
import json
import re
import smtplib
import sqlite3
import ssl
import threading
import time
import uuid
from datetime import datetime, timezone
from email.message import EmailMessage
from email.utils import formataddr, formatdate
from pathlib import Path


def stamp():
    return datetime.now(timezone.utc).isoformat(timespec='seconds')


def require(ok, message):
    if not ok:
        raise ValueError(message)


def email(value):
    require(isinstance(value, str) and len(value) <= 254 and re.fullmatch(r"[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Za-z0-9](?:[A-Za-z0-9.-]*[A-Za-z0-9])?\.[A-Za-z]{2,63}", value), 'Podaj jeden prawidłowy adres e-mail (bez nazwy i listy odbiorców).')
    return value.strip()


def clean(value, label, limit):
    require(isinstance(value, str) and value.strip() and len(value) <= limit, 'Sprawdź pole: ' + label)
    require('\x00' not in value, 'Niedozwolony znak w polu: ' + label)
    return value.strip()


def message(raw):
    require(isinstance(raw, dict), 'Nieprawidłowa wiadomość.')
    require(raw.get('mode') == 'pilot' and raw.get('is_demo') is False, 'Wysyłka tylko ze zbioru Mój pilot.')
    require(raw.get('status') == 'TO_CONTACT' and raw.get('do_not_contact') is False, 'Lead musi mieć status DO KONTAKTU bez blokady kontaktu.')
    require(raw.get('verified_email') is True, 'Brak potwierdzonego e-maila.')
    subject = clean(raw.get('subject'), 'temat', 300)
    require('\n' not in subject and '\r' not in subject, 'Temat musi być jednowierszowy.')
    return dict(lead_id=clean(raw.get('lead_id'), 'ID firmy', 150), company=clean(raw.get('company'), 'firma', 500),
                to=email(raw.get('to')), subject=subject, body=clean(raw.get('body'), 'treść', 12000))


class DeliveryError(Exception):
    def __init__(self, status, reason):
        super().__init__(reason)
        self.status = status


class SMTPTransport:
    def send(self, config, job):
        smtp = None
        attempted = False
        try:
            context = ssl.create_default_context()
            if config['security'] == 'ssl':
                smtp = smtplib.SMTP_SSL(config['host'], config['port'], timeout=20, context=context)
            else:
                smtp = smtplib.SMTP(config['host'], config['port'], timeout=20)
                smtp.ehlo()
                smtp.starttls(context=context)
                smtp.ehlo()
            smtp.login(config['username'], config['password'])
            msg = EmailMessage()
            msg['From'] = formataddr((config['sender_name'], config['sender_email']))
            msg['To'] = job['to']
            msg['Subject'] = job['subject']
            msg['Date'] = formatdate(localtime=False)
            msg['Message-ID'] = job['message_id']
            msg.set_content(job['body'])
            attempted = True
            refused = smtp.send_message(msg, from_addr=config['sender_email'], to_addrs=[job['to']])
            if refused:
                raise DeliveryError('failed', 'Serwer SMTP odrzucił odbiorcę. Sprawdź adres i ustawienia.')
        except DeliveryError:
            raise
        except smtplib.SMTPAuthenticationError:
            raise DeliveryError('failed', 'Serwer odrzucił logowanie. Sprawdź login, hasło aplikacji i dostęp SMTP.') from None
        except (smtplib.SMTPRecipientsRefused, smtplib.SMTPSenderRefused, smtplib.SMTPDataError):
            raise DeliveryError('failed', 'SMTP jawnie odrzucił wiadomość. Sprawdź adresy i ograniczenia skrzynki.') from None
        except Exception:
            # Do not leak SMTP replies, password or credentials via diagnostics.
            status = 'uncertain' if attempted else 'failed'
            reason = ('Brak pewności, czy SMTP przyjął wiadomość. Sprawdź skrzynkę lub logi operatora; nie ponawiaj automatycznie.'
                      if attempted else 'Nie udało się połączyć lub zalogować przez TLS. Sprawdź host, port, sieć i ustawienia skrzynki.')
            raise DeliveryError(status, reason) from None
        finally:
            if smtp:
                try:
                    smtp.close()  # QUIT errors must not turn an accepted message into a failure.
                except Exception:
                    pass


class Outbox:
    def __init__(self, path, transport=None, clock=time.monotonic):
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(path, check_same_thread=False)
        self.db.row_factory = sqlite3.Row
        self.lock = threading.RLock()
        self.clock = clock
        self.transport = transport or SMTPTransport()
        self.config = None
        self.paused = True
        self.owner = None
        self.heartbeat = -1000
        self.allowed = set()
        self.next_send = 0
        self.running = False
        self.stop = threading.Event()
        with self.db:
            self.db.execute('CREATE TABLE IF NOT EXISTS jobs (id TEXT PRIMARY KEY, email_key TEXT, status TEXT, payload TEXT, created_at TEXT, sent_at TEXT, error TEXT, attempts INTEGER DEFAULT 0)')
            self.db.execute("UPDATE jobs SET status='uncertain',error='Przerwano proces podczas wysyłki. Sprawdź przyjęcie wiadomości przez SMTP przed dalszym kontaktem.' WHERE status='sending'")

    def jobs(self):
        with self.lock:
            return [dict(json.loads(row['payload']), id=row['id'], status=row['status'], created_at=row['created_at'], sent_at=row['sent_at'], error=row['error'], attempts=row['attempts'])
                    for row in self.db.execute('SELECT * FROM jobs ORDER BY created_at,id')]

    def snapshot(self):
        with self.lock:
            return dict(configured=bool(self.config), paused=self.paused, active=self.running,
                        connected=self.clock()-self.heartbeat < 15,
                        config={k: v for k, v in (self.config or {}).items() if k != 'password'}, jobs=self.jobs())

    def configure(self, raw):
        with self.lock:
            require(not self.running and self.paused, 'Najpierw wstrzymaj kolejkę i poczekaj na zakończenie bieżącej wysyłki.')
            cfg = {k: clean(raw.get(k), k, limit) for k, limit in [('host',253),('username',254),('sender_name',150)]}
            require(re.fullmatch(r'[A-Za-z0-9.-]+', cfg['host']), 'Host SMTP: podaj nazwę bez https:// i ścieżki.')
            require('\r' not in cfg['sender_name'] and '\n' not in cfg['sender_name'], 'Nazwa nadawcy musi być jednowierszowa.')
            cfg['sender_email'] = email(raw.get('sender_email'))
            cfg['security'] = raw.get('security')
            require(cfg['security'] in ('ssl', 'starttls'), 'Wymagane szyfrowanie SSL/TLS lub STARTTLS.')
            cfg['port'] = int(raw.get('port', 0))
            cfg['interval'] = int(raw.get('interval', 30))
            require(1 <= cfg['port'] <= 65535 and 10 <= cfg['interval'] <= 3600, 'Port: 1–65535; odstęp: 10–3600 sekund.')
            cfg['password'] = raw.get('password') or (self.config or {}).get('password', '')
            require(isinstance(cfg['password'],str) and 0 < len(cfg['password']) <= 2000, 'Podaj hasło SMTP lub hasło aplikacji.')
            # Sender is frozen into every job; changes never redirect an approved batch.
            for job in self.jobs():
                if job['status'] in ('queued','failed'):
                    require(job['sender_email'] == cfg['sender_email'], 'Anuluj oczekujące/błędne wiadomości przed zmianą adresu nadawcy.')
            self.config = cfg
            return self.snapshot()

    def enqueue(self, raw, owner):
        with self.lock:
            require(self.config, 'Najpierw skonfiguruj SMTP.')
            self.claim(owner)
            require(isinstance(raw, list) and 1 <= len(raw) <= 50, 'Jedna partia: 1–50 wiadomości.')
            checked = [message(item) for item in raw]
            require(len({m['to'].lower() for m in checked}) == len(checked), 'Powtórzony adres w partii. Zostaw jedną wiadomość na skrzynkę.')
            for m in checked:
                require(not self.db.execute("SELECT 1 FROM jobs WHERE email_key=? AND status IN ('queued','sending','sent','uncertain')", (m['to'].lower(),)).fetchone(), 'Adres jest już w kolejce, został obsłużony albo ma niepewny wynik: '+m['to'])
            with self.db:
                for m in checked:
                    jobid = str(uuid.uuid4())
                    m.update(sender_email=self.config['sender_email'], sender_name=self.config['sender_name'], message_id=f'<{jobid}@{self.config["sender_email"].split("@")[1]}>')
                    self.db.execute('INSERT INTO jobs (id,email_key,status,payload,created_at,sent_at,error) VALUES (?,?,?,?,?,?,?)',
                                    (jobid,m['to'].lower(),'queued',json.dumps(m,ensure_ascii=False),stamp(),'',''))
            self.paused = True
            # Explicit resume after review; enqueue itself never starts delivery.
            return self.snapshot()

    def test_message(self, owner):
        with self.lock:
            require(self.config, 'Najpierw skonfiguruj SMTP.')
            self.claim(owner)
            require(not self.running and not any(j['status']=='queued' for j in self.jobs()), 'Test wykonaj przy pustej kolejce oczekujących wiadomości.')
            jobid=str(uuid.uuid4())
            data=dict(kind='test',lead_id='smtp-test:'+jobid,company='Test własnej skrzynki',to=self.config['sender_email'],sender_email=self.config['sender_email'],sender_name=self.config['sender_name'],subject='TABAL Lead Hunter — test SMTP',body='To wiadomość testowa wysłana przez Twój lokalny moduł TABAL Lead Hunter v2.3.',message_id=f'<{jobid}@{self.config["sender_email"].split("@")[1]}>')
            with self.db:
                self.db.execute('INSERT INTO jobs (id,email_key,status,payload,created_at,sent_at,error) VALUES (?,?,?,?,?,?,?)',(jobid,'test:'+jobid,'queued',json.dumps(data),stamp(),'',''))
            self.paused=True
            return self.snapshot()

    def claim(self, owner):
        require(isinstance(owner, str) and 10 <= len(owner) <= 100, 'Brak identyfikatora sesji.')
        require(self.owner in (None,owner) or self.clock()-self.heartbeat >= 15, 'Kolejkę obsługuje inna karta. Wstrzymaj ją lub zamknij i odczekaj 15 sekund.')
        if self.owner != owner:
            self.paused = True
            self.allowed.clear()
        self.owner = owner

    def sync(self, owner, allowed, writable=True, observed=None):
        with self.lock:
            self.claim(owner)
            require(isinstance(allowed,list) and len(allowed) <= 5000, 'Nieprawidłowa lista kolejki.')
            observed = set(observed) if observed is not None else {j['id'] for j in self.jobs()}
            self.heartbeat = self.clock()
            self.allowed = set(allowed) if writable else set()
            if not writable:
                self.paused = True
            # A changed status/address/draft or removed lead invalidates its pending approval.
            with self.db:
                for job in self.jobs():
                    if job['status'] == 'queued' and job['id'] in observed and job['id'] not in self.allowed:
                        self.db.execute("UPDATE jobs SET status='cancelled',error='Zmieniono dane, szkic lub status firmy. Dodaj aktualną wiadomość ponownie.' WHERE id=?",(job['id'],))
            return self.snapshot()

    def control(self, action, jobid='', owner=''):
        with self.lock:
            if action == 'pause':
                self.paused = True
            elif action == 'resume':
                self.claim(owner)
                require(self.config and self.clock()-self.heartbeat < 15, 'Połącz panel i skonfiguruj SMTP przed wznowieniem.')
                require(self.allowed, 'Brak zatwierdzonych wiadomości. Odśwież kolejkę.')
                self.paused = False
            elif action == 'cancel':
                with self.db:
                    row = self.db.execute("UPDATE jobs SET status='cancelled',error='Anulowano przez operatora.' WHERE id=? AND status IN ('queued','failed')",(jobid,))
                    require(row.rowcount, 'Można anulować tylko oczekującą lub błędną wiadomość. Trwającej wysyłki nie można cofnąć.')
            elif action == 'retry':
                require(self.paused, 'Wstrzymaj kolejkę przed ponowieniem.')
                self.claim(owner)
                job = next((j for j in self.jobs() if j['id']==jobid),None)
                require(job and job['status']=='failed', 'Ponowienie tylko po jednoznacznym błędzie, nigdy dla niepewnego wyniku.')
                require(jobid in self.allowed, 'Treść lub status firmy zmieniły się. Anuluj i dodaj aktualną wiadomość.')
                require(not self.db.execute("SELECT 1 FROM jobs WHERE email_key=? AND id<>? AND status IN ('queued','sending','sent','uncertain')",(job['to'].lower(),jobid)).fetchone(),'Ten adres ma już inną aktywną lub wysłaną wiadomość.')
                with self.db:
                    self.db.execute("UPDATE jobs SET status='queued',error='' WHERE id=?",(jobid,))
            else:
                raise ValueError('Nieznana operacja kolejki.')
            return self.snapshot()

    def run_one(self):
        with self.lock:
            if self.clock()-self.heartbeat >= 15:
                self.paused = True
            if self.paused or not self.config or self.running or self.clock() < self.next_send:
                return False
            job = next((j for j in self.jobs() if j['status']=='queued' and j['id'] in self.allowed),None)
            if not job:
                return False
            self.running = True
            cfg = dict(self.config, sender_email=job['sender_email'], sender_name=job['sender_name'])
            with self.db:
                self.db.execute("UPDATE jobs SET status='sending',attempts=attempts+1 WHERE id=?",(job['id'],))
        status, error, sent_at = 'sent', '', ''
        try:
            self.transport.send(cfg, job)
            sent_at = stamp()
        except DeliveryError as exc:
            status, error = exc.status, str(exc)
        except Exception:
            status, error = 'uncertain', 'Nieznany wynik wysyłki. Sprawdź logi skrzynki; automatyczne ponowienie zablokowane.'
        finally:
            with self.lock:
                with self.db:
                    self.db.execute('UPDATE jobs SET status=?,sent_at=?,error=? WHERE id=?',(status,sent_at,error,job['id']))
                self.running = False
                self.next_send = self.clock()+cfg['interval']
                if status != 'sent':
                    self.paused = True
        return True

    def work(self):
        while not self.stop.wait(0.5):
            try:
                self.run_one()
            except Exception:
                # A persistence failure must never cause automatic resend.
                with self.lock:
                    self.paused = True
                    self.running = False

    def close(self):
        self.stop.set()
        with self.lock:
            self.db.close()
