# TABAL Lead Hunter v2.3

Wersja 2.3.0 · 21.09.2026 · SYNAPSE X / TABAL

V2.3 dodaje **wysyłkę e-maili przez firmowe SMTP**. Po sprawdzeniu szkiców i zatwierdzeniu partii program wysyła wiadomości kolejno, zachowuje wyniki i aktualizuje historię leadów. Nie trzeba kopiować każdej wiadomości do poczty.

## Start na Windows

1. W starej aplikacji pobierz **Kopię JSON** zbioru Mój pilot.
2. Rozpakuj ZIP. Wymagany jest **Python 3.10 lub nowszy** (https://www.python.org/downloads/). Moduł nie wymaga instalowania dodatkowych bibliotek.
3. Uruchom **URUCHOM_WINDOWS.bat**. Otworzy się panel: **http://127.0.0.1:8765/START.html**. Pozostaw okno serwera otwarte.
4. W panelu wybierz Mój pilot → Profil i źródła → Dane i kopie → Przywróć kopię v1 / v2. Wczytaj kopię ze starej wersji i sprawdź firmy, notatki oraz statusy.
5. Otwórz zakładkę **Wysyłka** i skonfiguruj SMTP.

Na macOS/Linux: `python3 serve.py` z katalogu aplikacji. Można też użyć dołączonego skryptu `.command` (w razie potrzeby nadać mu uprawnienie do uruchamiania).

Dwuklik w START.html nadal uruchamia lokalny rejestr, ale **wysyłka działa tylko przez lokalny serwer**, nie przez `file://`. Pamięć dla obu adresów jest osobna — przenieś dane Kopią JSON.

## Konfiguracja i pierwsza wiadomość

Od administratora poczty potrzebujesz: hosta SMTP, portu, trybu SSL/TLS lub STARTTLS, loginu, hasła SMTP lub hasła aplikacji oraz dozwolonego adresu nadawcy. Nie podawaj hasła w rozmowie; wpisz je bezpośrednio w lokalnym panelu. Często spotykane porty to 465 dla SSL/TLS i 587 dla STARTTLS, ale obowiązują parametry Twojego operatora.

Kliknij **Zapisz konfigurację na tę sesję**, następnie **Wyślij test na adres nadawcy**. Ten przycisk wysyła rzeczywistą wiadomość na skonfigurowany adres nadawcy i jest dostępny przy pustej kolejce oczekujących. Sprawdź odbiór w swojej poczcie.

Hasło i konfiguracja pozostają tylko w pamięci serwera. Po jego ponownym uruchomieniu wpisujesz je ponownie. Obsługiwane jest uwierzytelnianie SMTP loginem i hasłem przez szyfrowane połączenie. **OAuth-only, Microsoft Graph i Gmail API nie są częścią tej wersji.**

## Automatyczna wysyłka partii

1. Na karcie firmy sprawdź źródła i e-mail, popraw i zapisz szkic, ustaw **DO KONTAKTU**.
2. W zakładce Wysyłka rozwiń treści, zaznacz wybrane wiadomości (do 50) i kliknij **Dodaj wybrane wiadomości do kolejki**.
3. Sprawdź kolejkę i kliknij **Uruchom kolejkę**. Każda wiadomość ma jednego adresata. Domyślny odstęp wynosi 30 sekund, zakres 10–3600 sekund.
4. Pozostaw panel Mój pilot i serwer otwarte. Po przyjęciu przez SMTP program zapisze **SKONTAKTOWANY** oraz wpis historii. Jeśli firma ma już późniejszy status, nie cofnie go.
5. Po sesji pobierz Kopię JSON i historię wysyłki. Odpowiedzi i odbicia sprawdzaj w swojej poczcie.

Dodanie kolejnej partii wstrzymuje kolejkę do ponownego uruchomienia. Zmiana treści, adresu, statusu lub blokady kontaktu anuluje oczekującą wiadomość podczas synchronizacji panelu. Wiadomości już wysyłanej nie da się cofnąć.

## Zachowanie przy przerwaniu

- **Wstrzymaj** zatrzymuje kolejne wiadomości; trwająca próba może się zakończyć.
- Zamknięcie lub utrata połączenia z panelem wstrzymuje kolejkę po maksymalnie około 15 sekundach. Uśpienie komputera i ograniczenie timerów karty również może zatrzymać wysyłkę.
- Po ponownym uruchomieniu serwera kolejka jest wstrzymana i nie ma hasła. Wpisz ustawienia, sprawdź stan i uruchom ją świadomie.
- **Błąd — nie wysłano:** popraw ustawienia i użyj przycisku ponowienia. Nie ma automatycznych ponowień.
- **Wynik niepewny:** połączenie zostało przerwane w momencie, gdy SMTP mógł już przyjąć wiadomość. Sprawdź logi dostawcy lub swoją skrzynkę. Program blokuje ponowienie, żeby nie wysłać dubla.
- Wysyłka początkowa na adres już przyjęty przez SMTP, aktywny lub z niepewnym wynikiem jest blokowana również przy innym leadzie. Automatyczne follow-upy nie są objęte tą wersją.

**Przyjęcie przez SMTP nie oznacza doręczenia ani przeczytania.** SMTP nie musi umieszczać kopii w folderze „Wysłane”; Hunter zachowuje własny dziennik i Message-ID. Brak kopii w „Wysłanych” nie dowodzi, że wiadomość nie została wysłana.

## Dane i kopie

Rejestr firm pozostaje w LocalStorage przeglądarki. Kolejka, treści zatwierdzonych wiadomości i wyniki SMTP są zapisane lokalnie w `.runtime/mail.sqlite3`. Hasła nie trafiają do tej bazy ani eksportów. API nasłuchuje wyłącznie na 127.0.0.1 i wymaga tokenu bieżącej sesji, poprawnego hosta i pochodzenia żądania.

**Kopia JSON Huntera zawiera zsynchronizowane potwierdzenia wysyłek na kartach**, ale nie zastępuje pełnej kopii lokalnej kolejki. Przed przenoszeniem aplikacji wstrzymaj wysyłkę, zamknij serwer i skopiuj cały katalog `.runtime` wraz z paczką. Nie usuwaj bazy kolejki podczas aktywnej pracy. Eksport „Pobierz historię wysyłki” służy do archiwum; nie uruchamia ani nie odtwarza kolejki.

Pracuj w jednej karcie i na jednym komputerze. Nie ma wspólnej bazy zespołowej, automatycznego odczytu odpowiedzi, załączników, śledzenia otwarć ani pracy w chmurze.

## Testy i dokumentacja

Szczegóły i wyniki: **docs/RAPORT_TESTOW.md**, instrukcja w przeglądarce: **INSTRUKCJA.html**. Testy obejmują logikę, interfejs DOM, lokalne API, SQLite oraz rzeczywiste połączenia TLS/STARTTLS do lokalnej skrzynki testowej. Nie wysłano wiadomości do realnych firm i nie podłączono rzeczywistego konta TABAL. Pełnego testu w Firefox/Chrome na Windows nie wykonano.

Źródła techniczne: Python smtplib https://docs.python.org/3/library/smtplib.html i sqlite3 https://docs.python.org/3/library/sqlite3.html.

## Dla osoby technicznej

- Budowanie: `python scripts/build.py`.
- Testy logiki: `node --test tests/core.test.js`.
- Testy starego interfejsu: `npm install`, potem `npm run test:dom`.
- Testy serwera/SMTP: `python tests/test_mail.py` (testy TLS wymagają narzędzia openssl; użytkownik aplikacji go nie potrzebuje).
- Interfejs + rzeczywiste lokalne API: `node tests/mail-dom.cjs` (jsdom i python3 w PATH).
- Test pliku Work: `node tests/research-file.cjs sciezka/do/wyniku.json`.
- Pakowanie bez bazy użytkownika: `python scripts/package.py`.
