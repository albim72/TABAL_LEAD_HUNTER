import contextlib
import importlib.util
import json
import smtplib
import socket
import socketserver
import ssl
import subprocess
import sys
import tempfile
import threading
import unittest
from http.client import HTTPConnection
from pathlib import Path
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from server.mailer import Outbox, SMTPTransport, DeliveryError, message
spec=importlib.util.spec_from_file_location('tabal_server',ROOT/'serve.py')
web=importlib.util.module_from_spec(spec);spec.loader.exec_module(web)
OWNER='test-owner-12345'
CONFIG=dict(host='localhost',port=465,security='ssl',username='test@example.com',password='TEST-SECRET-UNIQUE',sender_name='Zespół TABAL',sender_email='test@example.com',interval=10)


def raw(to='first@example.com',lead='lead-1'):
    return dict(mode='pilot',lead_id=lead,company='Firma testowa',to=to,subject='Oferta — test',body='Dzień dobry,\nTo wyłącznie test lokalny.',status='TO_CONTACT',is_demo=False,do_not_contact=False,verified_email=True)


class Transport:
    def __init__(self): self.sent=[];self.error=None
    def send(self,cfg,job):
        if self.error: raise self.error
        self.sent.append((cfg.copy(),job.copy()))


class OutboxTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.path=Path(self.tmp.name)/'mail.sqlite3'
        self.transport=Transport();self.now=100
        self.box=Outbox(self.path,self.transport,lambda:self.now)
        self.box.configure(CONFIG)
    def tearDown(self): self.box.close();self.tmp.cleanup()
    def ready(self,items=None):
        self.box.enqueue(items or [raw()],OWNER)
        ids=[j['id'] for j in self.box.jobs() if j['status']=='queued']
        self.box.sync(OWNER,ids);self.box.control('resume',owner=OWNER)
        return ids
    def test_01_requires_approved_status_contact_and_pilot(self):
        for changes in [dict(mode='demo'),dict(is_demo=True),dict(status='NEW'),dict(do_not_contact=True),dict(verified_email=False)]:
            with self.subTest(changes=changes),self.assertRaises(ValueError):self.box.enqueue([{**raw(),**changes}],OWNER)
        self.assertEqual(self.box.jobs(),[])
    def test_02_headers_and_recipient_lists_rejected(self):
        for changes in [dict(subject='X\r\nBcc: bad@example.com'),dict(to='one@example.com,two@example.com'),dict(to='a@example.com\r\nBcc:x@example.com')]:
            with self.assertRaises(ValueError):message({**raw(),**changes})
    def test_03_enqueue_does_not_send_before_resume(self):
        self.box.enqueue([raw()],OWNER);self.box.sync(OWNER,[self.box.jobs()[0]['id']]);self.assertFalse(self.box.run_one());self.assertEqual(len(self.transport.sent),0)
    def test_04_sends_once_and_records_smtp_acceptance(self):
        self.ready();self.assertTrue(self.box.run_one());self.now+=11;self.assertFalse(self.box.run_one());j=self.box.jobs()[0];self.assertEqual(j['status'],'sent');self.assertTrue(j['sent_at']);self.assertEqual(len(self.transport.sent),1)
    def test_05_interval_and_separate_recipient_messages(self):
        ids=self.ready([raw(),raw('second@example.com','lead-2')]);self.box.run_one();self.assertFalse(self.box.run_one());self.now+=10;self.box.sync(OWNER,ids);self.assertTrue(self.box.run_one());self.assertEqual(len(self.transport.sent),2)
    def test_06_duplicate_across_leads_and_batches_is_blocked(self):
        self.ready();self.box.run_one()
        with self.assertRaises(ValueError):self.box.enqueue([raw('first@example.com','other-id')],OWNER)
    def test_07_batch_is_atomic_when_a_row_is_invalid(self):
        with self.assertRaises(ValueError):self.box.enqueue([raw(),{**raw('two@example.com'), 'body':''}],OWNER)
        self.assertEqual(self.box.jobs(),[])
    def test_08_heartbeat_loss_pauses_without_resend(self):
        self.ready();self.now+=16;self.assertFalse(self.box.run_one());self.assertTrue(self.box.paused)
    def test_09_dnc_or_changed_draft_cancels_pending_job(self):
        self.ready();self.box.sync(OWNER,[]);self.assertFalse(self.box.run_one());self.assertEqual(self.box.jobs()[0]['status'],'cancelled')
    def test_10_error_pauses_and_requires_explicit_retry(self):
        ids=self.ready();self.transport.error=DeliveryError('failed','Błąd testowy');self.box.run_one();self.assertTrue(self.box.paused);self.assertEqual(self.box.jobs()[0]['status'],'failed')
        self.transport.error=None;self.box.control('retry',ids[0],OWNER);self.box.control('resume',owner=OWNER);self.now+=10;self.box.sync(OWNER,ids);self.box.run_one();self.assertEqual(self.box.jobs()[0]['status'],'sent')
    def test_11_uncertain_cannot_retry_or_enqueue_again(self):
        ids=self.ready();self.transport.error=DeliveryError('uncertain','Niepewny');self.box.run_one()
        with self.assertRaises(ValueError):self.box.control('retry',ids[0],OWNER)
        with self.assertRaises(ValueError):self.box.enqueue([raw()],OWNER)
    def test_12_restart_keeps_queue_paused_and_clears_credentials(self):
        self.ready();self.box.close();self.box=Outbox(self.path,self.transport,lambda:self.now);self.assertEqual(self.box.jobs()[0]['status'],'queued');self.assertIsNone(self.box.config);self.assertTrue(self.box.paused)
    def test_13_crash_during_sending_becomes_uncertain(self):
        self.ready()
        with self.box.db:self.box.db.execute("UPDATE jobs SET status='sending'")
        self.box.close();self.box=Outbox(self.path,self.transport,lambda:self.now);self.assertEqual(self.box.jobs()[0]['status'],'uncertain');self.assertFalse(self.box.run_one())
    def test_14_password_never_in_database_or_snapshot(self):
        self.ready();self.assertNotIn(CONFIG['password'],json.dumps(self.box.snapshot()));self.assertNotIn(CONFIG['password'].encode(),self.path.read_bytes())
    def test_15_only_verified_tls_modes_accepted(self):
        with self.assertRaises(ValueError):self.box.configure({**CONFIG,'security':'none'})
    def test_16_other_tab_cannot_take_active_queue(self):
        self.ready()
        with self.assertRaises(ValueError):self.box.sync('different-owner-1234',[])
    def test_17_new_owner_after_timeout_starts_paused(self):
        ids=self.ready();self.now+=16;self.box.sync('different-owner-1234',ids);self.assertTrue(self.box.paused)
    def test_18_cancel_and_pause_prevent_dispatch(self):
        ids=self.ready();self.box.control('cancel',ids[0]);self.assertFalse(self.box.run_one());self.box.enqueue([raw()],OWNER);self.assertTrue(self.box.paused)
    def test_19_sender_change_cannot_repurpose_pending_batch(self):
        self.ready();self.box.control('pause')
        with self.assertRaises(ValueError):self.box.configure({**CONFIG,'sender_email':'other@example.com'})
    def test_20_self_test_is_only_to_sender(self):
        self.box.test_message(OWNER);j=self.box.jobs()[0];self.assertEqual(j['to'],CONFIG['sender_email']);self.assertEqual(j['kind'],'test')
    def test_21_retry_conflicts_with_new_pending_message(self):
        ids=self.ready();self.transport.error=DeliveryError('failed','x');self.box.run_one();self.box.enqueue([raw()],OWNER)
        with self.assertRaises(ValueError):self.box.control('retry',ids[0],OWNER)

    def test_31_stale_sync_does_not_cancel_a_newly_added_batch(self):
        ids=self.ready();self.box.enqueue([raw('second@example.com','lead-2')],OWNER)
        self.box.sync(OWNER,ids,observed=ids)
        self.assertEqual([j['status'] for j in self.box.jobs()],['queued','queued'])
        self.assertTrue(self.box.paused)


class HTTPTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.box=Outbox(Path(self.tmp.name)/'mail.db',Transport());self.token='csrf-test-token'
        self.server=web.ThreadingHTTPServer(('127.0.0.1',0),web.make_handler(self.box,self.token));self.thread=threading.Thread(target=self.server.serve_forever,daemon=True);self.thread.start()
    def tearDown(self):self.server.shutdown();self.thread.join();self.server.server_close();self.box.close();self.tmp.cleanup()
    def request(self,path,body=None,headers=None):
        c=HTTPConnection('127.0.0.1',self.server.server_port,timeout=3);hs={'X-Tabal-Token':self.token,'Content-Type':'application/json'};hs.update(headers or {});c.request('POST' if body is not None else 'GET',path,json.dumps(body) if body is not None else None,hs);r=c.getresponse();status,data=r.status,r.read();c.close();return status,data
    def test_22_runtime_token_injected_only_into_served_app(self):
        status,data=self.request('/START.html');self.assertEqual(status,200);self.assertIn(self.token.encode(),data);self.assertNotIn(b'/*__MAIL_RUNTIME__*/',data)
    def test_23_runtime_database_not_served(self):
        for path in ['/.runtime/mail.sqlite3','/server/mailer.py','/../.runtime/mail.sqlite3']:
            self.assertEqual(self.request(path)[0],404)
    def test_24_cross_origin_wrong_host_and_token_blocked(self):
        self.assertEqual(self.request('/api/state',headers={'Origin':'https://evil.example'})[0],403)
        self.assertEqual(self.request('/api/state',headers={'Host':'evil.example'})[0],403)
        self.assertEqual(self.request('/api/state',headers={'X-Tabal-Token':'wrong'})[0],403)
        self.assertEqual(self.request('/api/control',{'action':'resume'},headers={'X-Tabal-Token':'wrong'})[0],400)
    def test_25_config_response_never_contains_password(self):
        status,data=self.request('/api/config',CONFIG);self.assertEqual(status,200);self.assertNotIn(CONFIG['password'].encode(),data)
    def test_26_http_queue_sync_dispatch_and_receipt(self):
        self.request('/api/config',CONFIG);status,data=self.request('/api/enqueue',dict(owner=OWNER,messages=[raw()]));self.assertEqual(status,200);j=json.loads(data)['jobs'][0]
        self.request('/api/sync',dict(owner=OWNER,allowed=[j['id']],writable=True));self.request('/api/control',dict(action='resume',owner=OWNER));self.box.run_one();self.assertEqual(json.loads(self.request('/api/state')[1])['jobs'][0]['status'],'sent')


class TLSServer(socketserver.ThreadingTCPServer):
    allow_reuse_address=True
    daemon_threads=True
    def get_request(self):
        sock,addr=super().get_request()
        return (self.context.wrap_socket(sock,server_side=True),addr) if self.implicit else (sock,addr)


class SMTPHandler(socketserver.StreamRequestHandler):
    def finish(self):
        super().finish()
        self.connection.close()
    def handle(self):
        def reply(line):self.wfile.write((line+'\r\n').encode());self.wfile.flush()
        reply('220 localhost test SMTP')
        while True:
            line=self.rfile.readline()
            if not line:return
            command=line.decode(errors='replace').strip().upper()
            if command.startswith(('EHLO','HELO')):
                reply('250-localhost');reply('250-STARTTLS');reply('250 AUTH PLAIN')
            elif command=='STARTTLS':
                reply('220 Ready');self.rfile.close();self.wfile.close();self.connection=self.server.context.wrap_socket(self.connection,server_side=True);self.rfile=self.connection.makefile('rb');self.wfile=self.connection.makefile('wb')
            elif command.startswith('AUTH'):reply('235 Authenticated')
            elif command.startswith(('MAIL','RCPT','RSET','NOOP')):reply('250 OK')
            elif command=='DATA':
                reply('354 Data');data=b''
                while True:
                    line=self.rfile.readline()
                    if not line:return
                    if line==b'.\r\n':break
                    data+=line
                self.server.messages.append(data)
                if self.server.drop:return  # accepted data, no final response: ambiguous
                reply('250 Accepted')
            elif command=='QUIT':reply('221 Bye');return
            else:reply('500 Unknown')


class RealSMTPTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp=tempfile.TemporaryDirectory();cls.cert=Path(cls.tmp.name)/'cert.pem';cls.key=Path(cls.tmp.name)/'key.pem'
        subprocess.run(['openssl','req','-x509','-newkey','rsa:2048','-nodes','-keyout',str(cls.key),'-out',str(cls.cert),'-days','1','-subj','/CN=localhost','-addext','subjectAltName=DNS:localhost,IP:127.0.0.1'],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    @classmethod
    def tearDownClass(cls):cls.tmp.cleanup()
    def run_smtp(self,implicit=True,drop=False):
        context=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER);context.load_cert_chain(self.cert,self.key)
        srv=TLSServer(('127.0.0.1',0),SMTPHandler);srv.context=context;srv.implicit=implicit;srv.drop=drop;srv.messages=[]
        th=threading.Thread(target=srv.serve_forever,daemon=True);th.start()
        real=ssl.create_default_context
        cfg={**CONFIG,'host':'localhost','port':srv.server_address[1],'security':'ssl' if implicit else 'starttls'}
        job={**message(raw()),'message_id':'<test-message-id@example.com>'}
        try:
            with patch('server.mailer.ssl.create_default_context',side_effect=lambda:real(cafile=str(self.cert))):
                if drop:
                    with self.assertRaises(DeliveryError) as cm:SMTPTransport().send(cfg,job)
                    self.assertEqual(cm.exception.status,'uncertain')
                else:SMTPTransport().send(cfg,job)
            self.assertEqual(len(srv.messages),1)
            from email import policy
            from email.parser import BytesParser
            parsed=BytesParser(policy=policy.default).parsebytes(srv.messages[0]);self.assertEqual(parsed['To'],'first@example.com');self.assertEqual(parsed['Subject'],'Oferta — test');self.assertIn('Dzień dobry',parsed.get_content());self.assertIsNone(parsed['Bcc'])
        finally:srv.shutdown();th.join();srv.server_close()
    def test_27_real_tls_socket_accepts_single_message(self):self.run_smtp()
    def test_28_real_starttls_socket_accepts_single_message(self):self.run_smtp(implicit=False)
    def test_29_disconnect_after_data_is_uncertain(self):self.run_smtp(drop=True)
    def test_30_auth_failure_is_safe_to_retry_and_secret_not_exposed(self):
        with patch('server.mailer.smtplib.SMTP_SSL',side_effect=smtplib.SMTPAuthenticationError(535,CONFIG['password'].encode())):
            with self.assertRaises(DeliveryError) as cm:SMTPTransport().send(CONFIG,{})
            self.assertEqual(cm.exception.status,'failed');self.assertNotIn(CONFIG['password'],str(cm.exception))

if __name__=='__main__':unittest.main(verbosity=2)
