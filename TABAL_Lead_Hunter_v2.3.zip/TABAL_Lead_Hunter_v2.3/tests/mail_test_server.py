"""Integration test server: all delivery is captured in memory, never external SMTP."""
import sys
import tempfile
import threading
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from serve import make_handler, ThreadingHTTPServer
from server.mailer import Outbox
class Capture:
    def send(self,config,job):
        pass
with tempfile.TemporaryDirectory() as temp:
    outbox=Outbox(Path(temp)/'mail.db',Capture())
    server=ThreadingHTTPServer(('127.0.0.1',0),make_handler(outbox,'integration-test-token'))
    worker=threading.Thread(target=outbox.work,daemon=True);worker.start()
    print(server.server_port,flush=True)
    try:server.serve_forever()
    finally:outbox.stop.set();worker.join();server.server_close();outbox.close()
