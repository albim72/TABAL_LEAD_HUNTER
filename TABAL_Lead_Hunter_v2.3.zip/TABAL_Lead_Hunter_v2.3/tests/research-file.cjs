/* Validate a real Work file through the built UI. This does not verify research facts. */
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {JSDOM,VirtualConsole}=require(process.env.LH_JSDOM_ROOT||'jsdom');
const root=path.resolve(__dirname,'..'),C=require('../src/core.js');
const input=process.argv[2];if(!input)throw Error('Podaj ścieżkę do pliku JSON z Work.');
const raw=fs.readFileSync(input,'utf8'),x=C.parse(raw),validation=C.merge(C.makeState(),Array.isArray(x)?x:x.leads,C.makeState().strategies.find(s=>s.id===x.strategy_id)||C.makeState().strategies[0]);
assert.equal(validation.errors.length,0,'Błędy walidacji: '+JSON.stringify(validation.errors));
const errors=[],vc=new VirtualConsole();vc.on('jsdomError',e=>errors.push(e.message));
const dom=new JSDOM(fs.readFileSync(path.join(root,'START.html'),'utf8'),{url:'https://tabal-import.test/',runScripts:'dangerously',virtualConsole:vc,beforeParse(w){w.TextEncoder=TextEncoder;w.Blob=Blob;w.HTMLDialogElement.prototype.close=function(){this.open=false;};}});
try{
 const w=dom.window,d=w.document;d.querySelector('[data-page=discover]').click();d.querySelector('.paste-option').open=true;const t=d.querySelector('#json-text');t.value=raw;t.dispatchEvent(new w.Event('input'));d.querySelector('#json-form').requestSubmit();
 assert.ok(d.querySelector('[data-action=import-confirm]'),'Brak poprawnego podglądu: '+d.querySelector('#import-result').textContent);
 assert.equal(w.localStorage.length,0,'Podgląd nie powinien zapisywać bazy');d.querySelector('[data-action=import-confirm]').click();
 const s=JSON.parse(w.localStorage.getItem('tabal-lead-hunter-v2-pilot')).state;assert.equal(s.leads.length,validation.added);assert.deepEqual(C.restore(C.backup(s),'pilot'),s);
 d.querySelector('[data-action=go-leads]').click();assert.equal(d.querySelectorAll('.lead-row').length,validation.added);assert.deepEqual(errors,[]);
 const report={date:new Date().toISOString(),file_name:path.basename(input),status:'PASS',leads:validation.added,errors:validation.errors,checks:['parse','preview without writes','explicit save','lead list','backup round trip'],limitation:'Import i struktura danych sprawdzone; prawdziwość researchu i źródeł nie była weryfikowana.'};
 fs.writeFileSync(path.join(root,'test-results/work-file-results.json'),JSON.stringify(report,null,2));console.log(JSON.stringify(report));
}finally{dom.window.close();}
