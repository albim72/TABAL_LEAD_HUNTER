@echo off
cd /d "%~dp0"
where py >nul 2>&1
if not errorlevel 1 (
  py -3 serve.py
) else (
  python serve.py
)
echo.
echo Jesli nie znaleziono Pythona, zainstaluj Python 3.10 lub nowszy z python.org.
pause
