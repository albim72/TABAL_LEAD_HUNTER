> Aktualizacja v2.3: na późniejsze życzenie użytkownika dodano lokalny moduł SMTP zatwierdzonej kolejki. Opisy ręcznej wysyłki poniżej dotyczą wcześniejszego zakresu v2/v2.2. Uruchomienie, ograniczenia i kopie kolejki opisuje README.md. Koszty własnej skrzynki i jej limity zależą od operatora; moduł nie używa płatnego API ani tokenów modelu do wysyłki.

# TABAL Lead Hunter v2.2 — przegląd i zmiany

21.09.2026 · wersja aplikacji 2.2.0 · schemat danych nadal 2

## Wnioski

Podstawowy zakres 12 wymagań TABAL jest obecny w v2. Na podstawie problemu z importem i ponownego przeglądu kodu priorytetem v2.2 jest niezawodny import oraz zachowanie historii handlowca.

| Problem wykryty w v2 | Zmiana w v2.2 |
| --- | --- |
| Łatwo pomylić wybór pliku z importem pustego pola | Przycisk wyboru pliku jako główna ścieżka, tekst w rozwijanej sekcji, konkretny komunikat pustego pola |
| Import zapisuje bazę od razu | Podgląd pliku, liczby nowych/duplikatów/błędów, jawny zapis i anulowanie |
| Błędy częściowego importu trudno przekazać do poprawienia | Raport JSON z numerem wiersza, nazwą firmy i powodem; raport w historii zadań także po odświeżeniu |
| Zmiana danych podczas podglądu mogłaby nadpisać nowszą pracę | Porównanie bieżącego stanu i ponowne przeliczenie przed zapisem |
| Odczyt asynchroniczny mógł zakończyć się po zmianie zbioru | Odrzucenie nieaktualnego wyniku odczytu; zapasowy odczyt FileReader |
| Wiadomość Work bywa kopiowana jako blok kodu | Obsługa pojedynczego bloku JSON i BOM; brak zgadywania lub naprawiania uszkodzonych danych |
| Kilka NIP używa wspólnej domeny | Dokładny NIP ma pierwszeństwo; niejednoznaczna domena trafia do błędów zamiast automatycznego scalenia |
| Nieuzupełniony NIP zwiększa ryzyko kolejnego błędnego scalenia | Uzupełnienie brakującego NIP z kolejnego researchu z wpisem do historii |
| Osoba bez kanału zasłania kontakt ogólny w podsumowaniu i CSV | Pierwszeństwo użytecznego kontaktu, w jego ramach pierwszeństwo osoby; wszystkie kontakty pozostają na karcie |
| Brak szybkiej listy pracy do wykonania | Filtr spełniających kryteria, brak kontaktu, brak feedbacku oraz blokada kontaktu |
| Niejasne przenoszenie danych między wersjami | Instrukcja aktualizacji i pobranie kopii bieżącej sesji przed przywróceniem |

Nie zmieniono ręcznie ustawianych statusów ani wag scoringu. Poprawa wyboru kontaktu może usunąć ostrzeżenie o braku kanału tam, gdzie poprawny kanał ogólny już był w danych. NIP i dowody pochodzą z researchu, nadal wymagają kontroli merytorycznej. Deduplikacja po domenie przy pojedynczym dopasowaniu pozostaje heurystyką — firma bez NIP może wymagać ręcznej weryfikacji.

## Odbiór wersji na komputerze użytkownika

1. Pobrać kopię pracy w starej wersji i uruchomić START.html z nowej paczki.
2. Przywrócić kopię w tym samym zbiorze, sprawdzić status i notatkę wybranej firmy.
3. W Odkrywanie wybrać plik Work, sprawdzić nazwę pliku i podgląd; baza nie powinna zmienić się przed zatwierdzeniem.
4. Zatwierdzić zapis, otworzyć Leady, sprawdzić wynik oraz źródła.
5. Ponownie wskazać ten sam plik: powinny pojawić się duplikaty, bez resetowania historii.
6. Pobrać kopię, raport importu i CSV; sprawdzić pliki w Pobranych.

Wyniki automatyczne i ograniczenia opisuje RAPORT_TESTOW.md. Nie wykonano nowego researchu ani pełnej sesji w rzeczywistym Firefoxie/Chromium.

## Kolejne iteracje po pilotażu

- Kalibracja wag i wykluczeń na podstawie rzeczywistych ocen handlowców i odpowiedzi klientów; obecna aplikacja już umożliwia ręczną zmianę wag.
- Raport konwersji według daty pozyskania, produktu i regionu, gdy powstanie wystarczająca historia kontaktów.
- Wspólna baza, konta i przypisywanie opiekuna — osobne wdrożenie serwerowe, jeśli narzędzie ma obsługiwać wielu handlowców jednocześnie.
- Integracja researchu i cykliczności z kontrolą kosztów i dziennikiem wykonań. Dzisiejszy etap nadal korzysta z ręcznego Work i importu.

Nie uruchomiono automatycznej wysyłki, API ani płatnych integracji.
