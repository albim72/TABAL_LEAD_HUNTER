# Model danych i import v2

## Plik z Work

```json
{
  "schema_version": 2,
  "strategy_id": "panels",
  "run_id": "ID_Z_ZADANIA",
  "research_notes": "Zasięg, zapytania i ograniczenia badania",
  "leads": []
}
```

- `strategy_id` wskazuje istniejącą strategię; dla importu bez tego pola użytkownik wybiera profil w panelu.
- `run_id` wiąże odpowiedź z konkretnym przygotowanym zadaniem. Cykl zachowuje kopię profilu z chwili utworzenia, nawet gdy strategię później zmieniono.
- Nie należy modyfikować identyfikatorów wygenerowanych w zadaniu Work.
- `leads` może być puste przy braku wyników lub braku dostępu do źródeł. Nie należy wymyślać wyników.
- Panel nie przyjmuje kopii zapasowej w polu importu researchu. Użyj przywracania kopii.

## Pojedyncza firma

| Pole | Znaczenie |
|---|---|
| `company` | Nazwa firmy, wymagana |
| `domain` | Domena firmowa; normalizacja usuwa www i ścieżkę |
| `nip` | Opcjonalne 10 cyfr; wymagane, gdy brak domeny. Walidacja formatu, bez weryfikacji w rejestrze |
| `region` | Lokalizacja firmy / obszar działalności |
| `context` | Udokumentowane fakty i uzasadnienie potencjału |
| `is_demo` | `false` dla prawdziwego researchu, `true` dla demonstracji |
| `sources` | 1–30 źródeł |
| `contacts` | 0–30 kontaktów; pusta tablica gdy nie ustalono danych |
| `criteria` | Oceny kryteriów według profilu |
| `draft` | Opcjonalne `{subject, body}` — propozycja wiadomości z researchu |

Źródło:

```json
{
  "url": "https://firma.pl/oferta",
  "title": "Oferta firmy",
  "quote": "Dokładny fragment, nie wymyślony opis",
  "checked_at": "2026-09-20",
  "verified": true
}
```

`verified=true` znaczy, że źródło faktycznie otwarto i sprawdzono w researchu lub ręcznej kontroli. Daty muszą być prawidłowe i nie mogą leżeć w przyszłości. Panel nie wykonuje zdalnego sprawdzenia strony.

Kontakt:

```json
{
  "type": "person",
  "name": "",
  "role": "",
  "reason": "",
  "email": "",
  "phone": "",
  "url": "",
  "quote": "",
  "checked_at": "",
  "verified": false
}
```

To struktura do uzupełnienia rzeczywistymi danymi; jeśli nie ustalono niczego, użyj `contacts: []`. `type` przyjmuje `person` albo `general`. Nie zgaduj adresu e-mail z imienia i domeny. Wszystkie potwierdzane dane osobowe i kanały muszą występować w cytacie źródła, a powód właściwości kontaktu powinien wynikać z jego funkcji.

`criteria` zawiera klucze `product`, `segment`, `client`, `region`, `extra`, `exclusion`. Każdy ma strukturę:

```json
{
  "value": "unknown",
  "evidence": "",
  "url": ""
}
```

`value` to `yes`, `no` lub `unknown`. URL powinien być identyczny z URL źródła w `sources`. Wykluczenie: `yes` oznacza, że firma spełnia warunek wykluczający; `no` oznacza potwierdzony brak wykluczenia. Gdy jest kilka warunków dodatkowych, `yes` wolno nadać dopiero po potwierdzeniu wszystkich; uzasadnienie powinno omówić każdy. Dla kilku wykluczeń `yes` wystarcza dla jednego potwierdzonego wykluczenia; `no` wymaga wyjaśnienia wszystkich.

## Deduplikacja

1. Jeżeli oba rekordy mają NIP, porównujemy NIP. Różne NIP nie są automatycznie scalane mimo tej samej domeny.
2. W przeciwnym razie porównujemy znormalizowane domeny.
3. Nazwa lub projekt nie są samodzielnym kluczem. Firma może mieć wiele projektów.

Ponowny import dopisuje `sightings`, `last_seen` i wpis w `history`. Nie nadpisuje bieżących źródeł, kryteriów, notatek, szkicu, feedbacku ani statusu. Karta pozwala ręcznie przyjąć nowy research do scoringu, zachowując poprzedni w historii.

Ograniczenie: firmy bez NIP, które zmieniły domenę, mogą wymagać ręcznego rozpoznania. Marki współdzielące domenę bez podanych NIP mogą zostać potraktowane jako jeden podmiot. Dla grup kapitałowych podawaj NIP.

## Stan aplikacji

`state` zawiera: `schema_version`, `mode`, `products`, `strategies`, `config`, `leads`, `runs`, `cycles`, `audit`, `created_at`, `updated_at`. Każdy lead ma także `profile` z historycznymi kryteriami, `product_name`, status, feedback, notatki, blokadę kontaktu, daty, `milestones`, `history`, `sightings` i szkic.

Pełna kopia:

```json
{
  "kind": "tabal-lead-hunter-backup",
  "schema_version": 2,
  "exported_at": "...",
  "state": {}
}
```

Eksport profilu ma `kind: tabal-profile` i zawiera tylko produkty, strategie, konfigurację i historię zmian konfiguracji. Nie obejmuje kontaktów, leadów ani wykonanych cykli; do tego służy pełna kopia.

Migracja v1 zachowuje oryginalny obiekt w `legacy_backup`. Historyczne QUALIFIED / ENRICHED przechodzą w DO WERYFIKACJI, ponieważ kryteria kwalifikacji v2 są inne. CONTACTED / REPLIED / OPPORTUNITY pozostają odpowiednimi etapami handlowymi. Dawny negatywny feedback jest zachowywany jako ocena jakości; sam w sobie nie jest dowodem ręcznie ustawionego statusu ODRZUCONY.

## Zasady techniczne

Wartości wyświetlane w HTML są escapowane. Linki dopuszczają tylko HTTP/HTTPS bez wbudowanych danych logowania. W CSV neutralizowane są początki formuł. Zewnętrzne źródła otwierają się w nowej karcie z `noopener noreferrer`. Nie ma automatycznych żądań sieciowych, wbudowanych kluczy API ani bibliotek ładowanych z CDN.

LocalStorage i JSON są zapisem pilota, nie zabezpieczonym przed zmianą audytem. Nie ma autoryzacji wieloużytkownikowej, kontroli uprawnień ani synchronizacji bazy.

## Uzupełnienia v2.2

Schemat danych pozostaje w wersji 2. Import ma etap podglądu bez modyfikacji stanu. Zapis wymaga zatwierdzenia aktualnego podglądu. Pole `runs[].imports[]` zawiera dodatkowo `file_name`, `errors_detail` (row, company, error) oraz `duplicates_detail`. Pełna kopia przenosi raporty importów. Nieznany wcześniej `run_id` z wyniku jest zachowywany w historii. Pliki bez run_id tworzą nowy wpis. Pusta lista leads może zakończyć cykl bez dodania firm.

Parser akceptuje BOM i jeden pełny blok kodu JSON. Nie próbuje odzyskiwać fragmentów z opisu, HTML, tabeli CSV ani niedomkniętego JSON.

## Wysyłka v2.3

Pole `leads[].mail_events[]` zawiera id zadania, to, subject, sent_at, message_id. Jest przenoszone Kopią JSON i zapobiega ponownej wysyłce początkowej na ten sam adres. Etap CONTACTED zapisywany jest dopiero dla statusu sent z lokalnego serwera. Statusy failed/uncertain nie dopisują kontaktu. SQLite ma odrębny trwały rejestr jobs; hasło pozostaje wyłącznie w pamięci.
