> Aktualizacja v2.3: na późniejsze życzenie użytkownika dodano lokalny moduł SMTP zatwierdzonej kolejki. Opisy ręcznej wysyłki poniżej dotyczą wcześniejszego zakresu v2/v2.2. Uruchomienie, ograniczenia i kopie kolejki opisuje README.md. Koszty własnej skrzynki i jej limity zależą od operatora; moduł nie używa płatnego API ani tokenów modelu do wysyłki.

# ChatGPT, koszty i dalsza automatyzacja

Stan dokumentacji sprawdzony 20.09.2026. Poniższe rozróżnia wymagania panelu od usługi researchu.

## Plan dla pilota

**Sam START.html: nie wymaga konta ChatGPT ani klucza API.** Można ręcznie wprowadzać i importować zweryfikowane dane.

**Dla uzgodnionego przepływu ChatGPT Work w przeglądarce: plan startowy ChatGPT Plus dla operatora.** Oficjalna tabela wskazuje Work na desktopie, w przeglądarce i na urządzeniach mobilnych w Plus; Free i Go opisuje jako dostęp ograniczony w aplikacji desktopowej. Jest to wybór wdrożeniowy dla pilota, nie twierdzenie, że każdy inny wariant jest technicznie niemożliwy. [Dostępność funkcji i plany](https://chatgpt.com/pricing/).

Oficjalna dokumentacja podaje cenę Plus 20 USD/miesiąc. Końcowa kwota, waluta i podatki są widoczne przy zakupie na danym koncie. API nie jest wliczone w subskrypcję Plus i ma oddzielne rozliczenie. [ChatGPT Plus](https://help.openai.com/en/articles/6950777-what-is-chatgpt-plus).

Nie jest wymagana konkretna numerowana wersja aplikacji ChatGPT ani jedno wskazane oznaczenie modelu. Potrzebne funkcje operatora: Work, wyszukiwanie publiczne, odczyt stron i możliwość zwrócenia kompletnego JSON lub pliku. Dostępność narzędzi trzeba sprawdzić w środowisku użytym do pilota. Brak narzędzia wyszukiwania ma skutkować pustym wynikiem z opisem ograniczenia, nie fikcyjnymi leadami.

Dla większego zespołu można osobno dobrać plan firmowy i zasady zarządzania kontami. Zmiana planu ChatGPT sama nie dodaje współdzielonej bazy do lokalnego Lead Huntera. Nie ma obowiązku zakupu planu Pro dla uruchomienia tej paczki.

## Składniki kosztów

| Element | W tej wersji |
|---|---|
| Uruchomienie panelu | Brak dodatkowych opłat usługowych generowanych przez kod panelu; warunki wynagrodzenia za projekt pozostają poza tą instrukcją |
| Subskrypcja ChatGPT | Koszt konta operatora według jego planu |
| Limity Work | Obowiązują limity planu; nie gwarantujemy liczby badań za stałą opłatę |
| Dodatkowe kredyty Work | Możliwe po przekroczeniu limitów, zależnie od konta i planu; decyzja użytkownika |
| Tokeny API OpenAI | Panel nie wywołuje API, nie wymaga klucza i nie generuje rachunku API |
| Płatna wyszukiwarka / baza firm | Nie jest wymagana do ręcznego przepływu MVP |
| Hosting, CRM, wysyłka | Brak wymaganych usług w paczce lokalnej |

Work może korzystać z płatnych kredytów poza zakresem planu. W Plus/Pro część funkcji agentowych może współdzielić pulę wykorzystania. Dostępność zakupu kredytów i kwoty są zależne od konta; kredyty Work nie są kredytami API. [Kredyty i limity Work](https://help.openai.com/en/articles/12642688-using-credits-for-flexible-usage-in-chatgpt-free-go-plus-pro-sora).

Nie da się rzetelnie określić kosztu jednej znalezionej lub zaakceptowanej firmy przed pomiarem długości researchu, użytego modelu i liczby zaakceptowanych wyników. Pierwszy cykl powinien zapisać: czas operatora, zużycie widoczne na koncie, liczbę nowych firm, liczbę dobrych leadów i dalsze kontakty.

## Kierunek dalszej automatyzacji

1. **Obecnie:** zapis strategii i terminów w panelu, ręczne wykonanie w Work, import JSON, deduplikacja i ocena.
2. **Następny etap:** wspólna baza z kontami operatorów, uprawnieniami i wersjonowaniem danych; serwerowy harmonogram i kolejka zadań z identyfikatorem cyklu.
3. **Research automatyczny:** zatwierdzony dostawca wyszukiwania, model/API, pobieranie źródeł i walidacja struktury, ponawianie błędów, limit kosztu na cykl. Klucze wyłącznie po stronie serwera.
4. **Kontrola handlowa:** kolejka firm do weryfikacji, decyzja o przyjęciu ponownego researchu, budżet jakości i rejestr zmian. Utrzymanie deduplikacji NIP/domena.
5. **Integracje:** import/eksport i ewentualne połączenie CRM. Wysyłkę automatyczną rozpatrywać oddzielnie od tego MVP.

Automatyzacja będzie miała odrębne koszty modelu, narzędzi wyszukiwania, infrastruktury i utrzymania. Ta paczka nie instaluje harmonogramu ani nie aktywuje płatnych usług. Terminy w strategiach są lokalnym planem pracy, nie aktywnymi zadaniami wykonawczymi.
