> Aktualizacja v2.3: na późniejsze życzenie użytkownika dodano lokalny moduł SMTP zatwierdzonej kolejki. Opisy ręcznej wysyłki poniżej dotyczą wcześniejszego zakresu v2/v2.2. Uruchomienie, ograniczenia i kopie kolejki opisuje README.md. Koszty własnej skrzynki i jej limity zależą od operatora; moduł nie używa płatnego API ani tokenów modelu do wysyłki.

# Realizacja maila TABAL z 17.09.2026

| Nr | Wymaganie | Realizacja v2 | Gdzie / granice |
|---|---|---|---|
| 1 | Otwarte wyszukiwanie | Dwa tryby: otwarte odkrywanie i wskazane firmy. Zadanie zawiera profil, wykluczenia, listę znanych firm i kontrakt JSON. | Odkrywanie. Research wykonuje Work; import pozostaje ręczny zgodnie z pkt 11 maila. |
| 2 | Własne segmenty | Dowolna liczba strategii z łańcuchem produkt → segment → klient → region → kryteria → wykluczenia. | Strategie oraz Profil i źródła → Segmenty. |
| 3 | Grupy produktowe | Ogrodzenia panelowe, ogrodzenia aluminiowe, profile konstrukcyjne, balustrady. Dodawanie i edycja własnych grup. | Profil i źródła → Produkty. Usuwanie produktu użytego historycznie jest blokowane. |
| 4 | Jawna kwalifikacja i scoring | Składowe, maksima, dowody, kary i powody wstrzymania na karcie; edytowalne wagi, próg i aktualność. | Karta firmy; Profil i źródła → Scoring i źródła; SCORING.md. |
| 5 | Osoba decyzyjna | Kontakty osobowe i ogólne, funkcja, uzasadnienie, e-mail, telefon, URL, cytat i data. Priorytet osoby. | Zadanie Work, karta firmy, edycja danych. Nieznane dane pozostają puste. |
| 6 | Naturalne wiadomości | Zadanie Work wymaga tekstu opartego na faktach; import zachowuje draft. Edytor, kopiowanie, TXT. Lokalny wariant korzysta z cytatu. | Karta firmy. Wariant lokalny jest regułowy; wysyłka wyłącznie ręczna. |
| 7 | Statusy i odrzucenia | NOWY, DO WERYFIKACJI, ZAAKCEPTOWANY, DO KONTAKTU, SKONTAKTOWANY, ODPOWIEDŹ, ZAINTERESOWANY, SZANSA SPRZEDAŻOWA, ODRZUCONY. Powód, data i kanał. | Karta firmy, lista i filtry. Każda zmiana zapisuje historię. |
| 8 | Feedback jakości | Dobry/zły lead z wymaganym uzasadnieniem. Raport ocen i średnich scoringów. | Karta i Raport pilota; kalibracja ręczna. |
| 9 | Deduplikacja i historia | NIP ma pierwszeństwo, przy braku NIP domena bez www. Zachowane statusy, blokady, feedback i notatki. Nowy research w historii. | Import i karta firmy. Różne NIP na tej samej domenie pozostają odrębnymi firmami. Bez NIP zmiana domeny może wymagać ręcznej identyfikacji duplikatu. |
| 10 | Zapis profili | Zapis/edycja/kopia strategii. Eksport/import profilu z historią konfiguracji. Pełna kopia JSON z firmami i całą historią. | Strategie; Profil i źródła → Dane i kopie. |
| 11 | Cykliczność | Interwały 7/14/30 dni, następny termin, sygnalizacja terminu, zapis zadania i importu. Termin aktualizowany po poprawnym imporcie przypisanym do cyklu. | Strategie i Odkrywanie. Nie ma automatycznego wykonania w tle. Kierunek automatyzacji opisano w PLAN_I_KOSZTY.md. |
| 12 | Pomiar skuteczności | Lejek historycznie zapisanych etapów, aktualne statusy, konwersje z jawnymi mianownikami, wyniki według strategii, feedback, czas pracy i raport. | Raport pilota. Pominięty etap nie jest automatycznie dopisywany. |

## Dodatkowe usprawnienia

- Pełna migracja kopii v1: oryginał zostaje wewnątrz kopii v2 jako `legacy_backup`.
- Oddzielne zbiory DEMO, próbka historyczna i pilot.
- Ochrona przed przypadkowym importem DEMO do pilota.
- Walidacja JSON, błędy wierszy, zabezpieczenie wyświetlania HTML i formuł w CSV.
- Rejestrowanie ponownego odkrycia oraz świadome przyjęcie nowego researchu do scoringu.
- Ostrzeżenie przy niedostępnym zapisie lub zmianie danych z innej karty.

## Co wymaga potwierdzenia w pilocie biznesowym

Wagi są konfiguracją startową do wspólnej kalibracji, a nie zasadami już zaakceptowanymi przez TABAL. Demo nie dowodzi skuteczności wyszukiwania ani konwersji. Przed pierwszym cyklem potwierdź segment i wykluczenia, a po nim sprawdź źródła na rzeczywistych kartach. Paczka nie obejmuje pracy wielu użytkowników na wspólnej bazie ani hostingu produkcyjnego.
