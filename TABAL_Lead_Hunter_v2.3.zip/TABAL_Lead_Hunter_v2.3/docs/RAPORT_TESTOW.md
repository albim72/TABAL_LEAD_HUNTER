# Raport testów TABAL Lead Hunter v2.3

Data testów integracji: 2026-09-21T21:04:00.510Z

**51 logiki + 42 DOM + 31 serwera/SMTP + 10 panelu z API = 134 zaliczonych testów.**

## Co rzeczywiście uruchomiono

- Node.js / node:test: scoring, deduplikacja, kopie, migracja, kwalifikacja do wysyłki i jednokrotny zapis potwierdzeń.
- jsdom: zbudowany START.html, formularze, import, eksport, statusy i historie (starsze funkcje).
- Python unittest: lokalna kolejka SQLite, walidacja, restart procesu, utrata połączenia z panelem, pauza, odstępy, blokowanie duplikatów, anulowanie, ponowienie jednoznacznego błędu, blokowanie niepewnego wyniku, ochrona hasła oraz lokalnego API.
- Rzeczywiste gniazda SMTP na 127.0.0.1: SSL/TLS, STARTTLS i rozłączenie po DATA. Użyto tymczasowego testowego certyfikatu z walidacją i lokalnego odbiornika. Zewnętrzna poczta nie była używana.
- jsdom → rzeczywiste lokalne HTTP API → SQLite → transport przechwytujący: konfiguracja z formularza, dodanie partii, jawne uruchomienie, potwierdzenie SMTP i status CONTACTED, blokada kontaktu, eksport historii i odseparowanie DEMO.
- Plik Work leady_work_v2(2).json: podgląd, zapis 17 firm i odtworzenie kopii. Nie weryfikowano ponownie prawdziwości researchu.

## Granice wyniku

Nie skonfigurowano rzeczywistej skrzynki TABAL i nie wysłano wiadomości do realnych firm. Nie sprawdzono dostarczalności, folderu spam, limitów operatora, OAuth ani odbioru odpowiedzi. Automatyczny status oznacza przyjęcie przez SMTP, nie potwierdzenie doręczenia.

Nie wykonano pełnej sesji w rzeczywistym Firefoxie/Chromium ani uruchomienia BAT na fizycznym Windows. Testy jsdom sprawdzają działanie kodu i formularzy, nie renderowanie. Przy wcześniejszej wersji środowisko blokowało lokalny podgląd; nie obchodzono tych ograniczeń. Przed pierwszą partią użyj w module przycisku testu na własną skrzynkę.

## Dowody

- test-results/core-results.tap
- test-results/dom-results.json
- test-results/smtp-tests.txt
- test-results/mail-dom-results.json
- test-results/work-file-results.json

## Odtworzenie

Polecenia znajdują się w README.md. Testy serwera używają wyłącznie danych fikcyjnych i lokalnych odbiorników. OpenSSL jest potrzebny tylko do wygenerowania certyfikatu w testach, nie do uruchamiania modułu.
