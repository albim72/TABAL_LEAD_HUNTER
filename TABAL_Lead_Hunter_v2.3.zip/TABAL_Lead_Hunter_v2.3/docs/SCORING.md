# Zasady kwalifikacji i punktowania v2

## Założenie

Scoring ocenia **dopasowanie firmy do profilu**, a nie prawdopodobieństwo zakupu. Obecność produktu w ofercie może wskazywać potencjalnego partnera, lecz nie stanowi dowodu aktualnego zamówienia. Ten model zastępuje scoring v1 skoncentrowany na inwestycji i sygnale budowlanym.

## Domyślne wagi

| Kryterium | Maksimum | Jak otrzymuje punkty |
|---|---:|---|
| Produkt | 25 | Potwierdzona zgodność z grupą produktową i dowód |
| Segment / rynek | 15 | Potwierdzone działanie na wybranym rynku |
| Typ klienta | 15 | Potwierdzony profil, np. dystrybutor lub monter |
| Region | 10 | Potwierdzona zgodność z wybranym obszarem |
| Dodatkowe kryteria | 15 | Spełnione wszystkie dodatkowe warunki; jeśli nie zdefiniowano warunków, pełne punkty |
| Jakość i aktualność źródła | 10 | Co najmniej jedno sprawdzone źródło z URL, cytatem i datą |
| Właściwy kontakt | 10 | Osoba z funkcją, uzasadnieniem i kanałem; kontakt ogólny daje 5 punktów |
| **Suma** | **100** | Wynik zaokrąglony do liczby całkowitej |

Przy zmianie wag ich suma jest normalizowana do 100:

`wkład kryterium = waga / suma wag × 100 × stopień spełnienia`

Stopień spełnienia to 0 lub 1, a dla kontaktu także 0,5. Wszystkie wagi nie mogą równocześnie wynosić zero. Ustawienie wagi kryterium na zero nie usuwa jego obowiązku kwalifikacyjnego.

## Dowody i braki danych

Każde kryterium ma `yes`, `no` albo `unknown`, uzasadnienie oraz URL obecny na liście źródeł leada. Dodatnie punkty wymagają wyniku `yes`, niepustego uzasadnienia i źródła oznaczonego jako sprawdzone, z cytatem i datą mieszczącą się w limicie aktualności. Panel sprawdza strukturę i daty, nie rozumie samodzielnie treści dowodu. Weryfikacja merytoryczna pozostaje częścią researchu i kontroli handlowca.

Brak dowodu daje 0 za kryterium i powód wstrzymania. Domyślna aktualność źródła to 90 dni od sprawdzenia; kontaktu — 60 dni. To data odczytu, nie data publikacji. Nie należy automatycznie nadawać dzisiejszej daty dawnym ustaleniom.

## Kary i blokady

| Zdarzenie | Kara domyślna | Skutek |
|---|---:|---|
| Potwierdzone spełnienie kryterium wykluczającego | −60 | Blokada kwalifikacji niezależnie od sumy |
| Brak aktualnego sprawdzonego źródła | −15 | Blokada kwalifikacji |
| Nie ustalono wykluczenia | 0 | Wymagana weryfikacja; brak automatycznej akceptacji |
| Domena własna / z listy wykluczeń | 0 | Blokada kwalifikacji |
| „Nie kontaktować” lub status ODRZUCONY | 0 | Blokada kwalifikacji |

Wynik końcowy jest ograniczony do 0–100. Niski wynik sam w sobie nie ustawia statusu ODRZUCONY.

Dla `exclusion` semantyka jest odwrócona względem dopasowania: `yes` oznacza spełnione wykluczenie, `no` — potwierdzony brak wykluczenia, `unknown` — brak rozstrzygnięcia. **Brak wzmianki o własnej produkcji nie dowodzi braku własnej produkcji.** Jeśli strategia nie definiuje wykluczeń, ten warunek nie obowiązuje.

## Kwalifikacja i decyzja handlowa

Domyślny próg: 65/100. Aby lead „spełniał kryteria”, musi także mieć potwierdzenie produktu, segmentu, klienta, regionu i dodatkowych warunków oraz brak blokad. Możliwy jest wynik 100 z adnotacją „Do weryfikacji”, gdy nie rozstrzygnięto wykluczeń.

Statusy sprzedażowe są ręczne. Handlowiec może odnotować rzeczywisty kontakt mimo słabego scoringu; aplikacja nie fałszuje historii, aby dopasować ją do oceny. Blokada „Nie kontaktować” zatrzymuje ustawienie nowych statusów DO KONTAKTU i SKONTAKTOWANY do czasu jej zdjęcia.

Feedback „dobry/zły” nie jest statusem i nie zmienia automatycznie wyniku. Jego rolą jest dostarczanie danych do świadomej kalibracji.

## Osoba i kanały kontaktowe

Osoba wymaga imienia i nazwiska, funkcji, uzasadnienia przydatności do celu sprzedaży i aktualnego potwierdzonego źródła. Nazwisko i funkcja muszą wystąpić w cytacie. E-mail i numer telefonu są uznawane za potwierdzone, gdy występują w cytacie; telefon jest porównywany po usunięciu znaków formatowania. Dane nie są zgadywane. Osoba ma priorytet prezentacji nad kontaktem ogólnym.

## Kalibracja po pilocie

1. Oceń 20–30 prawdziwych firm w jednej strategii; przy ocenach dodawaj konkretne powody.
2. Porównaj średni scoring dobrych i złych leadów, sprawdź fałszywe dopasowania i brakujące dowody.
3. Jeśli problem dotyczy rynku lub typu klienta, popraw profil. Jeśli proporcji sygnałów — wagi. Jeśli aktualności — limity dni.
4. Zmień jeden główny element i przeprowadź kolejny porównywalny cykl. Pobierz kopię przed zmianą.
5. Oceniaj również faktyczne odpowiedzi i szanse. Duża liczba firm sama nie potwierdza wartości procesu.

Historia konfiguracji zachowuje stare i nowe wagi. Wynik na karcie i w raporcie jest liczony z aktualnymi wagami; profil badania firmy pozostaje zapisany z chwili researchu. Nie jest to automatyczne uczenie modelu ani zabezpieczony audyt produkcyjny.

## Wybór kontaktu w v2.2

Do podsumowania i CSV wybierany jest kontakt z potwierdzonym kanałem: osoba ma pierwszeństwo przed kontaktem ogólnym. Jeśli znana osoba nie ma wiarygodnego kanału, a firma ma potwierdzony kontakt ogólny, używany jest kanał ogólny. Wszystkie osoby i źródła pozostają widoczne na karcie firmy. Wagi scoringu pozostają bez zmian.
