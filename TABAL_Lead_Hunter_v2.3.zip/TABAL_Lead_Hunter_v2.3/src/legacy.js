(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.LH = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const VERSION = '1.0.0';
  const STAGES = ['FOUND', 'QUALIFIED', 'ENRICHED', 'CONTACTED', 'REPLIED', 'OPPORTUNITY'];
  const SIGNALS = {rfq:'Zapytanie ofertowe', tender:'Przetarg', construction:'Rozpoczęcie budowy', expansion:'Rozbudowa', partnership:'Partnerstwo', lease:'Najem', completed:'Obiekt ukończony', other:'Inny sygnał'};
  const SEGMENTS = {industrial:'Inwestor przemysłowy / logistyczny', contractor:'Generalny wykonawca', residential:'Deweloper mieszkaniowy', public:'Sektor publiczny', reseller:'Dystrybutor / instalator', other:'Inny / brak danych'};
  const DEFAULT_CONFIG = {
    name:'Inwestycje przemysłowe w Polsce', country:'PL', regions:[], segments:['industrial','contractor'],
    product:'Techfence', threshold:65, max_age_days:90, contact_max_age_days:30,
    source_hosts:['panattonieurope.com','depenbrock.pl','ctp.eu','tabal.pl','ezamowienia.gov.pl'],
    excluded_domains:['tabal.pl'], icp_approved:false, contact_policy:false, sender:'Zespół TABAL',
  };
  const clone = x => JSON.parse(JSON.stringify(x));
  const clean = (x,max=5000) => typeof x === 'string' ? x.trim().slice(0,max) : '';
  const norm = x => clean(x).toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/ł/g,'l');
  const today = () => new Date().toISOString().slice(0,10);
  const timestamp = () => new Date().toISOString();
  function validDate(x) {
    return typeof x === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(x) && Number.isFinite(Date.parse(x)) && new Date(x).toISOString().slice(0,10) === x;
  }
  const age = (d,now=today()) => validDate(d) && validDate(now) ? Math.floor((Date.parse(now)-Date.parse(d))/86400000) : null;
  function safeUrl(x) {
    try { const u=new URL(clean(x)); return /^https?:$/.test(u.protocol) && !u.username && !u.password ? u.href : ''; } catch { return ''; }
  }
  function domain(x) {
    try { return new URL(/^https?:\/\//i.test(clean(x)) ? clean(x) : 'https://'+clean(x)).hostname.toLowerCase().replace(/^www\./,''); } catch { return ''; }
  }
  function allowed(url,hosts) {
    if (!safeUrl(url)) return false;
    const h=domain(url);
    return hosts.some(v => { const d=domain(v); return d && (h===d || h.endsWith('.'+d)); });
  }
  function config(input={}) {
    const c=clone(DEFAULT_CONFIG);
    for(const key of ['name','country','product','sender']) if(typeof input[key]==='string') c[key]=clean(input[key],200);
    for(const key of ['regions','segments','source_hosts','excluded_domains']) if(Array.isArray(input[key])) c[key]=[...new Set(input[key].map(x=>clean(x,150)).filter(Boolean))];
    for(const key of ['threshold','max_age_days','contact_max_age_days']) {
      if(input[key]!==undefined) {
        const n=Number(input[key]); const max=key==='threshold'?100:730;
        if(!Number.isInteger(n)||n<1||n>max) throw Error('Nieprawidłowe ustawienie: '+key);
        c[key]=n;
      }
    }
    if(!c.segments.length || c.segments.some(s=>!SEGMENTS[s])) throw Error('Wybierz prawidłowy segment ICP.');
    if(!['Techfence','Alufence'].includes(c.product)) throw Error('Nieznany produkt.');
    if(!c.source_hosts.length) throw Error('Lista dozwolonych domen nie może być pusta.');
    c.country=c.country.toUpperCase();
    c.icp_approved=input.icp_approved===true; c.contact_policy=input.contact_policy===true;
    return c;
  }
  function canonicalUrl(x) {
    const s=safeUrl(x); if(!s) return '';
    const u=new URL(s); u.hash='';
    for(const k of [...u.searchParams.keys()]) if(/^utm_|^(fbclid|gclid)$/i.test(k)) u.searchParams.delete(k);
    u.searchParams.sort(); u.hostname=u.hostname.replace(/^www\./,'');
    return u.href.replace(/\/$/,'');
  }
  function key(l) { return [domain(l.domain)||norm(l.company),norm(l.project).replace(/\s+/g,' ')].join('|'); }
  function sourceKey(l) { return [domain(l.domain)||norm(l.company),canonicalUrl(l.source_url),norm(l.project)].join('|'); }
  function id(l) {
    let n=2166136261; for(const c of key(l)){n^=c.charCodeAt(0);n=Math.imul(n,16777619);}
    return 'LH-'+(n>>>0).toString(16).toUpperCase().padStart(8,'0');
  }
  function validateLead(raw,now=today()) {
    if(!raw || typeof raw!=='object'||Array.isArray(raw)) throw Error('Lead musi być obiektem.');
    const l={};
    for(const k of ['company','domain','project','country','region','segment','signal_type','signal_date','detected_at','deadline','source_url','source_title','evidence','quote','product','product_basis','product_reason','context','enrichment_note']) l[k]=clean(raw[k]);
    if(!l.company||!l.project||!l.evidence) throw Error('Wymagane: company, project, evidence.');
    if(!safeUrl(l.source_url)) throw Error('Wymagany bezpieczny adres http/https źródła.');
    l.source_url=safeUrl(l.source_url); l.domain=domain(l.domain);
    if(!SIGNALS[l.signal_type]) throw Error('Nieznany signal_type.');
    if(!SEGMENTS[l.segment]) throw Error('Nieznany segment.');
    for(const k of ['signal_date','deadline','detected_at']) if(l[k]&&!validDate(l[k])) throw Error('Nieprawidłowa data: '+k);
    if(l.detected_at && age(l.detected_at,now)<0) throw Error('Data wykrycia nie może być przyszła.');
    l.detected_at=l.detected_at||now;
    l.country=l.country.toUpperCase();
    if(!['explicit','inferred','none'].includes(l.product_basis)) l.product_basis='none';
    l.source_verified=raw.source_verified===true;
    l.enrichment_attempted=raw.enrichment_attempted===true;
    l.is_demo=raw.is_demo===true;
    const contact=raw.contact&&typeof raw.contact==='object'?raw.contact:{};
    l.contact={};
    for(const k of ['name','role','email','phone','url','quote','verified_at','type']) l.contact[k]=clean(contact[k],2000);
    l.contact.reviewed=contact.reviewed===true;
    if(l.contact.email&&!/^[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+$/.test(l.contact.email)) throw Error('Nieprawidłowy e-mail.');
    if(l.contact.url&&!safeUrl(l.contact.url)) throw Error('Nieprawidłowy adres źródła kontaktu.');
    if(l.contact.verified_at&&!validDate(l.contact.verified_at)) throw Error('Nieprawidłowa data weryfikacji kontaktu.');
    l.id=id(l); l.status='FOUND'; l.feedback='pending'; l.feedback_note=''; l.notes='';
    l.do_not_contact=false; l.processed=false; l.history=[]; l.milestones={FOUND:timestamp()}; l.activities=[];
    return l;
  }
  function contacts(l,c=DEFAULT_CONFIG,now=today()) {
    const p=l.contact||{}; const a=age(p.verified_at,now);
    const base=p.reviewed===true&&allowed(p.url,c.source_hosts)&&a!==null&&a>=0&&a<=c.contact_max_age_days;
    const evidence=clean(p.quote).toLowerCase();
    const email=!!(base&&p.email&&evidence.includes(p.email.toLowerCase()));
    const digits=clean(p.phone).replace(/\D/g,'');
    const phone=!!(base&&digits.length>=7&&digits.length<=15&&evidence.replace(/\D/g,'').includes(digits));
    const person=!!(base&&p.name&&evidence.includes(p.name.toLowerCase()));
    const role=!!(person&&p.role&&evidence.includes(p.role.toLowerCase()));
    const useful=['general','procurement'].includes(p.type);
    return {email,phone,person,role,base,useful,reachable:useful&&(email||phone),
      status:!l.enrichment_attempted?'NOT_ATTEMPTED':person&&role&&(email||phone)?'COMPLETE':email||phone||person?'PARTIAL':'MISSING',
      warning:!base?'Źródło kontaktu wymaga sprawdzenia (domena, data lub potwierdzenie).':!useful?'Kontakt dotyczy PR / najmu lub ma nieustaloną rolę.':'Kontakt ogólny nie potwierdza osoby decyzyjnej.'};
  }
  function score(l,c=DEFAULT_CONFIG,now=today()) {
    const parts=[]; const blocks=[]; const warnings=[];
    const add=(label,points,max,reason)=>parts.push({label,points,max,reason});
    const fits=c.segments.includes(l.segment);
    add('Profil klienta',fits?25:0,25,fits?'Segment zgodny z profilem.':'Segment poza wybranym ICP.');
    if(!fits) blocks.push('Segment poza ICP');
    const geo=l.country===c.country&&(!c.regions.length||c.regions.map(norm).includes(norm(l.region)));
    add('Region',geo?10:0,10,geo?'Lokalizacja zgodna z profilem.':'Lokalizacja poza zakresem lub brak danych.');
    if(!geo) blocks.push('Lokalizacja poza zakresem lub brak danych');
    const intent={rfq:25,tender:25,construction:20,expansion:18,partnership:10,lease:3,completed:0,other:0}[l.signal_type]||0;
    add('Sygnał zakupowy',intent,25,SIGNALS[l.signal_type]||'Brak danych');
    if(['lease','completed','other'].includes(l.signal_type)) blocks.push('Brak aktualnego sygnału zakupu / budowy');
    const days=age(l.signal_date,now);
    const fresh=days!==null&&days>=0&&days<=c.max_age_days;
    add('Aktualność',fresh?(days<=30?15:days<=60?10:5):0,15,days===null?'Nieznana data publikacji.':days<0?'Data publikacji jest przyszła.':`Wiek sygnału: ${days} dni.`);
    if(!fresh) blocks.push(days===null?'Nieznana data publikacji':days<0?'Przyszła data publikacji':'Sygnał przeterminowany');
    if(l.deadline&&age(l.deadline,now)>0) blocks.push('Termin odpowiedzi minął');
    if(l.signal_type==='tender'&&!l.deadline) blocks.push('Nieznany termin przetargu');
    const product=l.product===c.product&&l.product_reason;
    add('Produkt',product?(l.product_basis==='explicit'?15:l.product_basis==='inferred'?7:0):0,15,product?l.product_reason:'Brak dopasowania produktu.');
    if(!product||l.product_basis==='none') blocks.push('Brak uzasadnienia produktu');
    if(l.product_basis==='inferred') warnings.push('Zapotrzebowanie na ogrodzenia jest hipotezą, nie potwierdzonym zamówieniem.');
    const source=l.source_verified&&allowed(l.source_url,c.source_hosts)&&!!l.evidence;
    add('Jakość dowodu',source?10:0,10,source?'Źródło oznaczone jako sprawdzone i znajduje się na liście domen.':'Źródło wymaga sprawdzenia lub dopuszczenia domeny.');
    if(!source) blocks.push('Niezweryfikowane źródło lub domena poza listą');
    if(!l.domain) blocks.push('Brak domeny firmy');
    if(c.excluded_domains.some(d=>domain(d)===l.domain)) blocks.push('Firma wykluczona / własna firma');
    if(l.do_not_contact) blocks.push('Nie kontaktować');
    if(l.feedback==='no') blocks.push('Lead odrzucony przez handlowca');
    const points=parts.reduce((a,p)=>a+p.points,0);
    const qualified=blocks.length===0&&points>=c.threshold;
    if(points<c.threshold) warnings.push('Wynik poniżej progu ICP.');
    const co=contacts(l,c,now);
    return {points,parts,blocks,warnings,qualified,contact:co,actionable:qualified&&co.reachable&&l.feedback==='yes',readiness:qualified?(co.reachable?'REVIEW':'ENRICH'):'HOLD'};
  }
  function log(l,action,note) { l.history.push({at:timestamp(),action,note:clean(note)}); }
  function processLead(l,c=DEFAULT_CONFIG,now=today()) {
    const out=clone(l); const s=score(out,c,now);
    out.processed=true;
    if(s.qualified) {
      out.milestones.QUALIFIED ||= timestamp();
      if(s.contact.reachable) out.milestones.ENRICHED ||= timestamp();
    }
    if(STAGES.indexOf(out.status)<3) out.status=s.qualified?(s.contact.reachable?'ENRICHED':'QUALIFIED'):'FOUND';
    log(out,'SCORE',`${s.points}/100; ${s.qualified?'ICP spełniony':s.blocks.join('; ')||'poniżej progu'}; enrichment ${s.contact.status}`);
    return out;
  }
  function draft(l,c=DEFAULT_CONFIG,now=today()) {
    const s=score(l,c,now);
    if(!s.qualified) return {subject:'',body:'',blocked:true,reason:s.blocks.join('; ')||'Wynik poniżej progu.'};
    return {blocked:false, subject:`${l.project} — zakres ogrodzeń i bram`,
      body:`Dzień dobry,\n\nzwracam się w związku z projektem ${l.project}. W publicznej informacji o inwestycji wskazano: ${l.evidence}\n\nW TABAL oferujemy ${c.product==='Techfence'?'systemy ogrodzeń panelowych Techfence oraz bramy':'systemy ogrodzeń aluminiowych Alufence wraz z bramami i furtkami'}. Chciałbym ustalić, czy zakres ogrodzenia i bram dla tej inwestycji jest jeszcze otwarty oraz kto koordynuje jego dobór. Jeżeli temat jest aktualny, możemy przygotować wstępne zestawienie rozwiązań na podstawie parametrów projektu.\n\nCzy mogą Państwo wskazać właściwą osobę lub dział?\n\nPozdrawiam\n${c.sender}\n\nŹródło kontekstu: ${l.source_url}`};
  }
  function feedback(l,value,note='') {
    if(!['yes','no','pending'].includes(value)) throw Error('Nieznana decyzja.');
    const out=clone(l);out.feedback=value;out.feedback_note=clean(note);log(out,'FEEDBACK',value+': '+out.feedback_note);return out;
  }
  function changeStage(l,next,activity,c=DEFAULT_CONFIG,now=today()) {
    activity=activity||{};
    const idx=STAGES.indexOf(l.status),target=STAGES.indexOf(next);
    if(target!==idx+1||target<3) throw Error('Kolejny status wymaga poprzedniego etapu. Uruchom ocenę dla FOUND / QUALIFIED.');
    const s=score(l,c,now);
    if(next==='CONTACTED') {
      if(!s.actionable||!c.icp_approved||!c.contact_policy) throw Error('Wymagane: kwalifikacja, kontakt ze źródłem, akceptacja leada, ICP i polityki kontaktu.');
      if(!['email','phone','other'].includes(activity.channel)) throw Error('Wybierz kanał kontaktu.');
      if(activity.channel==='email'&&!s.contact.email) throw Error('Brak potwierdzonego e-maila.');
      if(activity.channel==='phone'&&!s.contact.phone) throw Error('Brak potwierdzonego telefonu.');
    }
    if(l.do_not_contact) throw Error('Lead oznaczony jako nie kontaktować.');
    if(!activity||!validDate(activity.date)||age(activity.date,now)<0||!clean(activity.note)) throw Error('Podaj datę wykonanego działania i notatkę; data nie może być przyszła.');
    if(age(activity.date,l.detected_at)>0) throw Error('Działanie nie może poprzedzać wykrycia leada.');
    const last=l.activities.at(-1);
    if(last&&activity.date<last.date) throw Error('Data nie może poprzedzać poprzedniego działania.');
    const out=clone(l);out.status=next;out.milestones[next]=activity.date;
    out.activities.push({stage:next,date:activity.date,channel:clean(activity.channel),note:clean(activity.note),recorded_at:timestamp(),manual:true});
    log(out,'STATUS',`${l.status} → ${next}; wpis ręczny: ${activity.note}`);return out;
  }
  function merge(existing,rawLeads,mode='pilot',now=today()) {
    if(!Array.isArray(rawLeads)||rawLeads.length>1000) throw Error('Import wymaga tablicy leads (maks. 1000 rekordów).');
    const result=clone(existing), errors=[];let added=0,duplicates=0;
    const keys=new Set(existing.map(key)),sources=new Set(existing.map(sourceKey));
    rawLeads.forEach((raw,i)=>{
      try {
        const l=validateLead(raw,now);
        if(l.is_demo&&mode!=='demo') throw Error('Dane DEMO można importować tylko do zbioru DEMO.');
        if(!l.is_demo&&mode==='demo') throw Error('Rzeczywiste rekordy importuj do Pilota.');
        if(keys.has(key(l))||sources.has(sourceKey(l))) {duplicates++;return;}
        if(result.length>=1000) throw Error('Limit zbioru: 1000 rekordów. Zarchiwizuj sesję i rozpocznij nową.');
        // Collision guard: identifiers are deterministic but deduplication never relies on a short hash alone.
        while(result.some(x=>x.id===l.id)) l.id+='X';
        keys.add(key(l));sources.add(sourceKey(l));result.push(l);added++;
      } catch(e){errors.push({row:i+1,error:e.message});}
    });
    return {leads:result,added,duplicates,errors};
  }
  function parseImport(text) {
    let x;try{x=JSON.parse(text.replace(/^\uFEFF/,''));}catch{throw Error('Nieprawidłowy JSON. Użyj pliku wygenerowanego według kontraktu.');}
    if(x&&x.kind==='tabal-lead-hunter-backup') throw Error('To kopia zapasowa. Użyj przycisku Przywróć kopię.');
    if(x&&x.schema_version!==undefined&&x.schema_version!==1) throw Error('Nieobsługiwana wersja schematu.');
    const leads=Array.isArray(x)?x:x?.leads;
    if(!Array.isArray(leads)) throw Error('Plik musi zawierać tablicę leads.');
    return leads;
  }
  function metrics(leads,c=DEFAULT_CONFIG,now=today(),cycles=[]) {
    const assessed=leads.filter(l=>l.processed); const scores=leads.map(l=>score(l,c,now));
    const total=leads.length,qualified=leads.filter((l,i)=>l.processed&&scores[i].qualified).length;
    const reviewed=leads.filter(l=>l.feedback!=='pending').length;
    const accepted=leads.filter(l=>l.feedback==='yes').length;
    const contacted=leads.filter(l=>l.milestones.CONTACTED).length;
    const replied=leads.filter(l=>l.milestones.REPLIED).length;
    const opportunities=leads.filter(l=>l.milestones.OPPORTUNITY).length;
    const ratio=(a,b)=>b?Math.round(100*a/b):null;
    const businessCycles=cycles.filter(x=>x.kind==='research');
    return {total,assessed:assessed.length,qualified,reviewed,accepted,contacted,replied,opportunities,
      actionable:leads.filter((l,i)=>l.processed&&scores[i].actionable).length,
      qualification_rate:ratio(qualified,assessed.length),actionable_rate:ratio(accepted,reviewed),contact_rate:ratio(contacted,total),
      reply_rate:ratio(replied,contacted),opportunity_rate:ratio(opportunities,contacted),
      email_count:scores.filter(s=>s.contact.email).length,phone_count:scores.filter(s=>s.contact.phone).length,person_count:scores.filter(s=>s.contact.person).length,
      enrichment_rate:ratio(scores.filter(s=>s.contact.reachable).length,total),
      human_minutes:cycles.reduce((a,x)=>a+x.minutes,0),research_cycles:businessCycles.length,
      signal_yield:businessCycles.length?Math.round(businessCycles.reduce((a,x)=>a+x.signals,0)/businessCycles.length*10)/10:null,
      feedback_cycles:cycles.filter(x=>x.kind==='feedback').length};
  }
  function csv(leads,c=DEFAULT_CONFIG,now=today()) {
    const headers=['id','company','domain','project','region','signal_type','signal_date','detected_at','score','qualified','status','product','product_basis','source_url','evidence','email','phone','person','contact_source','enrichment','feedback','do_not_contact','is_demo','notes'];
    function cell(v) {let s=String(v??'');if(/^[\s]*[=+\-@]/.test(s))s="'"+s;return '"'+s.replace(/"/g,'""')+'"';}
    const rows=leads.map(l=>{const s=score(l,c,now);return [l.id,l.company,l.domain,l.project,l.region,l.signal_type,l.signal_date,l.detected_at,l.processed?s.points:'',l.processed&&s.qualified,l.status,l.product,l.product_basis,l.source_url,l.evidence,s.contact.email?l.contact.email:'',s.contact.phone?l.contact.phone:'',s.contact.person?l.contact.name:'',l.contact.url,s.contact.status,l.feedback,l.do_not_contact,l.is_demo,l.notes];});
    return '\uFEFF'+[headers,...rows].map(row=>row.map(cell).join(';')).join('\r\n');
  }
  function makeState(rawLeads=[],mode='pilot',now=today()) {
    const r=merge([],rawLeads,mode,now);return {schema_version:1,mode,config:config(),leads:r.leads,cycles:[],created_at:timestamp(),updated_at:timestamp()};
  }
  function restore(text,mode,now=today()) {
    const x=JSON.parse(text);
    if(x.kind!=='tabal-lead-hunter-backup'||x.schema_version!==1||!x.state||x.state.mode!==mode) throw Error('Kopia musi mieć wersję 1 i dotyczyć wybranego zbioru.');
    const s=x.state; const c=config(s.config);
    if(!Array.isArray(s.leads)||s.leads.length>1000||!Array.isArray(s.cycles)) throw Error('Uszkodzona kopia.');
    const known=new Set();
    const leads=s.leads.map(raw=>{
      const l=validateLead(raw,now);
      if((mode==='demo')!==l.is_demo) throw Error('Kopia zawiera dane z innego zbioru.');
      if(known.has(key(l))) throw Error('Kopia zawiera duplikaty.');known.add(key(l));
      if(!STAGES.includes(raw.status)) throw Error('Nieprawidłowy status w kopii.');
      l.status=raw.status;l.feedback=['yes','no','pending'].includes(raw.feedback)?raw.feedback:'pending';
      l.do_not_contact=raw.do_not_contact===true;l.processed=raw.processed===true;
      for(const k of ['notes','feedback_note'])l[k]=clean(raw[k]);
      l.activities=Array.isArray(raw.activities)?raw.activities.map(a=>({stage:clean(a.stage),date:clean(a.date),channel:clean(a.channel),note:clean(a.note),recorded_at:clean(a.recorded_at),manual:true})):[];
      if(l.activities.some(a=>!STAGES.includes(a.stage)||!validDate(a.date)||age(a.date,now)<0)) throw Error('Nieprawidłowy dziennik działań.');
      l.milestones={FOUND:clean(raw.milestones?.FOUND)||timestamp()};
      for(const stage of STAGES.slice(1))if(raw.milestones?.[stage])l.milestones[stage]=clean(raw.milestones[stage]);
      if(STAGES.indexOf(l.status)>=3&&!l.activities.some(a=>a.stage==='CONTACTED'))throw Error('Brak wpisu potwierdzającego kontakt.');
      l.history=Array.isArray(raw.history)?raw.history.map(h=>({at:clean(h.at),action:clean(h.action),note:clean(h.note)})):[];
      l.id=clean(raw.id,80)||l.id;
      return l;
    });
    if(new Set(leads.map(l=>l.id)).size!==leads.length) throw Error('Powtórzone identyfikatory w kopii.');
    const cycles=s.cycles.map(x=>{
      if(!validDate(x.date)||age(x.date,now)<0||!['research','feedback'].includes(x.kind)||!Number.isFinite(x.minutes)||x.minutes<0||!Number.isInteger(x.signals)||x.signals<0)throw Error('Nieprawidłowy cykl.');
      return {date:x.date,kind:x.kind,minutes:x.minutes,signals:x.signals,note:clean(x.note)};
    });
    return {schema_version:1,mode,config:c,leads,cycles,created_at:clean(s.created_at),updated_at:timestamp()};
  }
  function backup(state) {return JSON.stringify({kind:'tabal-lead-hunter-backup',schema_version:1,exported_at:timestamp(),state},null,2);}
  return {VERSION,STAGES,SIGNALS,SEGMENTS,DEFAULT_CONFIG,clone,clean,norm,today,age,validDate,safeUrl,domain,allowed,config,key,canonicalUrl,validateLead,contacts,score,processLead,draft,feedback,changeStage,merge,parseImport,metrics,csv,makeState,restore,backup,log,timestamp};
});
