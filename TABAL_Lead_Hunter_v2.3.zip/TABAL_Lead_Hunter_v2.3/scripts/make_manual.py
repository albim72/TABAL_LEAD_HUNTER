from pathlib import Path
import json,re
root=Path(__file__).resolve().parents[1]
tap=(root/'test-results/core-results.tap').read_text()
core=int(re.search(r'# pass (\d+)',tap).group(1))
assert '# fail 0' in tap
old=json.loads((root/'test-results/dom-results.json').read_text())
mail=json.loads((root/'test-results/mail-dom-results.json').read_text())
for result in (old,mail):
    assert not result['errors'] and all(r['status']=='PASS' for r in result['results'])
smtp=(root/'test-results/smtp-tests.txt').read_text()
assert smtp.rstrip().endswith('OK')
count=int(re.search(r'Ran (\d+) tests',smtp).group(1))
total=core+len(old['results'])+count+len(mail['results'])
counts=f"{core} logiki + {len(old['results'])} DOM + {count} serwera/SMTP + {len(mail['results'])} panelu z API = {total} zaliczonych testów"
report=f'''# Raport testów TABAL Lead Hunter v2.3

Data testów integracji: {mail['date']}

**{counts}.**

## Co rzeczywiście uruchomiono

- Node.js / node:test: scoring, deduplikacja, kopie, migracja, kwalifikacja do wysyłki i jednokrotny zapis potwierdzeń.
- jsdom: zbudowany START.html, formularze, import, eksport, statusy i historie (starsze funkcje).
- Python unittest: lokalna kolejka SQLite, walidacja, restart procesu, utrata połączenia z panelem, pauza, odstępy, blokowanie duplikatów, anulowanie, ponowienie jednoznacznego błędu, blokowanie niepewnego wyniku, ochrona hasła oraz lokalnego API.
- Rzeczywiste gniazda SMTP na 127.0.0.1: SSL/TLS, STARTTLS i rozłączenie po DATA. Użyto tymczasowego testowego certyfikatu z walidacją i lokalnego odbiornika. Zewnętrzna poczta nie była używana.
- jsdom → rzeczywiste lokalne HTTP API → SQLite → transport przechwytujący: konfiguracja z formularza, dodanie partii, jawne uruchomienie, potwierdzenie SMTP i status CONTACTED, blokada kontaktu, eksport historii i odseparowanie DEMO.
- Plik Work leady_work_v2(2).json: podgląd, zapis 17 firm i odtworzenie kopii. Nie weryfikowano ponownie prawdziwości researchu.

## Granice wyniku

Nie skonfigurowano rzeczywistej skrzynki TABAL i nie wysłano wiadomości do realnych firm. Nie sprawdzono dostarczalności, folderu spam, limitów operatora, OAuth ani odbioru odpowiedzi. Automatyczny status oznacza przyjęcie przez SMTP, nie potwierdzenie doręczenia.

Nie wykonano pełnej sesji w rzeczywistym Firefoxie/Chromium ani uruchomienia BAT na fizycznym Windows. Testy jsdom sprawdzają działanie kodu i formularzy, nie renderowanie. Przy wcześniejszej wersji środowisko blokowało lokalny podgląd; nie obchodzono tych ograniczeń. Przed pierwszą partią użyj w module przycisku testu na własną skrzynkę.

## Dowody

- test-results/core-results.tap
- test-results/dom-results.json
- test-results/smtp-tests.txt
- test-results/mail-dom-results.json
- test-results/work-file-results.json

## Odtworzenie

Polecenia znajdują się w README.md. Testy serwera używają wyłącznie danych fikcyjnych i lokalnych odbiorników. OpenSSL jest potrzebny tylko do wygenerowania certyfikatu w testach, nie do uruchamiania modułu.
'''
(root/'docs/RAPORT_TESTOW.md').write_text(report)
(root/'test-results/browser-status.json').write_text(json.dumps({'status':'NOT_RUN','release':'2.3.0','reason':'No real-browser or physical Windows test claimed; DOM/API/SMTP tests are described separately.'},indent=2))
manual='''<!doctype html><html lang="pl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>TABAL Lead Hunter v2.3 — start i wysyłka</title><style>
*{box-sizing:border-box}body{margin:0;background:#f4f7f4;color:#173b3b;font:16px/1.7 system-ui,Arial,sans-serif}main{max-width:960px;margin:auto;padding:30px 24px 60px}header{background:#143f40;color:white;padding:30px;border-radius:16px}h1{font-size:34px;line-height:1.2}h2{margin-top:36px}a{color:#246b5b}header a{color:white}section{background:white;border:1px solid #dbe6df;padding:22px;border-radius:12px;margin:20px 0}code{background:#eaf0ed;padding:2px 5px;overflow-wrap:anywhere}.note{border-left:4px solid #b58a55;padding:15px;background:#fff8ec}table{border-collapse:collapse;width:100%}td,th{padding:10px;border-bottom:1px solid #dde6df;text-align:left;vertical-align:top}@media(max-width:600px){main{padding:15px}header,section{padding:18px}h1{font-size:27px}}
</style></head><body><main><header><div>TABAL / SYNAPSE X · WERSJA 2.3</div><h1>Od leada do wysłanej wiadomości.</h1><p>Importuj, sprawdź i zatwierdź partię. Moduł SMTP wyśle wiadomości kolejno.</p><a href="START.html">Otwórz panel →</a></header>
<section><h2>1. Uruchomienie</h2><ol><li>W starej wersji pobierz <b>Kopię JSON</b> zbioru Mój pilot.</li><li>Rozpakuj całą paczkę v2.3. Zainstaluj <b>Python 3.10 lub nowszy</b>, jeśli go nie masz: <a href="https://www.python.org/downloads/">python.org</a>.</li><li>Windows: uruchom <b>URUCHOM_WINDOWS.bat</b>. Mac/Linux: <code>python3 serve.py</code>.</li><li>Panel otworzy się pod <b>http://127.0.0.1:8765/START.html</b>. Pozostaw okno serwera otwarte.</li><li>Przywróć kopię w <b>Mój pilot → Profil i źródła → Dane i kopie</b>.</li></ol><p class="note">Bezpośredni START.html nadal obsługuje leady, ale wysyłka wymaga lokalnego serwera. Adres file:// i adres http:// mają oddzielną pamięć; dane przenieś Kopią JSON.</p></section>
<section><h2>2. Podłącz firmową skrzynkę</h2><p>Otwórz <b>Wysyłka</b>. Wpisz host SMTP, port, SSL/TLS lub STARTTLS, login, hasło SMTP/hasło aplikacji, nazwę i adres nadawcy. Dane otrzymasz od administratora poczty.</p><p>Kliknij <b>Zapisz konfigurację na tę sesję</b>, a przy pustej kolejce <b>Wyślij test na adres nadawcy</b>. Sprawdź rzeczywisty odbiór we własnej poczcie.</p><p>Hasło jest tylko w pamięci serwera. Po restarcie wpisz ustawienia ponownie. Konta dopuszczające wyłącznie OAuth nie są obsługiwane.</p></section>
<section><h2>3. Wysyłaj partię automatycznie</h2><ol><li>Na karcie firmy sprawdź e-mail ze źródła, popraw i <b>zapisz szkic</b>.</li><li>Ustaw status <b>DO KONTAKTU</b>.</li><li>W zakładce Wysyłka sprawdź treść, wybierz do 50 wiadomości i kliknij <b>Dodaj wybrane wiadomości do kolejki</b>.</li><li>Sprawdź kolejkę i kliknij <b>Uruchom kolejkę</b>. Wiadomości wysyłają się pojedynczo; domyślnie co 30 sekund.</li><li>Po przyjęciu przez SMTP Hunter zapisze <b>SKONTAKTOWANY</b> i wpis historii. Późniejszych statusów nie cofa.</li></ol><p>Pozostaw panel Mój pilot i serwer otwarte. Po utracie połączenia z panelem kolejka wstrzymuje się po około 15 sekundach. Nowa partia wymaga ponownego uruchomienia.</p></section>
<section><h2>4. Rozumiej wynik</h2><table><tr><th>Stan</th><th>Co oznacza</th></tr><tr><td>Oczekuje</td><td>Wiadomość jest zatwierdzona w kolejce. Można ją anulować.</td></tr><tr><td>W trakcie wysyłki</td><td>Trwa połączenie SMTP. Nie można cofnąć rozpoczętej próby.</td></tr><tr><td>Przyjęta przez SMTP</td><td>Serwer przyjął wiadomość. Nie jest to dowód dostarczenia, przeczytania ani odpowiedzi.</td></tr><tr><td>Błąd — nie wysłano</td><td>Popraw dane/ustawienia. Ponowienie jest ręczne, kolejka wstrzymana.</td></tr><tr><td>Wynik niepewny</td><td>SMTP mógł przyjąć wiadomość przed zerwaniem połączenia. Sprawdź logi operatora; aplikacja blokuje ponowienie.</td></tr><tr><td>Anulowana</td><td>Operator anulował wpis albo zmienił dane, status czy szkic leada.</td></tr></table><p>Odpowiedzi i odbicia sprawdzaj w poczcie. SMTP nie musi zapisywać kopii w „Wysłanych”. Hunter zachowuje treść i Message-ID w swojej historii.</p></section>
<section><h2>5. Kopie i dalsza praca</h2><p>Pobieraj <b>Kopię JSON</b> oraz <b>historię wysyłki</b>. Rejestr firm jest w przeglądarce; kolejka i wyniki SMTP w <code>.runtime/mail.sqlite3</code>. Kopia JSON przenosi zapisane na kartach potwierdzenia, ale nie całą kolejkę serwera.</p><p>Przed przeniesieniem zatrzymaj kolejkę i serwer, skopiuj także katalog <code>.runtime</code>. Po ponownym starcie kolejka jest wstrzymana. Nie usuwaj jej bazy podczas pracy.</p><p>Pracuj w jednej karcie. Nie ma tu wspólnej bazy handlowców, pracy w chmurze, automatycznych follow-upów ani odczytywania odpowiedzi.</p></section>
<section><h2>6. Testy</h2><p><b>__COUNTS__.</b></p><p>Przetestowano także import Twojego pliku 17 leadów. Połączenia SMTP testowano na lokalnym odbiorniku przez SSL/TLS i STARTTLS. Nie wysłano wiadomości do rzeczywistych firm.</p><p>Nie podłączono skrzynki TABAL i nie wykonano pełnego testu w Firefox/Chrome na Windows. Pierwszy test na własną skrzynkę wykonaj po konfiguracji.</p><p>Szczegóły: <code>docs/RAPORT_TESTOW.md</code>. Pełna instrukcja tekstowa i polecenia testów: <code>README.md</code> w paczce.</p></section></main></body></html>'''
(root/'INSTRUKCJA.html').write_text(manual.replace('__COUNTS__',counts))
print(counts)
