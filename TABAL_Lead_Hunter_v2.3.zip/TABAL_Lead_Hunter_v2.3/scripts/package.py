"""Pack this release; run build.py and the tests before packaging."""
from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile, ZIP_DEFLATED
root = Path(__file__).resolve().parents[1]
files = sorted(p for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts and '.runtime' not in p.parts and 'node_modules' not in p.parts and p.name != 'SHA256SUMS.txt')
(root / 'SHA256SUMS.txt').write_text(''.join(f'{sha256(p.read_bytes()).hexdigest()}  {p.relative_to(root).as_posix()}\n' for p in files))
files.append(root / 'SHA256SUMS.txt')
target = root.parent / (root.name + '.zip')
with ZipFile(target, 'w', ZIP_DEFLATED) as z:
    for p in files:
        z.write(p, root.name + '/' + p.relative_to(root).as_posix())
with ZipFile(target) as z:
    assert z.testzip() is None
    for p in files:
        assert z.read(root.name + '/' + p.relative_to(root).as_posix()) == p.read_bytes()
print(f'{target}: {len(files)} files, {target.stat().st_size} bytes; verified')
