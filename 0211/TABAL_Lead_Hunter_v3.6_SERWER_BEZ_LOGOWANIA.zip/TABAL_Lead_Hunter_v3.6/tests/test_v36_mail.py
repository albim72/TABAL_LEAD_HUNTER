"""3.6 (TABAL 29.10): copy in the "Sent" folder on by default, visible and testable; inline signature images; HTML always."""
import base64
import json
import sys
import tempfile
import unittest
from email import policy
from email.parser import BytesParser
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from server import mailer  # noqa: E402
from server.mailer import Outbox, build_message, message, imap_copy, imap_check, decode_folder, imap_folders  # noqa: E402
from tests.test_mail import raw, CONFIG  # noqa: E402

PNG = base64.b64encode(b'\x89PNG\r\n\x1a\n' + b'\x00' * 40).decode()


def fake_imap(calls, folders=None, login_ok=True):
    rows = folders or [b'(\\HasNoChildren) "." "INBOX"', (b'(\\HasNoChildren \\Sent) "." {12}', b'Wys&AUI-ane')]

    class FakeIMAP:
        def __init__(self, host, port, ssl_context=None, timeout=None):
            calls.setdefault('hosts', []).append((host, port))
            if host.startswith('bad.'):
                raise OSError('no route')

        def login(self, u, p):
            if not login_ok:
                raise mailer.imaplib.IMAP4.error('auth')
            calls['login'] = u

        def list(self):
            return 'OK', rows

        def append(self, folder, flags, date, data):
            calls.setdefault('append', []).append((folder, data))
            return 'OK', [b'']

        def logout(self):
            pass
    return FakeIMAP


class MessageV36(unittest.TestCase):
    def test_data_image_in_signature_becomes_inline_cid(self):
        job = {**message({**raw(), 'html': f'<p>Dzień dobry</p><img src="data:image/png;base64,{PNG}" alt="logo">'}), 'message_id': '<x@example.com>'}
        msg = build_message(CONFIG, job)
        parsed = BytesParser(policy=policy.default).parsebytes(msg.as_bytes())
        html_part = parsed.get_body(('html',))
        self.assertNotIn('data:image', html_part.get_content())
        self.assertIn('src="cid:sig1.', html_part.get_content())
        related = [p for p in parsed.walk() if p.get_content_type() == 'image/png']
        self.assertEqual(len(related), 1)
        self.assertTrue(related[0]['Content-ID'].startswith('<sig1.'))
        self.assertIn('Dzień dobry', parsed.get_body(('plain',)).get_content())

    def test_imap_folder_helpers_handle_literal_rows_and_utf7(self):
        calls = {}
        box = fake_imap(calls)('h', 993)
        names = imap_folders(box)
        self.assertIn('"Wys&AUI-ane"', [n for _, n in names])
        self.assertEqual(decode_folder('"INBOX.Wys&AUI-ane"'), 'INBOX.Wysłane')
        self.assertEqual(decode_folder('Elementy wys&AUI-ane'), 'Elementy wysłane')


class ImapCheckV36(unittest.TestCase):
    def test_check_finds_sent_folder_and_stores_test_copy(self):
        calls = {}
        with patch('server.mailer.imaplib.IMAP4_SSL', fake_imap(calls, [b'(\\HasNoChildren) "/" "INBOX"', b'(\\HasNoChildren \\Sent) "/" "Wys&AUI-ane"'])):
            r = imap_check('mail.tabal.example', 993, 'bok@tabal.example', 'x', '', 'bok@tabal.example', 'TABAL')
        self.assertTrue(r['ok'], r)
        self.assertEqual(r['folder'], 'Wys&AUI-ane')
        self.assertEqual(r['folder_label'], 'Wysłane')
        self.assertEqual(calls['append'][0][0], '"Wys&AUI-ane"')
        self.assertIn(b'test_kopii', calls['append'][0][1])

    def test_check_tries_next_host_and_reports_login_problem(self):
        calls = {}
        with patch('server.mailer.imaplib.IMAP4_SSL', fake_imap(calls)):
            r = imap_check('bad.example', 993, 'u', 'p', '', 'u@tabal.example', 'T', True, ['imap.tabal.example'])
        self.assertTrue(r['ok'])
        self.assertEqual(r['host'], 'imap.tabal.example')
        self.assertEqual([h for h, _ in calls['hosts']], ['bad.example', 'imap.tabal.example'])
        with patch('server.mailer.imaplib.IMAP4_SSL', fake_imap({}, login_ok=False)):
            r = imap_check('imap.tabal.example', 993, 'u', 'p')
        self.assertFalse(r['ok'])
        self.assertTrue(any(s['step'] == 'Logowanie' and not s['ok'] for s in r['steps']))

    def test_unknown_folder_lists_real_folders(self):
        with patch('server.mailer.imaplib.IMAP4_SSL', fake_imap({})):
            r = imap_check('imap.tabal.example', 993, 'u', 'p', 'Nieistniejący')
        self.assertFalse(r['ok'])
        self.assertIn('INBOX', r['folders'])

    def test_copy_note_names_folder(self):
        calls = {}
        job = {**message(raw()), 'message_id': '<x@example.com>'}
        with patch('server.mailer.imaplib.IMAP4_SSL', fake_imap(calls)):
            note = imap_copy({**CONFIG, 'imap_port': 993}, build_message(CONFIG, job))
        self.assertIn('zapisano', note)
        self.assertIn('Wysłane', note)


class OutboxV36(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.cfgpath = Path(self.tmp.name) / 'smtp.json'

    def tearDown(self):
        self.tmp.cleanup()

    def test_settings_saved_by_35_get_sent_copy_switched_on_once(self):
        old = {k: v for k, v in CONFIG.items()}
        old.update(imap_copy=False, bcc_self=False, remember_password=True, daily_limit=200)
        self.cfgpath.write_text(json.dumps(old), encoding='utf-8')
        box = Outbox(Path(self.tmp.name) / 'm.sqlite3', config_path=self.cfgpath)
        self.assertTrue(box.load_saved())
        self.assertTrue(box.config['imap_copy'])
        self.assertEqual(json.loads(self.cfgpath.read_text(encoding='utf-8'))['cfg_version'], 36)
        # an explicit choice made in 3.6 is respected after restart
        box.configure({**box.config, 'imap_copy': False})
        box.db.close()
        box2 = Outbox(Path(self.tmp.name) / 'm2.sqlite3', config_path=self.cfgpath)
        self.assertTrue(box2.load_saved())
        self.assertFalse(box2.config['imap_copy'])
        box2.db.close()

    def test_bcc_choice_from_35_is_kept(self):
        old = dict(CONFIG, imap_copy=False, bcc_self=True, remember_password=True)
        self.cfgpath.write_text(json.dumps(old), encoding='utf-8')
        box = Outbox(Path(self.tmp.name) / 'm.sqlite3', config_path=self.cfgpath)
        self.assertTrue(box.load_saved())
        self.assertFalse(box.config['imap_copy'])
        box.db.close()

    def test_failed_copy_is_visible_in_snapshot(self):
        class T:
            def send(self, cfg, job):
                return 'kopia w „Wysłanych”: brak połączenia IMAP z x (OSError)'
        now = [100]
        box = Outbox(Path(self.tmp.name) / 'm.sqlite3', T(), lambda: now[0])
        box.configure(dict(CONFIG, imap_copy=True))
        box.test_message('owner-1234567890')
        box.sync('owner-1234567890', [j['id'] for j in box.jobs()])
        box.control('resume', '', 'owner-1234567890')
        self.assertTrue(box.run_one())
        snap = box.snapshot()
        self.assertFalse(snap['imap_last']['ok'])
        self.assertIn('brak połączenia', snap['imap_last']['note'])
        box.db.close()


if __name__ == '__main__':
    unittest.main()


class ServerImapCheckV36(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import io
        import os
        cls.tmp = tempfile.TemporaryDirectory()
        os.environ.setdefault('TABAL_DATA_DIR', cls.tmp.name)
        os.environ.setdefault('TABAL_ORIGIN', 'http://127.0.0.1:8765')
        from server import web
        cls.web, cls.io = web, io

    def req(self, path, body):
        raw_body = json.dumps(body).encode()
        env = {'HTTP_HOST': '127.0.0.1:8765', 'PATH_INFO': path, 'REQUEST_METHOD': 'POST', 'wsgi.input': self.io.BytesIO(raw_body),
               'CONTENT_LENGTH': str(len(raw_body)), 'CONTENT_TYPE': 'application/json', 'HTTP_ORIGIN': 'http://127.0.0.1:8765',
               'HTTP_X_TABAL_TOKEN': self.web.NOLOGIN_CSRF}
        out = {}

        def start(status, headers):
            out['status'] = int(status.split()[0])
        out['body'] = json.loads(b''.join(self.web.application(env, start)))
        return out

    def test_endpoint_rejects_foreign_host_and_missing_password(self):
        self.assertEqual(self.req('/api/imap-check', {'imap_host': 'evil.example', 'sender_email': 'bok@tabal.pl', 'password': 'x'})['status'], 403)
        self.assertEqual(self.req('/api/imap-check', {'imap_host': 'mail.tabal.pl', 'sender_email': 'bok@tabal.pl', 'username': 'nobody@tabal.pl'})['status'], 400)
        self.assertEqual(self.req('/api/imap-check', {'imap_host': 'mail.tabal.pl', 'imap_port': 25, 'sender_email': 'bok@tabal.pl', 'password': 'x'})['status'], 400)

    def test_endpoint_runs_check_and_remembers_success(self):
        calls = {}
        with patch('server.mailer.imaplib.IMAP4_SSL', fake_imap(calls)):
            r = self.req('/api/imap-check', {'imap_host': 'mail.tabal.pl', 'host': 'mail.tabal.pl', 'sender_email': 'bok@tabal.pl', 'username': 'bok@tabal.pl', 'password': 'x'})
        self.assertEqual(r['status'], 200)
        self.assertTrue(r['body']['ok'])
        self.assertTrue(self.web.outbox.snapshot()['imap_last']['ok'])
        self.assertEqual(r['body']['folder_label'], 'Wysłane')
