// TABAL Lead Hunter 3.7 — uwagi TABAL z 2.11.2026 (J. Moraczewski, e-mail „Uwagi do Lead Huntera z dnia 2.11”).
const test=require('node:test'),a=require('node:assert/strict'),C=require('../src/core.js');
const T=C.today();
function base(){const s=C.makeState('pilot');s.config.signature='Zespół TABAL\nbok@tabal.pl';return s;}
function strat(s,extra={}){const st=C.strategy({...s.strategies[0],product_id:'panel',...extra});s.strategies=[st];return st;}
const src=d=>[{url:'https://'+d+'/',title:'Strona',quote:'Firma '+d,checked_at:T,verified:true}];
const person=(name,role,email)=>({type:'person',name,role,reason:'Strona kontakt',email,url:'https://x.example/kontakt',quote:`${name} ${role} ${email}`,checked_at:T,verified:true});
const general=(email)=>({type:'general',name:'',role:'',reason:'Ogólny kontakt',email,url:'https://x.example/kontakt',quote:email,checked_at:T,verified:true});
function lead(s,st,x={}){const l=C.validateLead({company:'ASTOR Sp. z o.o.',domain:'astor.example',sources:src('astor.example'),contacts:[],criteria:{},...x},s,st);return l;}
const daysAgo=n=>new Date(Date.now()-n*86400000).toISOString();

// ---------- #8 short company name ----------
test('NAZWA 3.7: w wiadomości krótka nazwa firmy — bez formy prawnej i pełnej nazwy z KRS',()=>{
 for(const [full,short] of [['ASTOR Sp. z o.o.','ASTOR'],['P.P.H.U. "DREWMAX" Jan Kowalski','DREWMAX'],['DREWMAX Jan Kowalski','DREWMAX'],['Mebel-Bud spółka z ograniczoną odpowiedzialnością','Mebel-Bud'],['Meble Kowalski Sp. z o.o. Sp. k.','Meble Kowalski'],['Agata Spółka Akcyjna','Agata'],['PPHU Alu-Gard','Alu-Gard'],['Alu System Sp.j.','Alu System'],['Orion','Orion'],['Zakład Stolarski Nowak','Zakład Stolarski Nowak']])a.equal(C.shortCompany(full),short,full);
 const s=base(),st=strat(s),l=lead(s,st,{registry:{type:'KRS',status:'active',name:'ASTOR SPÓŁKA Z OGRANICZONĄ ODPOWIEDZIALNOŚCIĄ'}});
 l.draft={subject:'ASTOR Sp. z o.o. — współpraca z TABAL',body:'Dzień dobry,\n\nkontaktuję się, ponieważ ASTOR Sp. z o.o. dostarcza automatykę. ASTOR SPÓŁKA Z OGRANICZONĄ ODPOWIEDZIALNOŚCIĄ to lider.\n\nPozdrawiam'};
 const m=C.composeMessage(l,s.config,s.products);
 a.equal(m.subject,'ASTOR — współpraca z TABAL');a.ok(!/Sp\. z o\.o\.|SPÓŁKA/.test(m.body+m.html));a.match(m.body,/ponieważ ASTOR dostarcza/);
 a.match(C.draft(l,s.config,s.products).body,/ponieważ ASTOR (zajmuje|działa)/);
 a.match(C.task(s,{...st,mode:'open',research_stage:'full'},'r'),/KRÓTKIEJ nazwy firmy odbiorcy/);
});

// ---------- #3 main recipient + one general address in Cc ----------
test('ODBIORCY 3.7: osoba właściwa + DW na JEDEN ogólny adres; gdy jest tylko ogólny — tylko on',()=>{
 const s=base(),st=strat(s),l=lead(s,st,{contacts:[person('Anna Kowal','Kierownik zakupów','a.kowal@astor.example'),general('info@astor.example'),general('biuro@astor.example'),general('serwis@astor.example')]});
 l.status='TO_CONTACT';l.draft={subject:'Temat',body:'Dzień dobry,\n\nTreść.\n\nPozdrawiam'};
 let m=C.mailCandidate(l,s.config,'pilot',s.products).message;a.equal(m.to,'a.kowal@astor.example');a.ok(['biuro@astor.example','info@astor.example'].includes(m.cc),'one general address, never serwis@');
 a.equal(C.mailCandidate(l,{...s.config,recipient_mode:'person'},'pilot',s.products).message.cc,'');
 const g=C.mailCandidate(l,{...s.config,recipient_mode:'general'},'pilot',s.products).message;a.ok(/^(biuro|info)@/.test(g.to));a.equal(g.cc,'');
 const only=lead(s,st,{contacts:[general('biuro@astor.example')]});only.status='TO_CONTACT';only.draft=l.draft;
 m=C.mailCandidate(only,s.config,'pilot',s.products).message;a.equal(m.to,'biuro@astor.example');a.equal(m.cc,'');
 a.equal(C.settings({}).recipient_mode,'person_cc');
});

// ---------- #2 personal profiles ----------
test('PROFILE 3.7: każda osoba ma własną sygnaturę i nazwę nadawcy; zapis przetrwa kopię',()=>{
 const s=base(),st=strat(s);
 s.config=C.settings({...s.config,profiles:[{id:'pjm',name:'Jędrzej Moraczewski',sender_name:'Jędrzej Moraczewski | TABAL',signature:'Jędrzej Moraczewski\nOpiekun klienta | TABAL',signature_html:'<p><b>Jędrzej Moraczewski</b><br>Opiekun klienta</p><script>x</script>'},{id:'ppf',name:'Piotr Frankiewicz',signature:'Piotr Frankiewicz\nTABAL'},{id:'bad id!',name:'X'}]});
 a.deepEqual(s.config.profiles.map(p=>p.id),['pjm','ppf']);a.ok(!s.config.profiles[0].signature_html.includes('script'));
 const l=lead(s,st,{contacts:[general('biuro@astor.example')]});l.status='TO_CONTACT';l.draft={subject:'Temat',body:'Dzień dobry,\n\nTreść.\n\nPozdrawiam\nZespół TABAL'};
 let m=C.mailCandidate({...l,mail_profile:'pjm'},s.config,'pilot',s.products).message;
 a.match(m.body,/Pozdrawiam\nJędrzej Moraczewski\nOpiekun klienta \| TABAL$/);a.match(m.html,/<b>Jędrzej Moraczewski<\/b>/);a.equal(m.from_name,'Jędrzej Moraczewski | TABAL');a.equal(m.profile_id,'pjm');a.ok(!m.body.includes('Zespół TABAL'));
 m=C.mailCandidate({...l,mail_profile:'ppf'},s.config,'pilot',s.products).message;a.match(m.body,/Piotr Frankiewicz\nTABAL$/);a.equal(m.from_name,'');
 m=C.mailCandidate(l,s.config,'pilot',s.products).message;a.match(m.body,/Zespół TABAL\nbok@tabal\.pl$/,'without profile: company signature');
 const empty=C.settings({...s.config,profiles:[{id:'pe',name:'Ewa'}]});a.equal(C.mailCandidate({...l,mail_profile:'pe'},empty,'pilot',s.products).message,null,'profile without signature blocks sending');
 s.leads=[{...l,mail_profile:'pjm'}];const back=C.restore(C.backup(s),'pilot');a.equal(back.leads[0].mail_profile,'pjm');a.equal(back.config.profiles[0].sender_name,'Jędrzej Moraczewski | TABAL');
});
test('SYGNATURA 3.7: logo z pliku osadzone w HTML (data:), większy limit, podgląd',()=>{
 const png='data:image/png;base64,'+'iVBORw0KGgo'.padEnd(40000,'A');
 const r=C.signatureFromFields({name:'Jan Kowalski',company:'TABAL',logo_data:png});a.ok(r.html.includes(png.slice(0,60)));
 const s=C.settings({signature_html:r.html});a.ok(s.signature_html.includes('data:image/png;base64,'));
 a.ok(!C.signatureFromFields({name:'Jan',logo_data:'data:text/html;base64,PHNjcmlwdD4='}).html.includes('data:text'));
});

// ---------- #4 reminders ----------
function sent(s,st,{days=4,status='CONTACTED',kind='lead',extra=[]}={}){
 const l=lead(s,st,{contacts:[person('Anna Kowal','Kierownik zakupów','a.kowal@astor.example'),general('biuro@astor.example')]});l.status=status;l.mail_profile='';
 l.mail_events=[{id:'j1',to:'a.kowal@astor.example',cc:'biuro@astor.example',kind,subject:'Ogrodzenia panelowe — współpraca z TABAL',body:'Dzień dobry,\n\npierwsza wiadomość.\n\nPozdrawiam',sent_at:daysAgo(days),message_id:'<j1@tabal.pl>'},...extra];return l;
}
test('PRZYPOMNIENIA 3.7: po 3 dniach bez odpowiedzi — Re: w tym samym wątku, do tych samych adresów, z cytatem',()=>{
 const s=base(),st=strat(s);
 a.equal(C.followupDue(sent(s,st,{days:1}),s.config).due,false);
 const l=sent(s,st,{days:4}),fu=C.followupDue(l,s.config);a.equal(fu.due,true);a.equal(fu.no,1);a.equal(fu.days,4);
 const c=C.followupCandidate(l,s.config,'pilot',s.products),m=c.message;
 a.equal(m.kind,'followup');a.equal(m.to,'a.kowal@astor.example');a.equal(m.cc,'biuro@astor.example');a.equal(m.in_reply_to,'<j1@tabal.pl>');a.equal(m.followup_no,1);
 a.equal(m.subject,'Re: Ogrodzenia panelowe — współpraca z TABAL');a.match(m.body,/uprzejmie przypominam o mojej wiadomości z \d\d\.\d\d\.\d{4}/);a.match(m.body,/> pierwsza wiadomość/);a.match(m.html,/<blockquote/);a.match(m.body,/Zespół TABAL/);
 a.equal(C.followupCandidate(l,{...s.config,followup_days:0},'pilot',s.products).message,null,'0 = off');
 for(const st2 of ['REPLIED','INTERESTED','REJECTED','TO_CONTACT'])a.equal(C.followupDue({...l,status:st2},s.config),null,st2);
 a.equal(C.followupDue({...l,do_not_contact:true},s.config),null);
});
test('PRZYPOMNIENIA 3.7: limit przypomnień, liczenie od ostatniej wysyłki, potwierdzenie SMTP nie zmienia statusu',()=>{
 const s=base(),st=strat(s);
 const l=sent(s,st,{days:10,extra:[{id:'j2',to:'a.kowal@astor.example',kind:'followup',followup_no:1,subject:'Re: x',sent_at:daysAgo(1),message_id:'<j2@tabal.pl>'}]});
 a.equal(C.followupDue(l,s.config),null,'max 1 by default');
 const two={...s.config,followup_max:2};const fu=C.followupDue(l,two);a.equal(fu.no,2);a.equal(fu.due,false,'counted from the last reminder');
 const fresh=sent(s,st,{days:5});const job={id:'j9',status:'sent',lead_id:fresh.id,kind:'followup',followup_no:1,to:'a.kowal@astor.example',cc:'biuro@astor.example',subject:'Re: x',body:'b',sent_at:C.now(),message_id:'<j9@tabal.pl>'};
 a.equal(C.applyMailReceipt(fresh,job),true);a.equal(fresh.status,'CONTACTED');a.equal(fresh.mail_events.at(-1).kind,'followup');a.equal(C.followupDue(fresh,s.config),null);a.ok(fresh.history.some(h=>h.action==='EMAIL_FOLLOWUP'));
});
test('ODPOWIEDZI 3.7: odpowiedź wykryta w Odebranych → ODPOWIEDŹ i stop przypomnień; autoodpowiedź nie zmienia statusu',()=>{
 const s=base(),st=strat(s),l=sent(s,st,{days:5});
 a.equal(C.applyReply(l,{lead_id:l.id,key:'<auto@x>',from:'Anna <a.kowal@astor.example>',subject:'Automatyczna odpowiedź: urlop',auto:true}),true);a.equal(l.status,'CONTACTED');
 a.equal(C.applyReply(l,{lead_id:l.id,key:'<r1@x>',from:'Anna <a.kowal@astor.example>',subject:'Re: Ogrodzenia',date:C.now()}),true);a.equal(l.status,'REPLIED');a.equal(C.followupDue(l,s.config),null);
 a.equal(C.applyReply(l,{lead_id:l.id,key:'<r1@x>'}),false,'same reply only once');
 s.leads=[l];a.equal(C.restore(C.backup(s),'pilot').leads[0].replies.length,2);
});
test('USTAWIENIA 3.7: przypomnienia i czas Work — walidacja i domyślne',()=>{
 const c=C.settings({});a.equal(c.followup_days,3);a.equal(c.followup_max,1);a.match(c.followup_text,/\{data\}/);a.equal(c.work_minutes,0);
 for(const bad of [{followup_days:-1},{followup_max:5},{work_minutes:999}])a.throws(()=>C.settings(bad));
 const s=base(),st=strat(s);s.config.work_minutes=30;a.match(C.task(s,{...st,mode:'open'},'r'),/CZAS NA ZADANIE: około 30 minut/);s.config.work_minutes=0;a.doesNotMatch(C.task(s,{...st,mode:'open'},'r'),/CZAS NA ZADANIE/);
});
