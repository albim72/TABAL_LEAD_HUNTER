"""3.7 (TABAL 2.11): Cc on one general address, personal sender name, reminders (Re:, own duplicate key),
replies found in INBOX, signature images embedded by the server."""
import base64
import io
import json
import os
import subprocess
import sys
import tempfile
import unittest
from email import policy
from email.parser import BytesParser
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from server import embed  # noqa: E402
from server.mailer import Outbox, SMTPTransport, build_message, message, queue_key, find_replies  # noqa: E402
from tests.test_mail import raw, CONFIG  # noqa: E402

OWNER = 'test-owner-37-123456'


def fu(**kw):
    return {**raw(), 'kind': 'followup', 'status': 'CONTACTED', 'followup_no': 1, 'in_reply_to': '<first@tabal.example>', 'subject': 'Re: Temat', **kw}


class MessageV37(unittest.TestCase):
    def test_cc_sender_name_and_validation(self):
        m = message({**raw(), 'cc': 'biuro@example.com', 'from_name': 'Jędrzej Moraczewski | TABAL', 'profile_id': 'pjm'})
        self.assertEqual((m['cc'], m['from_name'], m['kind']), ('biuro@example.com', 'Jędrzej Moraczewski | TABAL', 'lead'))
        for bad in ({'cc': 'zly adres'}, {'cc': raw()['to']}, {'from_name': 'a\nBcc: x@y.pl'}, {'kind': 'spam'}):
            with self.assertRaises(ValueError):
                message({**raw(), **bad})

    def test_followup_rules(self):
        m = message(fu())
        self.assertEqual((m['kind'], m['followup_no'], m['in_reply_to']), ('followup', 1, '<first@tabal.example>'))
        with self.assertRaises(ValueError):
            message(fu(status='TO_CONTACT'))
        with self.assertRaises(ValueError):
            message(fu(followup_no=9))
        with self.assertRaises(ValueError):
            message(fu(in_reply_to='bad id'))
        with self.assertRaises(ValueError):
            message({**raw(), 'status': 'CONTACTED'})
        self.assertEqual(queue_key(m), 'fu1:' + raw()['to'].lower())
        self.assertEqual(queue_key(message(raw())), raw()['to'].lower())

    def test_headers_and_recipients(self):
        job = {**message(fu(cc='biuro@example.com')), 'message_id': '<x@example.com>'}
        cfg = {**CONFIG, 'sender_name': 'Jędrzej Moraczewski | TABAL'}
        msg = BytesParser(policy=policy.default).parsebytes(build_message(cfg, job).as_bytes())
        self.assertEqual(msg['Cc'], 'biuro@example.com')
        self.assertEqual(msg['In-Reply-To'], '<first@tabal.example>')
        self.assertEqual(msg['References'], '<first@tabal.example>')
        self.assertIn('Jędrzej Moraczewski', str(msg['From']))
        sent = {}

        class FakeSMTP:
            def __init__(self, *a, **k):
                pass

            def login(self, u, p):
                pass

            def send_message(self, msg, from_addr=None, to_addrs=None):
                sent['to'] = to_addrs
                return {}

            def close(self):
                pass
        with patch('server.mailer.smtplib.SMTP_SSL', FakeSMTP):
            SMTPTransport().send(cfg, job)
        self.assertEqual(sent['to'], [job['to'], 'biuro@example.com'])


class OutboxV37(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.box = Outbox(Path(self.tmp.name) / 'm.sqlite3', transport=None, clock=lambda: 100)
        self.box.configure(dict(CONFIG))

    def tearDown(self):
        self.box.db.close()
        self.tmp.cleanup()

    def test_reminder_allowed_after_first_message_but_only_once(self):
        snap = self.box.enqueue([raw()], OWNER)
        first = snap['jobs'][0]
        self.box.db.execute("UPDATE jobs SET status='sent',sent_at='2026-10-29T10:00:00+00:00' WHERE id=?", (first['id'],))
        with self.assertRaises(ValueError):
            self.box.enqueue([raw()], OWNER)
        snap = self.box.enqueue([fu()], OWNER)
        self.assertEqual(len(snap['jobs']), 2)
        with self.assertRaises(ValueError):
            self.box.enqueue([fu()], OWNER)
        self.box.enqueue([fu(followup_no=2)], OWNER)

    def test_profile_sender_name_frozen_in_job(self):
        snap = self.box.enqueue([{**raw(), 'from_name': 'Piotr Frankiewicz | TABAL'}], OWNER)
        self.assertEqual(snap['jobs'][0]['sender_name'], 'Piotr Frankiewicz | TABAL')
        snap = self.box.enqueue([raw('second@example.com', 'lead-2')], OWNER)
        self.assertEqual(next(j for j in snap['jobs'] if j['lead_id'] == 'lead-2')['sender_name'], CONFIG['sender_name'])


def eml_header(frm, subject, date='Fri, 30 Oct 2026 10:00:00 +0100', mid='<r1@astor.example>', auto=False):
    h = f'From: {frm}\r\nSubject: {subject}\r\nDate: {date}\r\nMessage-ID: {mid}\r\n'
    if auto:
        h += 'Auto-Submitted: auto-replied\r\n'
    return h.encode()


class FakeInbox:
    def __init__(self, messages):
        self.messages = messages
        self.searches = []
        self.readonly = None

    def login(self, u, p):
        pass

    def select(self, name, readonly=False):
        self.readonly = readonly
        return 'OK', [b'3']

    def search(self, charset, *criteria):
        self.searches.append(criteria)
        who = criteria[-1].strip('"')
        hits = [str(i + 1).encode() for i, (frm, _) in enumerate(self.messages) if who in frm.lower()]
        return 'OK', [b' '.join(hits)]

    def fetch(self, num, what):
        assert 'PEEK' in what
        return 'OK', [(b'1 (BODY[HEADER.FIELDS] {10}', self.messages[int(num) - 1][1]), b')']

    def logout(self):
        pass


class RepliesV37(unittest.TestCase):
    def test_reply_from_company_domain_after_our_message(self):
        jobs = [{'status': 'sent', 'kind': 'lead', 'lead_id': 'L1', 'to': 'a.kowal@astor.example', 'cc': 'biuro@astor.example', 'sent_at': '2026-10-29T10:00:00+00:00'},
                {'status': 'sent', 'kind': 'lead', 'lead_id': 'L2', 'to': 'jan.kowalski@gmail.com', 'sent_at': '2026-10-29T10:00:00+00:00'},
                {'status': 'failed', 'kind': 'lead', 'lead_id': 'L3', 'to': 'x@other.example', 'sent_at': ''}]
        box = FakeInbox([('anna kowal <a.kowal@astor.example>', eml_header('Anna Kowal <a.kowal@astor.example>', 'Re: Ogrodzenia')),
                         ('biuro@astor.example', eml_header('biuro@astor.example', 'Automatyczna odpowiedź: urlop', mid='<a1@astor.example>', auto=True)),
                         ('old@astor.example', eml_header('old@astor.example', 'stara', date='Mon, 26 Oct 2026 10:00:00 +0100', mid='<old@x>')),
                         ('kto@gmail.com', eml_header('kto@gmail.com', 'nie ten nadawca', mid='<g@x>'))])
        r = find_replies({**CONFIG, 'sender_email': 'bok@tabal.example'}, jobs, opener=lambda h, p: box)
        self.assertTrue(box.readonly, 'INBOX opened read-only')
        keys = {s[-1] for s in box.searches}
        self.assertEqual(keys, {'"@astor.example"', '"jan.kowalski@gmail.com"'}, 'company domain, but exact address for free mail')
        self.assertEqual(r['checked'], 2)
        real = [x for x in r['replies'] if not x['auto']]
        self.assertEqual([(x['lead_id'], x['subject']) for x in real], [('L1', 'Re: Ogrodzenia')])
        self.assertEqual([x['lead_id'] for x in r['replies'] if x['auto']], ['L1'])

    def test_no_sent_messages_and_bad_login(self):
        self.assertEqual(find_replies(CONFIG, [])['checked'], 0)

        class Bad(FakeInbox):
            def login(self, u, p):
                raise OSError('x')
        with self.assertRaises(ValueError):
            find_replies(CONFIG, [{'status': 'sent', 'kind': 'lead', 'lead_id': 'L', 'to': 'a@b.example', 'sent_at': '2026-10-29T10:00:00+00:00'}], opener=lambda h, p: Bad([]))


class FakeResp(io.BytesIO):
    def __init__(self, data, ctype):
        super().__init__(data)
        self.headers = {'Content-Type': ctype}

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False


class EmbedV37(unittest.TestCase):
    def test_remote_logo_embedded_local_images_reported(self):
        png = b'\x89PNG\r\n\x1a\n' + b'\x00' * 50

        class Opener:
            def open(self, req, timeout=None):
                url = req.full_url
                if 'big' in url:
                    return FakeResp(b'x' * 600_000, 'image/png')
                if 'html' in url:
                    return FakeResp(b'<html>', 'text/html')
                return FakeResp(png, 'image/png')
        html = ('<img src="https://tabal.example/logo.png"><img src="http://tabal.example/l2.png"><img src="cid:image001.png@01DA">'
                '<img src="https://tabal.example/big.png"><img src="https://tabal.example/page.html"><img src="data:image/png;base64,AAAA">')
        r = embed.embed_html(html, opener=Opener())
        self.assertEqual(r['embedded'], 2)
        self.assertEqual(r['unavailable'], 1)
        self.assertEqual(len(r['failed']), 2)
        self.assertIn('data:image/png;base64,' + base64.b64encode(png).decode(), r['html'])
        self.assertIn('500 kB', json.dumps(r['failed'], ensure_ascii=False))

    def test_private_addresses_refused(self):
        for url in ('http://127.0.0.1/logo.png', 'http://localhost/logo.png', 'https://10.0.0.5/x.png', 'ftp://x.example/a.png', 'https://example.com:8443/a.png'):
            with self.assertRaises(ValueError):
                embed.fetch_image(url)


class ServerV37(unittest.TestCase):
    """Reminder accepted by the server only for a lead that is really due; replies change status on the server."""

    @classmethod
    def setUpClass(cls):
        os.environ.setdefault('TABAL_DATA_DIR', tempfile.mkdtemp())
        os.environ.setdefault('TABAL_ORIGIN', 'http://127.0.0.1:8765')
        from server import web
        cls.web = web

    def req(self, path, body):
        data = json.dumps(body).encode()
        env = {'HTTP_HOST': '127.0.0.1:8765', 'PATH_INFO': path, 'REQUEST_METHOD': 'POST', 'wsgi.input': io.BytesIO(data), 'CONTENT_LENGTH': str(len(data)),
               'CONTENT_TYPE': 'application/json', 'HTTP_ORIGIN': 'http://127.0.0.1:8765', 'HTTP_X_TABAL_TOKEN': self.web.NOLOGIN_CSRF}
        out = {}

        def start(status, headers):
            out['status'] = int(status.split()[0])
        out['body'] = json.loads(b''.join(self.web.application(env, start)))
        return out

    def test_followup_enqueue_and_reply_detection(self):
        web = self.web
        web.outbox.stop.set()
        js = ("const C=require('./src/core.js'),s=C.makeState('pilot'),st=s.strategies[0],r=C.sample(st,s,false);const l=C.validateLead(r,s,st);"
              "l.status='CONTACTED';s.config.signature='Test Nadawca\\nTABAL';l.mail_events=[{id:'j0',to:l.contacts.find(p=>p.email).email,kind:'lead',subject:'Temat',body:'Pierwsza',"
              "sent_at:new Date(Date.now()-5*86400000).toISOString(),message_id:'<j0@tabal.pl>'}];s.leads=[l];console.log(JSON.stringify(s));")
        state = json.loads(subprocess.check_output(['node', '-e', js], cwd=ROOT))
        cur = web.store.get()
        r = self.req('/api/workspace', {'revision': cur['revision'], 'state': state})
        self.assertEqual(r['status'], 200, r)
        rev = r['body']['revision']
        if not web.outbox.config:
            web.outbox.configure(dict(host='localhost', port=465, security='ssl', username='t@example.com', password='x', sender_name='T', sender_email='t@example.com', interval=10))
        from server.storage import core
        cands = [m for m in core('candidates', state=web.store.get()['state']) if m.get('kind') == 'followup']
        self.assertEqual(len(cands), 1)
        self.assertTrue(cands[0]['subject'].startswith('Re: '))
        r = self.req('/api/enqueue', {'revision': rev, 'owner': OWNER, 'messages': cands})
        self.assertEqual(r['status'], 200, r)
        forged = dict(cands[0], to='inny@example.com')
        self.assertEqual(self.req('/api/enqueue', {'revision': rev, 'owner': OWNER, 'messages': [forged]})['status'], 400)
        lead_id = state['leads'][0]['id']
        web.outbox.db.execute("UPDATE jobs SET status='sent',sent_at='2026-10-29T10:00:00+00:00' WHERE email_key LIKE 'fu1:%'")
        with patch('server.web.find_replies', return_value={'replies': [{'lead_id': lead_id, 'key': '<r@x>', 'from': 'a@b', 'subject': 'Re: Temat', 'date': '2026-10-30T10:00:00+00:00', 'auto': False}], 'checked': 1, 'note': ''}):
            r = self.req('/api/check-replies', {})
        self.assertEqual(r['status'], 200, r)
        self.assertTrue(r['body']['changed'])
        lead = next(l for l in web.store.get()['state']['leads'] if l['id'] == lead_id)
        self.assertEqual(lead['status'], 'REPLIED')


if __name__ == '__main__':
    unittest.main()
