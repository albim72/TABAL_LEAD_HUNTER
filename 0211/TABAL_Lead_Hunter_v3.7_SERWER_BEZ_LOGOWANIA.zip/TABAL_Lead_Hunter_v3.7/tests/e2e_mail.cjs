// TABAL Lead Hunter 3.5 — end-to-end: SMTP check in the panel, catalog link + signature, send wizard for many firms,
// sending continues after the panel is closed (TABAL 23.10 #3, #4, #5, #6, #7, #9). Run via scripts/run_e2e_mail.py.
const {chromium}=require('playwright'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),C=require('../src/core.js');
const root=path.resolve(__dirname,'..'),base=process.env.TEST_URL||'http://127.0.0.1:8765',smtpPort=process.env.SMTP_PORT,results=[],errors=[];
const today=C.today();
(async()=>{const browser=await chromium.launch({headless:true});
const ctx=await browser.newContext({viewport:{width:1440,height:1000}});let p=await ctx.newPage();
const watch=pg=>{pg.on('pageerror',e=>errors.push(e.message));pg.on('dialog',d=>d.accept());};watch(p);
async function test(name,fn){try{await fn();results.push({name,status:'PASS'});console.log('PASS '+name);}catch(e){results.push({name,status:'FAIL',error:e.message});try{await p.screenshot({path:path.join(root,'test-results/e2e-mail-failure.png'),fullPage:true});}catch{}throw e;}}
async function api(page,url,body){return page.evaluate(async({url,body})=>{const r=await fetch(url,{method:body?'POST':'GET',headers:{'Content-Type':'application/json','X-Tabal-Token':window.TABAL_SERVER.csrf},...(body?{body:JSON.stringify(body)}:{})});return {status:r.status,data:await r.json()};},{url,body});}
async function open(page){await page.goto(base);await page.locator('[data-page=leads]').waitFor();await page.waitForFunction(()=>document.querySelector('#save-status').textContent.includes('wersja'));}
async function saved(){await p.waitForFunction(()=>document.querySelector('#save-status').textContent.startsWith('Zapisano na serwerze'));}
const lead=(dom,contacts,extra={})=>{const src='https://'+dom+'/oferta',cr={};for(const k of [...C.CRITERIA,'exclusion'])cr[k]={value:'yes',evidence:'Montaż ogrodzeń aluminiowych',url:src};cr.exclusion={value:'no',evidence:'Brak własnej produkcji',url:src};
 return {company:'Firma '+dom,domain:dom,is_demo:false,region:'lubelskie',address:'ul. Długa 1, 20-001 Lublin',city:'Lublin',postal_code:'20-001',business_profile:{core_activity:'montaż i sprzedaż ogrodzeń',fit:'core'},sources:[{url:src,title:'Oferta',quote:'Montaż ogrodzeń aluminiowych w Lublinie.',checked_at:today,verified:true}],contacts,criteria:cr,...extra};};
try{
await test('01 seed: 3 firmy w Lublinie (osoba-zaopatrzeniowiec, kontakt ogólny ze starym podpisem, adres do weryfikacji)',async()=>{
 await open(p);const w=(await api(p,'/api/workspace')).data,s=w.state;
 const st=C.strategy({...s.strategies.find(x=>x.id==='aluminium'),country:'Polska',province:'lubelskie',region:'lubelskie, Polska'});s.strategies[s.strategies.findIndex(x=>x.id==='aluminium')]=st;
 const k=d=>'https://'+d+'/kontakt';
 const A=C.validateLead(lead('alfa-e2e.example',[{type:'general',email:'biuro@alfa-e2e.example',url:k('alfa-e2e.example'),quote:'biuro@alfa-e2e.example',checked_at:today,verified:true},{type:'person',name:'Ola Nowak',role:'Zaopatrzeniowiec',reason:'Zakupy materiałów',email:'o.nowak@alfa-e2e.example',url:k('alfa-e2e.example'),quote:'Ola Nowak Zaopatrzeniowiec o.nowak@alfa-e2e.example',checked_at:today,verified:true}]),s,st);
 const B=C.validateLead(lead('beta-e2e.example',[{type:'general',email:'kontakt@beta-e2e.example',url:k('beta-e2e.example'),quote:'kontakt@beta-e2e.example',checked_at:today,verified:true}],{draft:{subject:'Ogrodzenia aluminiowe — współpraca',body:'Dzień dobry,\n\nszkic z Work.\n\nPozdrawiam\nZespół TABAL'}}),s,st);
 const G=C.validateLead(lead('gamma-e2e.example',[{type:'general',email:'info@gamma-e2e.example',uncertain:true,reason:'Adres z katalogu'}]),s,st);
 s.leads=[A,B,G];const r=await api(p,'/api/workspace',{state:s,revision:w.revision});assert.equal(r.status,200,JSON.stringify(r.data));await p.reload();await p.locator('.lead-row').first().waitFor();assert.equal(await p.locator('.lead-row').count(),3);
});
await test('02 katalog produktu i sygnatura HTML ustawione w panelu',async()=>{
 await p.locator('[data-page=settings]').click();await p.locator('[data-tab=products]').click();
 await p.locator('[data-product=alu]').click();await p.locator('#product-form [name=catalog_url]').fill('https://tabal.pl/katalog-alufence.pdf');await p.locator('#product-form button[type=submit]').click();await saved();
 await p.locator('[data-tab=messages]').click();await p.locator('#messages-form [name=signature]').fill('Jędrzej Moraczewski\nOpiekun klienta | TABAL\nbok@tabal.pl');
 await p.locator('#sig-html').fill('<p><b>Jędrzej Moraczewski</b><br>Opiekun klienta | TABAL<script>alert(1)</script></p>');
 assert.ok((await p.locator('#sig-preview').innerHTML()).includes('<b>Jędrzej Moraczewski</b>'));assert.ok(!(await p.locator('#sig-preview').innerHTML()).includes('script'));
 await p.locator('#messages-form button[type=submit]').click();await saved();
 const c=(await api(p,'/api/workspace')).data.state.config;assert.ok(c.signature_html.includes('<b>Jędrzej'));assert.ok(!c.signature_html.includes('script'));
});
await test('03 Wysyłka: 993 odrzucone z wyjaśnieniem; „Sprawdź połączenie” przechodzi wszystkie kroki i wysyła test; zapis ustawień',async()=>{
 await p.locator('[data-page=mail]').click();await p.locator('#smtp-form').waitFor();
 await p.evaluate(port=>{const sel=document.querySelector('#smtp-form [name=port]');sel.insertAdjacentHTML('beforeend',`<option value="993">993</option><option value="${port}">${port}</option>`);},smtpPort);
 await p.locator('#smtp-form [name=host]').fill('localhost');await p.locator('#smtp-form [name=password]').fill('test-haslo-e2e');
 await p.locator('#smtp-form [name=port]').selectOption('993');await p.locator('#smtp-form [name=security]').selectOption('ssl');
 await p.locator('[data-action=smtp-check]').click();await p.waitForFunction(()=>{const t=document.querySelector('#smtp-diag')?.textContent||'';return t&&!t.startsWith('Sprawdzam');},null,{timeout:30000});console.log('DIAG:',await p.locator('#smtp-diag').innerText());await p.locator('#smtp-diag .diag').waitFor({timeout:2000});assert.match(await p.locator('#smtp-diag').innerText(),/port odbioru poczty/);
 await p.locator('#smtp-form [name=port]').selectOption(String(smtpPort));await p.locator('#smtp-form [name=security]').selectOption('ssl');
 await p.locator('#smtp-form [name=interval]').fill('10');await p.locator('#smtp-form [name=send_to]').fill('test-odbiorca@example.com');
 await p.locator('[data-action=smtp-check]').click();await p.locator('#smtp-diag .diag.ok').waitFor({timeout:30000});assert.match(await p.locator('#smtp-diag').innerText(),/Wiadomość testowa/);
 await p.locator('#smtp-form button[type=submit]').click();await p.waitForFunction(()=>document.querySelector('#mail-state')?.textContent.includes('nadawca bok@tabal.pl'));
});
await test('04 kreator: zaznaczenie 3 firm → odbiorca wg roli, adres do weryfikacji wymaga zatwierdzenia, podgląd z katalogiem i sygnaturą',async()=>{
 await p.locator('[data-page=leads]').click();await p.locator('#select-page').check();await p.locator('[data-action=bulk-mail]').click();await p.locator('#wizard-table').waitFor();
 assert.match(await p.locator('#wizard-table').innerText(),/Gotowe do wysyłki: 2 z 3/);
 const t=await p.locator('#wizard-table').innerText();assert.ok(t.includes('o.nowak@alfa-e2e.example'));assert.match(t,/rola: zaopatrzeniowiec/);assert.match(t,/do weryfikacji/);
 await p.locator('[data-wiz-opt=approve]').check();assert.match(await p.locator('#wizard-table').innerText(),/Gotowe do wysyłki: 3 z 3/);
 const pre=await p.locator('#wizard-table .mail-html-preview').first().innerText();assert.ok(pre.includes('Katalog — Ogrodzenia aluminiowe: https://tabal.pl/katalog-alufence.pdf'));assert.ok(pre.includes('Jędrzej Moraczewski'));
 await p.screenshot({path:path.join(root,'test-results/scenariusz-v37-kreator-wysylki.png'),fullPage:true});
});
await test('05 „Zatwierdź i wyślij” → kolejka na serwerze, zaznaczenie wyczyszczone, panel zamknięty w trakcie wysyłki',async()=>{
 await p.locator('#wizard-apply').click();
 let n=0;for(let i=0;i<40&&!n;i++){await p.waitForTimeout(500);const x=(await api(p,'/api/state')).data;n=x.unattended||x.jobs.some(j=>j.kind!=='test'&&j.status==='sent')?1:0;}
 if(!n)console.log('DEBUG alert:',await p.locator('#mail-alert').innerText(),'| toast:',await p.locator('#toast').innerText());
 const st=(await api(p,'/api/state')).data;assert.equal(st.jobs.filter(j=>j.kind!=='test').length,3);assert.equal(st.unattended,true);
 const leads=(await api(p,'/api/workspace')).data.state.leads;assert.ok(leads.every(l=>l.status==='TO_CONTACT'||l.status==='CONTACTED'));
 assert.ok(leads.find(l=>l.domain==='gamma-e2e.example').contacts[0].operator_ok);
 await p.close();
});
await test('06 po zamknięciu panelu: 3 wiadomości wysłane, statusy SKONTAKTOWANY, wpisy w historii',async()=>{
 await new Promise(r=>setTimeout(r,32000));p=await ctx.newPage();watch(p);await open(p);
 let st;for(let i=0;i<30;i++){st=(await api(p,'/api/state')).data;if(st.jobs.filter(j=>j.kind!=='test'&&j.status==='sent').length===3)break;await new Promise(r=>setTimeout(r,2000));}
 assert.equal(st.jobs.filter(j=>j.kind!=='test'&&j.status==='sent').length,3,JSON.stringify(st.jobs.map(j=>[j.to,j.status,j.error])));
 await p.waitForTimeout(500);const leads=(await api(p,'/api/workspace')).data.state.leads;
 assert.ok(leads.every(l=>l.status==='CONTACTED'),JSON.stringify(leads.map(l=>l.status)));assert.ok(leads.every(l=>l.history.some(h=>h.action==='EMAIL_SENT')));
 await p.locator('[data-page=mail]').click();await p.locator('#mail-jobs details').first().waitFor();await p.screenshot({path:path.join(root,'test-results/scenariusz-v37-kolejka.png'),fullPage:true});
 assert.equal(await p.locator('.lead-row input:checked').count(),0);
});
await test('07 [3.7] profil osoby z logo z pliku → „Podpisuję jako” w tej przeglądarce',async()=>{
 await p.locator('[data-page=settings]').click();await p.locator('[data-tab=profiles]').click();await p.locator('[data-action=profile-add]').click();
 await p.locator('#profile-form [name=name]').fill('Anna Testowa');await p.locator('#profile-form [name=position]').fill('Opiekun klienta');await p.locator('#profile-form [name=sender_name]').fill('Anna Testowa | TABAL');await p.locator('#profile-form [name=sf_phone]').fill('81 000 00 00');
 const png=Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==','base64');
 await p.locator('#profile-form .sig-logo-file').setInputFiles({name:'logo.png',mimeType:'image/png',buffer:png});await p.locator('#profile-sig-build').click();
 await p.waitForFunction(()=>document.querySelector('#profile-sig-preview img')?.src.startsWith('data:image/png'));
 await p.locator('#profile-form button[type=submit]').click();await saved();
 assert.equal(await p.locator('#profile-pick').inputValue(),(await api(p,'/api/workspace')).data.state.config.profiles[0].id);
 await p.screenshot({path:path.join(root,'test-results/scenariusz-v37-profile.png'),fullPage:true});
});
await test('08 [3.7] brak odpowiedzi przez 4 dni → powiadomienie → przypomnienia (Re:, ten sam wątek, podpis z profilu)',async()=>{
 const w=(await api(p,'/api/workspace')).data;for(const l of w.state.leads)for(const e of l.mail_events)e.sent_at=new Date(Date.now()-4*86400000).toISOString();
 assert.equal((await api(p,'/api/workspace',{state:w.state,revision:w.revision})).status,200);await open(p);
 const notice=await p.locator('.notice.reminder').innerText();assert.match(notice,/3 firm nie odpowiedziało od 3 dni/);
 await p.locator('.notice.reminder [data-action=go-followups]').click();await p.locator('#wizard-table').waitFor();
 const t=await p.locator('#wizard-table').innerText();assert.match(t,/Gotowe do wysyłki: 3 z 3/);assert.match(t,/przypomnienie nr 1/);assert.match(t,/DW: biuro@alfa-e2e\.example/);
 const prev=await p.locator('#wizard-table .mail-html-preview').first().innerText();assert.match(prev,/uprzejmie przypominam/);assert.match(prev,/Anna Testowa/);
 await p.screenshot({path:path.join(root,'test-results/scenariusz-v37-przypomnienia.png'),fullPage:true});
 await p.locator('#wizard-apply').click();
 let st;for(let i=0;i<40;i++){st=(await api(p,'/api/state')).data;if(st.jobs.filter(j=>j.kind==='followup'&&j.status==='sent').length===3)break;await new Promise(r=>setTimeout(r,2000));}
 assert.equal(st.jobs.filter(j=>j.kind==='followup'&&j.status==='sent').length,3,JSON.stringify(st.jobs.map(j=>[j.kind,j.to,j.status,j.error])));
 await p.waitForTimeout(500);const leads=(await api(p,'/api/workspace')).data.state.leads;assert.ok(leads.every(l=>l.history.some(h=>h.action==='EMAIL_FOLLOWUP')));assert.ok(leads.every(l=>l.status==='CONTACTED'));
 await open(p);assert.equal(await p.locator('.notice.reminder').count(),0,'no reminder after the reminder was sent');
});
}finally{fs.writeFileSync(path.join(root,'test-results/e2e-mail-v37.json'),JSON.stringify({browser:browser.version(),at:new Date().toISOString(),results,errors},null,2));await browser.close();}
if(errors.length){console.log('PAGE ERRORS',errors);process.exitCode=1;}
})().catch(e=>{console.error(e);process.exitCode=1;});
