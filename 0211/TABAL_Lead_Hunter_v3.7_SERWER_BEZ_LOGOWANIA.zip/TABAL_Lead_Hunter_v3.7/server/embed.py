"""3.7 (TABAL 2.11 #7): embeds signature images. Remote images (http/https) are downloaded once by the server and
stored as data: URIs, then sent as inline attachments (cid:). Result: the logo shows in Outlook / Gmail / Thunderbird
without "show images", and in the panel preview. Only public addresses, ports 80/443, images up to 500 kB, 15 images."""
import base64, ipaddress, re, socket, urllib.request
from urllib.parse import urlsplit

MAX_IMAGE = 500_000
TYPES = {'image/png': 'png', 'image/jpeg': 'jpeg', 'image/jpg': 'jpeg', 'image/gif': 'gif', 'image/webp': 'webp'}
SRC = re.compile(r'(<img\b[^>]*?\bsrc\s*=\s*)(["\'])(.*?)\2', re.I | re.S)


def _public(host):
    try:
        infos = socket.getaddrinfo(host, None)
    except OSError:
        return False
    for info in infos:
        ip = ipaddress.ip_address(info[4][0])
        if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved or ip.is_multicast or ip.is_unspecified:
            return False
    return bool(infos)


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        u = urlsplit(newurl)
        if u.scheme not in ('http', 'https') or not u.hostname or not _public(u.hostname):
            return None
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def fetch_image(url, opener=None):
    u = urlsplit(url)
    if u.scheme not in ('http', 'https') or not u.hostname or (u.port and u.port not in (80, 443)):
        raise ValueError('adres obrazu musi być http(s) na standardowym porcie')
    if not opener and not _public(u.hostname):
        raise ValueError('adres prywatny lub nieosiągalny')
    op = opener or urllib.request.build_opener(_NoRedirect)
    req = urllib.request.Request(url, headers={'User-Agent': 'TABAL-Lead-Hunter/3.7 (signature image)'})
    with op.open(req, timeout=10) as r:
        ctype = (r.headers.get('Content-Type') or '').split(';')[0].strip().lower()
        if ctype not in TYPES:
            raise ValueError('to nie jest obraz PNG/JPG/GIF/WEBP')
        data = r.read(MAX_IMAGE + 1)
    if len(data) > MAX_IMAGE:
        raise ValueError('obraz większy niż 500 kB — zmniejsz logo')
    return f'data:image/{TYPES[ctype]};base64,' + base64.b64encode(data).decode()


def embed_html(html, opener=None):
    report = {'embedded': 0, 'failed': [], 'unavailable': 0}
    count = [0]

    def sub(m):
        src = m.group(3).strip()
        low = src.lower()
        if low.startswith('data:image/'):
            return m.group(0)
        if low.startswith(('cid:', 'file:', 'blob:')) or not low.startswith(('http://', 'https://')):
            report['unavailable'] += 1
            return m.group(0)
        if count[0] >= 15:
            report['failed'].append({'src': src[:200], 'error': 'limit 15 obrazów'})
            return m.group(0)
        count[0] += 1
        try:
            data = fetch_image(src.replace('&amp;', '&'), opener)
            report['embedded'] += 1
            return m.group(1) + m.group(2) + data + m.group(2)
        except Exception as e:
            report['failed'].append({'src': src[:200], 'error': str(e)[:200] if isinstance(e, ValueError) else type(e).__name__})
            return m.group(0)
    report['html'] = SRC.sub(sub, html or '')
    return report
