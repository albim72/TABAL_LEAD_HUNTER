# TABAL Lead Hunter 3.4 — zmiany według uwag z 21.10.2026

Wydanie: 22 października 2026. Aktualizacja wersji serwerowej 3.3 (bez logowania). Dane z 3.1–3.3 wczytują się automatycznie — statusy, notatki, historia, projekty i kampanie zostają.

## Uwagi TABAL → co zrobiono

### 1. Kontakty — e-mail i telefon jako dwa osobne kontakty
- **Przyczyna:** zadanie 3.3 kazało Work zapisywać „każdy telefon i e-mail jako osobny kontakt”, a lista leadów pokazywała tylko najlepszy z nich.
- **Scalanie w aplikacji:** e-mail i telefon tego samego biura / oddziału albo tej samej osoby są łączone w **jeden kontakt** — przy imporcie, przy uzupełnianiu w Work i automatycznie dla leadów już zapisanych (przy pierwszym otwarciu 3.4). Na karcie: „Scalono 2 wpisy z researchu w jeden kontakt”.
- **Osobno zostają tylko:** inna osoba, inny oddział, drugi, inny adres e-mail lub numer.
- **Bez utraty ostrożności:** gdy telefon pochodzi z niepotwierdzonego źródła (np. tylko katalog), a e-mail jest potwierdzony — kontakt jest jeden, e-mail ✓, telefon z oznaczeniem „do weryfikacji”.
- **Lista leadów i karta:** kolumna Kontakt pokazuje e-mail i telefon razem. Gdy osoba ma tylko e-mail, obok pojawia się telefon ogólny firmy z dopiskiem „(ogólny)”. Ten sam komplet trafia do eksportu CSV / JSON.
- **Zadanie dla Work:** „JEDEN KONTAKT = JEDNA OSOBA LUB JEDNO BIURO” — e-mail i telefon w jednym obiekcie.

### 2. Uzupełnianie kontaktów — eksport ucięty na 31 firmach
- **Przyczyna (błąd aplikacji):** lista firm w zadaniu była obcinana do 6000 znaków. Przy 50 firmach mieściło się ok. 31 wierszy, a 32. urywał się w połowie identyfikatora (`lead_ref=4c5cde01-7466-4`). Dokładnie to zgłosił Work.
- **Naprawa:** lista nie jest już ucinana (aplikacja dodatkowo sprawdza, że do zadania trafiły wszystkie zaznaczone firmy).
- **Paczki:** duża lista jest dzielona na **paczki po 15 firm** (ustawienie: Profil i źródła → Scoring → „Firm w jednym zadaniu uzupełniania”). Mniejsza paczka = Work nie ucina pliku wynikowego i kończy szybciej. Wszystkie paczki są przygotowane od razu, z osobnymi `batch_id`.
- **Zadanie wymaga rekordu dla każdej firmy** z listy („KONIEC LISTY FIRM”). Jeśli Work mimo to pominie firmy, „Przygotuj zadanie uzupełniające” zawiera **dokładnie brakujące** (po `lead_ref`).
- Z zadania uzupełniania usunięto listę wszystkich znanych firm z bazy (zbędna przy wskazanych firmach, wydłużała zadanie).

### 3. Czas wyszukiwania (50 firm ≈ 30 min)
- Czas zajmuje research w Work (otwieranie stron, CEIDG/KRS, katalogi) — nie kod aplikacji. Przyspieszenie bez obcinania zakresu daje **równoległość**:
  - **Odkrywanie:** „Zadania równoległe w Work: 2–6”. Obszar jest dzielony na rozłączne części (miejscowości / gminy; dla jednego miasta — frazy). Każda część to osobny czat Work uruchomiony w tym samym czasie. Cel jest dzielony między części. 3 części ≈ 3× krócej.
  - **Uzupełnianie kontaktów:** paczki po 15 firm uruchamiane równolegle — 50 firm = 4 czaty naraz.
- Zakres researchu się nie zmienia (te same źródła i pola). Jedyna oszczędność w treści zadania: pogłębione szukanie kontaktów kończy się dla firmy, gdy ma już potwierdzony e-mail i telefon.
- Wyniki importuje się kolejno (każdy plik ma swój `batch_id`); duplikaty między częściami są scalane.
- Domyślnie 1 zadanie (jak dotąd) — liczbę ustawia się w formularzu kampanii albo domyślnie w Profil i źródła → Scoring.

### 4. Wyniki poniżej progu 65/100
- **Podgląd importu** pokazuje: „Spełnia próg 65/100: X z Y nowych firm” i listę najsłabszych.
- **Firmy poniżej progu trafiają od razu do archiwum** (domyślnie; można odznaczyć w podglądzie). Nie zaśmiecają listy leadów, Work nie zwróci ich ponownie jako nowych, można je przywrócić (filtr „Wszystkie, także archiwum i usunięte”). Historia karty: „Poniżej progu przy imporcie: 20/100”.
- **Cel kampanii liczy tylko firmy ≥ progu.** Przy celu 25 i 4 dobrych wynikach: „4 z 25 — brakuje 21”.
- **Komunikat o wyczerpaniu:** gdy Work zgłasza wyczerpanie obszaru albo większość wyników jest słaba — „Brak kolejnych dobrze dopasowanych firm w tym obszarze… poszerz promień, dodaj sąsiednie województwo albo zmień frazy” zamiast kolejnych słabych leadów.
- **Zadanie dla Work:** „JAKOŚĆ ZAMIAST LICZBY” — cel to górna granica; zwróć mniej firm i `stop_reason: pool_exhausted`, zamiast dopełniać słabymi.

### SMTP (bok@tabal.pl)
- Kod wysyłki bez zmian (gotowy od 3.2). Nowy **`scripts/smtp_diag.py`** — sprawdza krok po kroku: DNS, porty 465/587, certyfikat TLS (czy pasuje do nazwy hosta — najczęstszy problem na hostingu), AUTH, logowanie, wiadomość testową. Hasła nie wypisuje ani nie zapisuje. Na końcu podaje gotowe wpisy do `.env`.
- Szczegóły i lista do sprawdzenia: `docs/SPOTKANIE_TABAL_22-10-2026.md`.

## Ustawienia nowe w 3.4 (Profil i źródła → Scoring → „Import i tempo”)
- **Firmy poniżej progu z nowego wyszukiwania odkładaj do archiwum** (domyślnie: tak).
- **Firm w jednym zadaniu uzupełniania** (domyślnie 15).
- **Domyślna liczba zadań równoległych** (domyślnie 1).

## Aktualizacja z 3.3
1. W 3.3 pobierz **Kopię JSON**; zatrzymaj serwer; zachowaj katalog `.runtime` (lub wolumen Docker) i plik `.env`.
2. Rozpakuj 3.4, przenieś `.runtime` i `.env` do nowego katalogu (Docker: ten sam projekt Compose i wolumen, `docker compose up -d --build`, **bez** `down -v`).
3. Uruchom: `python3 serve.py` / `URUCHOM_WINDOWS.bat` / Docker. W menu: „WERSJA 3.4”.
4. Leady z 3.3: kontakty scalą się przy pierwszym wczytaniu. Kampanie z 3.3 liczą postęp jak dotąd; nowe kampanie liczą tylko firmy ≥ progu.
5. Zadanie uzupełniania przygotowane w 3.3 (ucięte) — nie używaj go. Zaznacz firmy ponownie → „Uzupełnij kontakty w Work”.

Przykłady zadań: `docs/PRZYKLAD_ZADANIA_UZUPELNIENIE_PACZKA_1_z_4_v3.4.txt`, `docs/PRZYKLAD_ZADANIA_LUBELSKIE_ALU_CZESC_1_z_3_v3.4.txt`.

## Granice
Panel nadal nie wyszukuje sam — research wykonuje ChatGPT Work według zadania, a wynik się importuje. Równoległość skraca czas oczekiwania, ale wymaga uruchomienia kilku czatów Work i zaimportowania każdego wyniku. Testy wykonano na danych syntetycznych i lokalnym serwerze SMTP z TLS; nie uruchamiano rzeczywistego researchu w Work ani wysyłki z bok@tabal.pl.
