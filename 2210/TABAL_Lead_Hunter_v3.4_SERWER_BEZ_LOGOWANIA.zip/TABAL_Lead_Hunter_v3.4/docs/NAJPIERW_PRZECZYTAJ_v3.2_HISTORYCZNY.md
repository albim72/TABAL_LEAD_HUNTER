# TABAL Lead Hunter 3.2 — zmiany według uwag z 9.10.2026

Wydanie: 13 października 2026. Aktualizacja wersji serwerowej 3.1 (bez logowania). Dane z 3.1 wczytują się automatycznie.

## Najważniejsze: zniesione limity 20 / 100

| Było w 3.1 | Jest w 3.2 |
|---|---|
| Cel kampanii 1–100 | Cel 1–10 000 **albo „Bez limitu”** (wszystkie firmy z obszaru) |
| Partia 1–50, domyślnie 20; każda partia ręcznie | **Domyślnie cała pula w jednym zadaniu Work**; partie tylko opcjonalnie |
| 12 zapytań na partię | Pełny plan: każda fraza × każde miasto, potem gminy wiejskie, z kontrolą pokrycia po powiatach |
| Pełny plan tylko dla lubelskiego (24 punkty); inne województwa — sam napis, np. „mazowieckie” | **Wszystkie 16 województw** z oficjalnego rejestru TERYT GUS: łącznie 1026 miast, 1290 gmin wiejskich i 380 powiatów (lubelskie: 58 miast, 137 gmin, 24 powiaty) |
| Baza do 2000 firm, import do 10 MB | Baza do 10 000 firm, import do 50 MB |
| Uzupełnianie danych maks. 100 firm | Bez tego limitu |

Kolejne zadanie („Przygotuj zadanie uzupełniające”) jest potrzebne tylko, gdy Work sam przerwie pracę (limit czasu lub narzędzi) — licznik kampanii jest zachowany. Przykłady pełnych zadań: `docs/PRZYKLAD_ZADANIA_LUBELSKIE_BEZ_LIMITU_v3.2.txt`, `docs/PRZYKLAD_ZADANIA_MAZOWIECKIE_BEZ_LIMITU_v3.2.txt`. Pokrycie każdego województwa: `docs/POKRYCIE_WOJEWODZTW_v3.2.md`.

## Uwagi TABAL → co zrobiono

### Projekty i obsługa leadów
- **Filtrowanie projektów według daty** — zakładka *02 Projekty*: data utworzenia lub ostatniej zmiany, od–do, wyszukiwarka.
- **Archiwizacja i wczytywanie** — projekt można zarchiwizować i wczytać z archiwum; dodatkowo „Plik projektu” (JSON) i „Wczytaj projekt z pliku” — firmy już istniejące nie dublują się.
- **Usuwanie leadów z projektu** — na liście (zaznacz → „Usuń z tego projektu”) i na karcie firmy.
- **Wiele strategii w jednym projekcie** — przy starcie kampanii wybierasz istniejący projekt; można też łączyć projekty („Połącz…”). Każda dotychczasowa kampania 3.1 stała się projektem.
- **Sortowanie i paginacja** — sortowanie (scoring, ostatnia edycja, data wykrycia, nazwa, miejscowość, status; także kliknięciem w nagłówek) i 20 / 50 / 100 na stronie.
- **Pełna liczba wyników** — patrz wyżej.
- **Data ostatniej edycji leada** — kolumna „Ostatnia edycja” w panelu głównym i na karcie.
- **Kolorowe statusy** — kropka: zielony nowy, żółty w trakcie obsługi, niebieski skontaktowano się, fioletowy szansa, czerwony odrzucony, szary zarchiwizowany, czarny usunięty. Nowe statusy ZARCHIWIZOWANY i USUNIĘTY; operacje zbiorcze (zmiana statusu, archiwizacja, usunięcie, przywrócenie, trwałe usunięcie).
- **Automatyczna archiwizacja** — odrzucone po 30 dniach bez zmian (ustawialne); opcjonalnie nowe bez obsługi po N dniach.
- **Formaty pod NoSQL** — eksport JSON (kolekcje leads / projects / strategies / products z `_id`) i JSON Lines (jeden dokument w wierszu, np. pod `mongoimport`), plus CSV.

### Strategie i wyszukiwanie
- **Miasto + promień (km)** — w całej Polsce oraz na Słowacji i w Czechach aplikacja sama dobiera miasta i gminy w promieniu (współrzędne GeoNames, przybliżone).
- **Kraj jako lokalizacja** — Polska, Słowacja, Czechy, Niemcy… lub dowolny wpisany; poza Polską województwa są zablokowane, frazy dla SK/CZ w języku lokalnym, a plan obejmuje miejscowości SK/CZ (cały kraj albo wybrany kraj/region, np. „Jihomoravský kraj”).
- **Kompletność** — dla każdego województwa wszystkie miasta i gminy wiejskie z rejestru TERYT, kontrola po powiatach, wskazanie katalogów z adresem, map, CEIDG/KRS, Facebooka i stron gmin.
- **Dane adresowe** — Work zwraca `address`, `city`, `postal_code`; lokalizację potwierdza adresem; wyszukiwarka leadów przeszukuje adresy.
- **Opis produktów z tabal.pl** — opisy 7 grup (Techfence, Alufence, systemy konstrukcyjne, konstrukcje budowlane, hurtownia, tablice, waterjet) i oferta firmy; zadanie zawiera `product_description`, `product_url` i `company_url: https://tabal.pl/`. Przycisk „Uzupełnij opisy z tabal.pl”.
- **Typ klienta na liście leadów** — pole `client_type` z researchu (lub z profilu strategii).

### Kontakty
- **Naprawa: kontakty nie trafiały na kartę.** Przyczyny w 3.1: (1) dane z ponownego researchu znanej firmy szły tylko do historii, (2) schemat w zadaniu miał pusty `contacts: []` bez struktury, (3) inne nazwy pól (np. `position`, `mail`) i błędny e-mail odrzucały kontakt lub całą firmę, (4) niepotwierdzony e-mail był ukrywany jako „Brak potwierdzonego e-maila”. Teraz: nowe kontakty, adres i brakujące kryteria są dopisywane do głównej karty (status i notatki zostają), zadanie ma pełny wzór kontaktu, pola są rozpoznawane tolerancyjnie, a dane są zawsze widoczne z oznaczeniem.
- **Karta kontaktu** pokazuje nazwę firmy oraz imię i nazwisko osoby (jeśli ustalona).
- **Kontakt ogólny** — Work zawsze zwraca ogólny kontakt firmy; gdy brak osoby, karta to wyraźnie mówi.
- **Kontakty niepewne** — dopuszczone (ustawienie), oznaczone „WYMAGA WERYFIKACJI” z powodem; nie są używane do wysyłki SMTP, dopóki nie zostaną potwierdzone.

### Scoring i kwalifikacja
- **Równe wagi** domyślnie (wagi 3.1 zmieniono tylko tam, gdzie były domyślne) + przycisk „Ustaw równe wagi”.
- **Dodatkowe kryteria** liczone i przekazywane do Work tylko po zaznaczeniu w strategii.
- **Częściowe dopasowanie** — oznaczenia ✓ / ½ / ? / ✗ przy każdym kryterium; niezgodne na czerwono (np. produkt ✓, segment ✗).
- **Scoring kontaktu**: 10/10 potwierdzona osoba, 7/10 potwierdzony kontakt ogólny, 5/10 do weryfikacji, 0 brak.
- **Spójność i uzasadnienie** — „Dlaczego X pkt?” przy każdej firmie; konkretne powody (np. „URL dowodu nie występuje na liście źródeł”, „strona nieaktualizowana od 2023 r.”); TAK z niepełnym dowodem = połowa punktów zamiast 0 bez wyjaśnienia; adresy różniące się `www` lub ukośnikiem są tym samym dowodem.

### Aktualność i szybkość
- **Aktualne źródła** — Work podaje `updated_year` i `active_status`; strona nieaktualizowana > 2 lata (ustawialne) nie potwierdza działalności; zadanie wprost odrzuca źródła typu „2013–2023”.
- **GPT-6.1 Sol, tryb średni (Work)** — rekomendacja w panelu; zadanie jest zwięźlejsze (zwarta lista znanych firm, plan jako macierz). Czasu i jakości w Work nie dało się zmierzyć z tego środowiska — porównajcie średni i wysoki na tej samej strategii.

### Wysyłka
- **SMTP z bok@tabal.pl** — nadawca, login i nazwa domyślnie `bok@tabal.pl`. Administrator wpisuje w `.env`: `TABAL_SMTP_HOST` (serwer poczty TABAL) i opcjonalnie `TABAL_SMTP_PASSWORD`; wtedy wysyłka jest skonfigurowana od startu. Bez hasła w `.env` hasło wpisuje się w zakładce Wysyłka (tylko w pamięci serwera). **Host SMTP i hasło musi podać administrator poczty TABAL.**

## Aktualizacja z 3.1
1. W 3.1 pobierz **Kopię JSON**; zatrzymaj serwer; zachowaj katalog `.runtime` (lub wolumen Docker).
2. Rozpakuj 3.2, przenieś `.runtime` do nowego katalogu (Docker: ten sam projekt Compose i wolumen, `docker compose up -d --build`, **bez** `down -v`).
3. Uzupełnij `.env` (SMTP bok@tabal.pl). Uruchom: `python3 serve.py` / `URUCHOM_WINDOWS.bat` / Docker.
4. W menu powinno być „WERSJA 3.2”. Sprawdź zakładkę Projekty i Profil → Produkty.

## Granice
Panel nadal nie wyszukuje sam — wyszukiwanie wykonuje ChatGPT Work, a wynik się importuje. „Bez limitu” oznacza brak sztucznego limitu w aplikacji i polecenie zebrania pełnej puli, nie gwarancję, że Work w jednej sesji znajdzie każdą firmę w województwie. Testy wykonano na danych syntetycznych; nie uruchamiano rzeczywistego researchu w Work ani wysyłki z bok@tabal.pl.
