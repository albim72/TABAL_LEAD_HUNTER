# TABAL Lead Hunter 3.3 — zmiany według uwag z 14.10.2026

Wydanie: 19 października 2026. Aktualizacja wersji serwerowej 3.2 (bez logowania). Dane z 3.1 i 3.2 wczytują się automatycznie — statusy, notatki, historia i projekty zostają.

## Uwagi TABAL → co zrobiono

### 1. Trafność wyszukiwanych firm (np. steelove.pl — meble, ulankomarów.pl — pielęgnacja ogrodów)
- **Profil działalności.** Work musi ustalić *główną* działalność firmy z jej oferty, a nie z pojedynczego hasła („montaż ogrodzeń” na liście usług firmy meblowej). Każda firma dostaje ocenę: **zgodny / pokrewny / niezgodny**.
- **Firmy niezgodne nie trafiają do leadów** — Work wpisuje je na listę „odrzucone” z powodem, a podgląd importu ją pokazuje. Gdy niezgodna firma jednak trafi do bazy, scoring ją blokuje: 0 pkt za produkt, segment i klienta oraz kara −40 (ustawialna).
- Zadanie zawiera przykłady dla danej strategii: co jest pokrewne (ogrodzenia panelowe, bramy, automatyka bram, kowalstwo…), a co niezgodne (meble, pielęgnacja ogrodów, koszenie, architektura krajobrazu bez ogrodzeń…).
- **Portal → własna strona.** Firma znaleziona na Oferteo, Panorama Firm, PKT, Aleo, Google Maps lub Facebooku: Work musi znaleźć jej własną stronę, potwierdzić na niej ofertę i kontakty, a wynik zapisać (`website_check`). Kategorie zleceń z Oferteo nie są dowodem oferty. Lead potwierdzony tylko w katalogu dostaje połowę punktów za źródło i ostrzeżenie na karcie.

### 2. Wyszukiwanie i uzupełnianie kontaktów
- **Osoba + kontakt ogólny.** Work szuka osoby (właściciel z CEIDG, zarząd z KRS, osoba z podstrony Kontakt / Zespół) i zawsze zapisuje kontakt ogólny. **Kontakt ogólny jest pełnowartościowy**: 8/10 zamiast 7/10, oznaczony jako „wystarczający”, bez ostrzeżenia.
- **Oddział najbliżej TABAL.** Przy kilku oddziałach Work podaje jako główny adres i pierwsze kontakty oddział najbliższy TABAL (Lublin — wg tabal.pl/kontakt). Aplikacja liczy odległość sama, pokazuje „Oddział najbliżej TABAL” na karcie i preferuje kontakt z tego oddziału. Lokalizacje TABAL można zmienić: Profil i źródła → Wiadomości i podpis.
- **Zbiorcze uzupełnianie w Work.** Na liście leadów zaznacz kilka firm → **„Uzupełnij kontakty w Work”** — jedno zadanie dla wszystkich (także z różnych strategii). Każda firma ma w zadaniu `lead_ref`, więc wynik trafia na właściwą kartę, nawet gdy Work znajdzie nową domenę firmy z katalogu.
- **Profile społecznościowe.** Publiczne dane z oficjalnych profili firmy (Facebook — zakładka Informacje, Instagram, LinkedIn firmy, YouTube) — tylko przy potwierdzonym powiązaniu z firmą (link na stronie albo zgodny adres / telefon / NIP). Bez potwierdzenia kontakt jest oznaczony „do weryfikacji”. Bez danych z prywatnych profili i grup.

### 3. Prośba Grzegorza: firmy niepewne / bez kontaktów — mocniejsze przeszukiwanie, telefony i maile, CEIDG i KRS
- **Pogłębione wyszukiwanie kontaktów** w każdym zadaniu: strona (Kontakt, stopka, O nas, Regulamin, **polityka prywatności / RODO**, PDF), **CEIDG** (telefon, e-mail, www, właściciel), **KRS / rejestr.io** (zarząd, adres), Google Maps, Facebook, katalogi, wyszukiwanie po NIP i numerze telefonu. Każdy znaleziony telefon i e-mail zapisywany osobno; niepotwierdzone oznaczone z powodem.
- **Drugie przejście** w odkrywaniu: przed zwróceniem pliku Work wraca do firm bez e-maila i telefonu.
- **Przycisk „Pogłęb kontakty”** na liście leadów: jedno zadanie dla wszystkich widocznych firm bez kontaktu lub z kontaktem niepewnym. Ten sam przycisk jest w panelu kampanii. Nowy filtr: „Brak kontaktu lub kontakt niepewny”.
- **CEIDG / KRS dla każdej firmy:** status (aktywna / zawieszona / wykreślona), NIP, REGON, KRS, właściciel lub zarząd, link do wpisu. NIP z rejestru uzupełnia kartę; firma zawieszona lub wykreślona jest blokowana. CEIDG i KRS służą też do wyszukiwania kandydatów.

### 4. Punktacja za produkt i kategorię „Klient”
- **Oferta pokrewna (≈).** Firma ogrodzeniowa bez ogrodzeń aluminiowych nie dostaje już 0 pkt za produkt: dostaje 50% punktów (ustawialne) z opisem „potencjalny partner do rozszerzenia oferty”. Działa też dla leadów już zapisanych w bazie — wystarczy potwierdzony segment lub profil działalności. Oferta pokrewna nie blokuje kwalifikacji. Nowy filtr: „Oferta pokrewna (rozszerzenie)”.
- **Rozróżnienie zachowane:** ta sama branża = pokrewna; inna główna działalność = niezgodna (0 pkt i blokada).
- **„Klient” liczy się tylko w branży strategii.** Firma spoza branży (np. meble) ma 0 pkt za typ klienta, nawet jeśli Work napisał „firma montażowa”. Gdy branża nie jest potwierdzona — połowa punktów. Firma ogrodzeniowa z potwierdzonym typem klienta jest zawsze wyżej niż firma spoza branży.

### 5. Treść wiadomości
- **Nowy szkic lokalny** — 60–120 słów: konkretny powód kontaktu własnymi słowami („kontaktuję się, ponieważ X zajmuje się montażem ogrodzeń panelowych…”), **jeden** element oferty TABAL dopasowany do odbiorcy, korzyść i jedno pytanie. Bez cytatów ze strony, bez opisu TABAL i bez oddziałów. Dla oferty pokrewnej — propozycja poszerzenia oferty.
- **Szkice z Work są czyszczone przy imporcie:** usuwane są zdania typu „Na stronie X znalazłem informację: »…«”, „według strony…”, „przed wysyłką potwierdź aktualność informacji”, „Źródło: …”. Usunięte fragmenty trafiają do pola „Uwagi dla operatora (nie trafiają do wiadomości)”.
- **Kontrola szkicu na karcie:** ostrzeżenie, gdy treść brzmi automatycznie (cytat, uwaga robocza, lista oddziałów, za długa).
- **Oferta TABAL** przekazywana do Work to kontekst, nie tekst do wklejenia. Usunięto z niej niepotwierdzoną listę oddziałów (Radom, Zamość, Siedlce, Olsztyn — strona tabal.pl/kontakt podaje tylko adresy w Lublinie) i adnotację roboczą. Każdy produkt ma krótkie „zdanie do wiadomości” (Profil i źródła → Produkty).
- Zadanie dla Work ma twarde zasady pisania: trzy krótkie akapity, zakaz cytowania strony odbiorcy, wklejania opisu TABAL i uwag roboczych; wszystko do sprawdzenia trafia do `draft.notes`.

### 6. Wysyłka SMTP z bok@tabal.pl
Bez zmian w kodzie — konfiguracja jest gotowa od 3.2. **Do uruchomienia potrzebne są od administratora poczty TABAL: host serwera SMTP (i port: 465 SSL albo 587 STARTTLS) oraz hasło skrzynki bok@tabal.pl.** Wpis w `.env`: `TABAL_SMTP_HOST`, `TABAL_SMTP_PORT`, `TABAL_SMTP_SECURITY`, opcjonalnie `TABAL_SMTP_PASSWORD` — albo hasło w zakładce Wysyłka. Po wpisaniu: przycisk „Wiadomość testowa”.

## Ustawienia nowe w 3.3
- Profil i źródła → Scoring: **Oferta / profil pokrewny — % punktów** (domyślnie 50), **Kara: niezgodny profil działalności** (domyślnie 40).
- Profil i źródła → Wiadomości i podpis: **Lokalizacje TABAL** (domyślnie Lublin).
- Profil i źródła → Produkty: **Element oferty do wiadomości** dla każdej grupy.

## Aktualizacja z 3.2
1. W 3.2 pobierz **Kopię JSON**; zatrzymaj serwer; zachowaj katalog `.runtime` (lub wolumen Docker).
2. Rozpakuj 3.3, przenieś `.runtime` do nowego katalogu (Docker: ten sam projekt Compose i wolumen, `docker compose up -d --build`, **bez** `down -v`).
3. Uruchom: `python3 serve.py` / `URUCHOM_WINDOWS.bat` / Docker. W menu powinno być „WERSJA 3.3”.
4. Leady zapisane w 3.2 od razu korzystają z nowego scoringu (oferta pokrewna, reguła „Klient”, kontakt ogólny 8/10). Profil działalności, rejestry i oddziały pojawią się po uzupełnieniu w Work — najprościej: filtr projektu → zaznacz stronę → „Uzupełnij kontakty w Work”.

Przykłady zadań: `docs/PRZYKLAD_ZADANIA_LUBELSKIE_ALU_v3.3.txt` (odkrywanie, ogrodzenia aluminiowe, lubelskie) i `docs/PRZYKLAD_ZADANIA_UZUPELNIENIE_KONTAKTOW_v3.3.txt` (uzupełnianie wskazanych firm).

## Granice
Panel nadal nie wyszukuje sam — research wykonuje ChatGPT Work według zadania, a wynik się importuje. Trafność i liczba kontaktów zależą od tego, jak dokładnie Work wykona zadanie; aplikacja wymusza strukturę, pokazuje braki i blokuje leady niezgodne. Zadanie 3.3 jest dłuższe (ok. 20 tys. znaków) i wymaga więcej pracy od Work — przy dużych obszarach Work częściej zakończy przed wyczerpaniem puli; wtedy „Przygotuj zadanie uzupełniające”. Testy wykonano na danych syntetycznych; nie uruchamiano rzeczywistego researchu w Work ani wysyłki z bok@tabal.pl.
