# TABAL Lead Hunter 3.2 — raport weryfikacji

Data: 13 października 2026. Testy lokalne na danych syntetycznych, izolowana baza testowa.

| Zakres | Wynik | Plik |
|---|---:|---|
| Logika (testy 3.0/3.1 + 23 nowe testy 3.2) | 96/96 PASS | `test-results/core-v32.tap` |
| Serwer: API, zapis, konflikty, kolejka SMTP | 15/15 + 26/26 PASS | `test-results/server-v32.txt` |
| SMTP bok@tabal.pl z .env, brak wycieku hasła | 3/3 PASS | `test-results/smtp-env-v32.txt` |
| Restart Gunicorn i kopia baz | 2/2 PASS | `test-results/deployment-v32.txt` |
| Chromium (Playwright): komputer i telefon 390 px | 29/29 PASS, 0 błędów JS | `test-results/browser-v32.json` |

## Nowe scenariusze 3.2
1. Cel 0 = bez limitu, cele > 100 (np. 5000), partia 0 = cała pula; odrzucenie wartości poza zakresem.
2. Lubelskie bez limitu: jedno zadanie z 58 miastami, 137 gminami wiejskimi i 24 powiatami; kampania nie „kończy się” na 20/100.
2a. Każde z 16 województw: zadanie bez limitu zawiera wszystkie miasta, gminy wiejskie i powiaty z TERYT (razem 380 powiatów); rozpoznanie województwa z samego pola Obszar; cała Polska (66 miast na prawach powiatu, 314 powiatów).
3. Import 250 firm w jednej partii i baza powyżej 2000 firm (2550).
4. Cel 100 z pełną pulą — jedno zadanie o rozmiarze 100.
5. Miasto + promień: Lublin 30 km (Świdnik tak, Zamość nie), Warszawa 20 km (Pruszków tak, Radom nie), Kraków 25 km (Wieliczka tak, Tarnów nie), Brno 20 km; miasto spoza słownika.
6. Słowacja / Czechy: województwo zablokowane, miasta i frazy lokalne.
7. Zadanie zawiera adresy, aktualność źródeł, tabal.pl, typ klienta, kontakt ogólny i niepewny.
8. Kontakty z innymi nazwami pól, e-mail na poziomie firmy, błędny e-mail — firma importowana, kontakt oznaczony.
9. Ponowne znalezienie firmy dopisuje kontakty, adres i brakujące kryteria do karty, zachowując status i notatki.
10. Scoring kontaktu 10 / 7 / 5 / 0 i wyłączenie kontaktów niepewnych.
11. Równe wagi, migracja domyślnych wag 3.1, zachowanie własnych wag.
12. Dodatkowe kryteria tylko po zaznaczeniu.
13. Częściowe dopasowanie: produkt ✓, segment ✗ z czerwonym oznaczeniem i powodem.
14. Spójność: ten sam dowód z `www`/ukośnikiem daje ten sam wynik.
15. Strona nieaktualizowana od 2023 r. nie potwierdza działalności.
16. Migracja kampanii 3.1 → projekty, łączenie projektów, usuwanie leadów z projektu.
17. Plik projektu: eksport i wczytanie do innej bazy bez duplikatów.
18. Statusy ZARCHIWIZOWANY/USUNIĘTY, kolory, data edycji, automatyczna archiwizacja, trwałe usunięcie.
19. Eksport NoSQL (JSON z kolekcjami i JSON Lines z `_id`).
20. Opisy z tabal.pl uzupełniają tylko puste pola.

Przeglądarka: projekty (filtr dat, archiwum, plik projektu, przejście do leadów), 45 dodatkowych firm z paginacją 20/50 i sortowaniem, zbiorcza archiwizacja i przywrócenie, karta z kontaktem „do weryfikacji” i „Dlaczego X pkt?”, strategia Słowacja/miasto+promień, kampania bez limitu w istniejącym projekcie, domyślny nadawca bok@tabal.pl, brak przewijania poziomego na telefonie. Zrzuty: `test-results/*-v32*.png`.

## Odtwarzanie
```bash
python3 scripts/build.py
npm test
python3 tests/test_server.py && python3 tests/test_mail.py && python3 tests/test_smtp_env.py
python3 tests/deployment_smoke.py
npm run test:browser
```

## Czego nie weryfikowano
Rzeczywistego researchu w ChatGPT Work (liczby firm w lubelskim, czasu GPT-6.1 Sol w trybie średnim), skrzynki bok@tabal.pl (host i hasło nieznane) ani docelowego serwera TABAL. Współrzędne miejscowości (GeoNames) są przybliżone; kilkanaście gmin wiejskich nie ma współrzędnych i nie wchodzi do wyszukiwania po promieniu (są w planie województwa).
