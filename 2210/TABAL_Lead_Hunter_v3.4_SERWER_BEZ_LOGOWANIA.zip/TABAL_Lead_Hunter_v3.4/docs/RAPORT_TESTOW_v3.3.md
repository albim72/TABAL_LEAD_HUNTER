# Raport testów — TABAL Lead Hunter 3.3 (19.10.2026)

| Zestaw | Wynik | Plik |
|---|---|---|
| Testy logiki (Node, w tym 16 nowych dla 3.3) | 112 / 112 | `test-results/core-v33.tap` |
| Serwer, wysyłka, konfiguracja SMTP z .env (Python) | 15 + 26 + 3, OK | `test-results/server-v33.txt` |
| Wdrożenie: restart Gunicorn, kopia CLI | OK | `test-results/deployment-v33.txt` |
| Przeglądarka end-to-end na serwerze (Chromium) | 33 / 33, w tym 4 nowe dla 3.3 | `test-results/browser-v33.txt`, `browser-v33.json` |

## Nowe scenariusze 3.3 (wg uwag z 14.10.2026)
- Firma meblowa (fit=unrelated) z „TAK” od Work za segment i klienta: 0 pkt za produkt, segment i klienta, kara −40, blokada kwalifikacji.
- Firma ogrodzeniowa bez ogrodzeń aluminiowych: produkt „≈ oferta pokrewna” (50%, ustawialne), bez blokady, wyżej niż firma niezgodna.
- „Klient” poza branżą = 0 pkt; przy nieustalonej branży = połowa; w branży = pełne punkty.
- Lead tylko z katalogu (Oferteo): połowa punktów za źródło i ostrzeżenie; sprawdzony brak strony — pełne punkty.
- CEIDG/KRS: NIP z rejestru, status aktywna/wykreślona, blokada wykreślonych; rozpoznawanie typu źródła kontaktu.
- Oddział najbliżej TABAL (Lublin): wybór Zamościa spośród Warszawy/Radomia/Zamościa, preferencja kontaktu z tego oddziału, zmiana lokalizacji TABAL.
- Kontakt ogólny: 8/10, stan „OK”, bez ostrzeżenia.
- Czyszczenie szkicu z Work: usunięte „Na stronie … znalazłem”, „według strony”, „przed wysyłką potwierdź”, „Źródło:”; zachowane w uwagach dla operatora.
- Szkic lokalny: < 130 słów, bez cytatu, bez opisu TABAL i oddziałów, wersja „poszerzenie oferty” dla firm pokrewnych.
- Migracja oferty 3.2 → 3.3 (usunięcie oddziałów i adnotacji, własny tekst zachowany).
- Uzupełnianie: `lead_ref` trafia na właściwą kartę także przy nowej domenie; konflikt NIP odrzucany; rekordy z różnych strategii w jednym pliku; tryb „refresh” poprawia kryteria i profil.
- Zadanie dla Work zawiera bloki: trafność, portal → strona, CEIDG/KRS, pogłębione kontakty, drugie przejście, oddziały, profile społecznościowe, zasady wiadomości, `lead_ref`.
- Przeglądarka: zbiorcze „Uzupełnij kontakty w Work” dla 8 firm; import uzupełnienia (ta sama karta, profil, CEIDG, oddział, oczyszczony szkic, lista odrzuconych); „Pogłęb kontakty” tylko dla firm bez potwierdzonego kontaktu; zapis nowych ustawień.

## Poprawka testu z 3.2
Test „AKTUALNOŚĆ” w 3.2 miał wpisaną datę 13.10.2026 i od 14.10 nie przechodził niezależnie od kodu. W 3.3 używa bieżącej daty.

## Zrzuty
`test-results/scenariusz-v33-leady.png`, `scenariusz-v33-karta-oferta-pokrewna.png`, `scenariusz-v33-scoring-firma-meblowa.png`, `scenariusz-v33-szkic.png`, `lead-card-v33.png`, `leads-v33-desktop.png`.

## Czego nie testowano
Rzeczywistego researchu w ChatGPT Work (zgodność Work z nowymi zasadami trzeba sprawdzić na pierwszej kampanii, np. „Ogrodzenia aluminiowe – partnerzy montażowi”, lubelskie) oraz wysyłki z bok@tabal.pl (brak hosta i hasła SMTP).
