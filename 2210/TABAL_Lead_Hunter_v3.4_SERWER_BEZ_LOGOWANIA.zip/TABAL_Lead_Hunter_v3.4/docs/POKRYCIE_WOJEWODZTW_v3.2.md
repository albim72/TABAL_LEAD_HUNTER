# Pokrycie województw — plan wyszukiwania 3.2

Plan dla każdego z 16 województw jest budowany z oficjalnego rejestru **TERYT TERC (GUS, stan na 1.01.2026)**: wszystkie miasta, wszystkie gminy wiejskie (drugie przejście dla mniej znanych firm) i wszystkie powiaty (kontrola pokrycia). Wcześniej (3.1) pełny plan miało tylko lubelskie, a inne województwa — sam napis „mazowieckie” itp.

| Województwo | Miasta | Gminy wiejskie | Powiaty | Pozycji planu (6 fraz × miasta i gminy) |
|---|---:|---:|---:|---:|
| dolnośląskie | 93 | 62 | 30 | 930 |
| kujawsko-pomorskie | 56 | 75 | 23 | 786 |
| lubelskie | 58 | 137 | 24 | 1170 |
| lubuskie | 44 | 34 | 14 | 468 |
| łódzkie | 60 | 102 | 24 | 972 |
| małopolskie | 64 | 108 | 22 | 1032 |
| mazowieckie | 114 | 185 | 42 | 1794 |
| opolskie | 38 | 33 | 12 | 426 |
| podkarpackie | 54 | 92 | 25 | 876 |
| podlaskie | 40 | 67 | 17 | 642 |
| pomorskie | 43 | 68 | 20 | 666 |
| śląskie | 75 | 92 | 36 | 1002 |
| świętokrzyskie | 51 | 51 | 14 | 612 |
| warmińsko-mazurskie | 50 | 50 | 21 | 600 |
| wielkopolskie | 120 | 95 | 35 | 1290 |
| zachodniopomorskie | 66 | 39 | 21 | 630 |
| **razem** | **1026** | **1290** | **380** | **13896** |

## Inne zakresy
- **Cała Polska** (bez województwa): 66 miast na prawach powiatu + 314 powiatów ziemskich do kontroli pokrycia.
- **Miasto + promień**: działa w całej Polsce oraz na Słowacji i w Czechach — aplikacja wybiera miasta i gminy w promieniu (odległość w linii prostej, współrzędne przybliżone).
- **Słowacja / Czechy**: miejscowości ≥ 10 000 mieszkańców w całym kraju albo wszystkie ≥ 2000 w wybranym kraju (np. „Jihomoravský kraj” w polu Obszar).
- Własne miejscowości w strategii zawsze mają pierwszeństwo przed planem domyślnym.

## Źródła danych
- GUS, rejestr TERYT TERC (stan 2026-01-01), w opracowaniu pakietu npm @janekolszak/poland 1.3.0 (licencja MIT).
- Współrzędne i miejscowości SK/CZ: GeoNames (geonames.org), licencja CC BY 4.0, przez pakiet geonamescache 3.0.2.
- Generator: scripts/build_geo.py → src/geo.js.
