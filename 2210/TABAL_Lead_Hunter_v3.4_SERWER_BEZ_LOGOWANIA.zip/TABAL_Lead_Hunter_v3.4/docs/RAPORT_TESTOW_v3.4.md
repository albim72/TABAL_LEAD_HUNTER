# Raport testów — TABAL Lead Hunter 3.4 (22.10.2026)

| Zakres | Wynik | Plik |
|---|---|---|
| Logika (Node, `npm test`) — w tym 15 nowych testów 3.4 | 127 / 127 | `test-results/core-v34.tap` |
| Przeglądarka (Playwright, Chromium 141, serwer Gunicorn, dane tymczasowe) | 33 / 33, 0 błędów konsoli | `test-results/browser-v34.json` |
| Serwer HTTP, kolejka SMTP, konfiguracja SMTP z .env | 15 + 26 + 3 OK | `test-results/server-v34.txt` |
| Diagnostyka SMTP (`scripts/smtp_diag.py`) na lokalnym serwerze TLS: SSL + logowanie + wiadomość, STARTTLS, certyfikat dla innego hosta | 3 / 3, hasło nie pojawia się w wyjściu | `tests/test_smtp_diag.py` |
| Restart Gunicorna i kopia baz | OK | `test-results/deployment-v34.txt` |

## Testy 3.4 (tests/v34.test.js)
1. Dwa kontakty ogólne (sam e-mail, sam telefon) → jeden kontakt z e-mailem i telefonem; lista i karta pokazują komplet.
2. Telefon z niepotwierdzonego katalogu dołączony do potwierdzonego e-maila → jeden kontakt, telefon „do weryfikacji”, ocena kontaktu bez zmian.
3. Różne adresy e-mail, inna osoba, inny oddział → osobne kontakty.
4. Osoba z samym e-mailem → lista pokazuje telefon ogólny firmy z dopiskiem „ogólny”.
5. Uzupełnienie w Work dopisuje telefon do istniejącego kontaktu zamiast tworzyć drugi.
6. Lista 50 firm (> 6000 znaków) — wszystkie `lead_ref` w zadaniu, „LISTA FIRM (pełna — 50 wierszy)”.
7. 50 firm w paczkach po 15 → 4 zadania (15/15/15/5), każda firma dokładnie raz, osobne `batch_id`, bez listy znanych firm.
8. Work zwraca 12 z 20 firm paczki → zadanie uzupełniające zawiera dokładnie 8 brakujących.
9. Karta firmy nie przechowuje listy z zadania; kopia JSON odtwarza się 1:1.
10. Obszar w 3 równoległych częściach — rozłączne miejscowości, razem cały plan, cel 50 → 17/17/17.
11. Jedno miasto — części dzielą frazy.
12. Import 4 dobrych + 3 słabych → 3 do archiwum, postęp 4 z 25, archiwalne nadal „znane” dla Work.
13. Zadanie: „JAKOŚĆ ZAMIAST LICZBY”, „JEDEN KONTAKT = JEDNA OSOBA LUB JEDNO BIURO”, zakaz przerywania pliku.
14. Kampanie z 3.3 liczą postęp jak dotąd.
15. Nowe ustawienia: wartości domyślne i walidacja.

## Zmienione oczekiwania w testach przeglądarkowych
- Test 18: 8 syntetycznych kandydatów bez kryteriów ma wynik poniżej progu — 3.4 pokazuje ramkę „Spełnia próg 65/100: 0 z 8”; operator odznacza archiwizację; cel liczy tylko firmy ≥ progu („0 z 100”, „brakuje 100” zamiast „8 z 100”). Testy 19–20 odpowiednio.

## Zrzuty scenariusza
`test-results/scenariusz-v34-*.png` — lista z kompletnym kontaktem, karta, 4 paczki uzupełniania, 3 zadania równoległe, podgląd importu z progiem, postęp kampanii z komunikatem o wyczerpaniu obszaru.

## Granice
Dane syntetyczne i lokalny serwer SMTP. Nie uruchamiano rzeczywistego researchu w ChatGPT Work ani wysyłki z bok@tabal.pl.
