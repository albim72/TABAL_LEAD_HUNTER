# Spotkanie TABAL — 22.10.2026 · Lead Hunter 3.4 + SMTP

## 0. Przed spotkaniem (rano, ok. 20 min)
1. Wgraj 3.4 na serwer (zachowaj `.runtime` i `.env`, Docker bez `down -v`). Sprawdź: menu „WERSJA 3.4”, `/healthz` → `3.4.0`.
2. Pobierz Kopię JSON z działającej bazy (zabezpieczenie).
3. Przygotuj leada testowego do wysyłki: firma „TEST TABAL”, kontakt = Twój adres (np. Gmail), potwierdzony, status DO KONTAKTU, zapisany szkic.
4. Jeśli znasz już host SMTP: `python3 scripts/smtp_diag.py` (bez hasła — DNS, porty, certyfikat).

## 1. Kolejność pokazu (ok. 25 min)

### Uwaga 2 — ucięty eksport (zacznij od tego: to był błąd aplikacji)
- **Co powiedzieć:** „Work miał rację — aplikacja ucinała listę firm w zadaniu na 6000 znakach. Przy 50 firmach to ok. 31 wierszy, 32. urywał się w połowie lead_ref. Naprawione.”
- **Pokaż:** Leady → filtr projektu z ostatniego wyszukiwania 50 firm → zaznacz wszystkie (100 na stronie, „zaznacz stronę”) → **Uzupełnij kontakty w Work** → 4 zadania (15/15/15/5).
- W zadaniu: „LISTA FIRM (pełna — 15 wierszy)” … „KONIEC LISTY FIRM”.
- **Test na żywo:** uruchom 2 paczki w dwóch czatach Work jednocześnie, zaimportuj oba pliki → panel pokaże „30 z 50 zbadanych firm”. Pozostałe dwie paczki mogą zrobić u siebie po spotkaniu.
- Jeśli Work pominie firmę: „Przygotuj zadanie uzupełniające” → zawiera tylko brakujące.

### Uwaga 1 — kontakty rozbite na e-mail i telefon
- **Pokaż:** lead, który wcześniej miał e-mail w liście, a telefon w „Kontakt do właściwej osoby” → teraz jeden kontakt: e-mail + telefon, dopisek „Scalono 2 wpisy”.
- Lista leadów: kolumna Kontakt — e-mail i telefon razem; „(ogólny)” gdy telefon osoby uzupełnia numer biura.
- Telefon tylko z katalogu → „do weryfikacji” (celowo — nie udajemy, że jest potwierdzony).
- Eksport CSV: kolumny E-mail i Telefon wypełnione kompletem.

### Uwaga 3 — czas wyszukiwania
- **Co powiedzieć uczciwie:** 30 minut to czas pracy Work (otwieranie stron, CEIDG/KRS, katalogi), nie kodu aplikacji. Skracanie zadania = mniej informacji. Bez utraty zakresu przyspiesza **równoległość**.
- **Pokaż:** Odkrywanie → cel 50, „Zadania równoległe w Work: 3” → 3 zadania z rozłącznymi miejscowościami → 3 czaty Work naraz.
- **Zmierz:** czas od startu do ostatniego importu vs 30 min dotąd (oczekiwanie: ok. 10–12 min; zależy od Work).
- Do ustalenia: ile czatów Work TABAL może prowadzić równocześnie (limit planu Work).

### Uwaga 4 — wyniki poniżej progu
- **Pokaż na imporcie:** ramka „Spełnia próg 65/100: X z Y nowych firm” + najsłabsze; zaznaczone „zapisz od razu w archiwum”.
- Po zapisie: postęp liczy tylko firmy ≥ 65 („4 z 25 — brakuje 21”); komunikat „Brak kolejnych dobrze dopasowanych firm w tym obszarze — poszerz promień / dodaj województwo / zmień frazy”.
- Archiwum: filtr „Wszystkie, także archiwum” → firmy z wpisem „Poniżej progu przy imporcie: 20/100”, można przywrócić.
- Zadanie dla Work ma regułę „JAKOŚĆ ZAMIAST LICZBY” — Work zwraca mniej zamiast dopełniać słabymi.

## 2. SMTP — konfiguracja i test na spotkaniu (z administratorem poczty TABAL)

### Potrzebne od TABAL
- Kto hostuje pocztę tabal.pl: `nslookup -type=mx tabal.pl` (na dowolnym komputerze).
- **Host SMTP, port (465 SSL albo 587 STARTTLS), hasło skrzynki bok@tabal.pl** (albo hasło aplikacji).
- Limit wysyłki skrzynki (na godzinę / dobę).

### Kolejność testu
1. `python3 scripts/smtp_diag.py --host <host> --port 465 --security ssl` → DNS, porty, certyfikat, AUTH.
2. Jeśli **certyfikat nie pasuje** (najczęstsze na hostingu współdzielonym): skrypt wypisze nazwę z certyfikatu, np. `serwerXXXXX.home.pl` — tę nazwę wpisz jako host. Aplikacja celowo nie łączy się z niepasującym certyfikatem.
3. `python3 scripts/smtp_diag.py --login --send-to <Twój adres>` → logowanie + wiadomość testowa (hasło wpisywane, nie wyświetla się).
4. Wpisy do `.env` (skrypt je wypisze): `TABAL_SMTP_HOST`, `TABAL_SMTP_HOSTS` (ten sam host — inaczej panel odrzuci konfigurację), `TABAL_SMTP_PORT`, `TABAL_SMTP_SECURITY`. Restart serwera.
5. Panel → **Wysyłka** → hasło → Zapisz → **Wiadomość testowa** → dochodzi na bok@tabal.pl.
6. Lead testowy (DO KONTAKTU) → dodaj do kolejki → Wznów → wiadomość na Twój Gmail → „Pokaż oryginał”: **SPF, DKIM, DMARC = PASS**. Status leada zmienia się na SKONTAKTOWANY, wpis w historii.

### Ryzyka do sprawdzenia
- **Microsoft 365** (MX `*.mail.protection.outlook.com`): host `smtp.office365.com`, 587 STARTTLS. SMTP AUTH musi być włączony dla skrzynki bok@ (często domyślnie wyłączony). Logowanie hasłem działa do końca grudnia 2026 — wtedy Microsoft wyłącza je domyślnie (administrator może przywrócić, docelowo potrzebne OAuth). Jeśli TABAL jest na M365 — zaplanować to teraz.
- **Google Workspace:** `smtp.gmail.com`, hasło aplikacji (wymaga 2FA).
- **Hosting (home.pl, nazwa.pl, cyber_Folks, OVH):** host = nazwa serwera z certyfikatu; port 465 SSL.
- Serwer aplikacji (VPS) może blokować wychodzące porty SMTP — skrypt pokaże „zamknięty”.
- Hasło: w panelu (tylko w pamięci, po restarcie wpisać ponownie) **albo** w `.env` (`chmod 600`). Decyzja TABAL.
- Wysłane wiadomości **nie trafiają do folderu „Wysłane”** bok@ — historia jest w zakładce Wysyłka (eksport JSON). Jeśli potrzebna kopia w skrzynce — do decyzji (np. kopia UDW na bok@).
- Odstęp między wiadomościami: 30 s (`TABAL_SMTP_INTERVAL`), partia maks. 50 — dopasować do limitu skrzynki.

## 3. Decyzje do podjęcia na spotkaniu
- [ ] Próg 65/100 zostaje? Firmy poniżej progu — domyślnie do archiwum (tak/nie)?
- [ ] Paczka uzupełniania: 15 firm (więcej = dłuższe zadanie i ryzyko uciętego wyniku z Work).
- [ ] Domyślna liczba zadań równoległych (proponuję 3).
- [ ] SMTP: host/port/hasło; gdzie trzymamy hasło; kopia wysłanych; limit dzienny.
- [ ] Kto i kiedy robi pierwszy rzeczywisty test 50 firm na 3.4 (pomiar czasu, liczba rekordów, % kompletnych kontaktów).

## 4. Czego nie obiecywać
- Konkretnego czasu — zależy od Work (model, obciążenie, liczba stron).
- Kontaktu dla każdej firmy — część firm nie publikuje e-maila; aplikacja pokazuje braki i źródła.
- 3.4 przetestowana na danych syntetycznych i lokalnym serwerze SMTP z TLS (127 testów logiki, 33 testy przeglądarkowe, testy serwera i SMTP); nie była uruchamiana na rzeczywistym researchu Work ani na skrzynce bok@tabal.pl.
