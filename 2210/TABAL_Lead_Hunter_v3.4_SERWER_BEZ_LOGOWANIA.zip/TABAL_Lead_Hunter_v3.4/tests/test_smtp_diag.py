"""3.4: scripts/smtp_diag.py against a real local TLS SMTP server (implicit SSL and STARTTLS, wrong certificate name)."""
import os,ssl,subprocess,sys,tempfile,threading,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'tests'))
from test_mail import TLSServer,SMTPHandler

def cert(tmp,name):
    c=Path(tmp)/(name+'.pem');k=Path(tmp)/(name+'.key')
    subprocess.run(['openssl','req','-x509','-newkey','rsa:2048','-nodes','-keyout',str(k),'-out',str(c),'-days','1','-subj','/CN='+name,'-addext','subjectAltName=DNS:'+name],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    return c,k

class Diag(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.tmp=tempfile.TemporaryDirectory()
    @classmethod
    def tearDownClass(cls):cls.tmp.cleanup()
    def serve(self,name,implicit):
        c,k=cert(self.tmp.name,name);ctx=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER);ctx.load_cert_chain(c,k)
        srv=TLSServer(('127.0.0.1',0),SMTPHandler);srv.context=ctx;srv.implicit=implicit;srv.drop=False;srv.messages=[]
        threading.Thread(target=srv.serve_forever,daemon=True).start();self.addCleanup(lambda:(srv.shutdown(),srv.server_close()))
        return srv,c
    def run_diag(self,srv,ca,security,*extra):
        env={k:v for k,v in os.environ.items() if not k.startswith('TABAL_')};env['TABAL_SMTP_PASSWORD']='tajne-haslo-diag'
        p=subprocess.run([sys.executable,str(ROOT/'scripts/smtp_diag.py'),'--host','localhost','--port',str(srv.server_address[1]),'--security',security,'--cafile',str(ca),*extra],env=env,capture_output=True,text=True,timeout=60)
        self.assertNotIn('tajne-haslo-diag',p.stdout+p.stderr);return p
    def test_ssl_login_and_test_message(self):
        srv,ca=self.serve('localhost',True);p=self.run_diag(srv,ca,'ssl','--login','--send-to','test@example.com')
        self.assertEqual(p.returncode,0,p.stdout);self.assertIn('zalogowano',p.stdout);self.assertIn('wszystko działa',p.stdout);self.assertEqual(len(srv.messages),1)
        self.assertIn(b'TABAL Lead Hunter',srv.messages[0])
    def test_starttls_without_login(self):
        srv,ca=self.serve('localhost',False);p=self.run_diag(srv,ca,'starttls')
        self.assertEqual(p.returncode,0,p.stdout);self.assertIn('AUTH: PLAIN',p.stdout);self.assertEqual(srv.messages,[])
    def test_certificate_for_other_host_is_explained(self):
        srv,ca=self.serve('serwer123.hosting.example',True);p=self.run_diag(srv,ca,'ssl','--login')
        self.assertEqual(p.returncode,1);self.assertIn('NIE pasuje',p.stdout);self.assertIn('serwer123.hosting.example',p.stdout);self.assertIn('TABAL_SMTP_HOST',p.stdout)

if __name__=='__main__':unittest.main(verbosity=2)
