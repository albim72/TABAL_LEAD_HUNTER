"""3.2: SMTP sender bok@tabal.pl from environment / .env; password never exposed."""
import json,os,subprocess,sys,tempfile,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
SCRIPT=r'''
import io,json,sys
sys.path.insert(0,sys.argv[1])
from server import web
snap=web.outbox.snapshot()
env={'HTTP_HOST':'127.0.0.1:8765','PATH_INFO':'/api/state','REQUEST_METHOD':'GET','wsgi.input':io.BytesIO(b''),'CONTENT_LENGTH':'0'}
out={}
body=b''.join(web.application(env,lambda s,h:out.update(status=s)))
print(json.dumps({'snap':snap,'http':json.loads(body),'status':out['status'],'hosts':web.smtp_hosts()}))
'''
def run(extra):
    with tempfile.TemporaryDirectory() as tmp:
        env={k:v for k,v in os.environ.items() if not k.startswith('TABAL_')}
        env.update(TABAL_DATA_DIR=tmp,TABAL_ORIGIN='http://127.0.0.1:8765',**extra)
        p=subprocess.run([sys.executable,'-c',SCRIPT,str(ROOT)],env=env,capture_output=True,text=True,timeout=60)
        assert p.returncode==0,p.stderr
        return json.loads(p.stdout.strip().splitlines()[-1])
class SmtpEnv(unittest.TestCase):
    def test_defaults_are_bok_tabal(self):
        r=run({})
        self.assertFalse(r['snap']['configured'])
        self.assertEqual(r['snap']['defaults']['sender_email'],'bok@tabal.pl')
        self.assertEqual(r['snap']['defaults']['username'],'bok@tabal.pl')
    def test_env_password_autoconfigures_without_leaking(self):
        r=run({'TABAL_SMTP_HOST':'smtp.example.test','TABAL_SMTP_PASSWORD':'tajne-haslo-123','TABAL_SMTP_PORT':'587','TABAL_SMTP_SECURITY':'starttls'})
        self.assertTrue(r['snap']['configured'])
        self.assertEqual(r['snap']['config']['sender_email'],'bok@tabal.pl')
        self.assertEqual(r['snap']['config']['port'],587)
        self.assertIn('smtp.example.test',r['hosts'])
        self.assertNotIn('tajne-haslo-123',json.dumps(r['http']))
        self.assertTrue(r['http']['configured'])
    def test_env_file_loader_does_not_override_real_env(self):
        sys.path.insert(0,str(ROOT))
        os.environ.setdefault('TABAL_DATA_DIR',tempfile.mkdtemp())
        from server.web import _load_env_file
        with tempfile.NamedTemporaryFile('w',suffix='.env',delete=False,encoding='utf-8') as f:
            f.write('# komentarz\nTABAL_SMTP_USER="z-pliku@tabal.pl"\nTABAL_TEST_ONLY=1\nOTHER=x\n')
        os.environ['TABAL_TEST_ONLY']='z-env'
        os.environ.pop('TABAL_SMTP_USER',None)
        _load_env_file(f.name)
        self.assertEqual(os.environ['TABAL_SMTP_USER'],'z-pliku@tabal.pl')
        self.assertEqual(os.environ['TABAL_TEST_ONLY'],'z-env')
        self.assertNotIn('OTHER',os.environ)
        os.unlink(f.name)
if __name__=='__main__':unittest.main(verbosity=2)
