// TABAL Lead Hunter 3.4 — regressions for TABAL remarks of 21.10.2026 (contacts, cut export, speed, below-threshold results).
const {test}=require('node:test'),a=require('node:assert/strict'),C=require('../src/core.js');
function base(){return C.makeState('pilot');}
function alu(s,extra={}){const st=C.strategy({...s.strategies.find(x=>x.id==='aluminium'),country:'Polska',province:'lubelskie',region:'lubelskie, Polska',...extra});s.strategies[s.strategies.findIndex(x=>x.id==='aluminium')]=st;return st;}
const today=C.today();
function raw(dom,{company='Firma '+dom,contacts,criteria}={}){
 const src='https://'+dom+'/oferta',cr={};
 for(const k of [...C.CRITERIA,'exclusion'])cr[k]={value:'unknown',evidence:'',url:''};
 Object.assign(cr,criteria||{product:{value:'yes',evidence:'Montaż ogrodzeń aluminiowych',url:src},segment:{value:'yes',evidence:'Branża ogrodzeniowa',url:src},client:{value:'yes',evidence:'Firma montażowa',url:src},region:{value:'yes',evidence:'Lublin',url:src},exclusion:{value:'no',evidence:'Brak',url:src}});
 return {company,domain:dom,is_demo:false,region:'lubelskie',city:'Lublin',business_profile:{core_activity:'montaż ogrodzeń',fit:'core'},
  sources:[{url:src,title:'Oferta',quote:'Montaż ogrodzeń aluminiowych w Lublinie.',checked_at:today,verified:true}],
  contacts:contacts||[{type:'general',email:'biuro@'+dom,url:'https://'+dom+'/kontakt',quote:'biuro@'+dom,checked_at:today,verified:true}],criteria:cr};
}
const kontakt=dom=>'https://'+dom+'/kontakt';

// ---------- 1. Kontakty: e-mail i telefon w jednym kontakcie ----------
test('KONTAKT 3.4: e-mail i telefon zwrócone jako dwa kontakty ogólne → jeden kompletny kontakt (lista i karta)',()=>{
 const s=base(),st=alu(s);
 const l=C.validateLead(raw('alfa.example',{contacts:[
  {type:'general',email:'biuro@alfa.example',url:kontakt('alfa.example'),quote:'E-mail: biuro@alfa.example',checked_at:today,verified:true},
  {type:'general',phone:'+48 81 123 45 67',url:kontakt('alfa.example'),quote:'Tel. +48 81 123 45 67',checked_at:today,verified:true}]}),s,st);
 a.equal(l.contacts.length,1);
 a.equal(l.contacts[0].email,'biuro@alfa.example');a.equal(l.contacts[0].phone,'+48 81 123 45 67');a.equal(l.contacts[0].merged,2);
 const q=C.contactQuality(l.contacts[0],s.config);a.ok(q.email&&q.phone&&q.usable);
 const m=C.contactSummary(l,s.config);a.equal(m.email,'biuro@alfa.example');a.equal(m.phone,'+48 81 123 45 67');a.ok(m.email_ok&&m.phone_ok);
});
test('KONTAKT 3.4: niepewny telefon dołączony do potwierdzonego e-maila jest oznaczony „do weryfikacji”, e-mail zostaje potwierdzony',()=>{
 const s=base(),st=alu(s);
 const l=C.validateLead(raw('beta.example',{contacts:[
  {type:'general',email:'biuro@beta.example',url:kontakt('beta.example'),quote:'biuro@beta.example',checked_at:today,verified:true},
  {type:'general',phone:'601 202 303',url:'https://www.pkt.pl/firma/beta',quote:'tel. 601 202 303',checked_at:today,verified:false,uncertain:true,source_type:'catalog'}]}),s,st);
 a.equal(l.contacts.length,1);a.deepEqual(l.contacts[0].unverified_fields,['phone']);
 const q=C.contactQuality(l.contacts[0],s.config);a.ok(q.usable&&q.email);a.equal(q.phone,false);
 a.equal(C.score(l,s.config).parts.find(p=>p.key==='contact').state,'ok');
 const csv=C.csv({...s,leads:[l]});a.match(csv,/601 202 303/);
});
test('KONTAKT 3.4: różne adresy e-mail, inna osoba i inny oddział zostają osobnymi kontaktami',()=>{
 const s=base(),st=alu(s),u=kontakt('gamma.example');
 const l=C.validateLead(raw('gamma.example',{contacts:[
  {type:'general',email:'biuro@gamma.example',url:u,quote:'biuro@gamma.example',checked_at:today,verified:true},
  {type:'general',email:'handel@gamma.example',url:u,quote:'handel@gamma.example',checked_at:today,verified:true},
  {type:'general',phone:'81 555 66 77',branch:'Zamość',url:u,quote:'Oddział Zamość 81 555 66 77',checked_at:today,verified:true},
  {type:'person',name:'Jan Nowak',role:'Właściciel',reason:'CEIDG',email:'jan@gamma.example',url:u,quote:'Jan Nowak — Właściciel — jan@gamma.example',checked_at:today,verified:true}]}),s,st);
 const emails=l.contacts.map(p=>p.email).filter(Boolean).sort();
 a.deepEqual(emails,['biuro@gamma.example','handel@gamma.example','jan@gamma.example']);
 a.ok(l.contacts.some(p=>p.type==='person'&&p.name==='Jan Nowak'));
});
test('KONTAKT 3.4: osoba z samym e-mailem — lista pokazuje też telefon ogólny firmy (oznaczony „ogólny”)',()=>{
 const s=base(),st=alu(s),u=kontakt('delta.example');
 const l=C.validateLead(raw('delta.example',{contacts:[
  {type:'person',name:'Anna Kowal',role:'Kierownik zakupów',reason:'Zakupy',email:'anna@delta.example',url:u,quote:'Anna Kowal — Kierownik zakupów — anna@delta.example',checked_at:today,verified:true},
  {type:'general',phone:'81 444 55 66',url:u,quote:'Tel. 81 444 55 66',checked_at:today,verified:true}]}),s,st);
 const m=C.contactSummary(l,s.config);
 a.equal(m.contact.p.name,'Anna Kowal');a.equal(m.email,'anna@delta.example');a.equal(m.phone,'81 444 55 66');a.equal(m.phone_from,'ogólny');a.ok(m.phone_ok);
});
test('KONTAKT 3.4: uzupełnienie w Work dopisuje telefon do istniejącego kontaktu z e-mailem zamiast tworzyć drugi',()=>{
 const s=base(),st=alu(s);
 let r=C.merge(s,[raw('eps.example')],st);s.leads=r.leads;const id=s.leads[0].id;
 const second=raw('eps.example',{contacts:[{type:'general',phone:'81 700 80 90',url:kontakt('eps.example'),quote:'tel. 81 700 80 90',checked_at:today,verified:true}]});
 second.lead_ref=id;r=C.merge(s,[second],st,{refresh:true});s.leads=r.leads;
 const l=s.leads.find(x=>x.id===id);
 a.equal(l.contacts.length,1);a.equal(l.contacts[0].email,'biuro@eps.example');a.equal(l.contacts[0].phone,'81 700 80 90');
});

// ---------- 2. Ucięty eksport (50 firm → 31) ----------
function fiftyLeads(s,st,n=50){const raws=[];for(let i=0;i<n;i++)raws.push(raw('firma-ogrodzeniowa-'+String(i).padStart(2,'0')+'.example',{company:'Przedsiębiorstwo Ogrodzeniowe Numer '+i+' Spółka z o.o.'}));const r=C.merge(s,raws,st);s.leads=r.leads;return s.leads;}
function enrichRun(s,leads,pack){
 const st0=s.strategies.find(x=>x.id==='aluminium');
 const lines=leads.map(l=>['lead_ref='+l.id,l.company,l.domain,l.city,'strategy_id='+st0.id,'KONTAKT NIEPEWNY'].join(' | '));
 const st=C.strategy({...st0,mode:'targeted',research_stage:'full',limit:leads.length,batch_size:pack,targets:lines.join('\n')});
 const run=C.createResearchRun(st,'');s.runs.push(run);return {run,lines};
}
test('EKSPORT 3.4: lista 50 firm nie jest ucinana (3.3 cięła ją na 6000 znaków ≈ 31 firm i w połowie lead_ref)',()=>{
 const s=base(),st=alu(s),leads=fiftyLeads(s,st);
 const {run,lines}=enrichRun(s,leads,0);
 a.ok(lines.join('\n').length>6000,'test musi przekraczać dawny limit');
 a.equal(C.targetLines(run.profile).length,50);
 const task=C.prepareResearchBatch(s,run);
 for(const l of leads)a.ok(task.includes('lead_ref='+l.id),'brak '+l.company);
 a.match(task,/LISTA FIRM \(pełna — 50 wierszy\)/);a.match(task,/KONIEC LISTY FIRM/);
});
test('EKSPORT 3.4: 50 firm w paczkach po 15 → 4 zadania (15/15/15/5), każda firma dokładnie raz, osobne batch_id',()=>{
 const s=base(),st=alu(s),leads=fiftyLeads(s,st);
 const {run}=enrichRun(s,leads,15);
 const made=C.prepareParallel(s,run);
 a.deepEqual(made.map(b=>b.targets.length),[15,15,15,5]);
 a.equal(new Set(made.map(b=>b.id)).size,4);
 const all=made.flatMap(b=>b.targets.map(C.lineRef));a.equal(all.length,50);a.equal(new Set(all).size,50);
 for(const b of made){a.match(b.task,/PACZKA \d+ FIRM/);for(const t of b.targets)a.ok(b.task.includes(C.lineRef(t)));a.doesNotMatch(b.task,/ZNANE FIRMY — MOŻESZ ZWRÓCIĆ/);}
 a.equal(C.preparedBatches(run).length,4);
});
test('EKSPORT 3.4: Work zwrócił tylko część paczki → zadanie uzupełniające zawiera dokładnie brakujące firmy',()=>{
 const s=base(),st=alu(s),leads=fiftyLeads(s,st,20);
 const {run}=enrichRun(s,leads,20);
 const [b]=C.prepareParallel(s,run);
 const back=b.targets.slice(0,12).map(t=>({...raw(leads.find(l=>l.id===C.lineRef(t)).domain),lead_ref:C.lineRef(t)}));
 const r=C.merge(s,back,run.profile,{refresh:true});s.leads=r.leads;C.recordResearchImport(run,r,{batch_id:b.id,leads:back},'paczka1.json');
 const p=C.researchProgress(run);a.equal(p.found,12);a.equal(p.remaining,8);
 const task=C.prepareResearchBatch(s,run),next=run.batches.at(-1);
 a.equal(next.targets.length,8);
 for(const t of b.targets.slice(12))a.ok(task.includes(C.lineRef(t)));
 for(const t of b.targets.slice(0,12))a.ok(!task.includes(C.lineRef(t)));
});
test('EKSPORT 3.4: karta firmy nie przechowuje listy firm z zadania (profil bez targets)',()=>{
 const s=base(),st=alu(s),leads=fiftyLeads(s,st,3);
 const {run}=enrichRun(s,leads,15);
 const back=[{...raw(leads[0].domain),lead_ref:leads[0].id}];
 const r=C.merge(s,back,run.profile,{refresh:true});
 a.equal(r.leads.find(l=>l.id===leads[0].id).sightings.at(-1).profile.targets,undefined);
 s.leads=r.leads;a.deepEqual(C.restore(C.backup(s),'pilot').leads,s.leads);
});

// ---------- 3. Tempo: zadania równoległe ----------
test('TEMPO 3.4: obszar dzielony na 3 równoległe zadania — rozłączne miejscowości, razem cały plan, cel rozdzielony',()=>{
 const s=base(),st=alu(s,{limit:50,batch_size:0});
 const run=C.createResearchRun(st,'');s.runs.push(run);
 const plan=C.researchPlan(s,st),made=C.prepareParallel(s,run,3);
 a.equal(made.length,3);
 const areas=made.flatMap(b=>b.areas);a.equal(areas.length,plan.areas.length);a.deepEqual(new Set(areas),new Set(plan.areas));
 a.deepEqual(made.map(b=>b.size),[17,17,17]);
 for(const b of made){a.match(b.task,new RegExp('CZĘŚĆ '+b.part+' Z 3'));a.match(b.task,/ZADANIE RÓWNOLEGŁE/);a.ok(b.task.length<C.task(s,st,run.id).length);}
});
test('TEMPO 3.4: jedno miasto bez promienia — części dzielą frazy zamiast miejscowości',()=>{
 const s=base(),st=alu(s,{city:'Lublin',radius_km:0,limit:20});
 const run=C.createResearchRun(st,'');s.runs.push(run);
 const made=C.prepareParallel(s,run,2),plan=C.researchPlan(s,st);
 a.deepEqual(made.flatMap(b=>b.terms).sort(),[...plan.terms].sort());a.ok(made.every(b=>b.areas.includes('Lublin')));
});

// ---------- 4. Wyniki poniżej progu ----------
test('PRÓG 3.4: słabe firmy (np. 20/100) z importu trafiają do archiwum, cel liczy tylko firmy ≥ progu',()=>{
 const s=base(),st=alu(s,{limit:25});
 const run=C.createResearchRun(st,'');s.runs.push(run);const b=C.prepareParallel(s,run,1)[0];
 const good=[0,1,2,3].map(i=>raw('dobra-'+i+'.example'));
 const weak=[0,1,2].map(i=>raw('slaba-'+i+'.example',{criteria:{product:{value:'unknown'},segment:{value:'unknown'},client:{value:'unknown'},region:{value:'unknown'}},contacts:[]}));
 const r=C.merge(s,[...good,...weak],st);const q=C.importQuality(s,r.leads,r.addedIds);
 a.equal(q.total,7);a.equal(q.good,4);a.equal(q.weak.length,3);a.ok(q.weak.every(w=>w.points<s.config.threshold));
 s.leads=r.leads;a.equal(C.archiveWeak(s,q.weak.map(w=>w.id)),3);
 C.recordResearchImport(run,r,{batch_id:b.id,research_report:{stop_reason:'pool_exhausted'}},'wynik.json',q);
 const p=C.researchProgress(run);a.equal(p.found,4);a.equal(p.remaining,21);
 const archived=s.leads.filter(l=>l.status==='ARCHIVED');a.equal(archived.length,3);
 a.ok(archived.every(l=>l.history.at(-1).action==='IMPORT_BELOW_THRESHOLD'));
 // Archived firms stay "known" so Work does not return them again as new.
 const next=C.prepareResearchBatch(s,run);for(const l of archived)a.ok(next.includes(l.domain));
 a.equal(run.imports.at(-1).below_threshold,3);
});
test('PRÓG 3.4: zadanie mówi „jakość zamiast liczby” i każe zwrócić mniej firm zamiast słabych; kontakt = jeden obiekt',()=>{
 const s=base(),st=alu(s,{limit:25});const t=C.task(s,st,'run-x');
 a.match(t,/JAKOŚĆ ZAMIAST LICZBY/);a.match(t,/zwróć MNIEJ rekordów/);a.match(t,/pool_exhausted/);a.match(t,/65\/100/);
 a.match(t,/JEDEN KONTAKT = JEDNA OSOBA LUB JEDNO BIURO/);a.doesNotMatch(t,/jako osobny kontakt \(nie wybieraj jednego\)/);
 a.match(t,/nie przerywaj go w połowie rekordu/);a.match(t,/v3\.4/);
});
test('PRÓG 3.4: kampanie zapisane w 3.3 (bez count_good) liczą postęp jak dotąd',()=>{
 const run={profile:{mode:'open',limit:10},target:10,added:6};a.equal(C.researchProgress(run).found,6);
});
test('USTAWIENIA 3.4: paczka uzupełniania, zadania równoległe i archiwizacja słabych — domyślne i walidacja',()=>{
 const c=C.settings({});a.equal(c.enrich_pack,15);a.equal(c.parallel_tasks,1);a.equal(c.import_archive_weak,true);
 a.equal(C.settings({import_archive_weak:false}).import_archive_weak,false);
 a.throws(()=>C.settings({enrich_pack:0}));a.throws(()=>C.settings({parallel_tasks:9}));
});
