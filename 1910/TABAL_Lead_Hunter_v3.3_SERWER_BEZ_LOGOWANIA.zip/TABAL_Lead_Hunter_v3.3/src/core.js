(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.V2=api;})(globalThis,function(){
'use strict';
// TABAL Lead Hunter 3.3 — domain logic shared by the browser and the server validator.
const VERSION='3.3.0', MAX=10000;
const STATUS={NEW:'NOWY',REVIEW:'DO WERYFIKACJI',ACCEPTED:'ZAAKCEPTOWANY',TO_CONTACT:'DO KONTAKTU',CONTACTED:'SKONTAKTOWANY',REPLIED:'ODPOWIEDŹ',INTERESTED:'ZAINTERESOWANY',OPPORTUNITY:'SZANSA SPRZEDAŻOWA',REJECTED:'ODRZUCONY',ARCHIVED:'ZARCHIWIZOWANY',DELETED:'USUNIĘTY'};
// Colour dot per status: green = new, yellow = in progress, blue = contacted, violet = opportunity, red = rejected, gray = archived, black = deleted.
const STATUS_COLOR={NEW:'green',REVIEW:'yellow',ACCEPTED:'yellow',TO_CONTACT:'yellow',CONTACTED:'blue',REPLIED:'blue',INTERESTED:'blue',OPPORTUNITY:'violet',REJECTED:'red',ARCHIVED:'gray',DELETED:'black'};
const STATUS_LEGEND=[['green','Nowy'],['yellow','W trakcie obsługi'],['blue','Skontaktowano się'],['violet','Szansa sprzedażowa'],['red','Odrzucony'],['gray','Zarchiwizowany'],['black','Usunięty']];
const HIDDEN_STATUSES=['ARCHIVED','DELETED'];
const REASONS=['Zła branża','Konkurencja','Własna produkcja','Brak potencjału','Duplikat','Za drogo','Błędne dane','Inny powód'];
const LABELS={product:'Produkt',segment:'Segment / rynek',client:'Typ klienta',region:'Region',extra:'Dodatkowe kryteria',source:'Jakość i aktualność źródła',contact:'Właściwy kontakt'};
const CRITERIA=['product','segment','client','region','extra'];
// 3.2: equal weights by default (TABAL request). 3.1 defaults are migrated once.
const DEFAULT_WEIGHTS={product:10,segment:10,client:10,region:10,extra:10,source:10,contact:10};
const OLD_DEFAULT_WEIGHTS={product:25,segment:15,client:15,region:10,extra:15,source:10,contact:10};
// 3.3: a confirmed general company contact is fully usable for first contact (8/10), only a confirmed person scores higher.
const CONTACT_GRADES={person:1,general:0.8,uncertain:0.5};
const TABAL_URL='https://tabal.pl/';
const TABAL_PRODUCTS=[
 {id:'panel',name:'Ogrodzenia panelowe',url:'https://tabal.pl/ogrodzenia-techfence/',description:'TABAL Techfence — systemy ogrodzeń panelowych (Flat, Fokus Light, Fokus) ze słupami, obejmami i technologią montażu. Zastosowanie: posesje prywatne i obiekty przemysłowe. Powłoki lakiernicze z certyfikatem QUALISTEELCOAT (według tabal.pl).',pitch:'systemy ogrodzeń panelowych Techfence (Flat, Fokus Light, Fokus) z kompletem słupów i obejm — do posesji prywatnych i obiektów przemysłowych'},
 {id:'alu',name:'Ogrodzenia aluminiowe',url:'https://tabal.pl/tabal-alufence/',description:'TABAL Alufence — autorski system palisadowych ogrodzeń aluminiowych: poziome, pionowe, żaluzjowe, grzebieniowe i ozdobne. Segmenty, słupy, furtki, bramy skrzydłowe i przesuwne; dodatki: słupek multimedialny i pocztowy, zabudowy koszy na odpady, zadaszenia furtek, oświetlenie LED. Realizacja od projektu po montaż.',pitch:'aluminiowe ogrodzenia palisadowe Alufence — poziome, pionowe i żaluzjowe, z bramami, furtkami i dodatkami, realizowane od projektu po montaż'},
 {id:'profiles',name:'Profile konstrukcyjne',url:'https://tabal.pl/aluminiowe-systemy-konstrukcyjne/',description:'Aluminiowe systemy konstrukcyjne — szwajcarski system profili aluminiowych i akcesoriów; konstrukcje wykonywane na indywidualne zlecenie.',pitch:'aluminiowe systemy konstrukcyjne — profile i akcesoria do konstrukcji wykonywanych na indywidualne zlecenie'},
 {id:'rails',name:'Balustrady',url:'https://tabal.pl/aluminiowe-konstrukcje-budowlane/',description:'Aluminiowe konstrukcje budowlane — balustrady, przegrody balkonowe, zabudowy balkonów, zadaszenia i okienka podawcze.',pitch:'aluminiowe balustrady, przegrody i zabudowy balkonów oraz zadaszenia'},
 {id:'wholesale',name:'Hurtownia metali',url:'https://tabal.pl/hurtownia/',description:'Hurtownia: stal kwasoodporna, aluminium, metale kolorowe i nieżelazne, blachy perforowane, tworzywa konstrukcyjne, kraty pomostowe, elementy balustrad, armatura kwasoodporna; doradztwo i cięcie na wymiar.',pitch:'stal kwasoodporną, aluminium i metale kolorowe z hurtowni, z cięciem na wymiar'},
 {id:'signs',name:'Tablice',url:'https://tabal.pl/tablice/',description:'Tablice energetyczne, posesyjne, orientacyjne, gazowe, przemysłowe (BHP, PPOZ, ADR), unijne i informacyjne; produkcja tablic aluminiowych tłoczonych, grawerowanych i wyklejanych.',pitch:'tablice aluminiowe — energetyczne, posesyjne, BHP, PPOZ i informacyjne'},
 {id:'waterjet',name:'Cięcie waterjet',url:'https://tabal.pl/waterjet/',description:'Cięcie materiałów strumieniem wody pod wysokim ciśnieniem.',pitch:'cięcie materiałów strumieniem wody (waterjet)'}];
const OLD_TABAL_OFFER='TABAL Sp. z o.o. z Lublina działa od 1990 r. (według strony również oddziały w Radomiu, Zamościu, Siedlcach i Olsztynie). Oferta: ogrodzenia aluminiowe Alufence (od projektu po montaż), ogrodzenia panelowe Techfence, hurtownia metali z cięciem na wymiar, tablice, cięcie waterjet, aluminiowe systemy konstrukcyjne oraz aluminiowe konstrukcje budowlane (balustrady, zabudowy balkonów, zadaszenia). Źródło: https://tabal.pl/ — przed wysyłką potwierdź aktualność informacji.';
// 3.3: offer is context for Work and local drafts, not text to paste into a message. No unverified branch list, no working notes.
const TABAL_OFFER='TABAL Sp. z o.o. — firma z Lublina, działa od 1990 r. Oferta: ogrodzenia aluminiowe Alufence (od projektu po montaż), ogrodzenia panelowe Techfence, hurtownia metali z cięciem na wymiar, tablice, cięcie waterjet, aluminiowe systemy konstrukcyjne oraz aluminiowe konstrukcje budowlane (balustrady, zabudowy balkonów, zadaszenia).';
const TABAL_LOCATIONS=['Lublin'];
const MIGRATIONS=['v32-projects','v32-updated-at','v32-batch-full-pool','v32-tabal-offer','v33-offer-clean','v33-product-pitch'];
// Working notes that must never reach a customer message.
const NOTE_RE=/(przed wysy[łl]k[aą]|potwierd[źz] aktualno|do weryfikacji|wymaga weryfikacji|zweryfikuj|sprawd[źz] (przed|aktualno|dane)|uwaga robocza|notatka|\btodo\b|\[do uzupe|\[uzupe[łl]|\bwed[łl]ug strony\b|źr[óo]d[łl]o:|na stronie [^.\n]{0,80}znalaz[łl]em|znalaz[łl]em (na stronie|informacj)|\bcytat\b|research|lead hunter|scoring|work zwr)/i;
const clone=x=>JSON.parse(JSON.stringify(x)),txt=(x,n=12000)=>typeof x==='string'?x.trim().slice(0,n):(typeof x==='number'&&Number.isFinite(x)?String(x):''),norm=x=>txt(x).toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g,'').replace(/ł/g,'l').replace(/\s+/g,' ');
const now=()=>new Date().toISOString(),today=()=>now().slice(0,10);
const uid=()=>globalThis.crypto?.randomUUID?.()||'id-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2);
function date(d){return typeof d==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(d)&&Number.isFinite(Date.parse(d))&&new Date(d).toISOString().slice(0,10)===d;}
function age(d,t=today()){return date(d)?Math.floor((Date.parse(t)-Date.parse(d))/86400000):null;}
function url(x){try{const u=new URL(txt(x));return /^https?:$/.test(u.protocol)&&!u.username&&!u.password?u.href:'';}catch{return '';}}
function domain(x){if(!txt(x))return '';try{const u=new URL(/^https?:\/\//i.test(txt(x))?x:'https://'+x);return /^https?:$/.test(u.protocol)&&u.hostname.includes('.')?u.hostname.toLowerCase().replace(/^www\./,''):'';}catch{return '';}}
function list(x){return Array.isArray(x)?[...new Set(x.map(y=>txt(y,500)).filter(Boolean))]:txt(x).split(/[\n;]/).map(y=>y.trim()).filter(Boolean);}
function assert(ok,msg){if(!ok)throw Error(msg);}
// Comparable form of a URL: https, no www, no hash/utm, no trailing slash. Used for evidence matching.
function normUrl(x){const s=url(x);if(!s)return '';const u=new URL(s);u.hash='';for(const k of [...u.searchParams.keys()])if(/^(utm_|fbclid$|gclid$)/i.test(k))u.searchParams.delete(k);u.hostname=u.hostname.replace(/^www\./,'');u.pathname=u.pathname.replace(/\/+$/,'')||'/';u.searchParams.sort();return 'https://'+u.host+u.pathname+u.search;}
function settings(raw={}){
 raw=raw&&typeof raw==='object'?raw:{};
 const c={weights:{...DEFAULT_WEIGHTS},threshold:65,max_age_days:90,contact_age_days:60,exclusion_penalty:60,stale_penalty:15,sender:'Zespół TABAL',excluded_domains:['tabal.pl']};
 const oldDefaults=raw.weights&&raw.weights_version!==2&&Object.keys(OLD_DEFAULT_WEIGHTS).every(k=>raw.weights[k]===OLD_DEFAULT_WEIGHTS[k]);
 const weights=oldDefaults?DEFAULT_WEIGHTS:raw.weights;
 for(const k of Object.keys(c.weights)){const v=weights?.[k]??c.weights[k];assert(Number.isFinite(v)&&v>=0&&v<=100,'Wagi: wymagane liczby 0–100.');c.weights[k]=v;}
 c.weights_version=2;
 assert(Object.values(c.weights).reduce((a,b)=>a+b,0)>0,'Co najmniej jedna waga musi być dodatnia.');
 for(const k of ['threshold','max_age_days','contact_age_days','exclusion_penalty','stale_penalty']){c[k]=raw[k]??c[k];assert(Number.isInteger(c[k])&&c[k]>=(k.includes('penalty')?0:1)&&c[k]<=(k.includes('days')?730:100),'Nieprawidłowe ustawienie: '+k);}
 for(const [k,d,max] of [['source_max_age_years',2,50],['auto_archive_rejected_days',30,3650],['auto_archive_inactive_days',0,3650]]){c[k]=raw[k]??d;assert(Number.isInteger(c[k])&&c[k]>=0&&c[k]<=max,'Nieprawidłowe ustawienie: '+k);}
 for(const [k,d,max] of [['related_share',50,100],['mismatch_penalty',40,100]]){c[k]=raw[k]??d;assert(Number.isInteger(c[k])&&c[k]>=0&&c[k]<=max,'Nieprawidłowe ustawienie: '+k);}
 c.tabal_locations=raw.tabal_locations?list(raw.tabal_locations).slice(0,20):TABAL_LOCATIONS.slice();if(!c.tabal_locations.length)c.tabal_locations=TABAL_LOCATIONS.slice();
 c.allow_uncertain_contacts=raw.allow_uncertain_contacts!==false;
 c.sender=txt(raw.sender,1500)||c.sender;c.message_style=['consultative','concise','technical'].includes(raw.message_style)?raw.message_style:'consultative';c.offer=txt(raw.offer,6000);c.company_url=url(raw.company_url)||TABAL_URL;
 c.required={};c.criteria_names={};for(const k of CRITERIA){c.required[k]=raw.required?.[k]!==false;c.criteria_names[k]=txt(raw.criteria_names?.[k],100)||LABELS[k];}
 c.excluded_domains=raw.excluded_domains?list(raw.excluded_domains).map(domain).filter(Boolean):c.excluded_domains;return c;
}
function countryKey(x){const n=norm(x);if(!n)return '';if(/^(polska|poland|pl|polen)$/.test(n))return 'PL';if(/^(slowacja|slovakia|slovensko|sk|slowakei)$/.test(n))return 'SK';if(/^(czechy|czech|czechia|cesko|czech republic|ceska republika|cz|tschechien)$/.test(n))return 'CZ';if(n==='inny kraj')return 'OTHER';return 'OTHER';}
function strategy(raw){
 assert(raw&&typeof raw==='object','Nieprawidłowa strategia.');const s={};
 for(const k of ['id','name','product_id','segment','client','region','extra','exclusions','targets','last_run','country','province','benchmark','locations','query_terms','city'])s[k]=txt(raw[k],6000);
 s.id||=uid();s.mode=raw.mode==='targeted'?'targeted':'open';
 // 0 = no limit (whole pool); batch 0 = whole pool in one Work task.
 s.limit=Number(raw.limit??0);s.batch_size=Number(raw.batch_size??0);s.research_stage=raw.research_stage==='full'?'full':'discovery';
 assert(Number.isInteger(s.batch_size)&&s.batch_size>=0&&s.batch_size<=MAX,'Wielkość partii: 0 (cała pula w jednym zadaniu) lub 1–'+MAX+'.');
 s.every_days=Number(raw.every_days??0);s.next_date=txt(raw.next_date);assert(s.name,'Uzupełnij nazwę strategii.');
 s.use_extra=raw.use_extra===true||raw.use_extra==='on'||raw.use_extra==='true';
 s.radius_km=Number(raw.radius_km||0);assert(Number.isInteger(s.radius_km)&&s.radius_km>=0&&s.radius_km<=500,'Promień: 0–500 km.');
 if(countryKey(s.country)==='PL')s.country='Polska';
 s.country ||= /polska|lubelsk|mazowieck|wielkopolsk|slask|śląsk|pomorsk|malopolsk|małopolsk|podkarpack|podlask|lodzk|łódzk|swietokrzysk|świętokrzysk|opolsk|lubusk|kujawsk|warminsk|warmińsk|dolnoslask|dolnośląsk|zachodniopomorsk/i.test(s.region)?'Polska':'';
 if(s.country!=='Polska')s.province='';
 assert(Number.isInteger(s.limit)&&s.limit>=0&&s.limit<=MAX,'Cel kampanii: 0 (bez limitu) lub 1–'+MAX+'.');assert([0,7,14,30].includes(s.every_days),'Nieprawidłowa częstotliwość.');assert(!s.next_date||date(s.next_date),'Nieprawidłowa data kolejnego cyklu.');return s;
}
function upgrade(s){
 // Idempotent data upgrades for 3.2; applied ids are stored so user changes are never overwritten twice.
 s.migrations=Array.isArray(s.migrations)?s.migrations.filter(x=>typeof x==='string'):[];
 const once=(id,fn)=>{if(!s.migrations.includes(id)){fn();s.migrations.push(id);}};
 s.projects=Array.isArray(s.projects)?s.projects:[];
 once('v32-projects',()=>{for(const run of s.runs||[]){if(run.project_id&&s.projects.some(p=>p.id===run.project_id))continue;const p=project({name:(run.profile?.name||'Kampania')+' · '+txt(run.created_at).slice(0,10),created_at:run.created_at||now(),lead_ids:run.result_ids||[],run_ids:[run.id],strategy_ids:[run.strategy_id].filter(Boolean),source:'campaign'});s.projects.push(p);run.project_id=p.id;}});
 once('v32-updated-at',()=>{for(const l of s.leads||[])if(!l.updated_at)l.updated_at=l.history?.at(-1)?.at||(l.first_seen?l.first_seen+'T00:00:00.000Z':now());});
 once('v32-batch-full-pool',()=>{for(const st of s.strategies||[])if(st.batch_size===20)st.batch_size=0;});
 once('v33-offer-clean',()=>{if(s.config){const o=txt(s.config.offer);s.config.offer=!o||o===OLD_TABAL_OFFER?TABAL_OFFER:cleanOffer(o);}});
 once('v33-product-pitch',()=>{for(const p of s.products||[]){const known=TABAL_PRODUCTS.find(x=>x.id===p.id);if(known&&!txt(p.pitch))p.pitch=known.pitch;}});
 once('v32-tabal-offer',()=>{for(const p of s.products||[]){const known=TABAL_PRODUCTS.find(x=>x.id===p.id);if(known){if(!txt(p.description))p.description=known.description;if(!txt(p.url))p.url=known.url;}}if(s.config&&!txt(s.config.offer))s.config.offer=TABAL_OFFER;});
 const ids=new Set((s.leads||[]).map(l=>l.id));
 s.projects=s.projects.map(project).map(p=>({...p,lead_ids:p.lead_ids.filter(id=>ids.has(id))}));
 return s;
}
function project(raw={}){
 assert(raw&&typeof raw==='object','Nieprawidłowy projekt.');
 const ids=x=>Array.isArray(x)?[...new Set(x.filter(y=>typeof y==='string'&&y))]:[];
 const p={id:txt(raw.id,200)||uid(),name:txt(raw.name,200)||'Projekt bez nazwy',created_at:txt(raw.created_at,40)||now(),updated_at:txt(raw.updated_at,40)||txt(raw.created_at,40)||now(),archived:raw.archived===true,archived_at:txt(raw.archived_at,40),lead_ids:ids(raw.lead_ids),run_ids:ids(raw.run_ids),strategy_ids:ids(raw.strategy_ids),notes:txt(raw.notes,6000),source:['campaign','manual','import','merge'].includes(raw.source)?raw.source:'manual'};
 return p;
}
function makeState(mode='pilot'){
 const products=TABAL_PRODUCTS.map(p=>clone(p));
 const templates=[{id:'panels',name:'Ogrodzenia panelowe – dystrybutorzy PL',product_id:'panel',segment:'Branża ogrodzeniowa',client:'Dystrybutor lub monter',region:'Polska',extra:'Posiada w ofercie ogrodzenia panelowe',exclusions:'Własna produkcja paneli ogrodzeniowych'},{id:'aluminium',name:'Ogrodzenia aluminiowe – partnerzy montażowi',product_id:'alu',segment:'Branża ogrodzeniowa',client:'Firma montażowa',region:'Polska',extra:'Montaż ogrodzeń aluminiowych',exclusions:''},{id:'machines',name:'Profile konstrukcyjne – producenci maszyn',product_id:'profiles',segment:'Budowa maszyn',client:'Producent maszyn',region:'Polska',extra:'Wykorzystuje profile konstrukcyjne',exclusions:''}].map(strategy);
 const config=settings();config.offer=TABAL_OFFER;
 return upgrade({schema_version:2,app_version:VERSION,mode,products,strategies:templates,config,leads:[],runs:[],cycles:[],audit:[],projects:[],migrations:[...MIGRATIONS],created_at:now(),updated_at:now()});
}
function cleanDate(x){const d=txt(x,40).slice(0,10);return date(d)&&age(d)>=0?d:'';}
function source(raw={}){
 assert(raw&&typeof raw==='object','Źródło musi być obiektem.');
 const s={url:url(raw.url||raw.source_url||raw.link),title:txt(raw.title,500),quote:txt(raw.quote||raw.excerpt),checked_at:cleanDate(raw.checked_at),verified:raw.verified===true};
 assert(s.url,'Źródło musi mieć adres http/https.');
 const y=Number(raw.updated_year||raw.last_updated_year);if(Number.isInteger(y)&&y>=1990&&y<=new Date().getFullYear()+1)s.updated_year=y;
 return s;
}
const RELATED_VALUES=['related','partial','pokrewne','pokrewny','pokrewna','czesciowo','czesciowe','podobne','similar','adjacent'];
function assessment(raw={}){raw=raw&&typeof raw==='object'?raw:{};const v=norm(typeof raw.value==='boolean'?(raw.value?'yes':'no'):raw.value);return {value:['yes','tak','true'].includes(v)?'yes':['no','nie','false'].includes(v)?'no':RELATED_VALUES.includes(v)?'related':'unknown',evidence:txt(raw.evidence||raw.reason),url:url(raw.url||raw.source_url)};}
// Tolerant contact parser: Work and ChatGPT often use other field names. Invalid e-mail never drops the whole company.
function contact(raw={}){
 assert(raw&&typeof raw==='object','Kontakt musi być obiektem.');const c={};
 const name=raw.name||raw.full_name||raw.person||[raw.first_name,raw.last_name].filter(Boolean).join(' ');
 const pick={name,role:raw.role||raw.position||raw.title||raw.stanowisko||raw.function,reason:raw.reason||raw.why||raw.note,email:raw.email||raw.mail||raw['e-mail'],phone:raw.phone||raw.tel||raw.telephone||raw.telefon||raw.mobile,quote:raw.quote||raw.evidence,checked_at:raw.checked_at};
 for(const k of ['name','role','reason','email','phone','quote'])c[k]=txt(pick[k],3000);
 c.checked_at=cleanDate(pick.checked_at);
 c.url=url(raw.url||raw.source_url||raw.source);c.verified=raw.verified===true;c.type=raw.type==='person'?'person':raw.type==='general'?'general':(c.name?'person':'general');
 if(c.email&&!/^[^\s@<>,;]+@[^\s@<>,;]+\.[^\s@<>,;]+$/.test(c.email)){const m=c.email.match(/[^\s@<>,;:()"']+@[^\s@<>,;:()"']+\.[A-Za-z]{2,}/);c.email_raw=c.email;c.email=m?m[0]:'';c.uncertain=true;}
 if(raw.uncertain===true||raw.needs_verification===true)c.uncertain=true;
 const branch=txt(raw.branch||raw.oddzial||raw.location,200);if(branch)c.branch=branch;
 const st=txt(raw.source_type,20);if(['website','registry','catalog','social','other'].includes(st))c.source_type=st;
 return c;
}
function contactsFrom(raw){
 const out=[...(raw.contacts||[])];
 if(raw.contact&&typeof raw.contact==='object'&&!Array.isArray(raw.contact))out.push(raw.contact);
 if(raw.general_contact&&typeof raw.general_contact==='object')out.push({type:'general',...raw.general_contact});
 const email=txt(raw.email||raw.contact_email),phone=txt(raw.phone||raw.contact_phone);
 if((email||phone)&&!out.some(p=>p&&typeof p==='object'&&((email&&txt(p.email)===email)||(phone&&txt(p.phone)===phone))))out.push({type:'general',email,phone,url:raw.contact_url||'',reason:'Ogólny kontakt firmy podany w wyniku researchu.',uncertain:true});
 return out;
}
// ---------- 3.3: business profile, own website check, registries (CEIDG/KRS), branches, social profiles ----------
const FITS=['core','related','unrelated','unknown'];
function fitValue(x){const v=norm(x);if(['core','zgodny','zgodna','glowna','tak','yes','match'].includes(v))return 'core';if(RELATED_VALUES.includes(v)||v==='pokrewna branza')return 'related';if(['unrelated','niezgodny','niezgodna','inna','no','nie','mismatch'].includes(v))return 'unrelated';return 'unknown';}
function businessProfile(raw){if(!raw||typeof raw!=='object')return null;const b={core_activity:txt(raw.core_activity||raw.activity||raw.main_activity,600),main_offer:list(raw.main_offer||raw.offer).slice(0,20),fit:fitValue(raw.fit||raw.match),reason:txt(raw.reason||raw.evidence,1500),url:url(raw.url||raw.source_url)};return b.core_activity||b.main_offer.length||b.fit!=='unknown'?b:null;}
function websiteCheck(raw){if(!raw||typeof raw!=='object')return null;const v=norm(raw.status);const w={status:['verified','potwierdzona','sprawdzona'].includes(v)?'verified':['not_found','brak','nie znaleziono'].includes(v)?'not_found':'not_checked',url:url(raw.url),note:txt(raw.note||raw.reason,1500)};return w;}
function registryInfo(raw){if(!raw||typeof raw!=='object')return null;const t=txt(raw.type||raw.source,20).toUpperCase(),v=norm(raw.status);const r={type:['CEIDG','KRS'].includes(t)?t:'',status:['active','aktywny','aktywna','czynny'].includes(v)?'active':['suspended','zawieszony','zawieszona'].includes(v)?'suspended':['deleted','wykreslony','wykreslona','zakonczony','zlikwidowana','w likwidacji'].includes(v)?'deleted':'unknown',nip:txt(raw.nip,20).replace(/\D/g,''),regon:txt(raw.regon,20).replace(/\D/g,''),krs:txt(raw.krs,20).replace(/\D/g,''),name:txt(raw.name||raw.registered_name,400),address:addressText(raw.address),representatives:list(raw.representatives||raw.owners||raw.board).slice(0,10),url:url(raw.url),checked_at:cleanDate(raw.checked_at)};if(r.nip.length!==10)r.nip='';return r.type||r.nip||r.url||r.status!=='unknown'?r:null;}
function branchList(raw){return (Array.isArray(raw)?raw:[]).filter(b=>b&&typeof b==='object').slice(0,30).map(b=>({name:txt(b.name,300),address:addressText(b.address),city:txt(b.city||b.address?.city,200),postal_code:txt(b.postal_code,20),phone:txt(b.phone||b.tel,100),email:txt(b.email||b.mail,200),url:url(b.url)})).filter(b=>b.city||b.address);}
const SOCIAL_RE=/(^|\.)(facebook\.com|fb\.com|instagram\.com|linkedin\.com|youtube\.com|tiktok\.com|x\.com|twitter\.com)$/;
const REGISTRY_RE=/(^|\.)(ceidg\.gov\.pl|biznes\.gov\.pl|ekrs\.ms\.gov\.pl|ms\.gov\.pl|rejestr\.io|krs-online\.com\.pl|wyszukiwarkaregon\.stat\.gov\.pl|regon\.stat\.gov\.pl|stat\.gov\.pl)$/;
function socialList(raw){return (Array.isArray(raw)?raw:[]).filter(x=>x&&typeof x==='object').slice(0,10).map(x=>({platform:txt(x.platform,40),url:url(x.url),linked:x.linked===true||x.linked_from_site===true,evidence:txt(x.evidence||x.note,800)})).filter(x=>x.url);}
function sourceKind(u,l){const d=domain(u);if(!d)return 'other';if(l&&l.domain&&(d===l.domain||d.endsWith('.'+l.domain)))return 'website';if(REGISTRY_RE.test(d))return 'registry';if(SOCIAL_RE.test(d))return 'social';if(sharedDomain(d))return 'catalog';return 'other';}
const SOURCE_KIND_LABEL={website:'strona firmy',registry:'rejestr (CEIDG/KRS)',catalog:'katalog / portal',social:'profil społecznościowy',other:'inne źródło'};
function contactSource(p,l){return p.source_type||sourceKind(p.url,l);}
function addressText(a){if(a&&typeof a==='object')return [a.street,[a.postal_code,a.city].filter(Boolean).join(' '),a.country].map(x=>txt(x,300)).filter(Boolean).join(', ');return txt(a,600);}
function validateLead(raw,s,st){
 assert(raw&&typeof raw==='object'&&!Array.isArray(raw),'Lead musi być obiektem.');const l={};
 for(const k of ['company','nip','region','context','product_reason'])l[k]=txt(raw[k]);
 l.address=addressText(raw.address);l.city=txt(raw.city||raw.address?.city,200);l.postal_code=txt(raw.postal_code||raw.address?.postal_code,20);
 l.client_type=txt(raw.client_type||raw.customer_type||raw.typ_klienta,300);
 l.active_status=['active','inactive','unknown'].includes(raw.active_status)?raw.active_status:'unknown';
 l.domain=domain(raw.domain||raw.website);l.identity_url=identityUrl(raw.identity_url);l.nip=l.nip.replace(/\D/g,'');assert(l.company,'Brak nazwy firmy.');assert(l.domain||l.nip||l.identity_url,'Wymagana domena firmy, NIP lub pełny URL wizytówki (identity_url).');assert(!l.nip||l.nip.length===10,'NIP musi mieć 10 cyfr.');l.is_demo=raw.is_demo===true;assert((s.mode==='demo')===l.is_demo,'Dane DEMO można importować wyłącznie do zbioru DEMO.');
 assert(Array.isArray(raw.sources),'Pole sources musi być tablicą źródeł.');assert(raw.contacts==null||Array.isArray(raw.contacts),'Pole contacts musi być tablicą kontaktów.');
 l.sources=raw.sources.slice(0,30).map(source);if(l.identity_url)assert(l.sources.some(x=>identityUrl(x.url)===l.identity_url),'URL wizytówki musi występować w sources.');assert(l.sources.length,'Wymagane 1–30 źródeł.');
 l.contacts=contactsFrom(raw).filter(p=>p&&typeof p==='object').slice(0,30).map(contact).filter(p=>p.name||p.email||p.phone||p.email_raw);
 // 3.3 optional structures — stored only when Work returns them, so older records keep their shape.
 const bp=businessProfile(raw.business_profile||raw.profile_fit);if(bp)l.business_profile=bp;
 const wc=websiteCheck(raw.website_check||raw.own_website);if(wc)l.website_check=wc;
 const rg=registryInfo(raw.registry);if(rg){l.registry=rg;if(!l.nip&&rg.nip)l.nip=rg.nip;if(rg.status==='suspended'||rg.status==='deleted')l.active_status='inactive';else if(rg.status==='active'&&l.active_status==='unknown')l.active_status='active';}
 const br=branchList(raw.branches);if(br.length)l.branches=br;
 const so=socialList(raw.social||raw.social_profiles);if(so.length)l.social=so;
 if(raw.contact_search&&typeof raw.contact_search==='object')l.contact_search={deep:raw.contact_search.deep===true,checked:list(raw.contact_search.checked).slice(0,20),result:['found','not_found','partial'].includes(raw.contact_search.result)?raw.contact_search.result:'',note:txt(raw.contact_search.note,1500)};
 l.criteria={};for(const k of [...CRITERIA,'exclusion'])l.criteria[k]=assessment(raw.criteria?.[k]);
 l.id=uid();l.strategy_id=st.id;l.profile=clone(st);l.product_name=s.products.find(p=>p.id===st.product_id)?.name||txt(raw.product_name);l.status='NEW';l.feedback='pending';l.feedback_note='';l.rejection_reason='';l.notes='';l.do_not_contact=false;l.first_seen=today();l.last_seen=today();l.updated_at=now();l.milestones={NEW:today()};l.history=[{at:now(),action:'DISCOVER',note:'Dodano do rejestru.'}];l.sightings=[];const cd=cleanDraft(txt(raw.draft?.body));l.draft={subject:cleanSubject(txt(raw.draft?.subject,300)),body:cd.body,origin:raw.draft?.body?'work':''};const dn=[txt(raw.draft?.notes,3000),...cd.removed].filter(Boolean);if(dn.length)l.draft.notes=dn.join('\n');return l;
}
function currentYear(t=today()){return Number(String(t).slice(0,4));}
// Explains why a source cannot confirm facts. Empty string = source is fine.
function sourceIssue(s,c,t=today()){
 if(!s)return 'brak źródła';if(!s.verified)return 'źródło nieoznaczone jako sprawdzone (verified=false)';if(!s.quote)return 'brak cytatu ze źródła';
 const a=age(s.checked_at,t);if(a===null||a<0)return 'brak prawidłowej daty sprawdzenia źródła';if(a>c.max_age_days)return `źródło sprawdzono ${a} dni temu (limit ${c.max_age_days})`;
 if(c.source_max_age_years&&s.updated_year&&s.updated_year<currentYear(t)-c.source_max_age_years)return `strona nieaktualizowana od ${s.updated_year} r. — potrzebne bieżące źródło`;
 return '';
}
function evidenceCheck(l,a,c,t=today()){
 if(!a||!a.evidence)return {ok:false,reason:'brak opisu dowodu'};
 const u=normUrl(a.url);if(!u)return {ok:false,reason:'dowód bez adresu URL'};
 const src=l.sources.find(s=>normUrl(s.url)===u);if(!src)return {ok:false,reason:'URL dowodu nie występuje na liście źródeł'};
 const issue=sourceIssue(src,c,t);return {ok:!issue,reason:issue,source:src};
}
function evidence(l,a,c,t=today()){return evidenceCheck(l,a,c,t).ok;}
function contactQuality(p,c,t=today()){
 const a=age(p.checked_at,t);
 const fresh=!!(p.verified&&p.url&&p.quote&&a!==null&&a>=0&&a<=c.contact_age_days);
 const q=norm(p.quote),digits=txt(p.phone).replace(/\D/g,'');const email=!!(fresh&&p.email&&q.includes(norm(p.email))),phone=!!(fresh&&digits.length>=7&&digits.length<=15&&p.quote.replace(/\D/g,'').includes(digits));
 const person=!!(fresh&&p.type==='person'&&p.name&&p.role&&p.reason&&q.includes(norm(p.name))&&q.includes(norm(p.role)));
 const usable=!p.uncertain&&(p.type==='general'||person)&&(email||phone);
 const channel=!!(p.email||p.phone);
 const issue=usable?'':p.uncertain?'oznaczony jako niepewny — wymaga weryfikacji':!p.verified?'kontakt nieoznaczony jako potwierdzony':!p.url?'brak URL źródła kontaktu':!p.quote?'brak cytatu z danymi kontaktowymi':(a===null||a<0)?'brak daty sprawdzenia':a>c.contact_age_days?`kontakt sprawdzony ${a} dni temu`:(p.email&&!email&&!phone)?'e-mail nie występuje w cytacie':(p.phone&&!phone&&!email)?'telefon nie występuje w cytacie':!channel?'brak e-maila i telefonu':(p.type==='person'&&!person)?'nie potwierdzono imienia, funkcji lub uzasadnienia':'';
 return {email,phone,person,usable,fresh,channel,uncertain:!usable&&channel,issue};
}
function bestContact(l,c,t=today()){const near=norm(api.nearestBranch?.(l,c)?.city||'');const rank=x=>Number(x.person&&x.usable)*16+Number(x.usable)*8+Number(x.person)*2+Number(x.email)+Number(x.channel)*4+Number(x.p.type==='person'&&!!x.p.name)+(near&&x.p.branch&&norm(x.p.branch)===near?3:0);return l.contacts.map(p=>({p,...contactQuality(p,c,t)})).sort((a,b)=>rank(b)-rank(a))[0]||null;}
function criterionActive(l,k){if(k==='extra')return !!(l.profile.use_extra&&l.profile.extra);return !!l.profile[k==='product'?'product_id':k];}
// Industry fit: is the company in the strategy's line of business at all? Used to keep "Klient" points meaningful.
function industryState(l,states){
 const fit=l.business_profile?.fit||'unknown';
 if(fit==='unrelated')return 'mismatch';
 if(fit==='core'||['ok','partial'].includes(states.segment)||['ok','partial'].includes(states.product))return 'confirmed';
 if(fit==='related'||states.segment==='related'||states.product==='related')return 'related';
 if(states.segment==='no'&&!['ok','partial','related'].includes(states.product))return 'mismatch';
 return 'unknown';
}
function score(l,c,t=today()){
 const parts=[],blocks=[],warnings=[],checks={};let points=0;
 const active=k=>!CRITERIA.includes(k)||criterionActive(l,k);
 const sum=Object.entries(c.weights).reduce((a,[k,v])=>a+(active(k)?v:0),0)||1;
 const name=k=>c.criteria_names?.[k]||LABELS[k];
 const share=(c.related_share??50)/100;
 // Pass 1: raw state of each criterion from Work's assessment and evidence.
 const raw={};
 for(const k of CRITERIA){
  const a=l.criteria[k]||assessment(),na=!active(k)||c.weights[k]===0,max=na?0:c.weights[k]/sum*100;
  let state,value=0,reason;
  if(na){state='na';reason=k==='extra'&&l.profile.extra&&!l.profile.use_extra?'Nieuwzględniane: dodatkowe kryteria nie zostały zaznaczone w strategii.':'Kryterium nieaktywne: puste pole strategii lub waga 0.';}
  else if(a.value==='yes'){const e=evidenceCheck(l,a,c,t);if(e.ok){state='ok';value=max;reason=a.evidence;}else{state='partial';value=max/2;reason=`Work potwierdza zgodność, ale dowód jest niepełny (${e.reason}) — połowa punktów. ${a.evidence}`.trim();}}
  else if(a.value==='related'){state='related';value=max*share;reason=`OFERTA / PROFIL POKREWNY — ${Math.round(share*100)}% punktów. ${a.evidence||'Work wskazał dopasowanie pokrewne.'}`.trim();}
  else if(a.value==='no'){state='no';reason='NIEZGODNOŚĆ: '+(a.evidence||'Work oznaczył kryterium jako niespełnione.');}
  else{state='unknown';reason='Nie ustalono — Work nie podał dowodu zgodności (0 pkt).';}
  raw[k]={state,value,reason,max,a};
 }
 const states=Object.fromEntries(Object.entries(raw).map(([k,v])=>[k,v.state]));
 const industry=industryState(l,states),fit=l.business_profile?.fit||'unknown';
 // Pass 2: TABAL 14.10 — a fence company without aluminium fences is a related offer (expansion potential), not 0 points.
 const pr=raw.product;
 if(pr&&['unknown','no'].includes(pr.state)&&industry!=='mismatch'&&(['ok','partial'].includes(states.segment)||fit==='core'||fit==='related')){
  const basis=fit==='core'||fit==='related'?(l.business_profile.core_activity||'profil działalności zgodny z branżą'):(raw.segment.a.evidence||'segment potwierdzony');
  pr.state='related';pr.value=pr.max*share;
  pr.reason=`OFERTA POKREWNA — ${Math.round(share*100)}% punktów: ${pr.a.value==='no'?'nie potwierdzono produktu „'+(l.product_name||'produkt')+'” w ofercie':'nie ustalono produktu „'+(l.product_name||'produkt')+'”'}, ale firma działa w tej samej branży (${basis}). Potencjalny partner do rozszerzenia oferty.`;
 }
 // Pass 3: client type counts only inside the strategy's industry (STEELOVE case).
 const cl=raw.client;
 if(cl&&cl.state!=='na'){
  if(industry==='mismatch'&&cl.value>0){cl.state='no';cl.value=0;cl.reason='Typ klienta nie jest liczony: firma nie działa w branży strategii'+(l.business_profile?.core_activity?' (główna działalność: '+l.business_profile.core_activity+')':'')+'. '+(cl.a.evidence||'');}
  else if(industry==='unknown'&&cl.state==='ok'){cl.state='partial';cl.value=cl.max/2;cl.reason='Typ klienta potwierdzony, ale nie potwierdzono działalności w branży strategii — połowa punktów. '+(cl.a.evidence||'');}
 }
 if(fit==='unrelated')for(const k of ['product','segment','client'])if(raw[k]&&raw[k].state!=='na'&&raw[k].value>0){raw[k].value=0;raw[k].state='no';raw[k].reason='Profil działalności niezgodny ze strategią — 0 pkt. '+raw[k].reason;}
 for(const k of CRITERIA){const r=raw[k];points+=r.value;checks[k]=r.state;parts.push({key:k,label:name(k),points:r.value,max:r.max,state:r.state,reason:r.reason});
  if(r.state==='related')warnings.push(name(k)+': dopasowanie pokrewne');
  else if(r.state!=='ok'&&r.state!=='na'&&c.required?.[k]!==false)blocks.push(name(k)+': '+(r.state==='no'?'niezgodność':r.state==='partial'?'dowód niepełny':'nie ustalono'));}
 checks.industry=industry;
 // Source quality: own website / registry beats a portal listing.
 const kinds=l.sources.map(s=>sourceKind(s.url,l)),catalogOnly=kinds.length>0&&kinds.every(k=>k==='catalog'||k==='social');
 const best=[...l.sources].map(s=>({s,issue:sourceIssue(s,c,t)})).sort((a,b)=>Number(!a.issue)-Number(!b.issue)).reverse()[0];
 const goodSource=!!best&&!best.issue,wc=l.website_check?.status||'';
 const smax=c.weights.source/sum*100;let sval=goodSource?smax:0,sstate=goodSource?'ok':'no',sreason=goodSource?'Aktualne źródło oznaczone jako sprawdzone.':'Brak aktualnego sprawdzonego źródła: '+(best?.issue||'brak źródeł')+'.';
 if(goodSource&&catalogOnly&&wc!=='not_found'){sval=smax/2;sstate='partial';sreason='Tylko katalog / portal (np. Oferteo, Panorama Firm) — nie sprawdzono oferty na własnej stronie firmy. Połowa punktów.';warnings.push('Zweryfikuj ofertę na stronie firmy (znaleziono tylko w katalogu).');}
 else if(goodSource&&catalogOnly&&wc==='not_found')sreason='Firma bez własnej strony (sprawdzono) — dane z katalogów / profili'+(l.registry?.status==='active'?' i rejestru':'')+'.';
 if(l.registry?.status==='active'&&goodSource)sreason+=' Status w '+(l.registry.type||'rejestrze')+': aktywna.';
 points+=sval;checks.source=sstate;
 parts.push({key:'source',label:LABELS.source,points:sval,max:smax,state:sstate,reason:sreason});
 const co=bestContact(l,c,t),cmax=c.weights.contact/sum*100,anyUsable=l.contacts.some(p=>contactQuality(p,c,t).usable);
 let grade=0,creason='Brak kanału kontaktu (e-mail / telefon) — 0/10.',cstate='no';
 if(co?.person&&co.usable){grade=CONTACT_GRADES.person;cstate='ok';creason='10/10 — potwierdzona osoba właściwa: '+co.p.name+(co.p.role?', '+co.p.role:'')+'.';}
 else if(anyUsable){grade=CONTACT_GRADES.general;cstate='ok';creason='8/10 — potwierdzony kontakt ogólny firmy: wystarczający do pierwszego kontaktu. Osoba decyzyjna nieustalona (+2 po jej ustaleniu).';}
 else if(c.allow_uncertain_contacts&&co?.channel){grade=CONTACT_GRADES.uncertain;cstate='partial';creason='5/10 — kontakt wymaga weryfikacji: '+(co.issue||'niepotwierdzone dane')+'.';}
 else if(co?.channel){creason='0/10 — kontakty niepewne są wyłączone w ustawieniach scoringu ('+co.issue+').';}
 points+=cmax*grade;checks.contact=cstate;parts.push({key:'contact',label:LABELS.contact,points:cmax*grade,max:cmax,state:cstate,reason:creason});
 if(!goodSource){blocks.push('Źródło wymaga weryfikacji');points-=c.stale_penalty;parts.push({key:'stale',label:'Brak aktualnego źródła',points:-c.stale_penalty,max:0,state:'no',reason:'Kara za źródło nieaktualne lub niesprawdzone.'});}
 if(fit==='unrelated'){const pen=c.mismatch_penalty??40;points-=pen;blocks.push('Profil działalności niezgodny ze strategią'+(l.business_profile?.core_activity?': '+l.business_profile.core_activity:''));parts.push({key:'mismatch',label:'Niezgodny profil działalności',points:-pen,max:0,state:'no',reason:l.business_profile?.reason||l.business_profile?.core_activity||'Work ocenił główną działalność jako niezwiązaną ze strategią.'});}
 if(l.registry&&['suspended','deleted'].includes(l.registry.status))blocks.push('Rejestr '+(l.registry.type||'')+': działalność '+(l.registry.status==='deleted'?'wykreślona / zakończona':'zawieszona'));
 const ex=l.criteria.exclusion;if(l.profile.exclusions){if(ex.value==='yes'&&evidence(l,ex,c,t)){points-=c.exclusion_penalty;blocks.push('Spełnione wykluczenie: '+ex.evidence);parts.push({key:'exclusion',label:'Kryterium wykluczające',points:-c.exclusion_penalty,max:0,state:'no',reason:ex.evidence});checks.exclusion='no';}else if(ex.value!=='no'||!evidence(l,ex,c,t)){blocks.push('Kryteria wykluczające wymagają sprawdzenia');checks.exclusion='unknown';}else checks.exclusion='ok';}
 if(c.excluded_domains.some(d=>l.domain===d||l.domain.endsWith('.'+d)))blocks.push('Firma na liście wykluczeń');if(l.do_not_contact)blocks.push('Nie kontaktować');if(['REJECTED','ARCHIVED','DELETED'].includes(l.status))blocks.push('Lead '+STATUS[l.status].toLowerCase());points=Math.max(0,Math.min(100,Math.round(points)));if(points<c.threshold)blocks.push('Wynik poniżej progu '+c.threshold);if(!co?.usable)warnings.push(co?.channel?'Potwierdź kontakt (dane niepewne).':'Brak kontaktu — zleć pogłębione wyszukiwanie.');
 return {points,parts,blocks,warnings,qualified:!blocks.length,contact:co,checks};
}
function identityUrl(value){
 const safe=url(value);if(!safe)return '';
 const u=new URL(safe);u.hash='';
 for(const k of [...u.searchParams.keys()])if(/^(utm_|fbclid$|gclid$)/i.test(k))u.searchParams.delete(k);
 u.hostname=u.hostname.replace(/^www\./,'');u.pathname=u.pathname.replace(/\/+$/,'')||'/';u.searchParams.sort();
 return u.pathname==='/'&&!u.search?'':u.href;
}
function sharedDomain(d){return /(^|\.)(facebook\.com|instagram\.com|linkedin\.com|google\.com|google\.pl|maps\.app\.goo\.gl|panoramafirm\.pl|pkt\.pl|oferteo\.pl|firmy\.net|aleo\.com|rejestr\.io|krs-online\.com\.pl|olx\.pl)$/.test(d||'');}
function identityMatch(a,b){
 if(a.nip&&b.nip)return a.nip===b.nip;
 if(a.domain&&b.domain&&a.domain===b.domain&&!sharedDomain(a.domain))return true;
 return !!(a.identity_url&&b.identity_url&&identityUrl(a.identity_url)===identityUrl(b.identity_url));
}
function log(l,action,note){l.history.push({at:now(),action,note:txt(note)});l.updated_at=now();}
function contactKey(p){return norm(p.email)||txt(p.phone).replace(/\D/g,'')||norm(p.name);}
// Rediscovery keeps the sales history, but newly found facts (contacts, address, missing criteria) reach the main card.
function enrichExisting(same,l,st,opts={}){
 const changes=[],refresh=!!opts.refresh;
 // Targeted re-verification (refresh) may correct earlier data; plain rediscovery only fills gaps.
 if(refresh)for(const k of ['address','city','postal_code','client_type','context'])if(l[k]&&txt(same[k])!==l[k]){same[k]=l[k];changes.push(k);}
 if(l.business_profile&&(refresh||!same.business_profile||same.business_profile.fit==='unknown')&&JSON.stringify(same.business_profile)!==JSON.stringify(l.business_profile)){same.business_profile=l.business_profile;changes.push('profil działalności');}
 if(l.website_check&&(!same.website_check||same.website_check.status!=='verified'||refresh)&&JSON.stringify(same.website_check)!==JSON.stringify(l.website_check)){same.website_check=l.website_check;changes.push('weryfikacja strony');}
 if(l.registry&&(!same.registry||refresh)){same.registry=l.registry;changes.push('rejestr '+(l.registry.type||''));if(!same.nip&&l.registry.nip)same.nip=l.registry.nip;}
 if(l.branches){const old=same.branches||[];const add=l.branches.filter(b=>!old.some(o=>norm(o.city)===norm(b.city)&&norm(o.address)===norm(b.address)));if(add.length){same.branches=[...old,...add].slice(0,30);changes.push('oddziały +'+add.length);}}
 if(l.social){const old=same.social||[];const add=l.social.filter(x=>!old.some(o=>normUrl(o.url)===normUrl(x.url)));if(add.length){same.social=[...old,...add].slice(0,10);changes.push('profile społecznościowe +'+add.length);}}
 if(l.contact_search){same.contact_search=l.contact_search;}
 for(const k of ['address','city','postal_code','client_type','region','context'])if(!txt(same[k])&&l[k]){same[k]=l[k];changes.push(k);}
 if(l.active_status!=='unknown'&&same.active_status!==l.active_status){same.active_status=l.active_status;changes.push('aktywność');}
 let srcAdded=0;for(const s of l.sources)if(same.sources.length<30&&!same.sources.some(x=>normUrl(x.url)===normUrl(s.url))){same.sources.push(s);srcAdded++;}
 if(srcAdded)changes.push('źródła +'+srcAdded);
 let ctAdded=0;for(const p of l.contacts){const key=contactKey(p);if(!key||same.contacts.length>=30)continue;const old=same.contacts.find(x=>contactKey(x)===key);if(!old){same.contacts.push(p);ctAdded++;}else if(!old.verified&&p.verified){Object.assign(old,p);ctAdded++;}}
 if(ctAdded)changes.push('kontakty +'+ctAdded);
 const sameProfile=same.strategy_id===st.id||(same.profile.product_id===st.product_id&&norm(same.profile.segment)===norm(st.segment)&&norm(same.profile.client)===norm(st.client));
 if(sameProfile)for(const k of [...CRITERIA,'exclusion']){const old=same.criteria[k],nw=l.criteria[k];if(nw&&nw.value!=='unknown'&&(old.value==='unknown'||!old.evidence||(refresh&&(old.value!==nw.value||old.evidence!==nw.evidence)))){same.criteria[k]=nw;changes.push('kryterium '+(LABELS[k]||'wykluczenia'));}}
 if(l.draft?.body&&(!txt(same.draft?.body)||(refresh&&same.draft?.origin!=='manual'))){same.draft=l.draft;changes.push('szkic');}
 if(changes.length)log(same,'ENRICH','Uzupełniono kartę nowym researchem: '+changes.join(', ')+'.');
 return changes;
}
function merge(s,raw,st,opts={}){assert(Array.isArray(raw)&&raw.length<=MAX,'Import: wymagane maksymalnie '+MAX+' rekordów.');const leads=clone(s.leads),errors=[],duplicatesDetail=[],addedIds=[],matchedIds=[];let added=0,duplicates=0,enriched=0;
 raw.forEach((r0,i)=>{try{
  let r=r0;
  // 3.3: enrichment tasks carry lead_ref (lead id) and strategy_id per firm — robust matching even when Work finds a new own domain.
  const rowSt=(r&&typeof r==='object'&&txt(r.strategy_id)&&s.strategies.find(x=>x.id===txt(r.strategy_id)))||st;
  const ref=r&&typeof r==='object'?txt(r.lead_ref||r.lead_id,200):'';const byRef=ref?leads.find(x=>x.id===ref):null;
  if(byRef&&!txt(r.domain||r.website)&&!txt(r.nip)&&!txt(r.identity_url)){r={...r,domain:byRef.domain,nip:byRef.nip};if(!byRef.domain&&!byRef.nip&&byRef.identity_url){r.identity_url=byRef.identity_url;r.sources=[...(Array.isArray(r.sources)?r.sources:[]),...byRef.sources.filter(x=>identityUrl(x.url)===byRef.identity_url)];}if(!Array.isArray(r.sources)||!r.sources.length)r.sources=byRef.sources.slice(0,30);}
  const l=validateLead(r,s,rowSt);
  let same;
  if(byRef){assert(!(byRef.nip&&l.nip&&byRef.nip!==l.nip),'lead_ref wskazuje firmę o innym NIP ('+byRef.company+'). Sprawdź wynik Work.');same=byRef;}
  else{const exact=l.nip?leads.filter(x=>x.nip===l.nip):[],matches=exact.length?exact:leads.filter(x=>identityMatch(x,l));assert(matches.length<=1,'Niejednoznaczna firma: domena pasuje do kilku podmiotów. Uzupełnij NIP w wyniku Work.');same=matches[0];}
  if(same){duplicates++;matchedIds.push(same.id);if(!same.nip&&l.nip){same.nip=l.nip;log(same,'IDENTITY','Uzupełniono NIP z ponownego researchu: '+l.nip);}if(!same.domain&&l.domain){same.domain=l.domain;log(same,'IDENTITY','Ustalono własną stronę firmy: '+l.domain);}if(!same.identity_url&&l.identity_url&&(same.sources.length<30||same.sources.some(x=>identityUrl(x.url)===l.identity_url))){same.identity_url=l.identity_url;for(const source of l.sources)if(identityUrl(source.url)===l.identity_url&&!same.sources.some(x=>x.url===source.url))same.sources.push(source);}same.last_seen=today();same.sightings.push({at:now(),strategy_id:rowSt.id,profile:clone(rowSt),sources:l.sources,contacts:l.contacts,criteria:l.criteria,context:l.context,draft:l.draft});log(same,'REDISCOVER',(opts.refresh?'Uzupełnienie w Work: ':'Znaleziono ponownie: ')+rowSt.name+'. Zachowano status i obsługę; nowe dane uzupełniają kartę.');if(enrichExisting(same,l,rowSt,opts).length)enriched++;duplicatesDetail.push({company:same.company,id:same.id,status:same.status});return;}
  assert(leads.length<MAX,'Limit bazy: '+MAX+' firm.');leads.push(l);addedIds.push(l.id);added++;
 }catch(e){errors.push({row:i+1,company:txt(r0?.company),error:e.message});}});
 return {leads,added,duplicates,enriched,errors,duplicatesDetail,addedIds,matchedIds};}
function parse(text){
 assert(typeof text==='string','Wybierz plik JSON lub wklej jego zawartość.');
 assert(new TextEncoder().encode(text).length<=100000000,'Limit pliku: 100 MB.');
 let clean=text.replace(/^﻿/,'').trim();
 assert(clean,'Pole jest puste. Kliknij „Wybierz plik JSON z Work” albo wklej pełny JSON.');
 const fenced=clean.match(/^```(?:json)?\s*\n([\s\S]*?)\n```$/i);if(fenced)clean=fenced[1].trim();
 assert(!clean.startsWith('<'),'To dokument HTML, a nie wynik JSON. Pobierz plik .json z odpowiedzi Work.');
 let parsed;try{parsed=JSON.parse(clean);}catch{throw Error('Nieprawidłowy JSON. Pobierz pełny plik .json z Work; nie wklejaj samego linku ani skrótu z „…”.');}
 assert(parsed&&typeof parsed==='object','Wynik musi być obiektem JSON z tablicą leads albo tablicą firm.');return parsed;
}
function statusChange(l,stage,reason='',d=today(),channel='inne'){
 assert(STATUS[stage],'Nieprawidłowy status.');assert(date(d)&&age(d)>=0&&d>=l.first_seen,'Data działania musi mieścić się między wykryciem leada a dziś.');assert(reason.trim(),'Opisz wykonane działanie lub powód zmiany statusu.');assert(!(l.do_not_contact&&['TO_CONTACT','CONTACTED'].includes(stage)),'Najpierw zdejmij blokadę „Nie kontaktować”.');
 const out=clone(l);if(HIDDEN_STATUSES.includes(stage)&&!HIDDEN_STATUSES.includes(l.status))out.status_before=l.status;out.status=stage;out.milestones[stage]||=d;if(stage==='REJECTED')out.rejection_reason=txt(reason);log(out,'STATUS',`${STATUS[l.status]} → ${STATUS[stage]} | ${d} | ${channel} | ${reason}`);return out;
}
// Automatic archive: rejected leads after N days without edits; optionally untouched new leads.
function autoArchive(s,t=today()){
 const c=s.config;let n=0;
 for(const l of s.leads){
  if(HIDDEN_STATUSES.includes(l.status))continue;
  const last=txt(l.updated_at||l.history?.at(-1)?.at||l.first_seen).slice(0,10),idle=age(last,t);if(idle===null)continue;
  let why='';if(c.auto_archive_rejected_days&&l.status==='REJECTED'&&idle>=c.auto_archive_rejected_days)why=`odrzucony, brak zmian od ${idle} dni`;
  else if(c.auto_archive_inactive_days&&['NEW','REVIEW'].includes(l.status)&&idle>=c.auto_archive_inactive_days)why=`brak obsługi od ${idle} dni`;
  if(!why)continue;l.status_before=l.status;l.status='ARCHIVED';l.milestones.ARCHIVED||=t;log(l,'AUTO_ARCHIVE','Automatyczna archiwizacja: '+why+'.');n++;
 }
 return n;
}
// ---------- 3.3: messages ----------
function cleanOffer(o){return txt(o).replace(/\s*\(według strony[^)]*\)/gi,'').replace(/\s*Źródło:\s*\S+\s*[—-]\s*przed wysyłką[^.]*\.?/gi,'').replace(/\s*[—-]?\s*przed wysyłką potwierdź aktualność informacji\.?/gi,'').trim();}
function cleanSubject(x){return txt(x,300).replace(/[\r\n]+/g,' ').replace(/\s*\((do weryfikacji|robocz[ey])[^)]*\)/gi,'').trim();}
// Removes working notes, "according to the website" asides and quoted website snippets; returns removed fragments for the operator.
function cleanDraft(body){
 const removed=[];if(!txt(body))return {body:'',removed};
 let text=String(body).replace(/\r\n/g,'\n');
 text=text.replace(/\s*\((?:[^()]*?)(według strony|do weryfikacji|potwierd[źz]|sprawd[źz]|źródło)[^()]*\)/gi,m=>{removed.push(m.trim());return '';});
 const lines=text.split('\n').filter(line=>{const t=line.trim();if(!t)return true;
  if(/^(uwaga|notatka|nb|ps\.? dla operatora|do weryfikacji|todo|źródło)\b[:\s]/i.test(t)||/^\[.*\]$/.test(t)){removed.push(t);return false;}
  return true;});
 text=lines.join('\n');
 // Sentence level: drop sentences that are working notes or literal website citations.
 text=text.split(/(\n)/).map(seg=>seg==='\n'?seg:seg.split(/(?<=[.!?])\s+/).filter(sent=>{if(NOTE_RE.test(sent)&&!/^(dzień dobry|pozdrawiam)/i.test(sent.trim())){removed.push(sent.trim());return false;}if(/[„"»][^„"»«”]{3,250}[”"«]/.test(sent)&&/(stron|znalaz|informacj|ofert[aęy] [^.]{0,30}(ma|posiada))/i.test(sent)){removed.push(sent.trim());return false;}return true;}).join(' ')).join('');
 text=text.replace(/[ \t]+\n/g,'\n').replace(/\n{3,}/g,'\n\n').replace(/[ \t]{2,}/g,' ').trim();
 return {body:text,removed};
}
// Lint shown on the lead card: everything that makes a message sound automatic.
function draftIssues(d){
 const b=txt(d?.body),out=[];if(!b)return out;
 if(NOTE_RE.test(b))out.push('Zawiera uwagę roboczą lub odwołanie do „strony / źródła” — usuń przed wysyłką.');
 if(/[„"»][^„"»«”]{3,250}[”"«]/.test(b))out.push('Cytat ze strony odbiorcy — zastąp własnymi słowami.');
 if(/oddzia[łl]y? w [A-ZŁŚŻ]/.test(b))out.push('Lista oddziałów TABAL — zbędna w pierwszej wiadomości.');
 const words=b.split(/\s+/).filter(Boolean).length;if(words>160)out.push(`Wiadomość ma ${words} słów — celuj w 60–120.`);
 if(/https?:\/\/(?!(www\.)?tabal\.pl)/i.test(b))out.push('Link do strony odbiorcy lub źródła w treści.');
 return out;
}
function locative(segment){
 // "Branża ogrodzeniowa" -> "w branży ogrodzeniowej"; other phrases -> "w obszarze: …"
 const s=txt(segment,200).toLowerCase().replace(/[.;].*$/,'').trim();if(!s)return '';
 const m=s.match(/^branża\s+(.+)$/);if(m){const adj=m[1].split(/\s+/).map(w=>w.replace(/owa$/,'owej').replace(/(ń|n)a$/,'$1ej').replace(/ska$/,'skiej').replace(/cka$/,'ckiej').replace(/dzka$/,'dzkiej')).join(' ');return 'w branży '+adj;}
 return 'w obszarze: '+s;
}
// "produkcja mebli" -> "produkcją mebli"; returns '' when the phrase does not start with a known activity noun.
const INSTR={produkcja:'produkcją',sprzedaz:'sprzedażą',montaz:'montażem',dystrybucja:'dystrybucją',uslugi:'usługami',handel:'handlem',projektowanie:'projektowaniem',wykonawstwo:'wykonawstwem',wykonanie:'wykonaniem',serwis:'serwisem',instalacja:'instalacją',budowa:'budową',naprawa:'naprawą',wynajem:'wynajmem',hurtowa:'hurtową',detaliczna:'detaliczną',kompleksowe:'kompleksowymi',import:'importem',obrobka:'obróbką',wytwarzanie:'wytwarzaniem'};
function instrumental(phrase){const p=txt(phrase,200).replace(/[.;]+$/,'').trim();if(!p)return '';const words=p.split(/\s+/);if(!INSTR[norm(words[0]).replace(/ż/g,'z')])return '';return words.map(w=>INSTR[norm(w).replace(/ż/g,'z')]||w).join(' ').replace(/^./,ch=>ch.toLowerCase());}
function draft(l,c,products=[]){
 const co=bestContact(l,c),product=products.find(p=>p.id===l.profile.product_id)||TABAL_PRODUCTS.find(p=>p.id===l.profile.product_id);
 const fact=l.sources.find(s=>!sourceIssue(s,c));
 if(!fact)return {subject:'Współpraca z TABAL',body:'Brak aktualnego, sprawdzonego źródła. Uzupełnij research przed przygotowaniem wiadomości.'};
 const area=product?.name||l.product_name||'oferta TABAL',low=area.toLowerCase();
 const pitch=txt(product?.pitch)||TABAL_PRODUCTS.find(p=>p.id===product?.id)?.pitch||'';
 const sc=score(l,c),related=sc.checks.product==='related';
 const activity=txt(l.business_profile?.core_activity,200).replace(/\.$/,'');
 const where=locative(l.profile.segment);
 // 1) concrete reason, in our words — never a quote from their website
 const act=instrumental(activity);
 const reason=act?`kontaktuję się, ponieważ ${l.company} zajmuje się ${act}, a szukamy partnerów ${where||'w Państwa branży'}.`:`kontaktuję się, ponieważ ${l.company} działa ${where||'w branży bliskiej naszej ofercie'}, a szukamy partnerów do współpracy w zakresie: ${low}.`;
 // 2) one element of the offer that fits the recipient
 const offer=pitch?`W TABAL (Lublin) mamy ${pitch}.`:`W TABAL (Lublin) zajmujemy się ofertą: ${low}.`;
 // 3) possible benefit + one question
 const benefit=related?`Jeśli rozważają Państwo poszerzenie oferty o ${low}, chętnie pokażę, jak taki system mógłby wyglądać u Państwa.`:c.message_style==='technical'?'Chętnie przekażę parametry techniczne i porównam je z rozwiązaniami, z których Państwo korzystają.':'Może to być dla Państwa dodatkowe źródło dostaw albo uzupełnienie oferty dla klientów.';
 const question=c.message_style==='technical'?'Jakie parametry są dla Państwa kluczowe przy wyborze dostawcy?':c.message_style==='concise'?'Czy możemy krótko porozmawiać w przyszłym tygodniu?':'Czy byliby Państwo otwarci na krótką rozmowę o możliwej współpracy?';
 const handoff=!co?.person?' Jeśli tym tematem zajmuje się u Państwa inna osoba, będę wdzięczny za przekazanie wiadomości.':'';
 const body=c.message_style==='concise'
  ?`Dzień dobry,\n\n${reason} ${offer}\n\n${question}${handoff}\n\nPozdrawiam\n${c.sender}`
  :`Dzień dobry,\n\n${reason}\n\n${offer} ${benefit}\n\n${question}${handoff}\n\nPozdrawiam\n${c.sender}`;
 return {subject:related?`${area} — poszerzenie oferty z TABAL`:`${area} — współpraca z TABAL`,body};
}
function strategyMatches(l,id){return !id||l.strategy_id===id||l.sightings.some(r=>(r.strategy_id===id||r.profile?.id===id));}
function coverage(s,st){const names=list(st.benchmark);return names.map(name=>({name,found:s.leads.some(l=>strategyMatches(l,st.id)&&[l.company,l.domain].some(v=>norm(v).includes(norm(name))))}));}
function metrics(s){const keys=['NEW','ACCEPTED','CONTACTED','REPLIED','INTERESTED','OPPORTUNITY'];return keys.map(k=>({key:k,label:k==='NEW'?'Znalezione firmy':STATUS[k],count:s.leads.filter(l=>l.milestones[k]).length}));}
function backup(s){return JSON.stringify({kind:'tabal-lead-hunter-backup',schema_version:2,app_version:VERSION,exported_at:now(),state:s},null,2);}
function restoreLead(raw,s){
 const st=strategy(raw.profile),v=validateLead(raw,s,st);
 assert(raw.mail_events===undefined||(Array.isArray(raw.mail_events)&&raw.mail_events.every(e=>e&&typeof e.id==='string'&&typeof e.to==='string'&&typeof e.sent_at==='string')),'Uszkodzona historia wysyłki.');
 assert(STATUS[raw.status]&&txt(raw.id),'Uszkodzony status lub identyfikator.');assert(['pending','yes','no'].includes(raw.feedback),'Uszkodzony feedback.');assert(date(raw.first_seen)&&age(raw.first_seen)>=0&&date(raw.last_seen)&&age(raw.last_seen)>=0,'Błędne daty leada.');assert(Array.isArray(raw.history)&&Array.isArray(raw.sightings)&&raw.milestones&&typeof raw.milestones==='object','Brak historii leada.');assert(raw.history.every(e=>e&&typeof e==='object'&&typeof e.at==='string'&&typeof e.action==='string'&&typeof e.note==='string'),'Uszkodzone wpisy historii.');assert(raw.sightings.every(r=>r&&typeof r==='object'&&(r.legacy_record||(Array.isArray(r.sources)&&Array.isArray(r.contacts)&&r.criteria&&r.profile))),'Uszkodzona historia researchu.');for(const [k,d]of Object.entries(raw.milestones))assert(STATUS[k]&&date(d)&&age(d)>=0,'Błędny etap historyczny.');
 return {...v,...raw,sources:v.sources,contacts:v.contacts,criteria:v.criteria,profile:st};
}
function restore(text,mode){const x=parse(text);assert(x.kind==='tabal-lead-hunter-backup'&&x.schema_version===2&&x.state?.mode===mode,'Wybierz kopię v2 zgodną z bieżącym zbiorem.');const s=clone(x.state);s.config=settings(s.config);assert(Array.isArray(s.products)&&s.products.length>0&&s.products.every(p=>txt(p.id)&&txt(p.name)),'Uszkodzona lista produktów.');assert(new Set(s.products.map(p=>p.id)).size===s.products.length,'Powtórzone identyfikatory produktów.');assert(Array.isArray(s.strategies)&&s.strategies.length>0,'Kopia musi zawierać co najmniej jedną strategię.');s.strategies=s.strategies.map(strategy);assert(new Set(s.strategies.map(st=>st.id)).size===s.strategies.length,'Powtórzone identyfikatory strategii.');assert(s.strategies.every(st=>!st.product_id||s.products.some(p=>p.id===st.product_id)),'Strategia wskazuje nieistniejący produkt.');assert(Array.isArray(s.leads)&&s.leads.length<=MAX,'Nieprawidłowa baza leadów.');const ids=new Set();s.leads=s.leads.map(raw=>{const l=restoreLead(raw,s);assert(!ids.has(raw.id),'Uszkodzony status lub identyfikator.');ids.add(raw.id);return l;});for(const k of ['runs','cycles','audit'])assert(Array.isArray(s[k]),'Uszkodzona historia: '+k);assert(s.projects===undefined||Array.isArray(s.projects),'Uszkodzona lista projektów.');s.app_version=VERSION;return upgrade(s);}
// ---------- Projects ----------
function createProject(s,name,extra={}){const p=project({...extra,name:txt(name,200)||'Nowy projekt',id:uid(),created_at:now(),updated_at:now()});s.projects.push(p);return p;}
function touch(p){p.updated_at=now();return p;}
function projectLeads(s,p){const set=new Set(p?.lead_ids||[]);return s.leads.filter(l=>set.has(l.id));}
function leadProjects(s,l){return (s.projects||[]).filter(p=>p.lead_ids.includes(l.id));}
function addToProject(s,p,ids){const before=p.lead_ids.length;p.lead_ids=[...new Set([...p.lead_ids,...ids.filter(id=>s.leads.some(l=>l.id===id))])];touch(p);return p.lead_ids.length-before;}
function removeFromProject(s,p,ids){const set=new Set(ids),before=p.lead_ids.length;p.lead_ids=p.lead_ids.filter(id=>!set.has(id));touch(p);for(const l of s.leads)if(set.has(l.id))log(l,'PROJECT','Usunięto z projektu: '+p.name+'.');return before-p.lead_ids.length;}
function mergeProjects(s,targetId,sourceIds){
 const target=s.projects.find(p=>p.id===targetId);assert(target,'Wybierz projekt docelowy.');const sources=s.projects.filter(p=>sourceIds.includes(p.id)&&p.id!==targetId);assert(sources.length,'Wybierz co najmniej jeden inny projekt do połączenia.');
 for(const p of sources){target.lead_ids=[...new Set([...target.lead_ids,...p.lead_ids])];target.run_ids=[...new Set([...target.run_ids,...p.run_ids])];target.strategy_ids=[...new Set([...target.strategy_ids,...p.strategy_ids])];for(const r of s.runs)if(r.project_id===p.id)r.project_id=target.id;}
 s.projects=s.projects.filter(p=>!sources.includes(p));touch(target);s.audit.push({at:now(),action:'PROJECT_MERGE',note:'Połączono w „'+target.name+'”: '+sources.map(p=>p.name).join(', ')});return target;
}
function deleteLeads(s,ids){const set=new Set(ids),before=s.leads.length;s.leads=s.leads.filter(l=>!set.has(l.id));for(const p of s.projects)p.lead_ids=p.lead_ids.filter(id=>!set.has(id));for(const r of s.runs)if(Array.isArray(r.result_ids))r.result_ids=r.result_ids.filter(id=>!set.has(id));s.audit.push({at:now(),action:'DELETE_LEADS',note:'Trwale usunięto '+(before-s.leads.length)+' firm.'});return before-s.leads.length;}
function projectExport(s,p){return JSON.stringify({kind:'tabal-project',schema_version:1,app_version:VERSION,exported_at:now(),mode:s.mode,project:p,leads:projectLeads(s,p),strategies:s.strategies.filter(st=>p.strategy_ids.includes(st.id)||projectLeads(s,p).some(l=>l.strategy_id===st.id)),runs:s.runs.filter(r=>p.run_ids.includes(r.id)||r.project_id===p.id)},null,2);}
function importProject(s,text){
 const x=typeof text==='string'?parse(text):text;assert(x.kind==='tabal-project'&&x.schema_version===1&&x.project&&Array.isArray(x.leads),'To nie jest plik projektu Lead Huntera (kind: tabal-project).');
 const exists=s.projects.some(p=>p.id===x.project.id);
 const p=project({...x.project,id:exists?uid():x.project.id,archived:false,archived_at:'',lead_ids:[],source:'import'});if(exists)p.name+=' (wczytany)';
 for(const st of (Array.isArray(x.strategies)?x.strategies:[])){const v=strategy(st);if(!s.strategies.some(y=>y.id===v.id)&&(!v.product_id||s.products.some(pr=>pr.id===v.product_id)))s.strategies.push(v);}
 let added=0,matched=0;const errors=[];
 for(const [i,raw] of x.leads.entries()){try{const l=restoreLead(raw,s);const existing=s.leads.find(o=>o.id===l.id)||s.leads.find(o=>identityMatch(o,l));if(existing){matched++;p.lead_ids.push(existing.id);continue;}assert(s.leads.length<MAX,'Limit bazy: '+MAX+' firm.');s.leads.push(l);p.lead_ids.push(l.id);added++;}catch(e){errors.push({row:i+1,company:txt(raw?.company),error:e.message});}}
 p.lead_ids=[...new Set(p.lead_ids)];touch(p);s.projects.push(p);s.audit.push({at:now(),action:'PROJECT_IMPORT',note:`Wczytano projekt „${p.name}”: nowe ${added}, istniejące ${matched}, błędy ${errors.length}.`});
 return {project:p,added,matched,errors};
}
// ---------- Exports (CSV, NoSQL-ready JSON / JSON Lines) ----------
function leadDocument(s,l){
 const sc=score(l,s.config),co=sc.contact;
 return {_id:l.id,type:'lead',company:l.company,domain:l.domain,nip:l.nip,identity_url:l.identity_url||'',address:l.address||'',city:l.city||'',postal_code:l.postal_code||'',region:l.region,client_type:l.client_type||'',active_status:l.active_status||'unknown',business_profile:l.business_profile||null,website_check:l.website_check||null,registry:l.registry||null,branches:l.branches||[],nearest_branch:api.nearestBranch?.(l,s.config)||null,social:l.social||[],contact_search:l.contact_search||null,
  product:{id:l.profile.product_id,name:l.product_name},strategy:{id:l.strategy_id,name:l.profile.name},projects:leadProjects(s,l).map(p=>({_id:p.id,name:p.name})),
  status:{code:l.status,label:STATUS[l.status],color:STATUS_COLOR[l.status]},score:{points:sc.points,qualified:sc.qualified,checks:sc.checks,parts:sc.parts.map(p=>({criterion:p.key,label:p.label,points:Math.round(p.points*10)/10,max:Math.round(p.max*10)/10,state:p.state,reason:p.reason})),blocks:sc.blocks},
  best_contact:co?{type:co.p.type,name:co.p.name,role:co.p.role,email:co.p.email,phone:co.p.phone,confirmed:co.usable,needs_verification:!co.usable,issue:co.issue}:null,
  contacts:l.contacts,sources:l.sources,criteria:l.criteria,context:l.context,feedback:{value:l.feedback,note:l.feedback_note},rejection_reason:l.rejection_reason,notes:l.notes,do_not_contact:l.do_not_contact,
  first_seen:l.first_seen,last_seen:l.last_seen,updated_at:l.updated_at||'',milestones:l.milestones,history:l.history,mail_events:l.mail_events||[],draft:l.draft};
}
function exportNoSQL(s,{format='json',leads=s.leads,projects=s.projects}={}){
 const docs=leads.map(l=>leadDocument(s,l));
 if(format==='ndjson')return docs.map(d=>JSON.stringify(d)).join('\n')+'\n';
 return JSON.stringify({kind:'tabal-lead-hunter-nosql',schema_version:1,app_version:VERSION,exported_at:now(),collections:{leads:docs,projects:projects.map(p=>({_id:p.id,...p,id:undefined})),strategies:s.strategies.map(st=>({_id:st.id,...st,id:undefined})),products:s.products.map(p=>({_id:p.id,...p,id:undefined}))}},null,2);
}
function csv(s,leads=s.leads){const headers=['Firma','Domena','NIP','Adres','Miejscowość','Typ klienta','Profil działalności','Dopasowanie profilu','Rejestr / status','Oddział najbliżej TABAL','Produkt','Strategia','Projekty','Region','Scoring','Uzasadnienie scoringu','Status','Dobry/zły lead','Powód feedbacku','Powód odrzucenia','Osoba','Stanowisko','E-mail','Telefon','Źródło kontaktu','Kontakt do weryfikacji (niepotwierdzony)','Źródła researchu','Pierwsze wykrycie','Ostatnie wykrycie','Ostatnia edycja','Nie kontaktować','Notatki'];const cell=x=>'"'+(/^[\s]*[=+\-@]/.test(String(x??''))?"'":'')+String(x??'').replace(/"/g,'""')+'"';return '﻿'+[headers,...leads.map(l=>{const sc=score(l,s.config),co=sc.contact,unsure=l.contacts.filter(p=>!contactQuality(p,s.config).usable&&(p.email||p.phone)).map(p=>[p.name,p.email,p.phone].filter(Boolean).join(' ')).join(' | ');const near=api.nearestBranch?.(l,s.config);return [l.company,l.domain,l.nip,l.address,l.city,l.client_type||l.profile.client,l.business_profile?.core_activity||'',{core:'zgodny',related:'pokrewny',unrelated:'niezgodny'}[l.business_profile?.fit]||(sc.checks.product==='related'?'pokrewny (wg segmentu)':''),l.registry?[l.registry.type,l.registry.status].filter(Boolean).join(' '):'',near?near.city+' ('+near.km+' km)':'',l.product_name,l.profile.name,leadProjects(s,l).map(p=>p.name).join(' | '),l.region,sc.points,sc.parts.filter(p=>p.state!=='na').map(p=>p.label+' '+Math.round(p.points)+'/'+Math.round(p.max)+(p.state==='ok'?'':' ('+({partial:'dowód niepełny',unknown:'nie ustalono',no:'niezgodne'}[p.state]||p.state)+')')).join(' | '),STATUS[l.status],l.feedback,l.feedback_note,l.rejection_reason,co?.person?co.p.name:'',co?.person?co.p.role:'',co?.email?co.p.email:'',co?.phone?co.p.phone:'',co?.p.url||'',unsure,l.sources.map(s=>s.url).join(' | '),l.first_seen,l.last_seen,txt(l.updated_at).slice(0,16).replace('T',' '),l.do_not_contact,l.notes];})].map(r=>r.map(cell).join(';')).join('\r\n');}
function sample(st,s,demo=true){const sourceUrl='https://example.com/oferta',quote='PRZYKŁAD FIKCYJNY: dystrybucja i montaż ogrodzeń panelowych w Polsce. Kupujemy panele od dostawców, nie produkujemy ich.';const criteria={};for(const k of [...CRITERIA,'exclusion'])criteria[k]={value:k==='exclusion'?'no':'yes',evidence:quote,url:sourceUrl};return {company:'Partner Ogrodzeń DEMO',domain:'partner-demo.example',nip:'',region:'mazowieckie',address:'ul. Przykładowa 1, 00-001 Warszawa',city:'Warszawa',client_type:'Dystrybutor i monter ogrodzeń',context:'Fikcyjna firma do testów procesu.',is_demo:demo,sources:[{url:sourceUrl,title:'Oferta DEMO',quote,checked_at:today(),verified:true}],contacts:[{type:'person',name:'Anna Przykładowa',role:'Kierownik zakupów',reason:'Fikcyjna funkcja zakupowa związana z doborem dostawców.',email:'anna@example.com',phone:'',url:'https://example.com/kontakt',quote:'Anna Przykładowa — Kierownik zakupów — anna@example.com',checked_at:today(),verified:true}],criteria};}

function legacyRaw(raw){const productMap={Techfence:'panel',Alufence:'alu'};const seg={industrial:'Inwestor przemysłowy / logistyczny',contractor:'Generalny wykonawca',reseller:'Dystrybutor / instalator',residential:'Deweloper mieszkaniowy',public:'Sektor publiczny',other:'Inny'};const st=strategy({id:'legacy-'+(raw.product||'panel'),name:'Migracja v1 — '+(raw.product||'produkt'),product_id:productMap[raw.product]||'panel',segment:seg[raw.segment]||raw.segment||'Do weryfikacji',client:seg[raw.segment]||'Do weryfikacji',region:raw.region||'Polska',extra:'',exclusions:''});const c=raw.contact||{};const r={company:raw.company,domain:raw.domain,region:raw.region,context:[raw.project,raw.evidence,raw.product_reason].filter(Boolean).join('\n'),is_demo:raw.is_demo===true,sources:[{url:raw.source_url,title:raw.source_title,quote:raw.quote||raw.evidence,checked_at:raw.detected_at,verified:raw.source_verified}],contacts:(c.email||c.phone||c.name)?[{...c,type:c.name?'person':'general',reason:raw.enrichment_note||'',checked_at:c.verified_at,verified:c.reviewed}]:[],criteria:{}};for(const k of [...CRITERIA,'exclusion'])r.criteria[k]={value:'unknown',evidence:'Wymaga ponownej kwalifikacji według v2.',url:raw.source_url};return {r,st};}
function migrateV1(x,mode){assert(x.kind==='tabal-lead-hunter-backup'&&x.schema_version===1&&x.state?.mode===mode,'Kopia v1 musi odpowiadać wybranemu zbiorowi.');const s=makeState(mode), map={FOUND:'NEW',QUALIFIED:'REVIEW',ENRICHED:'REVIEW',CONTACTED:'CONTACTED',REPLIED:'REPLIED',OPPORTUNITY:'OPPORTUNITY'};assert(Array.isArray(x.state.leads)&&x.state.leads.length<=MAX,'Błędna kopia v1.');s.legacy_backup=clone(x);s.config=settings({threshold:x.state.config?.threshold??65,max_age_days:x.state.config?.max_age_days??90,contact_age_days:x.state.config?.contact_max_age_days??60,sender:x.state.config?.sender,excluded_domains:x.state.config?.excluded_domains,offer:TABAL_OFFER});const oldCfg=x.state.config||{};s.strategies.push(strategy({id:'v1-saved-profile',name:oldCfg.name||'Profil zapisany w v1',product_id:oldCfg.product==='Alufence'?'alu':'panel',segment:(oldCfg.segments||['Do weryfikacji']).join(', '),client:(oldCfg.segments||['Do weryfikacji']).join(', '),region:(oldCfg.regions||[]).join(', ')||oldCfg.country||'Polska',extra:'Profil przeniesiony z v1 — doprecyzuj segment i typ klienta.',exclusions:''}));for(const raw of x.state.leads){const {r,st}=legacyRaw(raw);if(!s.strategies.some(y=>y.id===st.id))s.strategies.push(st);const l=validateLead(r,s,st);l.status=map[raw.status]||'NEW';l.notes=txt(raw.notes);l.feedback=['yes','no'].includes(raw.feedback)?raw.feedback:'pending';l.feedback_note=txt(raw.feedback_note);l.do_not_contact=raw.do_not_contact===true;l.first_seen=date(raw.detected_at)?raw.detected_at:today();l.last_seen=l.first_seen;l.history=Array.isArray(raw.history)?clone(raw.history):[];l.milestones={NEW:l.first_seen};for(const [old,d]of Object.entries(raw.milestones||{})){const target=map[old];if(target&&date(d.slice(0,10)))l.milestones[target]=d.slice(0,10);}if(raw.feedback==='yes')l.milestones.ACCEPTED=l.first_seen;log(l,'MIGRATE','Zachowano v1; nowy scoring wymaga weryfikacji kryteriów.');const existing=s.leads.find(a=>identityMatch(a,l));if(existing){existing.notes+='\n\n[Projekt z v1]\n'+r.context+'\n'+l.notes;existing.history.push(...l.history);existing.do_not_contact||=l.do_not_contact;for(const [k,d]of Object.entries(l.milestones))existing.milestones[k]||=d;existing.sightings.push({at:now(),legacy_record:clone(raw)});if(Object.keys(STATUS).indexOf(l.status)>Object.keys(STATUS).indexOf(existing.status))existing.status=l.status;}else s.leads.push(l);}s.cycles=clone(x.state.cycles||[]);s.audit.push({at:now(),action:'MIGRATE_V1',note:'Pełna kopia oryginału w legacy_backup; '+x.state.leads.length+' rekordów → '+s.leads.length+' firm.'});return s;}
function mailCandidate(l,c,mode){
 const reasons=[];if(mode!=='pilot'||l.is_demo)reasons.push('Wysyłka tylko z Mojego pilota.');
 if(l.status!=='TO_CONTACT')reasons.push('Ustaw status DO KONTAKTU.');
 if(l.do_not_contact)reasons.push('Firma ma blokadę kontaktu.');
 if(c.excluded_domains.some(d=>l.domain===d||l.domain.endsWith('.'+d)))reasons.push('Firma na liście wykluczeń.');
 const contact=l.contacts.map(p=>({p,...contactQuality(p,c)})).filter(q=>q.usable&&q.email).sort((a,b)=>Number(b.person)-Number(a.person))[0];
 if(!contact)reasons.push('Brak aktualnego, potwierdzonego e-maila (kontakt niepewny wymaga weryfikacji przed wysyłką).');
 if(!txt(l.draft?.subject)||!txt(l.draft?.body))reasons.push('Otwórz kartę, sprawdź i zapisz temat oraz treść szkicu.');
 if(/[\r\n]/.test(l.draft?.subject||''))reasons.push('Temat musi być jednowierszowy.');
 if(contact&&(l.mail_events||[]).some(e=>e.to?.toLowerCase()===contact.p.email.toLowerCase()))reasons.push('W historii jest już wysyłka na ten adres.');
 return {reasons,message:reasons.length?null:{mode,lead_id:l.id,company:l.company,to:contact.p.email,subject:l.draft.subject,body:l.draft.body,status:l.status,is_demo:false,do_not_contact:false,verified_email:true}};
}
function applyMailReceipt(l,job){
 if(job.status!=='sent'||job.lead_id!==l.id||(l.mail_events||[]).some(e=>e.id===job.id))return false;
 const d=job.sent_at?.slice(0,10);if(!date(d)||age(d)<0)return false;
 l.mail_events||=[];l.mail_events.push({id:job.id,to:job.to,subject:job.subject,sent_at:job.sent_at,message_id:job.message_id});
 l.milestones.CONTACTED||=d;
 if(['NEW','REVIEW','ACCEPTED','TO_CONTACT'].includes(l.status))l.status='CONTACTED';
 log(l,'EMAIL_SENT','SMTP przyjął wiadomość: '+job.to+' | '+job.subject+' | '+job.message_id+'. Przyjęcie przez SMTP nie jest potwierdzeniem doręczenia.');return true;
}
const api={TABAL_LOCATIONS,OLD_TABAL_OFFER,RELATED_VALUES,FITS,SOURCE_KIND_LABEL,businessProfile,websiteCheck,registryInfo,branchList,socialList,sourceKind,contactSource,industryState,cleanOffer,cleanDraft,cleanSubject,draftIssues,locative,instrumental,identityUrl,sharedDomain,strategyMatches,coverage,mailCandidate,applyMailReceipt,VERSION,MAX,STATUS,STATUS_COLOR,STATUS_LEGEND,HIDDEN_STATUSES,REASONS,LABELS,CRITERIA,DEFAULT_WEIGHTS,OLD_DEFAULT_WEIGHTS,TABAL_PRODUCTS,TABAL_OFFER,TABAL_URL,clone,txt,norm,now,today,uid,date,age,url,normUrl,domain,list,assert,settings,strategy,countryKey,makeState,upgrade,validateLead,contact,score,sourceIssue,evidenceCheck,contactQuality,bestContact,identityMatch,merge,parse,statusChange,autoArchive,draft,metrics,backup,restore,csv,sample,log,migrateV1,legacyRaw,project,createProject,projectLeads,leadProjects,addToProject,removeFromProject,mergeProjects,deleteLeads,projectExport,importProject,leadDocument,exportNoSQL};
return Object.assign(api,typeof module==='object'&&module.exports?require('./research.js')(api):globalThis.TabalResearch(api));
});
