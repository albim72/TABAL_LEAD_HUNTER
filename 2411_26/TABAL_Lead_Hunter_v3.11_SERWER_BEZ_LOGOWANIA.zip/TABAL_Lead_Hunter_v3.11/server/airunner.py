"""3.11 (TABAL 19–24.11.2026): research tasks run on the server through the AI provider's API.

Why: in ChatGPT Work one search of 100 companies takes 14–46% of the 5-hour plan limit, so one person ends at
~500 messages a day. Through the API TABAL pays per token (its own key, its own invoice): no 5-hour window,
no copy/paste of the task and the JSON, several tasks at the same time, work continues after closing the panel.

The task text is exactly the one prepared for Work (same plan, rules, schema and import). The server only adds a short
note that there is no chat and no file — the answer must be the JSON itself.

Provider: an OpenAI-compatible Responses API (POST {base}/responses with a web-search tool, background mode,
polling GET {base}/responses/{id}). Base URL, model, tool name and reasoning effort come from .env.

The API key is never stored in the workspace data, never sent to the browser and never written to logs.
"""
import json
import os
import sqlite3
import threading
import time
import urllib.error
import urllib.request
import uuid

API_NOTE = ('TRYB API (Lead Hunter 3.11): to zadanie wykonujesz automatycznie, bez czatu i bez plików. '
            'Nie zadawaj pytań i nie proś o potwierdzenie — nikt nie odpowie. Wykonaj całe zadanie, a na końcu zwróć '
            'WYŁĄCZNIE kompletny obiekt JSON zgodny ze schematem z zadania: bez tekstu przed i po, bez bloku kodu, '
            'bez linków do pobrania. Jeśli zabraknie czasu, zwróć JSON z tym, co potwierdziłeś, i wpisz niesprawdzone '
            'miejscowości do research_report.remaining_areas.\n\n')
STATUS = ('queued', 'running', 'done', 'error', 'cancelled')
MAX_TASK = 2_000_000
MAX_RESULT = 20_000_000


def _env(name, default=''):
    return (os.environ.get(name) or default).strip()


def _int_env(name, default, lo, hi):
    try:
        v = int(_env(name, str(default)))
    except ValueError:
        v = default
    return max(lo, min(hi, v))


def response_text(data):
    """Text of the final answer from a Responses API object (all output_text parts of message items)."""
    if not isinstance(data, dict):
        return ''
    parts = []
    for item in data.get('output') or []:
        if isinstance(item, dict) and item.get('type') == 'message':
            for c in item.get('content') or []:
                if isinstance(c, dict) and c.get('type') in ('output_text', 'text') and isinstance(c.get('text'), str):
                    parts.append(c['text'])
    if not parts and isinstance(data.get('output_text'), str):
        parts.append(data['output_text'])
    return '\n'.join(parts).strip()


def search_calls(data):
    return sum(1 for i in (data.get('output') or []) if isinstance(i, dict) and str(i.get('type', '')).startswith('web_search'))


class AIRunner:
    def __init__(self, path, opener=None):
        self.lock = threading.RLock()
        self.db = sqlite3.connect(str(path), check_same_thread=False, timeout=30)
        self.db.row_factory = sqlite3.Row
        self.db.execute('PRAGMA journal_mode=WAL')
        self.db.executescript('''CREATE TABLE IF NOT EXISTS ai_jobs(id TEXT PRIMARY KEY,created REAL,label TEXT,batch_id TEXT,
            run_id TEXT,status TEXT,response_id TEXT,task TEXT,result TEXT,error TEXT,input_tokens INTEGER DEFAULT 0,
            output_tokens INTEGER DEFAULT 0,searches INTEGER DEFAULT 0,started REAL,finished REAL,imported INTEGER DEFAULT 0,
            import_note TEXT DEFAULT '',model TEXT,last_poll REAL DEFAULT 0)''')
        self.stop = threading.Event()
        self.opener = opener or urllib.request.urlopen
        self.panel_key = ''
        self.panel_model = ''
        self.reload()

    # ---- configuration -------------------------------------------------------------------------------------------
    def reload(self):
        self.base = _env('TABAL_AI_BASE_URL', 'https://api.openai.com/v1').rstrip('/')
        self.env_key = _env('TABAL_AI_API_KEY') or _env('TABAL_OPENAI_API_KEY')
        self.env_model = _env('TABAL_AI_MODEL')
        self.tool = _env('TABAL_AI_SEARCH_TOOL', 'web_search')
        self.effort = _env('TABAL_AI_REASONING', 'medium')
        self.parallel = _int_env('TABAL_AI_PARALLEL', 4, 1, 12)
        self.max_minutes = _int_env('TABAL_AI_MAX_MINUTES', 90, 5, 600)
        self.poll_seconds = _int_env('TABAL_AI_POLL_SECONDS', 15, 1, 300)
        try:
            self.price_in = float(_env('TABAL_AI_PRICE_IN', '0') or 0)
            self.price_out = float(_env('TABAL_AI_PRICE_OUT', '0') or 0)
        except ValueError:
            self.price_in = self.price_out = 0.0
        self.currency = _env('TABAL_AI_CURRENCY', 'USD')[:5]

    @property
    def key(self):
        return self.panel_key or self.env_key

    @property
    def model(self):
        return self.panel_model or self.env_model

    def configured(self):
        return bool(self.key and self.model)

    def set_panel(self, api_key=None, model=None):
        """Key typed in the panel is kept only in server memory (like the SMTP password)."""
        with self.lock:
            if api_key is not None:
                k = str(api_key).strip()
                if k and (len(k) < 20 or len(k) > 400 or any(c.isspace() for c in k)):
                    raise ValueError('Klucz API wygląda na niepoprawny.')
                self.panel_key = k
            if model is not None:
                m = str(model).strip()
                if m and (len(m) > 100 or any(c.isspace() for c in m)):
                    raise ValueError('Nazwa modelu bez spacji, do 100 znaków.')
                self.panel_model = m
        return self.info()

    def info(self):
        k = self.key
        return {'configured': self.configured(), 'model': self.model, 'key_hint': ('…' + k[-4:]) if k else '',
                'key_source': 'panel' if self.panel_key else ('env' if self.env_key else ''), 'parallel': self.parallel,
                'max_minutes': self.max_minutes, 'base_url': self.base, 'price_in': self.price_in,
                'price_out': self.price_out, 'currency': self.currency}

    # ---- jobs ----------------------------------------------------------------------------------------------------
    def add(self, items):
        if not self.configured():
            raise ValueError('Tryb API nie jest skonfigurowany: ustaw klucz API i model (plik .env: TABAL_AI_API_KEY, '
                             'TABAL_AI_MODEL albo w panelu Odkrywanie → Tryb API).')
        if not isinstance(items, list) or not 1 <= len(items) <= 20:
            raise ValueError('Jedno zlecenie: 1–20 zadań.')
        ids = []
        with self.lock, self.db:
            for it in items:
                if not isinstance(it, dict):
                    raise ValueError('Błędne zadanie.')
                task = it.get('task')
                if not isinstance(task, str) or not 200 <= len(task) <= MAX_TASK:
                    raise ValueError('Zadanie musi być pełnym tekstem zadania z Lead Huntera.')
                batch = str(it.get('batch_id') or '')[:80]
                if batch and self.db.execute("SELECT 1 FROM ai_jobs WHERE batch_id=? AND status IN ('queued','running')",
                                             (batch,)).fetchone():
                    raise ValueError('To zadanie już działa w trybie API.')
                jid = uuid.uuid4().hex[:16]
                self.db.execute('INSERT INTO ai_jobs(id,created,label,batch_id,run_id,status,task,model) VALUES(?,?,?,?,?,?,?,?)',
                                (jid, time.time(), str(it.get('label') or 'Zadanie')[:200], batch,
                                 str(it.get('run_id') or '')[:80], 'queued', task, self.model))
                ids.append(jid)
        return {'ids': ids, **self.snapshot()}

    def snapshot(self):
        with self.lock:
            rows = self.db.execute('SELECT id,created,label,batch_id,run_id,status,error,input_tokens,output_tokens,searches,'
                                   'started,finished,imported,import_note,model,length(result) AS result_size FROM ai_jobs '
                                   'ORDER BY created DESC LIMIT 60').fetchall()
        jobs = []
        for r in rows:
            j = dict(r)
            j['cost'] = round(j['input_tokens'] / 1e6 * self.price_in + j['output_tokens'] / 1e6 * self.price_out, 4) \
                if (self.price_in or self.price_out) else None
            jobs.append(j)
        return {'ai': self.info(), 'jobs': jobs}

    def result(self, jid):
        with self.lock:
            r = self.db.execute('SELECT status,result,label,batch_id,run_id FROM ai_jobs WHERE id=?', (str(jid),)).fetchone()
        if not r:
            raise ValueError('Nie znaleziono zadania API.')
        if r['status'] != 'done':
            raise ValueError('Zadanie API nie jest zakończone.')
        return {'id': jid, 'result': r['result'] or '', 'label': r['label'], 'batch_id': r['batch_id'], 'run_id': r['run_id']}

    def mark(self, jid, imported, note=''):
        with self.lock, self.db:
            self.db.execute('UPDATE ai_jobs SET imported=?,import_note=? WHERE id=?', (1 if imported else 0, str(note)[:500], str(jid)))
        return self.snapshot()

    def cancel(self, jid):
        with self.lock:
            r = self.db.execute('SELECT status,response_id FROM ai_jobs WHERE id=?', (str(jid),)).fetchone()
        if not r:
            raise ValueError('Nie znaleziono zadania API.')
        if r['status'] in ('queued', 'running'):
            if r['response_id']:
                try:
                    self._call('POST', '/responses/' + r['response_id'] + '/cancel', {})
                except (ValueError, OSError):
                    pass
            self._finish(jid, 'cancelled', error='Anulowano w panelu.')
        return self.snapshot()

    # ---- provider calls --------------------------------------------------------------------------------------------
    def _call(self, method, path, payload=None):
        data = json.dumps(payload).encode() if payload is not None else None
        req = urllib.request.Request(self.base + path, data=data, method=method,
                                     headers={'Authorization': 'Bearer ' + self.key, 'Content-Type': 'application/json',
                                              'User-Agent': 'TABAL-Lead-Hunter/3.11'})
        try:
            with self.opener(req, timeout=90) as resp:
                body = resp.read(MAX_RESULT + 1)
        except urllib.error.HTTPError as e:
            try:
                msg = json.loads(e.read(200_000) or b'{}').get('error', {})
                msg = msg.get('message') if isinstance(msg, dict) else str(msg)
            except (ValueError, AttributeError):
                msg = ''
            hint = {401: 'nieprawidłowy klucz API', 403: 'brak dostępu do modelu', 404: 'nieznany model lub adres API',
                    429: 'limit lub brak środków na koncie API — doładuj konto (tokeny)'}.get(e.code, 'błąd dostawcy')
            raise ValueError(f'API {e.code}: {hint}' + (f' ({msg[:300]})' if msg else '')) from None
        if len(body) > MAX_RESULT:
            raise ValueError('Odpowiedź API jest za duża.')
        try:
            return json.loads(body)
        except ValueError:
            raise ValueError('API zwróciło niepoprawną odpowiedź.') from None

    def _submit(self, row):
        payload = {'model': row['model'] or self.model, 'input': API_NOTE + row['task'], 'tools': [{'type': self.tool}],
                   'background': True, 'store': True}
        if self.effort and self.effort != 'none':
            payload['reasoning'] = {'effort': self.effort}
        data = self._call('POST', '/responses', payload)
        rid = data.get('id')
        if not isinstance(rid, str) or not rid:
            raise ValueError('API nie zwróciło identyfikatora zadania.')
        with self.lock, self.db:
            self.db.execute("UPDATE ai_jobs SET status='running',response_id=?,started=?,last_poll=? WHERE id=?",
                            (rid, time.time(), time.time(), row['id']))
        self._apply(row['id'], data)

    def _finish(self, jid, status, result=None, error=''):
        with self.lock, self.db:
            self.db.execute('UPDATE ai_jobs SET status=?,result=COALESCE(?,result),error=?,finished=? WHERE id=?',
                            (status, result, str(error)[:1000], time.time(), jid))

    def _apply(self, jid, data):
        st = data.get('status')
        usage = data.get('usage') or {}
        with self.lock, self.db:
            self.db.execute('UPDATE ai_jobs SET input_tokens=?,output_tokens=?,searches=?,last_poll=? WHERE id=?',
                            (int(usage.get('input_tokens') or 0), int(usage.get('output_tokens') or 0), search_calls(data),
                             time.time(), jid))
        if st == 'completed':
            text = response_text(data)
            if text:
                self._finish(jid, 'done', result=text)
            else:
                self._finish(jid, 'error', error='API zakończyło zadanie bez odpowiedzi tekstowej.')
        elif st == 'incomplete':
            text = response_text(data)
            reason = (data.get('incomplete_details') or {}).get('reason') or 'przerwane'
            if text:
                self._finish(jid, 'done', result=text, error='Odpowiedź niepełna (' + str(reason) + ') — zaimportowano to, co zwrócono.')
            else:
                self._finish(jid, 'error', error='Zadanie przerwane przez API: ' + str(reason))
        elif st in ('failed', 'cancelled'):
            err = data.get('error') or {}
            self._finish(jid, 'error' if st == 'failed' else 'cancelled',
                         error=(err.get('message') if isinstance(err, dict) else str(err)) or ('API: ' + st))

    def tick(self):
        """One scheduler step: poll running jobs, start queued ones up to the parallel limit, enforce the time limit."""
        now = time.time()
        with self.lock:
            running = self.db.execute("SELECT * FROM ai_jobs WHERE status='running'").fetchall()
            queued = self.db.execute("SELECT * FROM ai_jobs WHERE status='queued' ORDER BY created").fetchall()
        for row in running:
            if row['started'] and now - row['started'] > self.max_minutes * 60:
                try:
                    self._call('POST', '/responses/' + row['response_id'] + '/cancel', {})
                except (ValueError, OSError):
                    pass
                self._finish(row['id'], 'error', error=f'Przekroczono limit czasu {self.max_minutes} min (TABAL_AI_MAX_MINUTES).')
                continue
            if now - (row['last_poll'] or 0) < self.poll_seconds:
                continue
            try:
                self._apply(row['id'], self._call('GET', '/responses/' + row['response_id']))
            except ValueError as e:
                if 'API 4' in str(e) and 'API 429' not in str(e):
                    self._finish(row['id'], 'error', error=str(e))
            except OSError:
                pass  # network hiccup — try again on the next tick
        free = self.parallel - sum(1 for r in running if r['status'] == 'running')
        for row in queued[:max(0, free)]:
            if not self.configured():
                break
            try:
                self._submit(row)
            except ValueError as e:
                self._finish(row['id'], 'error', error=str(e))
            except OSError as e:
                self._finish(row['id'], 'error', error='Brak połączenia z API: ' + str(e)[:200])

    def work(self):
        while not self.stop.is_set():
            try:
                self.tick()
            except Exception:  # never let the scheduler thread die
                import traceback
                traceback.print_exc()
            self.stop.wait(3)
