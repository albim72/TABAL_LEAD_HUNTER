"""Server SMTP outbox. Password is held in memory (or, only on explicit request, in a 0600 file next to the database).

3.5 (TABAL 23.10 #4, #5, #9):
  * unattended sending — the queue keeps working after the panel is closed; every message is re-checked against
    the stored data right before sending (changed status / draft / address = cancelled, never sent);
  * daily limit, interval down to 10 s, batches up to 300 messages per request;
  * optional HTML part (company signature), optional copy in the mailbox "Sent" folder (IMAP) or Bcc to the sender;
  * port / encryption checks with explanations (993 = IMAP, 465 = SSL/TLS, 587 = STARTTLS);
  * non-secret SMTP settings survive a restart (smtp.json in the data directory).

3.6 (TABAL 29.10):
  * copy in the mailbox "Sent" folder is ON by default (settings saved by 3.5 are switched on once), can be tested from
    the panel (/api/imap-check) and its last result is shown in the panel — a failed copy is no longer silent;
  * images embedded in the signature (data:) are sent as inline attachments (cid:) — Gmail and Outlook do not show data: images.
"""
import base64
import imaplib
import json
import os
import re
import smtplib
import sqlite3
import ssl
import threading
import time
import uuid
from datetime import datetime, timedelta, timezone
from email.message import EmailMessage
from email.parser import BytesParser
from email.utils import formataddr, formatdate
from pathlib import Path

READ_PORTS = {993: 'IMAP (SSL)', 143: 'IMAP', 995: 'POP3 (SSL)', 110: 'POP3'}
MAX_BATCH = 300
CHANGED = 'Dane firmy, szkic lub status zmieniły się od zatwierdzenia — wiadomość anulowano przed wysyłką. Dodaj aktualną wiadomość ponownie.'


def stamp():
    return datetime.now(timezone.utc).isoformat(timespec='seconds')


def require(ok, message):
    if not ok:
        raise ValueError(message)


def email(value):
    require(isinstance(value, str) and len(value) <= 254 and re.fullmatch(r"[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Za-z0-9](?:[A-Za-z0-9.-]*[A-Za-z0-9])?\.[A-Za-z]{2,63}", value), 'Podaj jeden prawidłowy adres e-mail (bez nazwy i listy odbiorców).')
    return value.strip()


def clean(value, label, limit):
    require(isinstance(value, str) and value.strip() and len(value) <= limit, 'Sprawdź pole: ' + label)
    require('\x00' not in value, 'Niedozwolony znak w polu: ' + label)
    return value.strip()


def message(raw):
    require(isinstance(raw, dict), 'Nieprawidłowa wiadomość.')
    require(raw.get('mode') == 'pilot' and raw.get('is_demo') is False, 'Wysyłka tylko ze zbioru Mój pilot.')
    kind = raw.get('kind') or 'lead'
    require(kind in ('lead', 'followup'), 'Nieznany rodzaj wiadomości.')
    if kind == 'followup':
        require(raw.get('status') == 'CONTACTED' and raw.get('do_not_contact') is False, 'Przypomnienie tylko dla firmy ze statusem SKONTAKTOWANY bez blokady kontaktu.')
    else:
        require(raw.get('status') == 'TO_CONTACT' and raw.get('do_not_contact') is False, 'Lead musi mieć status DO KONTAKTU bez blokady kontaktu.')
    require(raw.get('verified_email') is True, 'Brak potwierdzonego e-maila.')
    subject = clean(raw.get('subject'), 'temat', 300)
    require('\n' not in subject and '\r' not in subject, 'Temat musi być jednowierszowy.')
    html = raw.get('html') or ''
    require(isinstance(html, str) and len(html) <= 1500000 and '\x00' not in html, 'Nieprawidłowa wersja HTML wiadomości.')
    out = dict(lead_id=clean(raw.get('lead_id'), 'ID firmy', 150), company=clean(raw.get('company'), 'firma', 500),
               to=email(raw.get('to')), subject=subject, body=clean(raw.get('body'), 'treść', 12000), kind=kind)
    if html:
        out['html'] = html
    # 3.7: one general company address in Cc (TABAL 2.11 #3), personal sender name (#2), reminders (#4).
    if raw.get('cc'):
        out['cc'] = email(raw.get('cc'))
        require(out['cc'].lower() != out['to'].lower(), 'Adres DW jest taki sam jak odbiorca.')
    from_name = str(raw.get('from_name') or '').strip()
    require(len(from_name) <= 150 and '\n' not in from_name and '\r' not in from_name, 'Nazwa nadawcy profilu musi być jednowierszowa.')
    if from_name:
        out['from_name'] = from_name
    if raw.get('profile_id'):
        out['profile_id'] = clean(raw.get('profile_id'), 'profil', 60)
    # 3.9 (TABAL 3–4.11): the profile's own mailbox as the sender address ('' = the shared mailbox).
    if raw.get('from_email'):
        out['from_email'] = email(raw.get('from_email')).lower()
    if kind == 'followup':
        try:
            out['followup_no'] = int(raw.get('followup_no') or 1)
        except (TypeError, ValueError):
            raise ValueError('Nieprawidłowy numer przypomnienia.') from None
        require(1 <= out['followup_no'] <= 3, 'Nieprawidłowy numer przypomnienia.')
        ref = str(raw.get('in_reply_to') or '').strip()
        require(not ref or re.fullmatch(r'<[^<>\s]{3,250}>', ref), 'Nieprawidłowy identyfikator wiadomości.')
        if ref:
            out['in_reply_to'] = ref
    return out


def queue_key(m):
    """Duplicate protection: one first message per address; reminders have their own key per number."""
    if m.get('kind') == 'followup':
        return f"fu{m.get('followup_no', 1)}:{m['to'].lower()}"
    return m['to'].lower()


class DeliveryError(Exception):
    def __init__(self, status, reason):
        super().__init__(reason)
        self.status = status


DATA_IMG = re.compile(r'src="data:image/(png|jpe?g|gif|webp);base64,([A-Za-z0-9+/=\s]+)"', re.I)


def build_message(config, job):
    msg = EmailMessage()
    msg['From'] = formataddr((config['sender_name'], config['sender_email']))
    msg['To'] = job['to']
    if job.get('cc'):
        msg['Cc'] = job['cc']
    if job.get('in_reply_to'):
        msg['In-Reply-To'] = job['in_reply_to']
        msg['References'] = job['in_reply_to']
    msg['Subject'] = job['subject']
    msg['Date'] = formatdate(localtime=False)
    msg['Message-ID'] = job['message_id']
    msg.set_content(job['body'])
    if job.get('html'):
        images = []

        def to_cid(m):
            try:
                data = base64.b64decode(re.sub(r'\s+', '', m.group(2)), validate=False)
            except Exception:
                return 'src=""'
            if not data or len(data) > 2_000_000:
                return 'src=""'
            cid = f'sig{len(images) + 1}.{uuid.uuid4().hex[:12]}@tabal-lead-hunter'
            images.append((cid, m.group(1).lower().replace('jpg', 'jpeg'), data))
            return f'src="cid:{cid}"'
        html = DATA_IMG.sub(to_cid, job['html'])
        msg.add_alternative('<!doctype html><html><head><meta charset="utf-8"></head><body>' + html + '</body></html>', subtype='html')
        if images:
            part = msg.get_payload()[1]
            for cid, sub, data in images:
                part.add_related(data, maintype='image', subtype=sub, cid=f'<{cid}>', disposition='inline')
    return msg


def _imap_open(host, port, timeout=20):
    port = int(port or 993)
    if port == 143:
        box = imaplib.IMAP4(host, port, timeout=timeout)
        box.starttls(ssl_context=ssl.create_default_context())
        return box
    return imaplib.IMAP4_SSL(host, port, ssl_context=ssl.create_default_context(), timeout=timeout)


def _row_text(row):
    dec = lambda x: x.decode('utf-8', 'replace') if isinstance(x, bytes) else str(x)  # noqa: E731
    if isinstance(row, tuple):
        # Folder name sent as an IMAP literal: (b'(\\Flags) "/" {12}', b'Wys&AUI-ane')
        head, lit = dec(row[0]), dec(row[1]) if len(row) > 1 else ''
        return re.sub(r'\{\d+\}\s*$', '"' + lit.replace('"', '') + '"', head) if re.search(r'\{\d+\}\s*$', head) else head + ' ' + lit
    return dec(row)


def imap_folders(box):
    typ, rows = box.list()
    names = []
    for row in rows or []:
        line = _row_text(row)
        m = re.match(r'\((?P<flags>[^)]*)\)\s+(?:"[^"]*"|NIL)\s+(?P<name>.+)$', line)
        if m:
            names.append((m.group('flags'), m.group('name').strip()))
    return names


def sent_folder(names):
    flagged = [n for f, n in names if '\\Sent' in f]
    guess = [n for f, n in names if re.search(r'sent|wys&aui-ane|wys.?ane|elementy wys', n, re.I)]
    return (flagged or guess or ['Sent'])[0], bool(flagged or guess)


def decode_folder(name):
    """Modified UTF-7 (IMAP) → readable name, e.g. Wys&AUI-ane → Wysłane."""
    name = name.strip('"')
    def dec(m):
        b64 = m.group(1).replace(',', '/')
        if not b64:
            return '&'
        try:
            return base64.b64decode(b64 + '=' * (-len(b64) % 4)).decode('utf-16-be')
        except Exception:
            return m.group(0)
    return re.sub(r'&([A-Za-z0-9+,]*)-', dec, name)


def imap_copy(config, msg):
    """Stores the sent message in the mailbox "Sent" folder. Never raises; returns a short status."""
    host = config.get('imap_host') or config['host']
    try:
        box = _imap_open(host, config.get('imap_port') or 993)
    except Exception as e:
        return f'kopia w „Wysłanych”: brak połączenia IMAP z {host} ({type(e).__name__}) — Wysyłka → „Sprawdź folder Wysłane”'
    try:
        box.login(config['username'], config['password'])
        folder = config.get('imap_folder') or ''
        if not folder:
            folder, _ = sent_folder(imap_folders(box))
        if not folder.startswith('"'):
            folder = '"' + folder.replace('"', '') + '"'
        typ, _ = box.append(folder, '\\Seen', imaplib.Time2Internaldate(time.time()), msg.as_bytes())
        return f'kopia w „Wysłanych”: zapisano ({decode_folder(folder)})' if typ == 'OK' else 'kopia w „Wysłanych”: serwer odmówił zapisu'
    except imaplib.IMAP4.error:
        return 'kopia w „Wysłanych”: serwer IMAP odrzucił logowanie lub folder — Wysyłka → „Sprawdź folder Wysłane”'
    except Exception as e:
        return f'kopia w „Wysłanych”: nie zapisano ({type(e).__name__})'
    finally:
        try:
            box.logout()
        except Exception:
            pass


def imap_check(host, port, username, password, folder='', sender_email='', sender_name='TABAL', append_test=True, candidates=()):
    """Panel test for the copy in "Sent": connection → login → folder → (optional) test message stored in that folder."""
    steps = []
    def add(step, ok, detail, hint=''):
        steps.append(dict(step=step, ok=ok, detail=detail, hint=hint))
    hosts = [h for h in dict.fromkeys([host, *candidates]) if h]
    box, used = None, ''
    for h in hosts:
        try:
            box = _imap_open(h, port, timeout=12)
            used = h
            add('Połączenie IMAP', True, f'{h}:{port}')
            break
        except ssl.SSLCertVerificationError:
            add('Połączenie IMAP', False, f'{h}:{port} — certyfikat wystawiony na inną nazwę serwera', 'Wpisz jako host IMAP nazwę serwera z certyfikatu (zwykle ta sama co host SMTP).')
        except Exception as e:
            add('Połączenie IMAP', False, f'{h}:{port} — brak połączenia ({type(e).__name__})', 'Sprawdź host IMAP (zwykle taki sam jak SMTP) i port 993.')
    if not box:
        return dict(ok=False, steps=steps, host='', folder='')
    try:
        try:
            box.login(username, password)
            add('Logowanie', True, username)
        except imaplib.IMAP4.error:
            add('Logowanie', False, 'serwer odrzucił login lub hasło', 'IMAP używa tego samego loginu i hasła co SMTP. Microsoft 365 / Google: wymagane hasło aplikacji lub włączony IMAP.')
            return dict(ok=False, steps=steps, host=used, folder='')
        names = imap_folders(box)
        chosen = folder or ''
        if chosen:
            known = any(n.strip('"') == chosen.strip('"') for _, n in names)
            add('Folder', known, decode_folder(chosen) + ('' if known else ' — nie ma takiego folderu'), '' if known else 'Zostaw pole puste — aplikacja sama znajdzie „Wysłane”.')
            if not known:
                return dict(ok=False, steps=steps, host=used, folder='', folders=[decode_folder(n) for _, n in names][:40])
        else:
            chosen, found = sent_folder(names)
            add('Folder „Wysłane”', found, decode_folder(chosen) if found else 'nie znaleziono — użyję „Sent”', '' if found else 'Wpisz nazwę folderu ręcznie (lista poniżej).')
        if append_test:
            msg = EmailMessage()
            msg['From'] = formataddr((sender_name or 'TABAL', sender_email or username))
            msg['To'] = sender_email or username
            msg['Subject'] = 'TABAL Lead Hunter — test kopii w folderze Wysłane'
            msg['Date'] = formatdate(localtime=False)
            msg.set_content('To jest test kopii w folderze „Wysłane”. Jeśli widzisz tę wiadomość w Wysłanych, kopie wiadomości z Lead Huntera będą tam trafiać. Wiadomość nie została nikomu wysłana — możesz ją usunąć.')
            q = chosen if chosen.startswith('"') else '"' + chosen.replace('"', '') + '"'
            typ, _ = box.append(q, '\\Seen', imaplib.Time2Internaldate(time.time()), msg.as_bytes())
            add('Zapis testowej kopii', typ == 'OK', 'zapisano — sprawdź folder ' + decode_folder(chosen) + ' w poczcie' if typ == 'OK' else 'serwer odmówił zapisu', '' if typ == 'OK' else 'Wybierz inny folder.')
        ok = all(s['ok'] for s in steps if s['step'] != 'Połączenie IMAP') and any(s['ok'] for s in steps if s['step'] == 'Połączenie IMAP')
        return dict(ok=ok, steps=steps, host=used, folder=chosen.strip('"'), folder_label=decode_folder(chosen), folders=[decode_folder(n) for _, n in names][:40])
    except Exception as e:
        add('IMAP', False, f'błąd ({type(e).__name__})')
        return dict(ok=False, steps=steps, host=used, folder='')
    finally:
        try:
            box.logout()
        except Exception:
            pass


FREE_MAIL = {'gmail.com', 'googlemail.com', 'wp.pl', 'o2.pl', 'onet.pl', 'onet.eu', 'op.pl', 'interia.pl', 'interia.eu', 'poczta.fm', 'gazeta.pl',
             'tlen.pl', 'vp.pl', 'outlook.com', 'hotmail.com', 'live.com', 'yahoo.com', 'icloud.com', 'me.com', 'proton.me', 'protonmail.com', 'int.pl', 'buziaczek.pl'}
AUTO_RE = re.compile(r'(automatyczn\w* odpowied|odpowied\w* automatyczn|auto[- ]?reply|automatic reply|out of (the )?office|nieobecno|urlop|abwesen|undeliver|niedostarcz|delivery status|mail delivery)', re.I)
IMAP_MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']


def find_replies(config, jobs, opener=None, max_targets=300):
    """3.7 (TABAL 2.11 #4): looks in INBOX (read only) for messages from the companies we wrote to, after our message.
    Returns {'replies': [{lead_id, key, from, subject, date, auto}], 'checked': n, 'note': ''}. Nothing is marked as read."""
    from email.header import decode_header, make_header
    from email.utils import parseaddr, parsedate_to_datetime
    sent = [j for j in jobs if j.get('status') == 'sent' and j.get('kind') in ('lead', 'followup', None) and j.get('sent_at') and j.get('lead_id') and not str(j.get('lead_id')).startswith('smtp-test')]
    if not sent:
        return {'replies': [], 'checked': 0, 'note': 'Brak wysłanych wiadomości do sprawdzenia.'}
    own = (config.get('sender_email') or '').split('@')[-1].lower()
    targets = {}
    for j in sorted(sent, key=lambda x: x['sent_at']):
        for addr in [j['to']] + ([j['cc']] if j.get('cc') else []):
            addr = addr.lower()
            dom = addr.split('@')[-1]
            if dom == own:
                continue
            key = addr if dom in FREE_MAIL else '@' + dom
            t = targets.setdefault(key, {'since': j['sent_at'], 'leads': set()})
            t['since'] = min(t['since'], j['sent_at'])
            t['leads'].add(j['lead_id'])
    host = config.get('imap_host') or config['host']
    try:
        box = (opener or (lambda h, p: imaplib.IMAP4_SSL(h, p, ssl_context=ssl.create_default_context(), timeout=20)))(host, int(config.get('imap_port') or 993))
        box.login(config['username'], config['password'])
    except Exception as e:
        raise ValueError(f'Nie udało się połączyć ze skrzynką przez IMAP ({type(e).__name__}). Sprawdź „Sprawdź folder Wysłane” w kroku 1 — odpowiedzi czytamy tym samym połączeniem.') from None
    out, checked = [], 0
    try:
        typ, _ = box.select('INBOX', readonly=True)
        if typ != 'OK':
            raise ValueError('Nie można otworzyć folderu Odebrane.')
        for key, t in list(targets.items())[:max_targets]:
            checked += 1
            d = datetime.fromisoformat(t['since'].replace('Z', '+00:00'))
            since = f'{d.day:02d}-{IMAP_MONTHS[d.month - 1]}-{d.year}'
            typ, data = box.search(None, 'SINCE', since, 'FROM', '"' + key + '"')
            if typ != 'OK' or not data or not data[0]:
                continue
            for num in data[0].split()[-20:]:
                typ, msg = box.fetch(num, '(BODY.PEEK[HEADER.FIELDS (FROM SUBJECT DATE MESSAGE-ID AUTO-SUBMITTED)])')
                raw = next((x[1] for x in msg if isinstance(x, tuple)), b'') if typ == 'OK' else b''
                hdr = BytesParser().parsebytes(raw, headersonly=True) if raw else {}
                frm = str(make_header(decode_header(hdr.get('From', '')))) if raw else ''
                subj = str(make_header(decode_header(hdr.get('Subject', '')))) if raw else ''
                addr = parseaddr(frm)[1].lower()
                if not addr or (key.startswith('@') and not addr.endswith(key)) or (not key.startswith('@') and addr != key):
                    continue
                try:
                    when = parsedate_to_datetime(hdr.get('Date', '')).astimezone(timezone.utc).isoformat(timespec='seconds')
                except Exception:
                    when = ''
                if when and when < t['since']:
                    continue
                auto = bool(AUTO_RE.search(subj)) or str(hdr.get('Auto-Submitted', 'no')).lower() not in ('', 'no')
                mid = str(hdr.get('Message-ID', '') or f'{addr}|{subj}|{when}')[:300]
                for lead in t['leads']:
                    out.append({'lead_id': lead, 'key': mid, 'from': frm[:300], 'subject': subj[:300], 'date': when, 'auto': auto})
    finally:
        try:
            box.logout()
        except Exception:
            pass
    return {'replies': out, 'checked': checked, 'note': ''}


class SMTPTransport:
    def send(self, config, job):
        smtp = None
        attempted = False
        note = ''
        try:
            context = ssl.create_default_context()
            if config['security'] == 'ssl':
                smtp = smtplib.SMTP_SSL(config['host'], config['port'], timeout=20, context=context)
            else:
                smtp = smtplib.SMTP(config['host'], config['port'], timeout=20)
                smtp.ehlo()
                smtp.starttls(context=context)
                smtp.ehlo()
            smtp.login(config['username'], config['password'])
            msg = build_message(config, job)
            recipients = [job['to']] + ([job['cc']] if job.get('cc') else []) + ([config['sender_email']] if config.get('bcc_self') and job.get('kind') != 'test' else [])
            attempted = True
            refused = smtp.send_message(msg, from_addr=config['sender_email'], to_addrs=recipients)
            if refused and job['to'] in refused:
                raise DeliveryError('failed', 'Serwer SMTP odrzucił odbiorcę. Sprawdź adres i ustawienia.')
            if config.get('imap_copy') and job.get('kind') != 'test':
                note = imap_copy(config, msg)
            return note
        except DeliveryError:
            raise
        except smtplib.SMTPAuthenticationError:
            raise DeliveryError('failed', 'Serwer odrzucił logowanie. Sprawdź login, hasło aplikacji i dostęp SMTP (Wysyłka → Sprawdź połączenie).') from None
        except (smtplib.SMTPRecipientsRefused, smtplib.SMTPSenderRefused, smtplib.SMTPDataError):
            raise DeliveryError('failed', 'SMTP jawnie odrzucił wiadomość. Sprawdź adresy i ograniczenia skrzynki.') from None
        except ssl.SSLCertVerificationError:
            raise DeliveryError('failed', 'Certyfikat serwera SMTP nie pasuje do hosta. Użyj „Sprawdź połączenie” — pokaże właściwą nazwę serwera.') from None
        except Exception:
            # Do not leak SMTP replies, password or credentials via diagnostics.
            status = 'uncertain' if attempted else 'failed'
            reason = ('Brak pewności, czy SMTP przyjął wiadomość. Sprawdź skrzynkę lub logi operatora; nie ponawiaj automatycznie.'
                      if attempted else 'Nie udało się połączyć lub zalogować przez TLS. Użyj „Sprawdź połączenie” w zakładce Wysyłka — pokaże, który krok zawodzi.')
            raise DeliveryError(status, reason) from None
        finally:
            if smtp:
                try:
                    smtp.close()  # QUIT errors must not turn an accepted message into a failure.
                except Exception:
                    pass


class Outbox:
    def __init__(self, path, transport=None, clock=time.monotonic, config_path=None):
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(path, check_same_thread=False)
        self.db.row_factory = sqlite3.Row
        self.lock = threading.RLock()
        self.clock = clock
        self.transport = transport or SMTPTransport()
        self.config = None
        self.accounts = {}  # 3.9: additional mailboxes of people (profiles), keyed by lower-case sender address
        self.defaults = {}
        self.paused = True
        self.owner = None
        self.heartbeat = -1000
        self.allowed = set()
        self.next_send = 0
        self.running = False
        self.unattended = False
        self.limit_wait = False
        self.limit_auto = False
        self.validator = None
        self.config_path = Path(config_path) if config_path else None
        self.detected_hosts = set()
        self.imap_last = None
        self.stop = threading.Event()
        with self.db:
            self.db.execute('CREATE TABLE IF NOT EXISTS jobs (id TEXT PRIMARY KEY, email_key TEXT, status TEXT, payload TEXT, created_at TEXT, sent_at TEXT, error TEXT, attempts INTEGER DEFAULT 0)')
            cols = {r['name'] for r in self.db.execute('PRAGMA table_info(jobs)')}
            if 'note' not in cols:
                self.db.execute("ALTER TABLE jobs ADD COLUMN note TEXT DEFAULT ''")
            self.db.execute("UPDATE jobs SET status='uncertain',error='Przerwano proces podczas wysyłki. Sprawdź przyjęcie wiadomości przez SMTP przed dalszym kontaktem.' WHERE status='sending'")

    # ---------- state ----------
    def jobs(self):
        with self.lock:
            return [dict(json.loads(row['payload']), id=row['id'], status=row['status'], created_at=row['created_at'], sent_at=row['sent_at'], error=row['error'], attempts=row['attempts'], note=row['note'] or '')
                    for row in self.db.execute('SELECT * FROM jobs ORDER BY created_at,id')]

    def sent_last_24h(self):
        since = (datetime.now(timezone.utc) - timedelta(hours=24)).isoformat(timespec='seconds')
        return self.db.execute("SELECT COUNT(*) FROM jobs WHERE status IN ('sent','uncertain','sending') AND sent_at<>'' AND sent_at>=? AND email_key NOT LIKE 'test:%'", (since,)).fetchone()[0]

    def limit_free_at(self):
        """3.10 (TABAL 13.11): when the daily limit is used up — the moment the next message may leave (ISO, UTC)."""
        limit = int((self.config or {}).get('daily_limit') or 0)
        if not limit:
            return ''
        since = (datetime.now(timezone.utc) - timedelta(hours=24)).isoformat(timespec='seconds')
        rows = [r[0] for r in self.db.execute("SELECT sent_at FROM jobs WHERE status IN ('sent','uncertain','sending') AND sent_at<>'' AND sent_at>=? AND email_key NOT LIKE 'test:%' ORDER BY sent_at", (since,)).fetchall()]
        if len(rows) < limit:
            return ''
        try:
            first = datetime.fromisoformat(rows[len(rows) - limit])
        except ValueError:
            return ''
        return (first + timedelta(hours=24, seconds=30)).isoformat(timespec='seconds')

    def snapshot(self):
        with self.lock:
            jobs = self.jobs()
            queued = sum(j['status'] == 'queued' for j in jobs)
            interval = (self.config or {}).get('interval', 30)
            return dict(configured=bool(self.config), paused=self.paused, active=self.running, unattended=self.unattended,
                        connected=self.clock()-self.heartbeat < 15, limit_wait=self.limit_wait,
                        sent_24h=self.sent_last_24h(), queued=queued, eta_seconds=queued*interval, limit_free_at=self.limit_free_at() if queued else '',
                        limit_auto=self.limit_auto,
                        config={k: v for k, v in (self.config or {}).items() if k != 'password'},
                        remembered=bool(self.config and self.config.get('remember_password')), imap_last=self.imap_last,
                        accounts=self.account_list(), defaults=dict(self.defaults), jobs=jobs)

    # ---------- 3.9: mailboxes of people — the message leaves from the address of the chosen profile ----------
    ACCOUNT_KEYS = ('host', 'port', 'security', 'username', 'password', 'imap_host', 'imap_port', 'imap_folder')

    def account_list(self):
        return [dict({k: v for k, v in a.items() if k != 'password'}, ready=bool(a.get('password'))) for a in sorted(self.accounts.values(), key=lambda x: x['sender_email'])]

    def is_main(self, address):
        return bool(self.config) and (address or '').lower() == self.config['sender_email'].lower()

    def mailbox_for(self, address):
        """Full sending configuration for a sender address: the shared mailbox or a person's mailbox. None = not connected."""
        if not self.config:
            return None
        if not address or self.is_main(address):
            return dict(self.config)
        acc = self.accounts.get(address.lower())
        if not acc or not acc.get('password'):
            return None
        return dict(self.config, sender_email=acc['sender_email'], **{k: acc[k] for k in self.ACCOUNT_KEYS})

    def mailboxes(self):
        out = [dict(self.config)] if self.config else []
        return out + [m for m in (self.mailbox_for(a) for a in sorted(self.accounts)) if m]

    def configure_account(self, raw):
        with self.lock:
            address = email(raw.get('sender_email')).lower()
            # Unlike the shared mailbox, a person's mailbox may be connected while the queue is idle or sending from other mailboxes.
            require(not any(j['status'] == 'sending' and j.get('sender_email', '').lower() == address for j in self.jobs()), 'Ta skrzynka właśnie wysyła wiadomość — spróbuj za chwilę.')
            require(not self.is_main(address), 'To adres skrzynki wspólnej — ustaw ją w kroku 1. Profil z tym adresem wysyła z niej bez dodatkowej konfiguracji.')
            require(len(self.accounts) < 30 or address in self.accounts, 'Limit: 30 skrzynek osób.')
            old, base = self.accounts.get(address, {}), (self.config or self.defaults or {})
            acc = dict(sender_email=address, username=clean(str(raw.get('username') or '').strip() or address, 'login', 254))
            acc['host'] = str(raw.get('host') or '').strip() or old.get('host') or base.get('host') or ''
            require(acc['host'] and re.fullmatch(r'[A-Za-z0-9.-]+', acc['host']), 'Host SMTP: podaj nazwę bez https:// i ścieżki.')
            try:
                acc['port'] = int(raw.get('port') or old.get('port') or base.get('port') or 465)
                acc['imap_port'] = int(raw.get('imap_port') or old.get('imap_port') or base.get('imap_port') or 993)
            except (TypeError, ValueError):
                raise ValueError('Port musi być liczbą.') from None
            require(acc['port'] not in READ_PORTS, f'Port {acc["port"]} to port odbioru poczty, nie wysyłki. Do wysyłki użyj 465 (SSL/TLS) albo 587 (STARTTLS).')
            require(1 <= acc['port'] <= 65535, 'Port: 1–65535.')
            acc['security'] = 'ssl' if acc['port'] == 465 else 'starttls' if acc['port'] in (587, 25, 2525) else (raw.get('security') or old.get('security') or base.get('security') or 'ssl')
            require(acc['security'] in ('ssl', 'starttls'), 'Wymagane szyfrowanie SSL/TLS lub STARTTLS.')
            imap_host = str(raw.get('imap_host') or '').strip() or (old.get('imap_host') or '' if acc['host'] == old.get('host') else '')
            require(not imap_host or re.fullmatch(r'[A-Za-z0-9.-]+', imap_host), 'Host IMAP: podaj nazwę bez https:// i ścieżki.')
            acc['imap_host'] = imap_host
            acc['imap_folder'] = str(raw.get('imap_folder') or old.get('imap_folder') or '').strip()[:120]
            acc['remember_password'] = raw.get('remember_password') in (True, 'on', 'true', '1')
            same = old.get('host') == acc['host'] and old.get('username') == acc['username']
            acc['password'] = raw.get('password') or (old.get('password', '') if same else '')
            require(isinstance(acc['password'], str) and 0 < len(acc['password']) <= 2000, 'Podaj hasło tej skrzynki (albo hasło aplikacji).')
            self.accounts[address] = acc
            self.save_config()
            return self.snapshot()

    def remove_account(self, address):
        with self.lock:
            address = str(address or '').strip().lower()
            require(address in self.accounts, 'Nie ma takiej skrzynki.')
            require(not any(j['status'] in ('queued', 'sending') and j.get('sender_email', '').lower() == address for j in self.jobs()), 'Anuluj oczekujące wiadomości tej skrzynki przed jej usunięciem.')
            del self.accounts[address]
            self.save_config()
            return self.snapshot()

    # ---------- configuration ----------
    def configure(self, raw):
        with self.lock:
            require(not self.running and self.paused, 'Najpierw wstrzymaj kolejkę i poczekaj na zakończenie bieżącej wysyłki.')
            cfg = {k: clean(raw.get(k), k, limit) for k, limit in [('host',253),('username',254),('sender_name',150)]}
            require(re.fullmatch(r'[A-Za-z0-9.-]+', cfg['host']), 'Host SMTP: podaj nazwę bez https:// i ścieżki.')
            require('\r' not in cfg['sender_name'] and '\n' not in cfg['sender_name'], 'Nazwa nadawcy musi być jednowierszowa.')
            cfg['sender_email'] = email(raw.get('sender_email'))
            try:
                cfg['port'] = int(raw.get('port', 0))
                cfg['interval'] = int(raw.get('interval', 30))
                cfg['daily_limit'] = int(raw.get('daily_limit', 200) if raw.get('daily_limit') not in (None, '') else 200)
            except (TypeError, ValueError):
                raise ValueError('Port, odstęp i limit dzienny muszą być liczbami.') from None
            require(cfg['port'] not in READ_PORTS, f'Port {cfg["port"]} to port odbioru poczty ({READ_PORTS.get(cfg["port"], "")}), nie wysyłki. Do wysyłki użyj 465 (SSL/TLS) albo 587 (STARTTLS).')
            cfg['security'] = raw.get('security')
            require(cfg['security'] in ('ssl', 'starttls'), 'Wymagane szyfrowanie SSL/TLS lub STARTTLS.')
            notes = []
            if cfg['port'] == 465 and cfg['security'] != 'ssl':
                cfg['security'] = 'ssl'; notes.append('Port 465 wymaga SSL/TLS — ustawiono automatycznie.')
            if cfg['port'] in (587, 25, 2525) and cfg['security'] != 'starttls':
                cfg['security'] = 'starttls'; notes.append(f'Port {cfg["port"]} wymaga STARTTLS — ustawiono automatycznie.')
            require(1 <= cfg['port'] <= 65535 and 10 <= cfg['interval'] <= 3600 and 0 <= cfg['daily_limit'] <= 5000, 'Port: 1–65535; odstęp: 10–3600 sekund; limit dzienny: 0–5000 (0 = bez limitu).')
            cfg['bcc_self'] = raw.get('bcc_self') in (True, 'on', 'true', '1')
            cfg['imap_copy'] = raw.get('imap_copy') in (True, 'on', 'true', '1')
            cfg['cfg_version'] = 36
            imap_host = str(raw.get('imap_host') or '').strip()
            require(not imap_host or re.fullmatch(r'[A-Za-z0-9.-]+', imap_host), 'Host IMAP: podaj nazwę bez https:// i ścieżki.')
            cfg['imap_host'] = imap_host
            try:
                cfg['imap_port'] = int(raw.get('imap_port') or 993)
            except (TypeError, ValueError):
                raise ValueError('Port IMAP musi być liczbą (zwykle 993).') from None
            cfg['imap_folder'] = str(raw.get('imap_folder') or '').strip()[:120]
            cfg['remember_password'] = raw.get('remember_password') in (True, 'on', 'true', '1')
            same = self.config and self.config.get('host') == cfg['host'] and self.config.get('username') == cfg['username']
            cfg['password'] = raw.get('password') or ((self.config or {}).get('password', '') if same or not self.config else '')
            require(isinstance(cfg['password'],str) and 0 < len(cfg['password']) <= 2000, 'Podaj hasło SMTP lub hasło aplikacji.')
            # Sender is frozen into every job; changes never redirect an approved batch.
            for job in self.jobs():
                if job['status'] in ('queued','failed') and job['sender_email'].lower() not in self.accounts:
                    require(job['sender_email'] == cfg['sender_email'], 'Anuluj oczekujące/błędne wiadomości przed zmianą adresu nadawcy.')
            require(cfg['sender_email'].lower() not in self.accounts, 'Ten adres jest podłączony jako skrzynka osoby. Usuń ją w „Skrzynki osób”, zanim ustawisz go jako skrzynkę wspólną.')
            self.config = cfg
            self.save_config()
            snap = self.snapshot()
            snap['notes'] = notes
            return snap

    def save_config(self):
        if not self.config_path or not (self.config or self.accounts):
            return
        data = {k: v for k, v in (self.config or {}).items() if k != 'password'}
        if self.config and self.config.get('remember_password'):
            data['password'] = self.config['password']
        # 3.9: people's mailboxes; a password is written only when the operator chose to remember it.
        data['accounts'] = [{k: v for k, v in a.items() if k != 'password' or a.get('remember_password')} for a in self.accounts.values()]
        tmp = self.config_path.with_suffix('.tmp')
        fd = os.open(str(tmp), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False)
        os.replace(tmp, self.config_path)
        try:
            os.chmod(self.config_path, 0o600)
        except OSError:
            pass

    def load_saved(self, env_password=''):
        """Restores panel settings after restart. Password: remembered one, else the .env one for the same host."""
        if not self.config_path or not self.config_path.exists():
            return False
        try:
            data = json.loads(self.config_path.read_text(encoding='utf-8'))
        except (OSError, ValueError):
            return False
        for a in data.pop('accounts', None) or []:
            try:
                address = email(a.get('sender_email')).lower()
            except (ValueError, AttributeError):
                continue
            self.accounts[address] = dict(sender_email=address, username=str(a.get('username') or address), host=str(a.get('host') or ''), port=int(a.get('port') or 465),
                                          security=a.get('security') if a.get('security') in ('ssl', 'starttls') else 'ssl', imap_host=str(a.get('imap_host') or ''),
                                          imap_port=int(a.get('imap_port') or 993), imap_folder=str(a.get('imap_folder') or ''), remember_password=bool(a.get('remember_password')),
                                          password=str(a.get('password') or ''))
        if not data.get('host'):
            return False
        if int(data.get('cfg_version') or 0) < 36 and not data.get('bcc_self'):
            data['imap_copy'] = True  # 3.6: copy in "Sent" on by default (TABAL 29.10)
        password = data.get('password') or (env_password if env_password and data.get('host') == self.defaults.get('host') else '')
        saved = {k: v for k, v in data.items() if k != 'password'}
        if not password:
            self.defaults = dict(self.defaults, **saved)
            return False
        try:
            with self.lock:
                self.config = None
                self.configure(dict(data, password=password))
            return True
        except ValueError:
            self.defaults = dict(self.defaults, **saved)
            return False

    # ---------- queue ----------
    def enqueue(self, raw, owner):
        with self.lock:
            require(self.config, 'Najpierw skonfiguruj SMTP.')
            self.claim(owner, force=True)
            require(isinstance(raw, list) and 1 <= len(raw) <= MAX_BATCH, f'Jedna partia: 1–{MAX_BATCH} wiadomości.')
            checked = [message(item) for item in raw]
            require(len({queue_key(m) for m in checked}) == len(checked), 'Powtórzony adres w partii. Zostaw jedną wiadomość na skrzynkę.')
            for m in checked:
                require(not self.db.execute("SELECT 1 FROM jobs WHERE email_key=? AND status IN ('queued','sending','sent','uncertain')", (queue_key(m),)).fetchone(), 'Adres jest już w kolejce, został obsłużony albo ma niepewny wynik: '+m['to'])
                # 3.9: the profile's own address needs its mailbox connected — never silently send from another address.
                box = self.mailbox_for(m.get('from_email', ''))
                require(box, f'Skrzynka {m.get("from_email")} nie jest podłączona. Wysyłka → „Skrzynki osób”: wpisz hasło tej skrzynki. Możesz też wyłączyć w profilu „Wysyłaj z własnego adresu” — wtedy wiadomość wyjdzie ze skrzynki wspólnej {self.config["sender_email"]}.')
                m['_sender'] = box['sender_email']
            with self.db:
                for m in checked:
                    jobid = str(uuid.uuid4())
                    sender = m.pop('_sender')
                    m.update(sender_email=sender, sender_name=m.get('from_name') or self.config['sender_name'], message_id=f'<{jobid}@{sender.split("@")[1]}>')
                    self.db.execute('INSERT INTO jobs (id,email_key,status,payload,created_at,sent_at,error) VALUES (?,?,?,?,?,?,?)',
                                    (jobid,queue_key(m),'queued',json.dumps(m,ensure_ascii=False),stamp(),'',''))
            self.paused = True
            # Explicit resume after review; enqueue itself never starts delivery.
            return self.snapshot()

    def test_message(self, owner, account=''):
        with self.lock:
            require(self.config, 'Najpierw skonfiguruj SMTP.')
            self.claim(owner, force=True)
            require(not self.running and not any(j['status']=='queued' for j in self.jobs()), 'Test wykonaj przy pustej kolejce oczekujących wiadomości.')
            box=self.mailbox_for(str(account or '').strip())
            require(box, 'Ta skrzynka nie jest podłączona — zapisz jej ustawienia i hasło.')
            jobid=str(uuid.uuid4());sender=box['sender_email']
            data=dict(kind='test',lead_id='smtp-test:'+jobid,company='Test własnej skrzynki',to=sender,sender_email=sender,sender_name=self.config['sender_name'],subject='TABAL Lead Hunter — test SMTP',body='To wiadomość testowa wysłana przez moduł TABAL Lead Hunter v3.9 ze skrzynki '+sender+'.',message_id=f'<{jobid}@{sender.split("@")[1]}>')
            with self.db:
                self.db.execute('INSERT INTO jobs (id,email_key,status,payload,created_at,sent_at,error) VALUES (?,?,?,?,?,?,?)',(jobid,'test:'+jobid,'queued',json.dumps(data),stamp(),'',''))
            self.paused=True
            return self.snapshot()

    def active_other(self, owner):
        return self.owner not in (None, owner) and self.clock()-self.heartbeat < 15

    def claim(self, owner, force=False):
        """3.5: an explicit operator action (add to queue, start, test, retry) takes the queue over — safe, because every
        message is re-checked against the stored data right before sending. Background syncs of other tabs never take over."""
        require(isinstance(owner, str) and 10 <= len(owner) <= 100, 'Brak identyfikatora sesji.')
        require(force or not self.active_other(owner), 'Kolejkę obsługuje inna karta. Wstrzymaj ją lub zamknij i odczekaj 15 sekund.')
        if self.owner != owner:
            if not self.unattended:
                self.paused = True
            self.allowed.clear()
        self.owner = owner

    def sync(self, owner, allowed, writable=True, observed=None):
        with self.lock:
            if self.active_other(owner):
                # Another tab operates the queue: read-only view, nothing is cancelled or taken over.
                return self.snapshot()
            self.claim(owner)
            require(isinstance(allowed,list) and len(allowed) <= 20000, 'Nieprawidłowa lista kolejki.')
            observed = set(observed) if observed is not None else {j['id'] for j in self.jobs()}
            self.heartbeat = self.clock()
            self.allowed = set(allowed) if writable else set()
            if not writable:
                self.paused = True
            # A changed status/address/draft or removed lead invalidates its pending approval.
            with self.db:
                for job in self.jobs():
                    if job['status'] == 'queued' and job['id'] in observed and job['id'] not in self.allowed:
                        self.db.execute("UPDATE jobs SET status='cancelled',error='Zmieniono dane, szkic lub status firmy. Dodaj aktualną wiadomość ponownie.' WHERE id=?",(job['id'],))
            return self.snapshot()

    def control(self, action, jobid='', owner='', unattended=False):
        with self.lock:
            if action == 'pause':
                self.paused = True
            elif action == 'resume':
                self.claim(owner, force=True)
                require(self.config, 'Najpierw skonfiguruj i sprawdź skrzynkę SMTP.')
                if unattended:
                    require(self.validator is not None, 'Wysyłka bez otwartego panelu jest niedostępna w tym trybie uruchomienia.')
                    require(any(j['status'] == 'queued' for j in self.jobs()), 'Brak wiadomości w kolejce.')
                    self.unattended = True
                else:
                    require(self.clock()-self.heartbeat < 15, 'Połącz panel i skonfiguruj SMTP przed wznowieniem.')
                    require(self.allowed, 'Brak zatwierdzonych wiadomości. Odśwież kolejkę.')
                    self.unattended = False
                    self.limit_auto = False
                self.paused = False
            elif action == 'cancel':
                with self.db:
                    row = self.db.execute("UPDATE jobs SET status='cancelled',error='Anulowano przez operatora.' WHERE id=? AND status IN ('queued','failed')",(jobid,))
                    require(row.rowcount, 'Można anulować tylko oczekującą lub błędną wiadomość. Trwającej wysyłki nie można cofnąć.')
            elif action == 'cancel-all':
                with self.db:
                    self.db.execute("UPDATE jobs SET status='cancelled',error='Anulowano przez operatora (cała kolejka).' WHERE status='queued'")
                self.paused = True
            elif action == 'retry':
                require(self.paused, 'Wstrzymaj kolejkę przed ponowieniem.')
                self.claim(owner, force=True)
                job = next((j for j in self.jobs() if j['id']==jobid),None)
                require(job and job['status']=='failed', 'Ponowienie tylko po jednoznacznym błędzie, nigdy dla niepewnego wyniku.')
                require(jobid in self.allowed, 'Treść lub status firmy zmieniły się. Anuluj i dodaj aktualną wiadomość.')
                require(not self.db.execute("SELECT 1 FROM jobs WHERE email_key=? AND id<>? AND status IN ('queued','sending','sent','uncertain')",(queue_key(job),jobid)).fetchone(),'Ten adres ma już inną aktywną lub wysłaną wiadomość.')
                with self.db:
                    self.db.execute("UPDATE jobs SET status='queued',error='' WHERE id=?",(jobid,))
            else:
                raise ValueError('Nieznana operacja kolejki.')
            return self.snapshot()

    def run_one(self):
        with self.lock:
            if not self.unattended and self.clock()-self.heartbeat >= 15:
                self.paused = True
            if self.paused or not self.config or self.running or self.clock() < self.next_send:
                return False
            limit = int(self.config.get('daily_limit') or 0)
            if limit and self.sent_last_24h() >= limit:
                self.limit_wait = True
                # 3.10 (TABAL 13.11 — maile „zablokowane wczoraj limitem 24 h” trzeba było dosyłać ręcznie): the rest of the
                # queue continues by itself after the 24 h window, also with the panel closed. Safe: in this mode every message
                # is re-checked against the stored data right before sending (validator), exactly like „Wyślij bez panelu”.
                if not self.unattended and self.validator is not None and any(j['status'] == 'queued' for j in self.jobs()):
                    self.unattended = True
                    self.limit_auto = True
                return False
            self.limit_wait = False
            job = next((j for j in self.jobs() if j['status']=='queued' and (self.unattended or j['id'] in self.allowed)),None)
            if not job:
                if self.unattended:
                    self.paused = True
                    self.unattended = False
                    self.limit_auto = False
                return False
            self.running = True
            # 3.5: with a validator (server), EVERY message is re-checked against stored data right before sending.
            check = self.validator is not None and job.get('kind') != 'test'
        try:
            if check:
                try:
                    valid = bool(self.validator(job)) if self.validator else False
                except Exception:
                    valid = False
                if not valid:
                    with self.lock:
                        with self.db:
                            self.db.execute("UPDATE jobs SET status='cancelled',error=? WHERE id=? AND status='queued'",(CHANGED,job['id']))
                        self.running = False
                    return True
            with self.lock:
                row = self.db.execute('SELECT status FROM jobs WHERE id=?',(job['id'],)).fetchone()
                if self.paused or not self.config or not row or row['status'] != 'queued':
                    self.running = False
                    return False
                box = self.mailbox_for(job['sender_email'])
                if not box and (job.get('from_email') or job['sender_email'].lower() in self.accounts):
                    # 3.9: the person's mailbox lost its password (restart) or was removed — stop, never fall back to another address.
                    with self.db:
                        self.db.execute("UPDATE jobs SET status='failed',error=? WHERE id=?",(f'Skrzynka {job["sender_email"]} nie jest podłączona — wpisz jej hasło (Wysyłka → Skrzynki osób) i ponów.',job['id']))
                    self.running = False
                    self.paused = True
                    self.unattended = False
                    self.limit_auto = False
                    return True
                cfg = dict(box or self.config, sender_email=job['sender_email'], sender_name=job['sender_name'])
                with self.db:
                    self.db.execute("UPDATE jobs SET status='sending',attempts=attempts+1 WHERE id=?",(job['id'],))
        except BaseException:
            with self.lock:
                self.running = False
            raise
        status, error, sent_at, note = 'sent', '', '', ''
        try:
            note = self.transport.send(cfg, job) or ''
            sent_at = stamp()
        except DeliveryError as exc:
            status, error = exc.status, str(exc)
        except Exception:
            status, error = 'uncertain', 'Nieznany wynik wysyłki. Sprawdź logi skrzynki; automatyczne ponowienie zablokowane.'
        finally:
            with self.lock:
                with self.db:
                    self.db.execute('UPDATE jobs SET status=?,sent_at=?,error=?,note=? WHERE id=?',(status,sent_at,error,str(note)[:300],job['id']))
                if note and 'kopia' in str(note):
                    self.imap_last = dict(ok='zapisano' in str(note), note=str(note)[:300], at=stamp())
                self.running = False
                self.next_send = self.clock()+cfg['interval']
                if status != 'sent':
                    self.paused = True
                    self.unattended = False
                    self.limit_auto = False
        return True

    def work(self):
        while not self.stop.wait(0.5):
            try:
                self.run_one()
            except Exception:
                # A persistence failure must never cause automatic resend.
                with self.lock:
                    self.paused = True
                    self.running = False
                    self.unattended = False
                    self.limit_auto = False

    def close(self):
        self.stop.set()
        with self.lock:
            self.db.close()
