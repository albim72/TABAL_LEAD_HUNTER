"""3.10 (TABAL 13.11): e-mail and phone read directly from the company's OWN website by the server.

Why: Work in quick mode opens 2–3 pages per company and often misses an address that is on the site (footer loaded by
JavaScript, a separate Kontakt / Polityka prywatności page, Cloudflare "[email protected]", "biuro [at] firma.pl").
Jędrzej then had to complete the addresses by hand. The server reads a few pages of the company's own domain in seconds,
without any ChatGPT limit.

Safety: only http(s) on ports 80/443, only public addresses (also after redirects), HTML only, max 1.5 MB per page,
max 6 pages per company, no forms, no logins, no portals / catalogues (their e-mails are not the company's).
"""
import html as htmllib
import ipaddress
import re
import socket
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import unquote, urljoin, urlsplit

MAX_PAGE = 1_500_000
MAX_PAGES = 6
TIMEOUT = 8
UA = 'Mozilla/5.0 (compatible; TABAL-Lead-Hunter/3.10; +https://tabal.pl/)'

# Domains that are never a company's own website: their addresses belong to the portal, not to the company.
PORTALS = ('oferteo.pl', 'panoramafirm.pl', 'pkt.pl', 'aleo.com', 'firmy.net', 'olx.pl', 'facebook.com', 'instagram.com',
           'linkedin.com', 'google.com', 'goo.gl', 'youtube.com', 'allegro.pl', 'otodom.pl', 'gratka.pl', 'fixly.pl',
           'zumi.pl', 'cylex-polska.pl', 'biznesfinder.pl', 'rejestr.io', 'krs-online.com.pl', 'ceidg.gov.pl',
           'biznes.gov.pl', 'owg.pl', 'baza-firm.com.pl', 'firmy.pl', 'yelp.com', 'tiktok.com', 'x.com', 'twitter.com',
           'wikipedia.org', 'oferia.pl', 'muratordom.pl', 'budujemydom.pl', 'kreatorbudowy.pl')
# Free mail providers: small installers often use them — fine for the company, but not "the company's domain".
FREE_MAIL = ('gmail.com', 'googlemail.com', 'wp.pl', 'o2.pl', 'onet.pl', 'onet.eu', 'op.pl', 'poczta.onet.pl', 'interia.pl',
             'interia.eu', 'interia.com', 'poczta.fm', 'tlen.pl', 'gazeta.pl', 'vp.pl', 'yahoo.com', 'outlook.com',
             'hotmail.com', 'live.com', 'icloud.com', 'me.com', 'buziaczek.pl', 'int.pl', 'autograf.pl', 'poczta.pl',
             'spoko.pl', 'go2.pl', 'protonmail.com', 'proton.me', 'seznam.cz', 'centrum.sk', 'azet.sk', 'zoznam.sk')
# Pages that usually carry contact data — Polish, Czech, Slovak and English names.
CONTACT_HINT = re.compile(r'kontakt|contact|o-nas|o_nas|onas|about|firma|impressum|polityka|privacy|prywatnos|rodo|regulamin|dane-firmy|zespol|team|biuro|obchod|spolocnost', re.I)
EMAIL = re.compile(r'(?<![\w.+-])[A-Za-z0-9][A-Za-z0-9._%+-]{0,63}@[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?(?:\.[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?)*\.[A-Za-z]{2,24}(?![\w-])')
OBFUSCATED = re.compile(r'([A-Za-z0-9][A-Za-z0-9._%+-]{0,63})\s*(?:\[|\(|\{|<)\s*(?:at|małpa|malpa|@)\s*(?:\]|\)|\}|>)\s*'
                        r'([A-Za-z0-9-]+(?:\s*(?:\.|(?:\[|\(|\{|<)\s*(?:dot|kropka|\.)\s*(?:\]|\)|\}|>))\s*[A-Za-z0-9-]+)+)', re.I)
CF_ATTR = re.compile(r'data-cfemail\s*=\s*["\']([0-9a-fA-F]+)["\']')
CF_LINK = re.compile(r'/cdn-cgi/l/email-protection#([0-9a-fA-F]+)')
MAILTO = re.compile(r'mailto:([^"\'\s>?]+)', re.I)
TEL = re.compile(r'href\s*=\s*["\']tel:([+0-9 ()./-]{7,24})["\']', re.I)
HREF = re.compile(r'<a\b[^>]*?\bhref\s*=\s*["\']([^"\'#]+)["\']', re.I)
TAGS = re.compile(r'<script\b.*?</script>|<style\b.*?</style>|<[^>]+>', re.I | re.S)
BAD_SUFFIX = ('.png', '.jpg', '.jpeg', '.gif', '.svg', '.webp', '.css', '.js', '.ico', '.bmp', '.tif', '.woff', '.woff2')
BAD_DOMAINS = ('example.com', 'example.pl', 'domain.com', 'domena.pl', 'email.com', 'test.pl', 'sentry.io', 'wixpress.com',
               'sentry-next.wixpress.com', 'mysite.com', 'yourdomain.com', 'twojadomena.pl', 'firma.pl', 'adres.pl')
BAD_LOCAL = ('example', 'twojemail', 'twoj.email', 'jan.kowalski', 'name', 'email', 'user', 'username', 'your', 'imie.nazwisko')


def _public(host):
    try:
        infos = socket.getaddrinfo(host, None)
    except OSError:
        return False
    for info in infos:
        ip = ipaddress.ip_address(info[4][0])
        if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved or ip.is_multicast or ip.is_unspecified:
            return False
    return bool(infos)


class _SafeRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        u = urlsplit(newurl)
        if u.scheme not in ('http', 'https') or not u.hostname or (u.port and u.port not in (80, 443)) or not _public(u.hostname):
            return None
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def clean_domain(value):
    d = str(value or '').strip().lower()
    d = re.sub(r'^[a-z]+://', '', d).split('/')[0].split('?')[0].split('#')[0].split(':')[0]
    d = d[4:] if d.startswith('www.') else d
    return d if re.fullmatch(r'[a-z0-9.-]+\.[a-z]{2,24}', d or '') else ''


def is_portal(domain):
    d = clean_domain(domain)
    return bool(d) and any(d == p or d.endswith('.' + p) for p in PORTALS)


def root(domain):
    """Registrable part, good enough for Polish second-level domains (firma.com.pl → firma.com.pl)."""
    parts = clean_domain(domain).split('.')
    if len(parts) >= 3 and parts[-2] in ('com', 'net', 'org', 'biz', 'info', 'waw', 'lublin', 'lodz', 'krakow', 'gda', 'wroc', 'pl', 'co', 'edu'):
        return '.'.join(parts[-3:])
    return '.'.join(parts[-2:])


def cf_decode(hexstr):
    try:
        data = bytes.fromhex(hexstr)
        key = data[0]
        return bytes(b ^ key for b in data[1:]).decode('utf-8', 'replace')
    except (ValueError, IndexError):
        return ''


def valid_email(e):
    e = e.strip().strip('.').lower()
    if not EMAIL.fullmatch(e) or len(e) > 254:
        return ''
    local, dom = e.rsplit('@', 1)
    if dom.endswith(BAD_SUFFIX) or any(dom == b or dom.endswith('.' + b) for b in BAD_DOMAINS) or local in BAD_LOCAL:
        return ''
    if re.search(r'@\d+x\.', e) or local.endswith(BAD_SUFFIX):
        return ''
    return e


def extract(page_html):
    """All addresses on one page: (email, how) and phones from tel: links."""
    found = []
    raw = page_html or ''
    for m in CF_ATTR.finditer(raw):
        found.append((cf_decode(m.group(1)), 'ochrona Cloudflare (odkodowano)'))
    for m in CF_LINK.finditer(raw):
        found.append((cf_decode(m.group(1)), 'ochrona Cloudflare (odkodowano)'))
    unesc = htmllib.unescape(raw)
    for m in MAILTO.finditer(unesc):
        found.append((unquote(m.group(1)).split('?')[0], 'link mailto'))
    text = htmllib.unescape(TAGS.sub(' ', raw))
    for m in EMAIL.finditer(text):
        found.append((m.group(0), 'tekst strony'))
    for m in OBFUSCATED.finditer(text):
        dom = re.sub(r'\s*(?:\[|\(|\{|<)\s*(?:dot|kropka|\.)\s*(?:\]|\)|\}|>)\s*', '.', m.group(2), flags=re.I)
        dom = re.sub(r'\s*\.\s*', '.', dom)
        found.append((m.group(1) + '@' + dom, 'zapis z [at] / (małpa)'))
    # Addresses kept only in scripts or attributes (e.g. footer rendered by JavaScript).
    for m in EMAIL.finditer(unesc):
        found.append((m.group(0), 'kod strony'))
    out, seen = [], set()
    for e, how in found:
        e = valid_email(e)
        if e and e not in seen:
            seen.add(e)
            out.append((e, how))
    phones, pseen = [], set()
    for m in TEL.finditer(unesc):
        p = re.sub(r'[^\d+]', '', m.group(1))
        digits = p.lstrip('+')
        if 9 <= len(digits) <= 13 and p not in pseen:
            pseen.add(p)
            phones.append(m.group(1).strip())
    return out, phones


def contact_links(base_url, page_html, domain):
    links = []
    for m in HREF.finditer(page_html or ''):
        href = htmllib.unescape(m.group(1)).strip()
        if href.lower().startswith(('mailto:', 'tel:', 'javascript:')):
            continue
        u = urljoin(base_url, href)
        p = urlsplit(u)
        if p.scheme not in ('http', 'https') or root(p.hostname or '') != root(domain):
            continue
        if p.path.lower().endswith(BAD_SUFFIX + ('.pdf', '.zip', '.doc', '.docx', '.xls', '.xlsx')):
            continue
        if CONTACT_HINT.search(p.path + ' ' + (p.query or '')):
            u = u.split('#')[0]
            if u not in links:
                links.append(u)
    # Kontakt first, then the rest.
    links.sort(key=lambda x: 0 if re.search(r'kontakt|contact', x, re.I) else 1)
    return links


def _default_fetch(url):
    u = urlsplit(url)
    if u.scheme not in ('http', 'https') or not u.hostname or (u.port and u.port not in (80, 443)) or not _public(u.hostname):
        raise ValueError('adres niedozwolony')
    op = urllib.request.build_opener(_SafeRedirect)
    req = urllib.request.Request(url, headers={'User-Agent': UA, 'Accept': 'text/html,application/xhtml+xml', 'Accept-Language': 'pl,en;q=0.5'})
    with op.open(req, timeout=TIMEOUT) as r:
        ctype = (r.headers.get('Content-Type') or '').lower()
        if ctype and 'html' not in ctype and 'text/plain' not in ctype:
            raise ValueError('to nie jest strona HTML')
        data = r.read(MAX_PAGE + 1)[:MAX_PAGE]
        charset = r.headers.get_content_charset() or 'utf-8'
        final = r.geturl()
    try:
        return final, data.decode(charset, 'replace')
    except LookupError:
        return final, data.decode('utf-8', 'replace')


def find(domain, pages=(), fetch=None):
    """Reads up to MAX_PAGES pages of the company's own domain. Returns e-mails ranked: company domain first."""
    fetch = fetch or _default_fetch
    d = clean_domain(domain)
    result = {'domain': d, 'emails': [], 'phones': [], 'checked': [], 'error': ''}
    if not d:
        result['error'] = 'brak własnej domeny firmy'
        return result
    if is_portal(d):
        result['error'] = 'domena portalu / katalogu — to nie jest strona firmy'
        return result
    queue = [p for p in pages if clean_domain(p) and root(clean_domain(p)) == root(d)][:2]
    start = ['https://' + d + '/', 'https://www.' + d + '/', 'http://' + d + '/']
    emails, phones, errors = {}, [], []
    home_ok = False
    for url in start:
        try:
            final, page = fetch(url)
        except Exception as e:  # noqa: BLE001 — network errors are reported, never raised
            errors.append(str(e)[:120] if isinstance(e, ValueError) else type(e).__name__)
            continue
        home_ok = True
        result['checked'].append(final)
        found, tel = extract(page)
        for e, how in found:
            emails.setdefault(e, (final, how))
        phones += [t for t in tel if t not in phones]
        queue += [x for x in contact_links(final, page, d) if x not in queue]
        break
    for url in queue:
        if len(result['checked']) >= MAX_PAGES:
            break
        if url in result['checked']:
            continue
        try:
            final, page = fetch(url)
        except Exception as e:  # noqa: BLE001
            errors.append(str(e)[:120] if isinstance(e, ValueError) else type(e).__name__)
            continue
        result['checked'].append(final)
        found, tel = extract(page)
        for e, how in found:
            emails.setdefault(e, (final, how))
        phones += [t for t in tel if t not in phones]
    own = root(d)
    ranked = []
    for e, (url, how) in emails.items():
        dom = e.rsplit('@', 1)[1]
        kind = 'own' if root(dom) == own else 'free' if dom in FREE_MAIL else 'other'
        ranked.append({'email': e, 'url': url, 'how': how, 'domain_match': kind})
    ranked.sort(key=lambda x: ({'own': 0, 'free': 1, 'other': 2}[x['domain_match']], 0 if re.match(r'(biuro|kontakt|info|office|sprzedaz|handel|zakupy|zaopatrzenie|bok)@', x['email']) else 1))
    result['emails'] = ranked[:8]
    result['phones'] = phones[:4]
    if not home_ok:
        result['error'] = 'strona firmy nie odpowiada' + (' (' + errors[0] + ')' if errors else '')
    return result


def find_many(items, fetch=None, workers=8):
    """items: [{lead_id, domain, pages}] — at most 40 per request; results in the same order."""
    items = [i for i in (items or []) if isinstance(i, dict)][:40]

    def one(i):
        pages = [str(p) for p in (i.get('pages') or []) if isinstance(p, str)][:3]
        r = find(str(i.get('domain') or ''), pages, fetch)
        r['lead_id'] = str(i.get('lead_id') or '')[:200]
        return r
    if not items:
        return []
    with ThreadPoolExecutor(max_workers=min(workers, len(items))) as ex:
        return list(ex.map(one, items))
