// Shared validation and scoring: exactly the same domain logic as the browser.
const C=require('../src/core.js');let data='';
process.stdin.setEncoding('utf8');process.stdin.on('data',x=>data+=x);process.stdin.on('end',()=>{try{const x=JSON.parse(data);let result;
if(x.op==='initial')result=C.makeState('pilot');
else {const s=C.restore(C.backup(x.state),'pilot');
 if(x.op==='validate')result=s;
 else if(x.op==='candidates')result=s.leads.flatMap(l=>[C.mailCandidate(l,s.config,'pilot',s.products).message,C.followupCandidate(l,s.config,'pilot',s.products).message]).filter(Boolean);
 else if(x.op==='replies'){let changed=false;for(const r of x.replies||[]){const l=s.leads.find(l=>l.id===r.lead_id);if(l)changed=C.applyReply(l,r)||changed;}result={state:s,changed};}
 else if(x.op==='receipts'){let changed=false;for(const j of x.jobs){const l=s.leads.find(l=>l.id===j.lead_id);if(l)changed=C.applyMailReceipt(l,j)||changed;}result={state:s,changed};}
 else throw Error('Unknown operation');}
process.stdout.write(JSON.stringify({ok:true,result}));}catch(e){process.stdout.write(JSON.stringify({ok:false,error:e.message}));process.exitCode=1;}});
