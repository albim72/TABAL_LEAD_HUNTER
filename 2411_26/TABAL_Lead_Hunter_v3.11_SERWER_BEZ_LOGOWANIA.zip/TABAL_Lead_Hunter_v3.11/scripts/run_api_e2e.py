#!/usr/bin/env python3
"""3.11: browser scenario of the API mode. Isolated test database, a local fake of the provider's API; never touches
production data and never calls a real provider (no key, no cost)."""
import os, socket, subprocess, sys, tempfile, time, urllib.request
from pathlib import Path
root = Path(__file__).resolve().parents[1]


def free_port():
    with socket.socket() as s:
        s.bind(('127.0.0.1', 0))
        return s.getsockname()[1]


with tempfile.TemporaryDirectory(prefix='tabal-api-e2e-') as tmp:
    fake = free_port()
    env = dict(os.environ, TABAL_DATA_DIR=tmp, TABAL_ORIGIN='http://127.0.0.1:8765', TABAL_SMTP_HOSTS='localhost',
               TABAL_AI_BASE_URL=f'http://127.0.0.1:{fake}/v1', TABAL_AI_API_KEY='sk-e2e-0123456789abcdefghij',
               TABAL_AI_MODEL='e2e-model', TABAL_AI_POLL_SECONDS='1', FAKE_AI_PORT=str(fake),
               NO_PROXY='127.0.0.1,localhost', no_proxy='127.0.0.1,localhost')
    with socket.socket() as check:
        check.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            check.bind(('127.0.0.1', 8765))
        except OSError:
            raise SystemExit('Port 8765 zajęty. Zatrzymaj lokalną instancję przed testem.')
    server = subprocess.Popen([sys.executable, str(root / 'serve.py')], env=env, cwd=root,
                              stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        for _ in range(100):
            try:
                urllib.request.urlopen('http://127.0.0.1:8765/healthz', timeout=1)
                break
            except Exception:
                time.sleep(.1)
        env['TEST_URL'] = 'http://127.0.0.1:8765'
        result = subprocess.run(['node', str(root / 'tests/api_e2e.cjs')], env=env, cwd=root)
    finally:
        server.terminate()
        try:
            server.wait(timeout=15)
        except subprocess.TimeoutExpired:
            server.kill()
    sys.exit(result.returncode)
