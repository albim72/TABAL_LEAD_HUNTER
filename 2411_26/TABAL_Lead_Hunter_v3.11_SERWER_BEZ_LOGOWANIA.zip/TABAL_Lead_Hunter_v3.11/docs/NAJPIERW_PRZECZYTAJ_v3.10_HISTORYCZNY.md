# TABAL Lead Hunter 3.10: e-maile ze stron firm, leady z portali, lżejsze zadanie Work, limit dobowy

Wydanie z 17 listopada 2026. Aktualizacja wersji 3.9. Wszystko, co działało w 3.9, działa bez zmian: stałe profile, adres nadawcy z profilu, język korzyści i szybkie odkrywanie. Opis 3.9 jest w `docs/NAJPIERW_PRZECZYTAJ_v3.9_HISTORYCZNY.md`.

Źródła uwag: raporty J. Moraczewskiego z 12.11 (śląskie) i 13.11 (dolnośląskie) oraz uwagi P. Frankiewicza z grupy „AI dla TABAL” (13.11).

## Co pokazały raporty

| Strategia | Wyniki | Maile | Firmy z e-mailem |
|---|---|---|---|
| Profile konstrukcyjne (śl.) | 99 | 97 | 98% |
| Ogrodzenia aluminiowe (śl.) | 95 | 80 | 84% |
| Balustrady, strategia 2 (śl.) | 97 | 67 | 69% |
| Ogrodzenia panelowe (śl.) | 98 | 48 | 49% |
| Balustrady, strategia 1 (śl.) | 98 | 14 | 14% (zły typ klienta) |
| Profile (doln.) | 99 | 84 | 85% |
| Aluminiowe (doln.) | 78 | 37 | 47% |
| Panelowe (doln.) | 78 | 27 | 35% |

Tam, gdzie firmy mają własne strony (producenci, dystrybutorzy), narzędzie działa dobrze. Przy ogrodzeniach dużo wyników to mali montażyści z Oferteo, często bez strony. Zdarzało się też, że e-mail był na stronie firmy, a aplikacja go nie znalazła.

## 1. E-maile czytane bezpośrednio ze stron firm (nowe)

**Problem:** w trybie szybkim Work otwiera 2–3 strony na firmę. Przez to pomija adresy, które są:
- ukryte przez Cloudflare („[email protected]”),
- zapisane jako „biuro [at] firma.pl”,
- umieszczone w stopce ładowanej przez JavaScript albo na podstronie Kontakt / Polityka prywatności.

Jędrzej musiał wtedy uzupełniać je ręcznie.

**Rozwiązanie:** serwer aplikacji sam czyta do 6 stron z **własnej domeny** firmy: stronę główną, Kontakt, O nas, Politykę prywatności, Regulamin. Odczytuje e-maile i telefony (z linków `tel:`). Trwa to kilka sekund na firmę i **nie zużywa limitu ChatGPT**.

- **Automatycznie po imporcie:** nowe i ponownie znalezione firmy bez potwierdzonego e-maila są sprawdzane same. Ustawienie jest w Odkrywaniu → „Po imporcie sprawdź strony firm bez e-maila” i jest domyślnie włączone.
- **Ręcznie:**
  - Leady → zaznacz firmy → **„✉ Szukaj e-maili na stronach firm”**,
  - albo **„✉ Szukaj e-maili na stronach (widoczne bez e-maila)”** dla firm widocznych na liście,
  - albo na karcie firmy **„✉ Szukaj e-maila na stronie firmy”**.
- **Nowy filtr:** „Bez potwierdzonego e-maila (ma stronę)”.

**Jak traktowane są znalezione adresy:**
- **Adres w domenie firmy** (np. biuro@firma.pl) albo z poczty darmowej (gmail, wp, o2, interia… — tak piszą montażyści) jest **potwierdzony** (źródło: URL podstrony) i można na niego wysyłać.
- **Adres z innej domeny** (np. firma, która zrobiła stronę WWW) jest dodawany jako **„do weryfikacji”** i nie trafia do wysyłki bez zatwierdzenia.
- **Niepewny adres z katalogu**, jeśli jest na stronie firmy, zostaje **potwierdzony** (bez duplikatu).
- Aplikacja **nie** czyta portali i katalogów (Oferteo, Panorama Firm, PKT, Facebook…), bo ich adresy nie należą do firmy. Firmy bez własnej domeny nie są sprawdzane.
- Każde sprawdzenie zapisuje się w historii firmy. Na karcie widać, ile stron sprawdzono i ile adresów znaleziono.

**Bezpieczeństwo:**
- tylko publiczne adresy http(s), także po przekierowaniu,
- tylko strony HTML, do 1,5 MB na stronę,
- bez formularzy i logowania.

Serwer TABAL musi mieć wyjście do internetu (porty 80/443), tak samo jak do wysyłki poczty.

## 2. Leady z portali (Oferteo) i firmy bez strony

Zgodnie z uwagą P. Frankiewicza: firmy montażowe często nie mają strony, a są dobrym celem. Dlatego **nie są wykluczane**. Zadanie dla Work (tryb szybki) mówi teraz:

- **Portal to tylko trop.** Dla firmy z Oferteo / Panoramy / PKT Work wykonuje jedno wyszukiwanie (nazwa + miejscowość), żeby znaleźć jej stronę albo wizytówkę Google / Facebook / CEIDG z telefonem.
- **Wizytówka z telefonem wystarczy.** Firma bez strony, ale z telefonem jest dodawana, a kontakt dostaje oznaczenie „do weryfikacji”.
- **Firma bez żadnego kanału kontaktu** (bez e-maila i bez telefonu) **nie jest leadem**. Trafia do `research_report.rejected` z powodem „brak kontaktu” i nie liczy się do celu. To odpowiedź na „lead jest spalony”.
- **Ukryty e-mail:** Work zapisuje adres podstrony Kontakt z uwagą „e-mail ukryty na stronie”, a aplikacja odczyta adres sama (pkt 1).

## 3. Lżejsze zadanie dla Work (czat się zacinał)

**Przyczyna:** zadanie zawierało listę **wszystkich** firm z bazy (żeby Work nie liczył ich jako nowych). Ta lista rosła z każdym wyszukiwaniem.

**Zmiana:** zadanie zawiera teraz tylko znane firmy **z obszaru kampanii** oraz firmy bez ustalonego adresu. Firmy spoza obszaru i tak rozpoznaje import, bo ma deduplikację po domenie i NIP. Przy bazie 1500 firm z 6 województw zadanie dla dolnośląskiego spadło z ok. 122 tys. do ok. 37 tys. znaków (−70%). Przy obszarze „cała Polska” lista jest pełna, jak wcześniej.

## 4. Limit dobowy: zaległe maile wychodzą same

**Problem:** gdy dzienny limit się wyczerpał, a panel został zamknięty, kolejka się wstrzymywała. Następnego dnia trzeba było dosyłać ręcznie („zablokowane wczoraj limitem 24 h”).

**Zmiana:**
- Po osiągnięciu limitu kolejka **sama przechodzi w tryb „bez panelu”**. Pozostałe wiadomości wychodzą po odnowieniu limitu, także po zamknięciu przeglądarki.
- To ten sam bezpieczny tryb co „Wyślij bez panelu”: tuż przed wysyłką serwer sprawdza każdą wiadomość z aktualnymi danymi firmy. Gdy coś się zmieni, wiadomość jest anulowana.
- Panel wysyłki pokazuje **godzinę**, od której wyjdzie kolejna wiadomość.
- Kreator ostrzega przed zatwierdzeniem, ile wiadomości wyjdzie dziś, a ile po odnowieniu limitu.

## 5. Wykluczenia produktu

W raporcie z 13.11 zabrakło wykluczenia „własna produkcja ogrodzeń aluminiowych”. Wtedy Work dodaje producentów, czyli konkurencję.

- **Nowa strategia:** pole „Kryteria wykluczające” jest wstępnie wypełnione domyślnym wykluczeniem dla wybranego produktu. Każdy z 7 produktów TABAL ma swoje.
- **Istniejąca strategia:** przycisk **„Wstaw domyślne wykluczenie dla wybranego produktu”**.
- **Odkrywanie:** gdy strategia nie ma wykluczeń, widać czerwone ostrzeżenie z podpowiedzią.

Istniejących strategii aplikacja **nie zmienia sama**. Wykluczenie trzeba wstawić i zapisać.

## 6. Status SKONTAKTOWANY bez adresu

W raporcie z 13.11 było 21 firm „ze statusem wysłanych bez adresu”. Wysyłka z kreatora ustawia SKONTAKTOWANY dopiero po przyjęciu wiadomości przez SMTP. Takie firmy mogły więc powstać tylko przez ręczną zmianę statusu. Dokładnej ścieżki nie udało się odtworzyć bez danych z serwera.

- **Ręczna zmiana** statusu na SKONTAKTOWANY z kanałem **e-mail** dla firmy bez adresu e-mail i bez wysłanej wiadomości jest **blokowana**, z podpowiedzią. Kanał „telefon” lub „spotkanie” działa jak wcześniej.
- **Nowy filtr:** „Skontaktowane bez wysłanego e-maila”.
- **Karta firmy** pokazuje ostrzeżenie dla takich firm.

**Prośba do TABAL:** proszę o nazwy 2–3 firm z tych 21. Pozwoli to potwierdzić przyczynę w historii karty.

## Nie zmieniono (do decyzji)

- **„Łączenie strategii”** (np. panelowe + aluminiowe w jednym zadaniu Work) wymaga zmian w kampaniach i projektach, więc zostaje na kolejną wersję. Import już dziś rozpoznaje tę samą firmę z różnych strategii i nie liczy jej podwójnie.
- **Balustrady, strategia 1 (14% maili):** to ustawienie typu klienta w strategii (raport Jędrzeja), a nie błąd aplikacji.

## Aktualizacja z 3.9

1. Poczekaj, aż kolejka wysyłki będzie pusta. Pobierz Kopię JSON, zatrzymaj serwer, zachowaj `.runtime` i `.env`.
2. Rozpakuj 3.10, przenieś `.runtime` i `.env`, uruchom serwer. W Dockerze: `docker compose up -d --build`, **bez** `down -v`.
3. `/healthz` ma zwracać `3.10.0`, a w menu ma być „WERSJA 3.10”.
4. **Pierwszy test:** Leady → filtr „Bez potwierdzonego e-maila (ma stronę)” → „✉ Szukaj e-maili na stronach (widoczne bez e-maila)”. Komunikat pokaże, dla ilu firm znaleziono adres.

## Testy

| Zakres | Wynik |
|---|---|
| Logika | 183 testy (10 nowych), wszystkie przechodzą |
| Serwer, SMTP, IMAP, czytanie stron | 106 testów (11 nowych), wszystkie przechodzą |
| Przeglądarka | 37 testów (1 nowy), wszystkie przechodzą |
| Pełny scenariusz wysyłki (lokalny SMTP z TLS) | OK |

Nowe testy logiki i serwera sprawdzają m.in.:
- Cloudflare, zapisy „[at]” i „(małpa)”, mailto, encje HTML, adresy w skryptach, podstronę Kontakt,
- odmowę dla portali i adresów prywatnych,
- przejście kolejki w tryb bez panelu po limicie,
- listę znanych firm ograniczoną do obszaru,
- blokadę statusu bez adresu.

**Nie testowano:** czytania prawdziwych stron firm, bo środowisko testowe nie ma dostępu do internetu (testy działały na lokalnych stronach testowych), ani rzeczywistego researchu w ChatGPT Work. Pierwszy test u TABAL: filtr i przycisk z pkt 4 powyżej, a potem import kolejnego wyszukiwania dla ogrodzeń panelowych.
