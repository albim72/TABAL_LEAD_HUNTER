"""3.11 (TABAL 19–24.11.2026): research through the AI provider's API — job queue, background polling, results,
errors (key, missing funds), cancel, time limit, parallel limit. A local fake of the Responses API stands in for the provider."""
import http.server
import json
import os
import socketserver
import sys
import tempfile
import threading
import time
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from server import airunner as ar  # noqa: E402

TASK = 'ZADANIE TESTOWE ' + 'x' * 400
RESULT = {'schema_version': 2, 'strategy_id': 's1', 'run_id': 'r1', 'batch_id': 'b1',
          'research_report': {'stop_reason': 'target_reached'}, 'leads': [{'company': 'Firma A'}]}


class Fake:
    """Minimal Responses API: POST /v1/responses (background), GET /v1/responses/{id}, POST …/cancel."""
    def __init__(self):
        self.responses = {}
        self.posts = []
        self.mode = 'ok'          # ok | 401 | 429 | incomplete | empty | slow
        self.polls_to_finish = 1

    def handler(self):
        fake = self

        class H(http.server.BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def _send(self, code, data):
                body = json.dumps(data).encode()
                self.send_response(code)
                self.send_header('Content-Type', 'application/json')
                self.send_header('Content-Length', str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def do_POST(self):
                payload = json.loads(self.rfile.read(int(self.headers['Content-Length'])) or b'{}')
                if self.headers.get('Authorization') != 'Bearer sk-test-0123456789abcdefghij':
                    return self._send(401, {'error': {'message': 'Incorrect API key'}})
                if self.path.endswith('/cancel'):
                    rid = self.path.split('/')[-2]
                    fake.responses[rid]['status'] = 'cancelled'
                    return self._send(200, fake.responses[rid])
                if fake.mode == '429':
                    return self._send(429, {'error': {'message': 'You exceeded your current quota'}})
                fake.posts.append(payload)
                rid = 'resp_' + str(len(fake.posts))
                fake.responses[rid] = {'id': rid, 'status': 'queued', 'polls': 0, 'output': []}
                return self._send(200, {'id': rid, 'status': 'queued'})

            def do_GET(self):
                rid = self.path.split('/')[-1]
                r = fake.responses.get(rid)
                if not r:
                    return self._send(404, {'error': {'message': 'not found'}})
                if r['status'] == 'cancelled':
                    return self._send(200, r)
                r['polls'] += 1
                if fake.mode == 'slow' or r['polls'] < fake.polls_to_finish:
                    return self._send(200, {'id': rid, 'status': 'in_progress'})
                out = [{'type': 'web_search_call', 'status': 'completed'}, {'type': 'web_search_call', 'status': 'completed'},
                       {'type': 'message', 'content': [{'type': 'output_text', 'text': json.dumps(RESULT)}]}]
                if fake.mode == 'empty':
                    out = [{'type': 'web_search_call'}]
                status = 'incomplete' if fake.mode == 'incomplete' else 'completed'
                return self._send(200, {'id': rid, 'status': status, 'output': out,
                                        'incomplete_details': {'reason': 'max_output_tokens'},
                                        'usage': {'input_tokens': 120000, 'output_tokens': 8000}})
        return H


class APIModeTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.fake = Fake()
        socketserver.TCPServer.allow_reuse_address = True
        cls.httpd = socketserver.ThreadingTCPServer(('127.0.0.1', 0), cls.fake.handler())
        threading.Thread(target=cls.httpd.serve_forever, daemon=True).start()
        cls.base = 'http://127.0.0.1:%d/v1' % cls.httpd.server_address[1]

    @classmethod
    def tearDownClass(cls):
        cls.httpd.shutdown()

    def setUp(self):
        self.fake.mode = 'ok'
        self.fake.polls_to_finish = 1
        self.env = {k: os.environ.get(k) for k in list(os.environ) if k.startswith('TABAL_AI') or k == 'TABAL_OPENAI_API_KEY'}
        for k in self.env:
            os.environ.pop(k)
        os.environ.update(TABAL_AI_BASE_URL=self.base, TABAL_AI_API_KEY='sk-test-0123456789abcdefghij',
                          TABAL_AI_MODEL='test-model', TABAL_AI_POLL_SECONDS='1', TABAL_AI_PARALLEL='2',
                          TABAL_AI_PRICE_IN='1.25', TABAL_AI_PRICE_OUT='10')
        self.tmp = tempfile.TemporaryDirectory()
        self.r = ar.AIRunner(Path(self.tmp.name) / 'ai.sqlite3')
        self.r.poll_seconds = 0

    def tearDown(self):
        self.r.db.close()
        self.tmp.cleanup()
        for k in [k for k in os.environ if k.startswith('TABAL_AI')]:
            os.environ.pop(k)
        for k, v in self.env.items():
            if v is not None:
                os.environ[k] = v

    def job(self, jid):
        return next(j for j in self.r.snapshot()['jobs'] if j['id'] == jid)

    def run_until(self, jid, statuses=('done', 'error', 'cancelled'), n=10):
        for _ in range(n):
            self.r.tick()
            if self.job(jid)['status'] in statuses:
                break
        return self.job(jid)

    def test_full_cycle_result_tokens_cost_and_payload(self):
        jid = self.r.add([{'task': TASK, 'batch_id': 'b1', 'run_id': 'r1', 'label': 'Wielkopolskie · Część 1/3'}])['ids'][0]
        self.assertEqual(self.job(jid)['status'], 'queued')
        j = self.run_until(jid)
        self.assertEqual(j['status'], 'done')
        self.assertEqual(j['searches'], 2)
        self.assertEqual(j['input_tokens'], 120000)
        self.assertAlmostEqual(j['cost'], 0.12000 * 1.25 + 0.008 * 10, places=4)
        self.assertEqual(json.loads(self.r.result(jid)['result'])['leads'][0]['company'], 'Firma A')
        sent = self.fake.posts[-1]
        self.assertEqual(sent['model'], 'test-model')
        self.assertTrue(sent['background'])
        self.assertEqual(sent['tools'], [{'type': 'web_search'}])
        self.assertTrue(sent['input'].startswith('TRYB API'))
        self.assertIn(TASK, sent['input'])
        self.assertNotIn('result', json.dumps(self.r.snapshot()['jobs']).replace('result_size', ''))  # status list without big texts
        self.r.mark(jid, True)
        self.assertEqual(self.job(jid)['imported'], 1)

    def test_key_never_exposed(self):
        snap = json.dumps(self.r.snapshot(), ensure_ascii=False)
        self.assertNotIn('sk-test-0123456789abcdefghij', snap)
        self.assertIn('…ghij', snap)

    def test_not_configured_and_bad_input(self):
        os.environ.pop('TABAL_AI_API_KEY')
        self.r.reload()
        with self.assertRaisesRegex(ValueError, 'nie jest skonfigurowany'):
            self.r.add([{'task': TASK}])
        self.r.set_panel(api_key='sk-test-0123456789abcdefghij')
        self.assertTrue(self.r.info()['configured'])
        self.assertEqual(self.r.info()['key_source'], 'panel')
        with self.assertRaisesRegex(ValueError, 'niepoprawny'):
            self.r.set_panel(api_key='short')
        with self.assertRaisesRegex(ValueError, 'pełnym tekstem'):
            self.r.add([{'task': 'za krótkie'}])
        with self.assertRaisesRegex(ValueError, '1–20'):
            self.r.add([])

    def test_same_batch_cannot_run_twice(self):
        self.r.add([{'task': TASK, 'batch_id': 'b9'}])
        with self.assertRaisesRegex(ValueError, 'już działa'):
            self.r.add([{'task': TASK, 'batch_id': 'b9'}])

    def test_parallel_limit(self):
        self.fake.mode = 'slow'
        ids = self.r.add([{'task': TASK, 'batch_id': 'p%d' % i} for i in range(5)])['ids']
        self.r.tick()
        st = [self.job(i)['status'] for i in ids]
        self.assertEqual(st.count('running'), 2)
        self.assertEqual(st.count('queued'), 3)

    def test_missing_funds_message(self):
        self.fake.mode = '429'
        jid = self.r.add([{'task': TASK}])['ids'][0]
        j = self.run_until(jid)
        self.assertEqual(j['status'], 'error')
        self.assertIn('doładuj konto', j['error'])

    def test_wrong_key(self):
        self.r.set_panel(api_key='sk-wrong-0123456789abcdefghij')
        jid = self.r.add([{'task': TASK}])['ids'][0]
        j = self.run_until(jid)
        self.assertEqual(j['status'], 'error')
        self.assertIn('nieprawidłowy klucz', j['error'])

    def test_incomplete_with_text_is_imported_with_note(self):
        self.fake.mode = 'incomplete'
        jid = self.r.add([{'task': TASK}])['ids'][0]
        j = self.run_until(jid)
        self.assertEqual(j['status'], 'done')
        self.assertIn('niepełna', j['error'])

    def test_completed_without_text_is_error(self):
        self.fake.mode = 'empty'
        jid = self.r.add([{'task': TASK}])['ids'][0]
        self.assertEqual(self.run_until(jid)['status'], 'error')

    def test_cancel_and_time_limit(self):
        self.fake.mode = 'slow'
        a, b = self.r.add([{'task': TASK, 'batch_id': 'c1'}, {'task': TASK, 'batch_id': 'c2'}])['ids']
        self.r.tick()
        self.r.cancel(a)
        self.assertEqual(self.job(a)['status'], 'cancelled')
        with self.r.db:
            self.r.db.execute('UPDATE ai_jobs SET started=? WHERE id=?', (time.time() - 99999, b))
        self.r.tick()
        self.assertEqual(self.job(b)['status'], 'error')
        self.assertIn('limit czasu', self.job(b)['error'])

    def test_resume_after_restart(self):
        self.fake.polls_to_finish = 3
        jid = self.r.add([{'task': TASK}])['ids'][0]
        self.r.tick()
        self.assertEqual(self.job(jid)['status'], 'running')
        path = self.r.db.execute('PRAGMA database_list').fetchone()[2]
        self.r.db.close()
        self.r = ar.AIRunner(Path(path))
        self.r.poll_seconds = 0
        self.assertEqual(self.run_until(jid)['status'], 'done')

    def test_response_text_helpers(self):
        self.assertEqual(ar.response_text({'output_text': 'abc'}), 'abc')
        self.assertEqual(ar.response_text({'output': [{'type': 'message', 'content': [{'type': 'output_text', 'text': 'a'},
                                                                                       {'type': 'output_text', 'text': 'b'}]}]}), 'a\nb')
        self.assertEqual(ar.search_calls({'output': [{'type': 'web_search_call'}, {'type': 'message'}]}), 1)


if __name__ == '__main__':
    unittest.main()
