"""3.10 (TABAL 12–13.11.2026): e-mails read from the company's own website and the daily limit that no longer
leaves messages for manual re-sending the next day."""
import http.server
import socketserver
import sys
import tempfile
import threading
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from server import emailfinder as ef  # noqa: E402
from server.mailer import Outbox  # noqa: E402
from tests.test_mail import raw, CONFIG, Transport  # noqa: E402

OWNER = 'test-owner-310-123456'


def cf(email, key=0x5a):
    return format(key, '02x') + ''.join(format(ord(ch) ^ key, '02x') for ch in email)


SITE = {
    'https://ogrodzenia-nowak.pl/': '<html><body><a href="/oferta">Oferta</a> <a href="/kontakt/">Kontakt</a> '
                                     '<a href="https://www.facebook.com/nowak">FB</a> <img src="logo@2x.png"></body></html>',
    'https://ogrodzenia-nowak.pl/kontakt/': '<p>Napisz: <a href="/cdn-cgi/l/email-protection" class="__cf_email__" '
                                            f'data-cfemail="{cf("biuro@ogrodzenia-nowak.pl")}">[email&#160;protected]</a></p>'
                                            '<p>Tel. <a href="tel:+48601222333">601 222 333</a></p>'
                                            '<footer>Strona: kontakt@agencja-www.pl</footer>',
}


def fake_fetch(site):
    calls = []

    def fetch(url):
        calls.append(url)
        if url not in site:
            raise ValueError('404')
        return url, site[url]
    fetch.calls = calls
    return fetch


class EmailFinder(unittest.TestCase):
    def test_01_cloudflare_contact_page_and_phone(self):
        f = fake_fetch(SITE)
        r = ef.find('https://www.ogrodzenia-nowak.pl/', fetch=f)
        self.assertEqual(r['error'], '')
        self.assertEqual(r['emails'][0], {'email': 'biuro@ogrodzenia-nowak.pl', 'url': 'https://ogrodzenia-nowak.pl/kontakt/',
                                          'how': 'ochrona Cloudflare (odkodowano)', 'domain_match': 'own'})
        self.assertEqual([e['domain_match'] for e in r['emails']], ['own', 'other'])
        self.assertEqual(r['phones'], ['+48601222333'])
        self.assertNotIn('https://www.facebook.com/nowak', f.calls, 'portale i obce domeny nie są otwierane')
        self.assertLessEqual(len(r['checked']), ef.MAX_PAGES)
        self.assertFalse(any('2x.png' in e['email'] for e in r['emails']))

    def test_02_obfuscated_entities_mailto_and_script(self):
        page = ('<p>biuro [at] firma-abc [dot] pl</p><p>zakupy(małpa)firma-abc.pl</p>'
                '<a href="mailto:handel%40firma-abc.pl?subject=Zapytanie">Napisz</a><p>info&#64;firma-abc.pl</p>'
                '<script>var m="sklep"+"@"; var full="serwis@firma-abc.pl";</script><p>jan.kowalski@example.com</p>')
        found = {e for e, _ in ef.extract(page)[0]}
        self.assertEqual(found, {'biuro@firma-abc.pl', 'zakupy@firma-abc.pl', 'handel@firma-abc.pl', 'info@firma-abc.pl', 'serwis@firma-abc.pl'})

    def test_03_portal_missing_domain_and_dead_site(self):
        self.assertIn('portalu', ef.find('www.oferteo.pl', fetch=fake_fetch({}))['error'])
        self.assertIn('brak', ef.find('', fetch=fake_fetch({}))['error'])
        r = ef.find('nie-ma-takiej.pl', fetch=fake_fetch({}))
        self.assertIn('nie odpowiada', r['error'])
        self.assertEqual(r['emails'], [])

    def test_04_ranking_company_domain_first_then_free_mail(self):
        site = {'https://firma.com.pl/': '<p>kontakt@agencja.pl</p><p>firma.montaz@gmail.com</p><p>sprzedaz@firma.com.pl</p>'}
        r = ef.find('firma.com.pl', fetch=fake_fetch(site))
        self.assertEqual([(e['email'], e['domain_match']) for e in r['emails']],
                         [('sprzedaz@firma.com.pl', 'own'), ('firma.montaz@gmail.com', 'free'), ('kontakt@agencja.pl', 'other')])

    def test_05_private_addresses_refused(self):
        with self.assertRaises(ValueError):
            ef._default_fetch('http://127.0.0.1/')
        with self.assertRaises(ValueError):
            ef._default_fetch('http://localhost:8080/')

    def test_06_many_in_parallel_keeps_order_and_ids(self):
        out = ef.find_many([{'lead_id': 'a', 'domain': 'ogrodzenia-nowak.pl'}, {'lead_id': 'b', 'domain': 'oferteo.pl'}, 'zle'],
                           fetch=fake_fetch(SITE))
        self.assertEqual([r['lead_id'] for r in out], ['a', 'b'])
        self.assertEqual(out[0]['emails'][0]['email'], 'biuro@ogrodzenia-nowak.pl')

    def test_07_real_http_server_redirect_to_public_only(self):
        # Local HTTP server: the default fetcher refuses it (private address) — the finder reports it, never raises.
        class H(http.server.BaseHTTPRequestHandler):
            def do_GET(self):
                self.send_response(200)
                self.send_header('Content-Type', 'text/html')
                self.end_headers()
                self.wfile.write(b'<p>biuro@local.test</p>')

            def log_message(self, *a):
                pass
        srv = socketserver.TCPServer(('127.0.0.1', 0), H)
        t = threading.Thread(target=srv.serve_forever, daemon=True)
        t.start()
        try:
            r = ef.find('127.0.0.1')
            self.assertEqual(r['emails'], [])
            self.assertTrue(r['error'])
        finally:
            srv.shutdown()
            srv.server_close()


class DailyLimit(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.dir = Path(self.tmp.name)
        self.transport = Transport()
        self.now = 100
        self.box = Outbox(self.dir / 'mail.sqlite3', self.transport, lambda: self.now, config_path=self.dir / 'smtp.json')

    def tearDown(self):
        self.box.close()
        self.tmp.cleanup()

    def test_01_attended_queue_continues_by_itself_after_the_limit(self):
        self.box.configure({**CONFIG, 'daily_limit': 1})
        self.box.validator = lambda job: True
        self.box.enqueue([raw('a@example.com', 'l1'), raw('b@example.com', 'l2')], OWNER)
        ids = [j['id'] for j in self.box.jobs()]
        self.box.sync(OWNER, ids)
        self.box.control('resume', owner=OWNER)
        self.assertFalse(self.box.unattended)
        self.assertTrue(self.box.run_one())
        self.now += 11
        self.assertFalse(self.box.run_one())
        snap = self.box.snapshot()
        self.assertTrue(snap['limit_wait'])
        self.assertTrue(snap['unattended'], 'po osiągnięciu limitu kolejka działa bez panelu')
        self.assertTrue(snap['limit_auto'])
        self.assertTrue(snap['limit_free_at'])
        # The panel is closed (no heartbeat for a long time): the queue is NOT paused.
        self.now += 10_000
        self.assertFalse(self.box.run_one())
        self.assertFalse(self.box.paused)
        self.assertEqual(self.box.snapshot()['queued'], 1)

    def test_02_without_validator_no_automatic_switch(self):
        self.box.configure({**CONFIG, 'daily_limit': 1})
        self.box.enqueue([raw('a@example.com', 'l1'), raw('b@example.com', 'l2')], OWNER)
        self.box.sync(OWNER, [j['id'] for j in self.box.jobs()])
        self.box.control('resume', owner=OWNER)
        self.assertTrue(self.box.run_one())
        self.now += 11
        self.assertFalse(self.box.run_one())
        self.assertFalse(self.box.unattended)

    def test_03_no_limit_no_free_time(self):
        self.box.configure(CONFIG)
        self.assertEqual(self.box.limit_free_at(), '')
        self.assertNotIn('limit_free_at', {k for k, v in self.box.snapshot().items() if v})


if __name__ == '__main__':
    unittest.main()
