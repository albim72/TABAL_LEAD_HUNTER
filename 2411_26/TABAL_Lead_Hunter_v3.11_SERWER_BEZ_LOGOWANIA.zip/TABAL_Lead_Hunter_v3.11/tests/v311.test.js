// TABAL Lead Hunter 3.11 — raport J. Moraczewskiego z 20.11.2026 i uwagi z 19.11 (grupa „AI dla TABAL”):
// stara strona nie odrzuca leada, szkic dla każdej firmy, jednoznaczny werdykt „pula wyczerpana”, lista klientów
// i archiwum wysłanych, strategia łączona z dwoma linkami.
const test=require('node:test'),a=require('node:assert/strict'),C=require('../src/core.js');
const T=C.today(),Y=Number(T.slice(0,4));
function base(){const s=C.makeState('pilot');s.config.signature='Zespół TABAL\nbok@tabal.pl';return s;}
function strat(s,id='profiles',extra={}){const st=C.strategy({...s.strategies[0],product_id:id,...extra});s.strategies=[st];return st;}
const src=(d,year)=>[{url:'https://'+d+'/',title:'Strona',quote:'Firma '+d+' biuro@'+d,checked_at:T,verified:true,...(year?{updated_year:year}:{})}];
function lead(s,st,x={}){return C.validateLead({company:'Alu-Profil Kowalski',domain:'alu-kowalski.pl',city:'Poznań',postal_code:'60-001',address:'ul. Polna 1, 60-001 Poznań',sources:src('alu-kowalski.pl',x.year),contacts:[{type:'general',email:'biuro@alu-kowalski.pl',url:'https://alu-kowalski.pl/',quote:'biuro@alu-kowalski.pl',checked_at:T,verified:true}],criteria:{},...x},s,st);}

// ---------- stara strona (raport 20.11, pkt 3: 22 leady odrzucone ręcznie) ----------
test('STARA STRONA 3.11: strona sprzed 4 lat nie odejmuje punktów, nie blokuje i daje tylko ostrzeżenie',()=>{
 const s=base(),st=strat(s),fresh=lead(s,st),old=lead(s,st,{year:Y-4});
 const a1=C.score(fresh,s.config),a2=C.score(old,s.config);
 a.equal(a2.points,a1.points,'ten sam wynik co przy aktualnej stronie');
 a.ok(!a2.parts.some(p=>p.key==='stale'),'bez kary za stare źródło');
 a.ok(!a2.blocks.some(b=>/Źródło wymaga weryfikacji/.test(b)));
 a.ok(a2.warnings.some(w=>new RegExp('nieaktualizowana od '+(Y-4)).test(w)),a2.warnings.join(' | '));
 a.equal(a2.checks.source,'ok');
});
test('STARA STRONA 3.11: import nie odkłada takiej firmy do archiwum „poniżej progu”',()=>{
 const s=base(),st=strat(s);const raw={company:'Alu-Profil Kowalski',domain:'alu-kowalski.pl',city:'Poznań',postal_code:'60-001',sources:src('alu-kowalski.pl',Y-5),contacts:[{type:'general',email:'biuro@alu-kowalski.pl',url:'https://alu-kowalski.pl/',quote:'biuro@alu-kowalski.pl',checked_at:T,verified:true}],criteria:{}};
 const r=C.merge(s,[raw],st);s.leads=r.leads;const q=C.importQuality(s,r.leads,r.addedIds);
 const strict=C.importQuality({...s,config:C.settings({...s.config,stale_site_block:true})},r.leads,r.addedIds);
 a.ok(q.weak.length<=strict.weak.length);
 a.ok(C.score(s.leads[0],s.config).points>C.score(s.leads[0],C.settings({...s.config,stale_site_block:true})).points,'3.11 daje więcej punktów niż stara reguła');
});
test('SZKIC 3.11: lokalny szkic powstaje także dla firmy ze starą lub niesprawdzoną stroną',()=>{
 const s=base(),st=strat(s),old=lead(s,st,{year:Y-6});
 const d=C.draft(old,C.settings({...s.config,stale_site_block:true}),s.products);
 a.ok(!/Brak aktualnego/.test(d.body),d.body.slice(0,120));a.ok(d.subject&&d.body.length>80);
 a.match(C.draft({...old,domain:'',sources:[]},s.config,s.products).body,/Brak źródła/);
 const portal=C.validateLead({company:'Monter z portalu',domain:'',identity_url:'https://www.oferteo.pl/monter',sources:[{url:'https://www.oferteo.pl/monter',title:'Oferteo',quote:'Monter',checked_at:T,verified:false}],contacts:[],criteria:{}},s,st);
 a.ok(!/Brak/.test(C.draft(portal,s.config,s.products).body),'szkic także z wizytówki z portalu');
});
test('ZADANIE 3.11: Work nie odrzuca firm za starą stronę',()=>{
 const s=base(),st=strat(s),run=C.createResearchRun(st,'',s.config.work_model);s.runs.push(run);const t=C.prepareResearchBatch(s,run);
 a.match(t,/stara strona NIE wyklucza firmy/);a.doesNotMatch(t,/nieaktualizowana od ponad 2 lat nie potwierdza/);
});

// ---------- werdykt puli (19.11 pkt 1 i 8) ----------
function runWith(imports,target=100){const s=base(),st=strat(s,'profiles',{limit:target});const run=C.createResearchRun(st,'','sol');run.target=target;run.imports=imports;run.added=imports.reduce((x,i)=>x+i.added,0);run.added_good=imports.reduce((x,i)=>x+(i.added_good??i.added),0);run.count_good=true;run.result_ids=[];return run;}
test('PULA 3.11: wyczerpana — po wykonaniu planu i stop_reason pool_exhausted',()=>{
 const v=C.poolVerdict(runWith([{added:62,added_good:58,coverage:{executed:40,planned:42},research:{stop_reason:'pool_exhausted'}}]));
 a.equal(v.state,'exhausted');a.match(v.title,/zakończ wyszukiwanie/);
});
test('PULA 3.11: niepełna — mało wykonanych zapytań to NIE koniec puli',()=>{
 const v=C.poolVerdict(runWith([{added:56,added_good:51,coverage:{executed:12,planned:42},research:{stop_reason:'pool_exhausted'}}]));
 a.equal(v.state,'partial');a.match(v.text,/NIE jest wyczerpana/);a.match(v.text,/29%/);
});
test('PULA 3.11: niepełna przy limicie czasu; wyczerpana po dwóch pustych importach',()=>{
 a.equal(C.poolVerdict(runWith([{added:40,added_good:40,coverage:{executed:30,planned:30},research:{stop_reason:'budget'}}])).state,'partial');
 a.equal(C.poolVerdict(runWith([{added:50,added_good:48,research:{stop_reason:'other'}},{added:2,added_good:1,research:{stop_reason:'other'}},{added:1,added_good:0,research:{stop_reason:'other'}}])).state,'exhausted');
 a.equal(C.poolVerdict(runWith([])).state,'none');
});

// ---------- lista klientów i archiwum wysłanych (19.11 pkt 3) ----------
test('LISTA 3.11: rozpoznaje e-maile, domeny, NIP i nazwy z wklejonego CSV',()=>{
 const x=C.parseBlocklist('Nazwa;E-mail;WWW;NIP\nOgrodzenia Nowak Sp. z o.o.;biuro@nowak-ogrodzenia.pl;www.nowak-ogrodzenia.pl;712-010-11-21\nhandel@inna.pl\nhttps://www.klient-staly.pl/kontakt\nAlu Serwis S.C.\nfirma z oferteo.pl\n');
 a.ok(x.emails.includes('biuro@nowak-ogrodzenia.pl')&&x.emails.includes('handel@inna.pl'));
 a.ok(x.domains.includes('nowak-ogrodzenia.pl')&&x.domains.includes('klient-staly.pl'));a.ok(!x.domains.includes('inna.pl'),'domena z e-maila nie jest dopisywana jako strona');a.ok(!x.domains.includes('oferteo.pl'),'portal nie jest wykluczany');
 a.deepEqual(x.nips,['7120101121']);a.ok(x.names.includes('Alu Serwis S.C.'));a.ok(!x.names.some(n=>/^nazwa/i.test(n)),'nagłówek pominięty');
});
test('LISTA 3.11: klient z listy jest zablokowany w scoringu i w kreatorze wysyłki; lista przetrwa kopię',()=>{
 const s=base(),st=strat(s);let l=lead(s,st);l=C.statusChange(l,'TO_CONTACT','test',T,'e-mail');s.leads=[l];
 a.equal(C.blockedBy(l,s.config),'');
 s.config=C.settings({...s.config,excluded_emails:['BIURO@alu-kowalski.pl']});
 a.match(C.blockedBy(l,s.config),/archiwum wysłanych/);a.ok(C.score(l,s.config).blocks.some(b=>/archiwum/.test(b)));
 const m=C.mailCandidate(l,s.config,'pilot',s.products);a.equal(m.message,null);a.ok(m.reasons.some(r=>/archiwum/.test(r)));
 s.config=C.settings({...s.config,excluded_emails:[],excluded_names:['ALU-PROFIL KOWALSKI sp. z o.o.']});a.match(C.blockedBy(l,s.config),/nazwa/);
 s.config=C.settings({...s.config,excluded_names:[],excluded_nips:['712-010-11-21']});l.nip='7120101121';a.match(C.blockedBy(l,s.config),/NIP/);
 const back=C.restore(C.backup(s),'pilot');a.deepEqual(back.config.excluded_nips,['7120101121']);
});
test('LISTA 3.11: darmowa poczta montażysty nie blokuje innych firm z tą samą domeną',()=>{
 const s=base(),st=strat(s);const l=lead(s,st,{domain:'',identity_url:'https://www.oferteo.pl/jan-monter',sources:[{url:'https://www.oferteo.pl/jan-monter',title:'Oferteo',quote:'jan.monter@gmail.com',checked_at:T,verified:true}],contacts:[{type:'general',email:'jan.monter@gmail.com',quote:'jan.monter@gmail.com',url:'https://www.oferteo.pl/x',checked_at:T,verified:true}]});
 s.config=C.settings({...s.config,excluded_domains:['tabal.pl','gmail.com']});a.equal(C.blockedBy(l,s.config),'');
});

// ---------- strategia łączona (19.11 pkt 4) ----------
test('DWA PRODUKTY 3.11: strategia aluminiowe + panelowe daje linki do obu ofert i opis w zadaniu',()=>{
 const s=base();const st=strat(s,'alu',{product2_id:'panel'});a.equal(st.product2_id,'panel');a.equal(C.strategy({...st,product2_id:'alu'}).product2_id,'','ten sam produkt dwa razy = brak');
 const l=lead(s,st);const links=C.offerLinks(l,s.products,s.config).map(x=>x.label).join(' | ');
 a.match(links,/aluminiowe/i);a.match(links,/panelowe/i);
 const run=C.createResearchRun(st,'','sol');s.runs.push(run);const t=C.prepareResearchBatch(s,run);a.match(t,/combined_offer/);a.match(t,/Strategia łączona/);
});
