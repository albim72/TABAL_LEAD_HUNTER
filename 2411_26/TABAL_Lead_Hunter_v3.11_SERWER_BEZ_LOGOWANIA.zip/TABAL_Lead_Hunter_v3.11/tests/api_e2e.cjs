// 3.11: full browser scenario of the API mode against a local fake of the provider's Responses API.
// Campaign → "▶ Uruchom bieżące zadanie przez API" → the server runs the task in the background → the panel imports
// the result automatically (no copy/paste) → leads in the base, batch marked as imported, verdict shown.
// Also: client list / archive of sent (paste → counts) and the second product in a strategy.
const {chromium}=require('playwright'),assert=require('node:assert/strict'),http=require('node:http'),path=require('node:path'),C=require('../src/core.js');
const base=process.env.TEST_URL||'http://127.0.0.1:8765',fakePort=Number(process.env.FAKE_AI_PORT),root=path.resolve(__dirname,'..');
let workspace=null;const seen={posts:[],inputs:[]};
// ---- fake provider: answers with leads built from the strategy named in the task ----
const responses={};
const fake=http.createServer((req,res)=>{let body='';req.on('data',d=>body+=d);req.on('end',()=>{
 const send=(code,data)=>{res.writeHead(code,{'Content-Type':'application/json'});res.end(JSON.stringify(data));};
 if(req.headers.authorization!=='Bearer sk-e2e-0123456789abcdefghij')return send(401,{error:{message:'bad key'}});
 if(req.method==='POST'&&req.url==='/v1/responses'){const x=JSON.parse(body);seen.posts.push(x);seen.inputs.push(x.input);const id='resp_'+seen.posts.length;responses[id]={input:x.input,polls:0};return send(200,{id,status:'queued'});}
 const m=req.url.match(/^\/v1\/responses\/([^/]+)$/);
 if(req.method==='GET'&&m&&responses[m[1]]){const r=responses[m[1]];r.polls++;if(r.polls<2)return send(200,{id:m[1],status:'in_progress'});
  const tail=r.input.slice(r.input.lastIndexOf('"schema_version"')),pick=k=>(tail.match(new RegExp('"'+k+'":\\s*"([^"]*)"'))||[])[1]||'';const ids={strategy_id:pick('strategy_id'),run_id:pick('run_id'),batch_id:pick('batch_id')};
  const st=workspace.state.strategies.find(s=>s.id===ids.strategy_id)||workspace.state.strategies[0];
  const leads=[1,2,3].map(i=>{const x={...C.sample(st,workspace.state,false),address:`ul. Testowa ${i}, 20-00${i} Lublin`,city:'Lublin'};x.company='Firma API '+i;x.domain=`firma-api-${i}.example`;x.nip='';x.identity_url='';
   x.sources=x.sources.map(s=>({...s,url:`https://firma-api-${i}.example/`,updated_year:2021}));for(const k of Object.keys(x.criteria))x.criteria[k]={...x.criteria[k],url:`https://firma-api-${i}.example/`};
   x.contacts=(x.contacts||[]).map(c=>({...c,email:c.email?`biuro@firma-api-${i}.example`:c.email,url:`https://firma-api-${i}.example/`,quote:(c.quote||'')+` biuro@firma-api-${i}.example`}));return x;});
  const text='```json\n'+JSON.stringify({schema_version:2,strategy_id:ids.strategy_id,run_id:ids.run_id,batch_id:ids.batch_id,model:'fake-e2e',research_report:{stop_reason:'pool_exhausted',queries:['q1'],remaining_areas:[],rejected:[],limitations:''},leads})+'\n```';
  return send(200,{id:m[1],status:'completed',output:[{type:'web_search_call'},{type:'message',content:[{type:'output_text',text}]}],usage:{input_tokens:50000,output_tokens:4000}});}
 send(404,{error:{message:'not found'}});});});
(async()=>{
 await new Promise(r=>fake.listen(fakePort,'127.0.0.1',r));
 const browser=await chromium.launch({headless:true,...(process.env.CHROMIUM_PATH?{executablePath:process.env.CHROMIUM_PATH,args:['--no-sandbox','--disable-dev-shm-usage','--disable-gpu']}:{})});
 const p=await (await browser.newContext({viewport:{width:1440,height:1000}})).newPage();const errors=[];p.on('pageerror',e=>errors.push(e.message));p.on('dialog',d=>d.accept());
 const api=(path,body)=>p.evaluate(async({path,body})=>{const r=await fetch(path,{method:body?'POST':'GET',headers:{'Content-Type':'application/json','X-Tabal-Token':window.TABAL_SERVER.csrf},...(body?{body:JSON.stringify(body)}:{})});return {status:r.status,data:await r.json()};},{path,body});
 const results=[];const test=async(name,fn)=>{try{await fn();results.push(name);console.log('PASS '+name);}catch(e){await p.screenshot({path:path.join(root,'test-results/api-e2e-failure.png'),fullPage:true});console.log('FAIL '+name+': '+e.message);process.exitCode=1;throw e;}};
 try{
  await p.goto(base);await p.locator('[data-page=leads]').waitFor({timeout:15000});await p.waitForFunction(()=>document.querySelector('#save-status').textContent.includes('wersja'));
  await test('A1 API mode is configured from .env; the key is not visible in the page',async()=>{
   await p.locator('[data-page=discover]').click();await p.locator('#ai-panel').waitFor({timeout:15000});
   await p.waitForFunction(()=>/Model: /.test(document.querySelector('#ai-panel')?.innerText||''),null,{timeout:20000});
   const txt=await p.locator('#ai-panel').innerText();assert.match(txt,/e2e-model/);assert.match(txt,/…ghij/);assert.doesNotMatch(await p.content(),/sk-e2e-0123456789abcdefghij/);
  });
  await test('A2 campaign → "Uruchom przez API" → automatic import of leads without copy/paste',async()=>{
   await p.locator('#research-form button[type=submit]').click();await p.locator('#work-preview').waitFor();
   workspace=(await api('/api/workspace')).data;const before=workspace.state.leads.length;
   await p.locator('[data-action=ai-run-current]').click();
   await p.waitForFunction(()=>/W kolejce|W toku|Gotowe/.test(document.querySelector('#ai-panel')?.innerText||''),null,{timeout:20000});
   await p.waitForFunction(n=>fetch('/api/workspace').then(r=>r.json()).then(x=>x.state.leads.length>=n+3),before,{timeout:90000,polling:1500});
   const ws=(await api('/api/workspace')).data;const added=ws.state.leads.filter(l=>/^Firma API/.test(l.company));assert.equal(added.length,3);
   const run=ws.state.runs.at(-1);assert.ok(run.batches.some(b=>b.status==='imported'),'partia oznaczona jako zaimportowana');assert.ok(run.imports.at(-1).file_name.startsWith('API:'));
   assert.ok(seen.inputs[0].startsWith('TRYB API'),'zadanie z notą trybu API');assert.equal(seen.posts[0].model,'e2e-model');
   const job=(await api('/api/ai-status',{})).data.jobs[0];assert.equal(job.status,'done');assert.equal(job.imported,1);assert.equal(job.searches,1);
  });
  await test('A3 stale websites (2021) do not archive the imported firms; verdict box after import',async()=>{
   const ws=(await api('/api/workspace')).data;const added=ws.state.leads.filter(l=>/^Firma API/.test(l.company));
   assert.ok(added.every(l=>l.status!=='ARCHIVED'),'stara strona nie odkłada do archiwum: '+added.map(l=>l.status).join(','));
   await p.locator('[data-page=discover]').click();const v=await p.locator('.research-progress').innerText();assert.match(v,/Obszar wyczerpany|Wynik niepełny|Cel kampanii osiągnięty/);
  });
  await test('A4 client list / archive of sent: paste → counts; listed firm blocked',async()=>{
   await p.locator('[data-page=settings]').click();await p.locator('[data-tab=backup]').click();await p.locator('#blocklist-text').waitFor();
   await p.locator('#blocklist-text').fill('biuro@firma-api-1.example\nwww.stary-klient.pl\nNIP 712-010-11-21\nStały Klient Sp. z o.o.');
   await p.locator('[data-action=blocklist-add]').click();await p.waitForFunction(()=>/Dodano do listy wykluczeń/.test(document.querySelector('#toast')?.textContent||''));
   const c=(await api('/api/workspace')).data.state.config;
   await p.waitForFunction(()=>fetch('/api/workspace').then(r=>r.json()).then(x=>x.state.config.excluded_emails?.includes('biuro@firma-api-1.example')),null,{timeout:15000});
   const c2=(await api('/api/workspace')).data.state.config;assert.ok(c2.excluded_domains.includes('stary-klient.pl'));assert.deepEqual(c2.excluded_nips,['7120101121']);assert.equal(c2.excluded_names.length,1);
   assert.match(await p.locator('body').innerText(),/Firm w bazie objętych listą: 1/);
  });
  await test('A5 strategy: second product (aluminium + panels) persists',async()=>{
   await p.locator('[data-page=strategies]').click();await p.locator('[data-action=strategy-add]').first().click();await p.locator('#strategy-form').waitFor();
   await p.locator('#strategy-form [name=name]').fill('Alu + panele 3.11');await p.locator('#strategy-form [name=product_id]').selectOption('alu');await p.locator('#strategy-form [name=product2_id]').selectOption('panel');
   await p.locator('#strategy-form button[type=submit]').click();
   await p.waitForFunction(()=>fetch('/api/workspace').then(r=>r.json()).then(x=>x.state.strategies.some(s=>s.name==='Alu + panele 3.11'&&s.product2_id==='panel')),null,{timeout:15000});
  });
  assert.deepEqual(errors,[],'błędy JavaScript: '+errors.join(' | '));
 }finally{await browser.close();fake.close();}
 console.log(`API E2E: ${results.length} PASS`);
})().catch(e=>{console.error(e);process.exitCode=1;fake.close();});
