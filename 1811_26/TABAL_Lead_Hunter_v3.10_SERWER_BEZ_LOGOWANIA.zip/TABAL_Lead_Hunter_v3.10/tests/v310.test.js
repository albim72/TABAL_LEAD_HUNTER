// TABAL Lead Hunter 3.10 — raporty J. Moraczewskiego z 12–13.11.2026 i uwagi P. Frankiewicza (grupa „AI dla TABAL”):
// maile ze stron firm bez ręcznego uzupełniania, leady z portali bez kontaktu, rozmiar zadania (czat się zacinał),
// wykluczenia produktu, status SKONTAKTOWANY bez adresu.
const test=require('node:test'),a=require('node:assert/strict'),C=require('../src/core.js');
const T=C.today();
function base(){const s=C.makeState('pilot');s.config.signature='Zespół TABAL\nbok@tabal.pl';return s;}
function strat(s,id='alu',extra={}){const st=C.strategy({...s.strategies[0],product_id:id,...extra});s.strategies=[st];return st;}
const src=d=>[{url:'https://'+d+'/',title:'Strona',quote:'Firma '+d,checked_at:T,verified:true}];
function lead(s,st,x={}){return C.validateLead({company:'Ogrodzenia Nowak',domain:'ogrodzenia-nowak.pl',city:'Wrocław',postal_code:'50-001',address:'ul. Długa 1, 50-001 Wrocław',sources:src('ogrodzenia-nowak.pl'),contacts:[],criteria:{},...x},s,st);}

// ---------- e-maile ze strony firmy ----------
test('E-MAIL 3.10: adres ze strony firmy (własna domena) trafia na kartę jako potwierdzony i pozwala wysłać wiadomość',()=>{
 const s=base(),st=strat(s),l=lead(s,st);s.leads=[l];
 a.equal(C.emailScanNeeded(l,s.config),true);
 const items=C.emailScanItems(s,[l.id]);a.deepEqual(items,[{lead_id:l.id,domain:'ogrodzenia-nowak.pl',pages:[]}]);
 const r=C.applyFoundContacts(l,{lead_id:l.id,emails:[{email:'biuro@ogrodzenia-nowak.pl',url:'https://ogrodzenia-nowak.pl/kontakt',how:'ochrona Cloudflare (odkodowano)',domain_match:'own'}],phones:['+48 601 222 333'],checked:['https://ogrodzenia-nowak.pl/','https://ogrodzenia-nowak.pl/kontakt']},s.config);
 a.deepEqual({added:r.added,confirmed:r.confirmed,phone:r.phone},{added:1,confirmed:0,phone:true});
 a.equal(l.contacts.length,1,'e-mail i telefon w jednym kontakcie');const p=l.contacts[0];
 a.equal(p.email,'biuro@ogrodzenia-nowak.pl');a.equal(p.phone,'+48 601 222 333');a.equal(p.source_type,'website');
 const q=C.contactQuality(p,s.config);a.ok(q.email&&q.phone&&q.usable,'kontakt potwierdzony: '+q.issue);
 a.equal(C.emailScanNeeded(l,s.config),false,'drugi raz nie sprawdzamy');
 a.match(l.history.at(-1).note,/nowe adresy: biuro@ogrodzenia-nowak\.pl/);a.equal(l.email_scan.pages,2);
 // the found address is enough for the send wizard
 const sent=C.statusChange(l,'TO_CONTACT','test',T,'e-mail');s.leads=[sent];const m=C.mailCandidate(sent,s.config,'pilot',s.products);
 a.equal(m.recipient?.p.email,'biuro@ogrodzenia-nowak.pl');a.ok(!m.reasons.some(x=>/e-maila/.test(x)),m.reasons.join(' | '));
});
test('E-MAIL 3.10: adres z obcej domeny (np. firma od strony WWW) jest do weryfikacji; gmail montażysty — potwierdzony',()=>{
 const s=base(),st=strat(s),l=lead(s,st);
 C.applyFoundContacts(l,{lead_id:l.id,emails:[{email:'kontakt@agencja-www.pl',url:'https://ogrodzenia-nowak.pl/',how:'tekst strony',domain_match:'other'},{email:'nowak.ogrodzenia@gmail.com',url:'https://ogrodzenia-nowak.pl/kontakt',how:'link mailto',domain_match:'free'}],phones:[],checked:['https://ogrodzenia-nowak.pl/']},s.config);
 const by=e=>l.contacts.find(p=>p.email===e);
 a.equal(by('kontakt@agencja-www.pl').uncertain,true);a.equal(C.contactQuality(by('kontakt@agencja-www.pl'),s.config).usable,false);
 a.equal(C.contactQuality(by('nowak.ogrodzenia@gmail.com'),s.config).usable,true);
});
test('E-MAIL 3.10: niepewny adres z katalogu, znaleziony na stronie firmy, zostaje potwierdzony (bez duplikatu)',()=>{
 const s=base(),st=strat(s),l=lead(s,st,{contacts:[{type:'general',email:'biuro@ogrodzenia-nowak.pl',phone:'601222333',url:'https://www.panoramafirm.pl/x',quote:'biuro@ogrodzenia-nowak.pl 601222333',checked_at:T,verified:false,uncertain:true,source_type:'catalog'}]});
 a.equal(C.emailScanNeeded(l,s.config),true);
 const r=C.applyFoundContacts(l,{lead_id:l.id,emails:[{email:'Biuro@ogrodzenia-nowak.pl',url:'https://ogrodzenia-nowak.pl/kontakt',how:'link mailto',domain_match:'own'}],phones:[],checked:['https://ogrodzenia-nowak.pl/kontakt']},s.config);
 a.equal(r.confirmed,1);a.equal(r.added,0);a.equal(l.contacts.length,1);a.equal(C.contactQuality(l.contacts[0],s.config).email,true);a.equal(l.contacts[0].url,'https://ogrodzenia-nowak.pl/kontakt');
});
test('E-MAIL 3.10: portale, brak domeny, archiwum i firmy z potwierdzonym e-mailem nie są sprawdzane',()=>{
 const s=base(),st=strat(s);
 const portal=lead(s,st,{company:'Firma z Oferteo',domain:'oferteo.pl',sources:src('oferteo.pl')}),none=lead(s,st,{company:'Bez strony',domain:'',identity_url:'https://www.google.com/maps/place/x',sources:[{url:'https://www.google.com/maps/place/x',title:'Mapy',quote:'Bez strony',checked_at:T,verified:true}]});
 const ok=lead(s,st,{company:'Ma e-mail',domain:'ma-email.pl',sources:src('ma-email.pl'),contacts:[{type:'general',email:'biuro@ma-email.pl',url:'https://ma-email.pl/kontakt',quote:'biuro@ma-email.pl',checked_at:T,verified:true}]});
 const arch={...lead(s,st,{company:'Archiwum',domain:'archiwum.pl',sources:src('archiwum.pl')}),status:'ARCHIVED'};
 s.leads=[portal,none,ok,arch];
 a.equal(C.isPortalDomain('www.oferteo.pl'),true);a.equal(C.isPortalDomain('m.facebook.com'),true);a.equal(C.isPortalDomain('ogrodzenia-nowak.pl'),false);
 a.deepEqual(C.emailScanItems(s,s.leads.map(l=>l.id)),[]);
 a.equal(C.applyFoundContacts(portal,{lead_id:'inny'},s.config),null,'wynik innej firmy jest ignorowany');
});
test('E-MAIL 3.10: brak adresu na stronie — karta zostaje bez zmian, z zapisem sprawdzenia',()=>{
 const s=base(),st=strat(s),l=lead(s,st);const before=JSON.stringify(l.contacts);
 const r=C.applyFoundContacts(l,{lead_id:l.id,emails:[],phones:[],checked:[],error:'strona firmy nie odpowiada'},s.config);
 a.equal(r.added+r.confirmed,0);a.equal(JSON.stringify(l.contacts),before);a.equal(l.email_scan.error,'strona firmy nie odpowiada');a.match(l.history.at(-1).note,/nie znaleziono/);
 // the scan record survives a backup / restore (server validation)
 s.leads=[l];const back=C.restore(C.backup(s),'pilot');a.equal(back.leads[0].email_scan.error,'strona firmy nie odpowiada');
});
test('E-MAIL 3.10: automatyczne sprawdzanie po imporcie jest domyślnie włączone i można je wyłączyć',()=>{
 a.equal(C.settings({}).auto_email_scan,true);a.equal(C.settings({auto_email_scan:false}).auto_email_scan,false);
 const s=base();s.config.auto_email_scan=false;a.equal(C.restore(C.backup(s),'pilot').config.auto_email_scan,false);
});

// ---------- zadanie Work ----------
test('ZADANIE 3.10: lista znanych firm tylko z obszaru kampanii — plik zadania nie rośnie z całą bazą',()=>{
 const s=base(),st=strat(s,'alu',{country:'Polska',province:'dolnośląskie',region:'dolnośląskie'});
 const cities=[['Wrocław','50-001'],['Katowice','40-001'],['Lublin','20-001'],['Poznań','60-001']];
 for(let i=0;i<400;i++){const [city,pc]=cities[i%4];s.leads.push(lead(s,st,{company:'Firma '+i,domain:'firma'+i+'.pl',sources:src('firma'+i+'.pl'),city,postal_code:pc,address:'ul. Testowa '+i+', '+pc+' '+city}));}
 s.leads.push(lead(s,st,{company:'Bez adresu',domain:'bez-adresu.pl',sources:src('bez-adresu.pl'),city:'',postal_code:'',address:''}));
 const run=C.createResearchRun(st);s.runs.push(run);const t=C.task(s,st,run.id);
 const m=t.match(/ZNANE FIRMY Z TEGO OBSZARU.*?NIE LICZ ICH JAKO NOWE \((\d+); pominięto (\d+) znanych firm spoza obszaru/);a.ok(m,'nagłówek listy znanych firm');
 a.equal(Number(m[1]),101,'100 firm z Wrocławia + 1 bez adresu');a.equal(Number(m[2]),300);
 a.match(t,/Firma 0 \| firma0\.pl/);a.doesNotMatch(t,/Firma 1 \| firma1\.pl/);a.match(t,/Bez adresu/);
 // without an area (whole country) all known companies are listed, as before
 const st2=strat(s,'alu',{country:'Polska',province:'',region:'Polska'});const t2=C.task(s,st2,C.createResearchRun(st2).id);a.match(t2,/NIE LICZ ICH JAKO NOWE \(401\)/);
});
test('ZADANIE 3.10: tryb szybki — portal to tylko trop, firma bez żadnego kontaktu nie jest leadem, ukryty e-mail czyta aplikacja',()=>{
 const s=base(),st=strat(s);const t=C.task(s,st,'r');
 a.match(t,/TABAL LEAD HUNTER v3\.10/);a.match(t,/TRYB SZYBKI/);
 a.match(t,/PORTALE I KATALOGI \(Oferteo/);a.match(t,/JEDNO wyszukiwanie: nazwa firmy \+ miejscowość/);a.match(t,/Firmy montażowe często nie mają strony — wizytówka z telefonem wystarczy/);
 a.match(t,/nie ma ŻADNEGO kanału kontaktu \(ani e-maila, ani telefonu\), NIE dodawaj/);a.match(t,/E-MAIL UKRYTY/);a.match(t,/\[email protected\]/);
 a.match(t,/Do celu liczą się tylko firmy z co najmniej jednym kanałem kontaktu/);
 s.config.search_depth='full';const full=C.task(s,st,'r');a.doesNotMatch(full,/TRYB SZYBKI/);a.match(full,/E-mail bywa ukryty/);
});

// ---------- wykluczenia ----------
test('WYKLUCZENIA 3.10: podpowiedź dla każdego produktu TABAL (producent tego samego produktu = konkurencja)',()=>{
 const s=base();for(const p of s.products)a.ok(C.productExclusion(p.id),p.id);
 a.match(C.productExclusion('alu'),/Własna produkcja ogrodzeń aluminiowych/);a.equal(C.productExclusion('nieznany'),'');
});

// ---------- status bez adresu ----------
test('STATUS 3.10: SKONTAKTOWANY kanałem e-mail wymaga adresu; telefon dozwolony; filtr wykrywa takie firmy',()=>{
 const s=base(),st=strat(s),l=lead(s,st,{contacts:[{type:'general',phone:'601222333',url:'https://ogrodzenia-nowak.pl/kontakt',quote:'tel. 601222333',checked_at:T,verified:true}]});
 a.throws(()=>C.statusChange(l,'CONTACTED','Wysłano ofertę',T,'e-mail'),/nie ma adresu e-mail/);
 const ph=C.statusChange(l,'CONTACTED','Rozmowa telefoniczna',T,'telefon');a.equal(ph.status,'CONTACTED');a.equal(C.contactedNoMail(ph),true);
 const withMail=lead(s,st,{contacts:[{type:'general',email:'biuro@ogrodzenia-nowak.pl',url:'https://ogrodzenia-nowak.pl/kontakt',quote:'biuro@ogrodzenia-nowak.pl',checked_at:T,verified:true}]});
 const em=C.statusChange(withMail,'CONTACTED','Wysłano z Outlooka',T,'e-mail');a.equal(em.status,'CONTACTED');a.equal(C.contactedNoMail(em),false);
 a.equal(C.contactedNoMail(l),false,'NOWY nie jest „skontaktowany bez e-maila”');
});
