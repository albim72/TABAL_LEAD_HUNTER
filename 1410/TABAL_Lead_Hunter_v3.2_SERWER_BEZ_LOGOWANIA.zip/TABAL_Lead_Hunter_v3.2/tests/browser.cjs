const {chromium}=require('playwright'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),C=require('../src/core.js');
const root=path.resolve(__dirname,'..'),results=[],errors=[],base=process.env.TEST_URL||'http://127.0.0.1:8765';
(async()=>{const browser=await chromium.launch({headless:true,...(process.env.CHROMIUM_PATH?{executablePath:process.env.CHROMIUM_PATH}:{}),args:process.env.CHROMIUM_PATH?['--no-sandbox','--disable-dev-shm-usage','--disable-gpu']:[]});
const ctx=await browser.newContext({viewport:{width:1440,height:1000},acceptDownloads:true}),p=await ctx.newPage();p.on('pageerror',e=>errors.push(e.message));p.on('dialog',d=>d.accept());
async function test(name,fn){try{await fn();results.push({name,status:'PASS'});console.log('PASS '+name);}catch(e){results.push({name,status:'FAIL',error:e.message});await p.screenshot({path:path.join(root,'test-results/browser-failure.png'),fullPage:true});throw e;}}
async function nav(v){await p.locator('[data-page='+v+']').click();}
async function saved(){await p.waitForFunction(()=>document.querySelector('#save-status').textContent.startsWith('Zapisano na serwerze'));}
async function api(page,path,body){return page.evaluate(async({path,body})=>{const r=await fetch(path,{method:body?'POST':'GET',headers:{'Content-Type':'application/json','X-Tabal-Token':window.TABAL_SERVER.csrf},...(body?{body:JSON.stringify(body)}:{})});return {status:r.status,data:await r.json()};},{path,body});}
async function login(page){await page.goto(base);try{await page.locator('[data-page=leads]').waitFor({timeout:10000});}catch(e){console.log('BOOT DEBUG',page.url(),await page.locator('body').innerText());throw e;}await page.waitForFunction(()=>document.querySelector('#save-status').textContent.includes('wersja'));}
try{
await test('01 no-login boot, clean server workspace, no client runtime errors',async()=>{await login(p);assert.equal((await api(p,'/api/workspace')).status,200);assert.equal(errors.length,0);});
await test('02 optional strategy and Polish province selection',async()=>{await nav('strategies');await p.locator('[data-action=strategy-add]').click();await p.locator('#strategy-form [name=name]').fill('Lubelskie TEST');await p.locator('#strategy-form [name=country_select]').selectOption('');assert.ok(await p.locator('#strategy-form [name=province]').isDisabled());await p.locator('#strategy-form [name=country_select]').selectOption('Polska');await p.locator('#strategy-form [name=province]').selectOption('lubelskie');await p.locator('[name=benchmark]').fill('Stalplast\nParkan');await p.locator('#strategy-form button[type=submit]').click();await saved();const st=(await api(p,'/api/workspace')).data.state.strategies.find(s=>s.name==='Lubelskie TEST');assert.equal(st.region,'lubelskie, Polska');assert.equal(st.product_id,'');assert.equal(st.segment,'');assert.equal(st.client,'');});
await test('03 message style, offer and multiline signature persist',async()=>{await nav('settings');await p.locator('[data-tab=messages]').click();await p.locator('[name=message_style]').selectOption('technical');await p.locator('[name=offer]').fill('TEST: oferta zatwierdzona przez TABAL.');await p.locator('#messages-form [name=sender]').fill('Jan Testowy\nDział handlowy\ntest@example.com');await p.locator('#messages-form button').click();await saved();await p.reload();await p.locator('[data-page=settings]').click();await p.locator('[data-tab=messages]').click();assert.equal(await p.locator('[name=sender]').inputValue(),'Jan Testowy\nDział handlowy\ntest@example.com');});
await test('04 criterion labels, required flags and weights',async()=>{await p.locator('[data-tab=scoring]').click();await p.locator('[name=label_extra]').fill('Potwierdzony montaż');await p.locator('[name=required_region]').uncheck();await p.locator('[name=w_region]').fill('0');await p.locator('#config-form button[type=submit]').click();await saved();const c=(await api(p,'/api/workspace')).data.state.config;assert.equal(c.required.region,false);assert.equal(c.weights.region,0);assert.equal(c.criteria_names.extra,'Potwierdzony montaż');});
await test('05 Work task includes coverage, offer and no forced duplicate omission',async()=>{await nav('discover');const s=(await api(p,'/api/workspace')).data.state;await p.locator('#research-strategy').selectOption(s.strategies.find(s=>s.name==='Lubelskie TEST').id);await p.locator('#research-form button[type=submit]').click();await saved();const task=await p.locator('#work-preview').innerText();for(const x of ['Stalplast','Parkan','TEST: oferta','MOŻESZ ZWRÓCIĆ PONOWNIE'])assert.ok(task.includes(x));assert.ok((await p.locator('#view').innerText()).includes('Brak w wynikach'));});
let leadRaw,st;
await test('06 real file import preview and commit',async()=>{const s=(await api(p,'/api/workspace')).data.state;st=s.strategies.find(s=>s.name==='Lubelskie TEST');leadRaw=C.sample(st,s,false);leadRaw.company='Stalplast TEST';leadRaw.domain='stalplast-test.example';leadRaw.contacts[0].phone='+48 123 456 789';leadRaw.contacts[0].quote+=' +48 123 456 789';leadRaw.draft={subject:'Współpraca TEST',body:'Test lokalny, bez wysyłki.'};await p.locator('#import-file').setInputFiles({name:'wynik.json',mimeType:'application/json',buffer:Buffer.from(JSON.stringify({schema_version:2,strategy_id:st.id,leads:[leadRaw]}))});await p.locator('[data-action=import-confirm]').waitFor();assert.equal((await api(p,'/api/workspace')).data.state.leads.length,0);await p.locator('[data-action=import-confirm]').click();await saved();assert.equal((await api(p,'/api/workspace')).data.state.leads.length,1);});
await test('07 contacts visible directly in lead table',async()=>{await nav('leads');const row=await p.locator('.lead-row').innerText();for(const x of ['Anna Przykładowa','anna@example.com','+48 123 456 789'])assert.ok(row.includes(x));await p.screenshot({path:path.join(root,'test-results/leads-desktop.png'),fullPage:true});});
await test('08 rediscovery preserved and filter includes both strategies',async()=>{await nav('discover');const s=(await api(p,'/api/workspace')).data.state;const second=s.strategies[1];await p.locator('#import-file').setInputFiles({name:'ponownie.json',mimeType:'application/json',buffer:Buffer.from(JSON.stringify({schema_version:2,strategy_id:second.id,leads:[{...leadRaw,context:'Drugi kontekst / nowa strategia'}]}))});await p.locator('[data-action=import-confirm]').click();await saved();await nav('leads');await p.locator('#strategy-filter').selectOption(second.id);assert.equal(await p.locator('.lead-row').count(),1);await p.locator('#strategy-filter').selectOption(st.id);assert.equal(await p.locator('.lead-row').count(),1);await p.locator('.company-btn').click();assert.ok((await p.locator('#detail').innerText()).includes('Firma występowała już wcześniej'));await p.locator('#detail details.source-card summary').last().click();assert.ok((await p.locator('#detail').innerText()).includes('Drugi kontekst'));await p.locator('[data-action=close]').click();});
await test('09 per-lead scoring reasons and local draft offer',async()=>{await p.locator('.company-btn').click();assert.ok((await p.locator('#detail').innerText()).includes('Kryterium nieaktywne'));await p.locator('[data-action=draft-refresh]').click();assert.ok((await p.locator('#draft-form [name=body]').inputValue()).includes('TEST: oferta'));await p.locator('#draft-form button[type=submit]').click();await saved();await p.locator('[data-action=close]').click();});
await test('10 backup exports full state without auth secrets',async()=>{const promise=p.waitForEvent('download');await p.locator('[data-action=backup]').click();const d=await promise;const file=await d.path();const raw=fs.readFileSync(file,'utf8'),x=JSON.parse(raw);assert.equal(x.state.leads[0].sightings.length,1);assert.ok(!raw.includes('tabal_session'));assert.ok(!raw.includes('Browser-test-123456'));});
await test('11 desktop navigation, report and SMTP admin panel',async()=>{for(const v of ['projects','strategies','report','settings','help','mail']){await nav(v);assert.ok((await p.locator('#view').innerText()).length>30);}assert.equal(await p.locator('#smtp-form').count(),1);assert.equal(errors.length,0);});
await test('12 separate browser sees shared data and has admin SMTP access',async()=>{const c=await browser.newContext();const q=await c.newPage();await login(q);assert.equal(await q.locator('.lead-row').count(),1);await q.locator('[data-page=mail]').click();assert.ok(!(await q.locator('#smtp-form button').isDisabled()));await c.close();});
await test('13 concurrent stale browser cannot overwrite newer server data',async()=>{await nav('settings');await p.locator('[data-tab=messages]').click();const c=await browser.newContext(),q=await c.newPage();await login(q);await q.locator('[data-page=settings]').click();await q.locator('[data-tab=messages]').click();await p.locator('[name=offer]').fill('NOWSZA ZMIANA');await p.locator('#messages-form button').click();await saved();await q.locator('[name=offer]').fill('STARA KARTA');await q.locator('#messages-form button').click();await q.locator('#storage-warning:not([hidden])').waitFor();assert.ok((await q.locator('#storage-warning').innerText()).includes('Inny użytkownik'));assert.equal((await api(p,'/api/workspace')).data.state.config.offer,'NOWSZA ZMIANA');await c.close();});
await test('14 malicious imported strings render as text',async()=>{await nav('discover');await p.locator('#import-file').setInputFiles({name:'xss.json',mimeType:'application/json',buffer:Buffer.from(JSON.stringify({schema_version:2,strategy_id:st.id,leads:[{...leadRaw,company:'<img src=x onerror="window.XSS=1">',domain:'xss-test.example'}]}))});await p.locator('[data-action=import-confirm]').click();await saved();await nav('leads');assert.equal(await p.evaluate(()=>window.XSS),undefined);assert.equal(await p.locator('#view img').count(),0);});
await test('15 mobile navigation without page overflow',async()=>{await p.setViewportSize({width:390,height:844});for(const v of ['leads','strategies','settings']){await nav(v);assert.ok(await p.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));}await nav('leads');await p.screenshot({path:path.join(root,'test-results/leads-mobile.png'),fullPage:true});});
await test('16 DEMO isolated, switch back reloads server',async()=>{await p.locator('#mode').selectOption('demo');await p.locator('.lead-row').first().waitFor();assert.equal(await p.locator('.lead-row').count(),6);await p.locator('#mode').selectOption('pilot');await p.waitForFunction(()=>document.querySelectorAll('.lead-row').length===2);assert.equal((await api(p,'/api/workspace')).data.state.leads.length,2);});
let campaign,firstQueries,batchFixture;
await test('17 campaign target 100 and batch size survive reload',async()=>{
 await nav('discover');await p.locator('#research-strategy').selectOption(st.id);
 await p.locator('#no-limit').uncheck();await p.locator('#research-form [name=limit]').fill('100');await p.locator('#batch-mode').selectOption('batches');await p.locator('#research-form [name=batch_size]').fill('20');
 await p.locator('#research-form button[type=submit]').click();await saved();
 let s=(await api(p,'/api/workspace')).data.state;campaign=s.runs.at(-1);firstQueries=campaign.batches[0].queries;
 assert.equal(campaign.target,100);assert.equal(campaign.batches[0].size,20);
 await p.reload();await nav('discover');await p.locator('#research-strategy').selectOption(st.id);
 assert.equal(await p.locator('#research-form [name=limit]').inputValue(),'100');
 batchFixture=Array.from({length:8},(_,i)=>({...C.sample(st,s,false),company:'Kandydat TEST '+i,domain:'candidate-'+i+'.example',contacts:[],criteria:{}}));
});
await test('18 real import of 8 candidates keeps campaign open at 8/100',async()=>{
 await p.locator('#import-file').setInputFiles({name:'partia-1.json',mimeType:'application/json',buffer:Buffer.from(JSON.stringify({schema_version:2,strategy_id:st.id,run_id:campaign.id,batch_id:campaign.batches[0].id,research_report:{stop_reason:'budget',queries:[{query:'test Lublin',area:'Lublin'}]},leads:batchFixture}))});
 await p.locator('[data-action=import-confirm]').click();await saved();
 const s=(await api(p,'/api/workspace')).data.state;campaign=s.runs.find(r=>r.id===campaign.id);
 assert.equal(campaign.status,'needs_more');assert.equal(campaign.added,8);assert.equal(s.leads.length,10);
 assert.ok((await p.locator('.research-progress').innerText()).includes('8 z 100'));
 assert.ok((await p.locator('.research-progress').innerText()).includes('brakuje 92'));
 assert.ok((await p.locator('.research-progress').innerText()).includes('Limit czasu'));
 await p.setViewportSize({width:1440,height:1050});await p.screenshot({path:path.join(root,'test-results/discovery-v32-desktop.png'),fullPage:true});
});
await test('19 continuation changes searches and preserves 92 remaining after server reload',async()=>{
 await p.locator('.research-progress [data-continue-run]').click();await saved();
 const text=await p.locator('#work-preview').innerText();assert.ok(text.includes('BRAKUJE: 92'));
 campaign=(await api(p,'/api/workspace')).data.state.runs.find(r=>r.id===campaign.id);
 assert.equal(campaign.batches.length,2);assert.ok(campaign.batches[1].queries.every(q=>!firstQueries.some(old=>old.query===q.query)));
 await p.reload();await nav('discover');await p.locator('#research-strategy').selectOption(st.id);
 await p.locator('.research-progress [data-continue-run]').click();await saved();
 assert.equal((await api(p,'/api/workspace')).data.state.runs.find(r=>r.id===campaign.id).batches.length,2);
});
await test('20 invalid batch is rejected and empty unavailable-search report preserves goal',async()=>{
 await p.locator('#import-file').setInputFiles({name:'wrong.json',mimeType:'application/json',buffer:Buffer.from(JSON.stringify({schema_version:2,strategy_id:st.id,run_id:campaign.id,batch_id:'wrong-batch',leads:batchFixture}))});
 await p.locator('#import-result .import-error').waitFor();assert.ok((await p.locator('#import-result').innerText()).includes('Nieznana partia'));
 assert.equal((await api(p,'/api/workspace')).data.state.leads.length,10);
 await p.locator('#import-file').setInputFiles({name:'no-access.json',mimeType:'application/json',buffer:Buffer.from(JSON.stringify({schema_version:2,strategy_id:st.id,run_id:campaign.id,batch_id:campaign.batches[1].id,research_report:{stop_reason:'no_access',limitations:'Brak wyszukiwania w tej sesji'},leads:[]}))});
 await p.locator('[data-action=import-confirm]').click();await saved();
 assert.ok((await p.locator('.research-progress').innerText()).includes('brakuje 92'));
 assert.ok((await p.locator('.research-progress').innerText()).includes('Brak wyszukiwania w tej sesji'));
 await p.setViewportSize({width:390,height:844});assert.ok(await p.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));
 await p.screenshot({path:path.join(root,'test-results/discovery-v32-mobile.png'),fullPage:true});
});
await test('21 enrichment prepares a separate targeted run without resetting discovery',async()=>{
 await p.locator('.research-progress [data-enrich-run]').click();await saved();
 const s=(await api(p,'/api/workspace')).data.state,enrich=s.runs.at(-1);
 assert.equal(enrich.parent_id,campaign.id);assert.equal(enrich.profile.mode,'targeted');assert.equal(enrich.target,8);
 assert.equal(s.runs.find(r=>r.id===campaign.id).added,8);
 assert.ok((await p.locator('#work-preview').innerText()).includes('KWALIFIKACJA I UZUPEŁNIANIE DANYCH'));
});

let projectId;
await test('23 V3.2 projects: campaign project listed, date filter, archive and reload from archive, project file',async()=>{
 await p.setViewportSize({width:1440,height:1000});await nav('projects');
 const s=(await api(p,'/api/workspace')).data.state;assert.ok(s.projects.length>=2);const proj=s.projects.find(x=>x.run_ids.includes(campaign.id));projectId=proj.id;assert.equal(proj.lead_ids.length,8);
 assert.ok((await p.locator('#proj-table').innerText()).includes(proj.name));
 await p.locator('#proj-filter [name=from]').fill('2099-01-01');await p.waitForFunction(()=>document.querySelector('#proj-table').innerText.includes('Brak projektów'));
 await p.locator('#proj-filter [name=from]').fill('');await p.locator(`[data-proj-op=archive][data-proj-id="${projectId}"]`).click();await saved();
 assert.equal(await p.locator(`#proj-table [data-proj-id="${projectId}"]`).count(),0);await p.locator('#proj-filter [name=archived]').check();
 await p.locator(`[data-proj-op=unarchive][data-proj-id="${projectId}"]`).click();await saved();assert.equal((await api(p,'/api/workspace')).data.state.projects.find(x=>x.id===projectId).archived,false);
 const dl=p.waitForEvent('download');await p.locator(`[data-proj-op=export][data-proj-id="${projectId}"]`).click();const file=JSON.parse(fs.readFileSync(await (await dl).path(),'utf8'));assert.equal(file.kind,'tabal-project');assert.equal(file.leads.length,8);
 await p.screenshot({path:path.join(root,'test-results/projects-v32-desktop.png'),fullPage:true});
 await p.locator(`[data-proj-op=open][data-proj-id="${projectId}"]`).click();await p.locator('.lead-row').first().waitFor();assert.equal(await p.locator('.lead-row').count(),8);
});
await test('24 V3.2 leads: 45 more firms, pagination 20/50, sorting, bulk archive and restore, status dots',async()=>{
 const s=(await api(p,'/api/workspace')).data.state;const more=Array.from({length:45},(_,i)=>({...C.sample(st,s,false),company:'Paginacja '+String(i).padStart(2,'0'),domain:'page-'+i+'.example'}));
 await nav('discover');await p.locator('#import-file').setInputFiles({name:'more.json',mimeType:'application/json',buffer:Buffer.from(JSON.stringify({schema_version:2,strategy_id:st.id,leads:more}))});await p.locator('[data-action=import-confirm]').click();await saved();
 await nav('leads');await p.locator('#project-filter').selectOption('');await p.locator('#page-size').selectOption('20');assert.equal(await p.locator('.lead-row').count(),20);assert.ok((await p.locator('#row-count').innerText()).includes('strona 1 z 3'));
 await p.locator('[data-action=page-next]').click();assert.ok((await p.locator('#row-count').innerText()).includes('strona 2 z 3'));
 await p.locator('#page-size').selectOption('50');assert.equal(await p.locator('.lead-row').count(),50);
 await p.locator('#sort').selectOption('name:1');const first=await p.locator('.lead-row .company-btn').first().innerText();await p.locator('#sort').selectOption('name:-1');assert.notEqual(await p.locator('.lead-row .company-btn').first().innerText(),first);
 assert.ok(await p.locator('.lead-row .dot-green').count()>0);assert.ok((await p.locator('.legend').first().innerText()).includes('W trakcie obsługi'));
 await p.locator('#search').fill('Paginacja 0');await p.waitForFunction(()=>document.querySelectorAll('.lead-row').length===10);
 await p.locator('#select-page').check();assert.ok(!(await p.locator('#bulk').isHidden()));await p.locator('[data-action=bulk-archive]').click();await saved();
 assert.equal(await p.locator('.lead-row').count(),0);let st2=(await api(p,'/api/workspace')).data.state;assert.equal(st2.leads.filter(l=>l.status==='ARCHIVED').length,10);
 await p.locator('#filter').selectOption('ARCHIVED');assert.equal(await p.locator('.lead-row').count(),10);assert.ok(await p.locator('.lead-row .dot-gray').count()===10);
 await p.locator('#select-page').check();await p.locator('[data-action=bulk-restore]').click();await saved();st2=(await api(p,'/api/workspace')).data.state;assert.equal(st2.leads.filter(l=>l.status==='ARCHIVED').length,0);
 await p.locator('#filter').selectOption('');await p.locator('#search').fill('');await p.locator('[data-action=bulk-clear]').click().catch(()=>{});
 await p.locator('#page-size').selectOption('20');await p.screenshot({path:path.join(root,'test-results/leads-v32-desktop.png'),fullPage:true});
});
await test('25 V3.2 lead card: company + person, unsure contact badge, score explanation, remove from project',async()=>{
 const s=(await api(p,'/api/workspace')).data.state;const r={...C.sample(st,s,false),company:'Niepewny Kontakt TEST',domain:'unsure.example',contacts:[{full_name:'Ewa Testowa',position:'Zakupy',mail:'ewa@unsure.example',uncertain:true,reason:'Adres z katalogu, brak na stronie firmy'}]};
 await nav('discover');await p.locator('#import-file').setInputFiles({name:'unsure.json',mimeType:'application/json',buffer:Buffer.from(JSON.stringify({schema_version:2,strategy_id:st.id,leads:[r]}))});await p.locator('[data-action=import-confirm]').click();await saved();
 await nav('leads');await p.locator('#search').fill('Niepewny');await p.locator('.lead-row').first().waitFor();const row=await p.locator('.lead-row').innerText();assert.ok(row.includes('Ewa Testowa')&&row.includes('ewa@unsure.example')&&row.includes('do weryfikacji'));
 await p.locator('[data-why]').first().click();const why=await p.locator('#detail').innerText();assert.ok(why.includes('5/10'));
 await p.locator('#detail [data-open]').click();const card=await p.locator('#detail').innerText();for(const x of ['Kontakt do właściwej osoby','Niepewny Kontakt TEST','Ewa Testowa','WYMAGA WERYFIKACJI','ewa@unsure.example','Typ klienta'])assert.ok(card.includes(x),x);
 await p.screenshot({path:path.join(root,'test-results/lead-card-v32.png'),fullPage:false});
 await p.locator('#detail [data-lead-unproject]').first().click();await saved();const l=(await api(p,'/api/workspace')).data.state;assert.ok(!l.projects.some(pr=>pr.lead_ids.includes(l.leads.find(x=>x.company==='Niepewny Kontakt TEST').id)));
 await p.locator('[data-action=close]').click();await p.locator('#search').fill('');
});
await test('26 V3.2 strategy: Słowacja blocks province, city + radius and extra-criteria flag persist',async()=>{
 await nav('strategies');await p.locator('[data-action=strategy-add]').click();await p.locator('#strategy-form [name=name]').fill('Słowacja TEST');
 await p.locator('#strategy-form [name=country_select]').selectOption('Słowacja');assert.ok(await p.locator('#strategy-form [name=province]').isDisabled());
 await p.locator('#strategy-form [name=extra]').fill('Montaż bram');await p.locator('#strategy-form button[type=submit]').click();await saved();
 let sk=(await api(p,'/api/workspace')).data.state.strategies.find(x=>x.name==='Słowacja TEST');assert.equal(sk.country,'Słowacja');assert.equal(sk.province,'');assert.equal(sk.use_extra,false);
 await p.locator(`[data-strategy="${sk.id}"]`).click();await p.locator('#strategy-form [name=country_select]').selectOption('Polska');await p.locator('#strategy-form [name=province]').selectOption('lubelskie');await p.locator('#strategy-form [name=city]').fill('Lublin');await p.locator('#strategy-form [name=radius_km]').fill('30');await p.locator('#strategy-form [name=use_extra]').check();await p.locator('#strategy-form button[type=submit]').click();await saved();
 sk=(await api(p,'/api/workspace')).data.state.strategies.find(x=>x.id===sk.id);assert.equal(sk.city,'Lublin');assert.equal(sk.radius_km,30);assert.equal(sk.use_extra,true);assert.equal(sk.region,'lubelskie, Polska');
});
await test('27 V3.2 unlimited lubelskie campaign into existing project: one task with full pool',async()=>{
 await nav('discover');await p.locator('#research-strategy').selectOption(st.id);await p.locator('#research-project').selectOption(projectId);await p.locator('#no-limit').check();await p.locator('#batch-mode').selectOption('full');
 await p.locator('#research-form button[type=submit]').click();await saved();const task=await p.locator('#work-preview').innerText();
 for(const x of ['BEZ LIMITU','PEŁNA PULA','Biała Podlaska','powiat biłgorajski','DANE ADRESOWE','AKTUALNOŚĆ'])assert.ok(task.includes(x),x);
 const s=(await api(p,'/api/workspace')).data.state,run=s.runs.at(-1);assert.equal(run.target,0);assert.equal(run.project_id,projectId);assert.equal(run.batches[0].size,0);
 assert.ok((await p.locator('.research-progress').innerText()).includes('bez limitu'));
});
await test('28 V3.2 SMTP form defaults to bok@tabal.pl and products filled from tabal.pl',async()=>{
 await nav('mail');assert.equal(await p.locator('#smtp-form [name=sender_email]').inputValue(),'bok@tabal.pl');assert.equal(await p.locator('#smtp-form [name=username]').inputValue(),'bok@tabal.pl');
 await nav('settings');await p.locator('[data-tab=products]').click();assert.ok((await p.locator('#settings-content').innerText()).includes('Techfence'));
 await p.locator('[data-tab=scoring]').click();await p.locator('[data-action=weights-equal]').click();assert.equal(await p.locator('[name=w_product]').inputValue(),'10');
});
await test('29 V3.2 mobile: leads and projects without page overflow',async()=>{await p.setViewportSize({width:390,height:844});for(const v of ['leads','projects','discover']){await nav(v);assert.ok(await p.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),v);}await nav('leads');await p.screenshot({path:path.join(root,'test-results/leads-v32-mobile.png'),fullPage:false});await p.setViewportSize({width:1440,height:1000});});

await test('22 no login or logout controls are exposed',async()=>{assert.equal(await p.locator('#logout').count(),0);assert.equal(await p.locator('input[name=username]').count(),0);const r=await ctx.request.get(base+'/api/workspace');assert.equal(r.status(),200);});
assert.equal(errors.length,0);
}finally{fs.writeFileSync(path.join(root,'test-results/browser-v32.json'),JSON.stringify({browser:browser.version(),at:new Date().toISOString(),results,errors},null,2));await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
