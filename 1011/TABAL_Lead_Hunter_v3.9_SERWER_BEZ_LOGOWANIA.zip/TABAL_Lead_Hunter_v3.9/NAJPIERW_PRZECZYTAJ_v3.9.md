# TABAL Lead Hunter 3.9: stałe profile, adres nadawcy z profilu, język korzyści, więcej firm z puli

Wydanie z 10 listopada 2026. Aktualizacja wersji 3.8 — wszystko z 3.8 działa bez zmian (obszar przy kampanii, DW, przypomnienia, wykrywanie odpowiedzi). Opis 3.8: `docs/NAJPIERW_PRZECZYTAJ_v3.8_HISTORYCZNY.md`.

Źródła uwag: e-maile „Lead Hunter – uwagi po ostatnim spotkaniu” (3.11) i „Profile w Lead Hunterze” (4–5.11) oraz grupa „AI dla TABAL” (4–7.11: J. Moraczewski, P. Frankiewicz).

## 1. Stałe profile na ekranie głównym — kto podpisuje leady

- Na ekranie **Leady** jest panel **„Kto podpisuje leady”**: siedem profili wbudowanych na stałe + „Sygnatura firmowa”. Kliknięcie osoby wybiera ją dla tej przeglądarki (to samo co „Podpisuję jako” u góry).
- Pod kaflami: **Ustawienia** wybranej osoby — nazwa w polu „Od:”, adres nadawcy, podgląd sygnatury, przycisk **„Ustawienia profilu”**.
- Profile wbudowane (dane z e-maili TABAL):

| Osoba | Stanowisko w sygnaturze | Adres nadawcy | Telefon |
|---|---|---|---|
| Paweł Szewczak | Doradca techniczno-handlowy \| TABAL ALUFENCE | pszewczak@tabal.pl | +48 665 010 292 |
| Jędrzej Moraczewski | Opiekun klienta \| TABAL | bok@tabal.pl | +48 665 010 292 |
| Michał Zieliński | Premium Resin | biuro@premiumresin.pl | 661 088 383 |
| Szymon Bochen | Konstruktor \| TABAL | sbochen@tabal.pl | +48 735 253 707 |
| Patrycja Cholewa | Dział ogrodzeń panelowych \| TABAL TECHFENCE | pcholewa@tabal.pl | 601 374 833 · 81 745 55 37 |
| Karol Latuszyński | Dział ogrodzeń panelowych \| TABAL TECHFENCE | klatuszynski@tabal.pl | 601 374 316 · 81 745 55 47 |
| Monika Milanowska-Kozłowska | Specjalista ds. marketingu \| TABAL | mmilanowska@tabal.pl | 538 189 743 |

- Profil stały można **edytować** (np. dodać logo: Ustawienia profilu → Kreator sygnatury → „Logo z pliku”), nie można go usunąć. „Przywróć dane TABAL” wraca do danych z tabeli.
- Jeśli w 3.7/3.8 ktoś założył już swój profil (to samo imię i nazwisko), **zostaje jego profil i jego sygnatura** — stały nie jest dublowany.

**Do potwierdzenia przez TABAL:** stanowiska P. Cholewy i K. Latuszyńskiego (w e-mailu podano tylko dział), stanowisko M. Zielińskiego (brak), adres w stopce (użyto ul. Energetyków 14; w stopce P. Frankiewicza jest ul. Smoluchowskiego 7), logo w sygnaturach (nie było pliku — do dodania w profilu).

## 2. Wybór adresu e-mail, z którego wychodzi wiadomość

- Profil ma przełącznik **„Wysyłaj z własnego adresu”** (profile stałe: włączony). Wiadomość podpisana przez taką osobę wychodzi **z jej skrzynki** — adres w „Od:”, kopia w jej „Wysłanych”, odpowiedzi czytane z jej „Odebranych”.
- Skrzynkę osoby podłącza się raz: **Wysyłka → 1b. Skrzynki osób → Podłącz** (login i hasło; serwer domyślnie taki jak skrzynki wspólnej; inny serwer — np. premiumresin.pl — wpisuje się w tym samym oknie). Potem „Test” wysyła wiadomość próbną na ten adres.
- **Jędrzej Moraczewski (bok@tabal.pl)** działa od razu — to adres skrzynki wspólnej.
- **Niepodłączona skrzynka = brak wysyłki**, nigdy cicha podmiana adresu: kreator pokazuje „skrzynka … niepodłączona”, panel na ekranie głównym — przycisk „Podłącz skrzynkę →”. Kto woli wysyłać ze skrzynki wspólnej z własnym nazwiskiem w „Od:”, wyłącza przełącznik w profilu.
- **Przypomnienie** wychodzi z tej samej skrzynki co pierwsza wiadomość (ten sam wątek).
- Hasło skrzynki osoby: w pamięci serwera albo — po zaznaczeniu — zapamiętane w pliku 0600 (jak skrzynka wspólna). Bez zapamiętania po restarcie serwera trzeba je wpisać ponownie.
- Limit dzienny i odstęp między wiadomościami są wspólne dla wszystkich skrzynek.

## 3. Wiadomości: język korzyści, argumenty według segmentu odbiorcy

Uwagi P. Frankiewicza (producent, kompletność oferty, szybki termin, mniej sztywno, segment odbiorcy, bez powtarzania pełnej nazwy) i wzór J. Moraczewskiego.

- **Nowy układ szkicu:** w czyim imieniu i w jakiej sprawie → dlaczego ta firma → argumenty → zaproszenie do rozmowy → „Z poważaniem”.
- **Argumenty zależą od typu odbiorcy** (z pola „typ klienta” z researchu, potem z głównej działalności): firma montażowa, dystrybutor / sklep, firma produkcyjna, projektant, wykonawca inwestycji. Firma pokrewna dostaje propozycję poszerzenia oferty bez własnej produkcji.
- **Producent i kompletność oferty:** nowe pole produktu **„Argumenty w wiadomości”** (Profil i źródła → Produkty → Edytuj) — wypełnione dla 7 grup TABAL, do poprawienia przez handlowca.
- **Termin realizacji:** jedno stałe zdanie (Wiadomości i podpis → „Termin realizacji”), domyślnie „Zapewniamy szybki termin realizacji zamówień.” Puste pole = bez zdania.
- **Nazwa firmy odbiorcy:** najwyżej raz, w krótkiej formie — także bez imienia i nazwiska właściciela („Ogrodzenia Fajsławice”, nie „Ogrodzenia Fajsławice Jakub Stefaniak”). Poza tym „Państwo”.
- **Linki:** gdy produkt ma kilka (oferta, galeria realizacji, katalog) — lista „Zachęcam do zapoznania się z naszą ofertą”. Dla ogrodzeń aluminiowych wpisano linki ze wzoru: /tabal-alufence/, /realizacje/, /do-pobrania/ — **proszę je sprawdzić** (Produkty → Ogrodzenia aluminiowe).
- Formy neutralne („chętnie przedstawię”, „proszę o przekazanie”) — wiadomość może podpisać każda osoba.
- **Szkice już zapisane** nie zmieniają się same. W kreatorze wysyłki jest opcja **„Odśwież szkice przygotowane automatycznie we wcześniejszych wersjach”** — szkice ręczne i szkice z Work zostają.
- Work (etap pełny) dostaje te same zasady pisania wiadomości.

## 4. Liczba leadów bliżej zadanej puli, mniejsze zużycie limitu ChatGPT

W Odkrywaniu są dwa nowe ustawienia (oba domyślnie włączone):

- **Tryb wyszukiwania: „Szybkie odkrywanie”.** Work potwierdza działalność, adres siedziby i kontakt ogólny — 2–3 strony na firmę. Nie sprawdza na tym etapie CEIDG/KRS, oddziałów, social mediów i nie robi pogłębionego szukania kontaktów. To uzupełnia się potem **tylko dla wybranych firm** („Uzupełnij kontakty w Work”). „Pełne badanie każdej firmy” = zadanie jak w 3.8.
- **„Dąż do pełnej puli”.** Zamiast „cel to górna granica, zwróć mniej” zadanie mówi: cel liczbowy jest zobowiązaniem, pracuj do celu albo do wykonania całego planu, firmy pokrewne (ta sama branża) liczą się do celu. Bez zmian: firm z inną główną działalnością, spoza obszaru i nieaktywnych Work nie dodaje.

**Uczciwie:** te zmiany dotyczą treści zadania. Nie zostały jeszcze uruchomione w ChatGPT Work, więc nie ma pomiaru, o ile wzrośnie liczba firm i spadnie zużycie limitu — to pierwszy punkt jutrzejszych testów (ta sama strategia i obszar: 3.8 vs 3.9, cel 100). Aplikacja nie zwiększy liczby firm, których w obszarze nie ma; próg 65/100 i sprawdzanie obszaru działają jak dotąd.

## Aktualizacja z 3.8
1. Poczekaj, aż kolejka wysyłki będzie pusta. Pobierz Kopię JSON, zatrzymaj serwer, zachowaj `.runtime` i `.env`.
2. Rozpakuj 3.9, przenieś `.runtime` i `.env`, uruchom serwer. W Dockerze: `docker compose up -d --build`, **bez** `down -v`.
3. `/healthz` ma zwracać `3.9.0`, a w menu ma być „WERSJA 3.9”. Na ekranie Leady pojawi się panel „Kto podpisuje leady”.
4. Wysyłka → 1b. Skrzynki osób: podłącz skrzynki osób, które mają wysyłać ze swojego adresu, i kliknij „Test”.

## Testy
- **Logika:** 173 testy (11 nowych) — wszystkie przechodzą.
- **Serwer, SMTP i IMAP:** 95 testów (10 nowych) — wszystkie przechodzą.
- **Przeglądarka:** 36 testów (3 nowe: panel profili, tryb wyszukiwania, argumenty produktu) — wszystkie przechodzą.
- **Pełny scenariusz wysyłki** (lokalny serwer SMTP z TLS): 9 kroków, w tym nowy — stały profil, zablokowana wysyłka bez skrzynki, podłączenie skrzynki, wiadomość z adresu profilu w nowym wzorze. Przykład: `test-results/e2e-mail-v39-przyklad.eml`.
- **Nie testowano:** rzeczywistych skrzynek TABAL / Premium Resin ani rzeczywistego researchu w ChatGPT Work.
