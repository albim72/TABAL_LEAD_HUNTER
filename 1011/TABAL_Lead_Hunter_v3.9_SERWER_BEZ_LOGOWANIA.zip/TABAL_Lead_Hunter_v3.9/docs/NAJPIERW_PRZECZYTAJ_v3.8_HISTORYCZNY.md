# TABAL Lead Hunter 3.8: obszar wyszukiwania przy kampanii

Wydanie z 2 listopada 2026. Aktualizacja wersji 3.7. Wszystko z 3.7 działa bez zmian: profile osób, DW, przypomnienia, wykrywanie odpowiedzi, logo w sygnaturze, krótka nazwa firmy. Opis tych funkcji jest w `docs/NAJPIERW_PRZECZYTAJ_v3.7_HISTORYCZNY.md` — punkt 1 tamtej notatki zastępuje ta wersja.

## Co się zmieniło

**Kraj, województwo, miasto, promień (km) i własne miejscowości ustawiasz w Odkrywaniu, przy każdej kampanii — obok wyboru projektu.** Edycja strategii nie ma już tych pól.

- **Strategia** opisuje, *czego* szukamy: produkt, segment, typ klienta, kryteria, wykluczenia, frazy, powtarzanie.
- **Kampania** w Odkrywaniu mówi, *gdzie* szukamy: sekcja „Obszar wyszukiwania — ta kampania”, zaraz pod „Projekt — gdzie zapisać wyniki”.
- **Ta sama strategia w kilku obszarach:** np. „Ogrodzenia aluminiowe” raz w lubelskim, raz w Poznań +50 km. Każdy obszar może mieć swój projekt, bez kopiowania strategii.

### Podpowiedzi obszaru
- Po wybraniu strategii formularz wstawia **ostatni obszar** użyty z tą strategią.
- Po wybraniu **istniejącego projektu** formularz wstawia obszar **ostatniej kampanii tego projektu**.
- Lista **Projekty** pokazuje obszary kampanii każdego projektu, a karta strategii — „Ostatni obszar kampanii”.

### Co zostaje bez zmian
- **Sprawdzanie „Poza obszarem”** (domyślnie: siedziba firmy) działa względem obszaru kampanii, z której firma pochodzi.
- **Kontynuacja kampanii, zadania uzupełniające i powtarzanie strategii** (co 7/14/30 dni) używają obszaru ostatniej kampanii.
- **Dane z wcześniejszych wersji:** obszar zapisany dotąd w strategii staje się podpowiedzią dla następnej kampanii. Nic nie trzeba przenosić ręcznie.

## Aktualizacja z 3.7
1. Poczekaj, aż kolejka wysyłki będzie pusta. Pobierz Kopię JSON, zatrzymaj serwer, zachowaj `.runtime` i `.env`.
2. Rozpakuj 3.8, przenieś `.runtime` i `.env`, uruchom serwer. W Dockerze: `docker compose up -d --build`, **bez** `down -v`.
3. `/healthz` ma zwracać `3.8.0`, a w menu ma być „WERSJA 3.8”.

## Testy
- **Logika:** 162 testy — wszystkie przechodzą.
- **Serwer, SMTP i IMAP:** 85 testów — wszystkie przechodzą.
- **Przeglądarka:** 33 testy. Nowe lub zmienione:
  - edycja strategii nie ma pól obszaru;
  - w kampanii Słowacja blokuje województwo, a miasto i promień zapisują się w kampanii i jako podpowiedź strategii;
  - przy ponownym wejściu formularz podpowiada ostatni obszar.
- **Pełny scenariusz wysyłki** z przypomnieniami (SMTP z TLS): OK.
