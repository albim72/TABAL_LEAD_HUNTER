#!/usr/bin/env python3
"""3.5 end-to-end mail test: local TLS SMTP server + isolated app server + Playwright scenario (tests/e2e_mail.cjs).
Never touches production data or real mailboxes."""
import os, socket, ssl, subprocess, sys, tempfile, threading, time, urllib.request
from email import policy
from email.parser import BytesParser
from pathlib import Path
root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root))
from tests.test_mail import TLSServer, SMTPHandler  # noqa: E402

with tempfile.TemporaryDirectory(prefix='tabal-e2e-') as tmp:
    cert, key = Path(tmp) / 'cert.pem', Path(tmp) / 'key.pem'
    subprocess.run(['openssl', 'req', '-x509', '-newkey', 'rsa:2048', '-nodes', '-keyout', str(key), '-out', str(cert), '-days', '1', '-subj', '/CN=localhost',
                    '-addext', 'subjectAltName=DNS:localhost,IP:127.0.0.1'], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER); ctx.load_cert_chain(cert, key)
    smtp = TLSServer(('127.0.0.1', 0), SMTPHandler); smtp.context = ctx; smtp.implicit = True; smtp.drop = False; smtp.messages = []
    threading.Thread(target=smtp.serve_forever, daemon=True).start()
    with socket.socket() as check:
        check.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try: check.bind(('127.0.0.1', 8765))
        except OSError: raise SystemExit('Port 8765 zajęty.')
    env = dict(os.environ, TABAL_DATA_DIR=str(Path(tmp) / 'data'), TABAL_ORIGIN='http://127.0.0.1:8765', TABAL_SMTP_HOSTS='localhost', SSL_CERT_FILE=str(cert))
    server = subprocess.Popen([sys.executable, str(root / 'serve.py')], env=env, cwd=root, stdout=subprocess.DEVNULL, stderr=open(Path(tmp) / 'server.log', 'w'))
    try:
        for _ in range(80):
            try: urllib.request.urlopen('http://127.0.0.1:8765/healthz', timeout=1); break
            except Exception: time.sleep(.1)
        result = subprocess.run(['node', str(root / 'tests/e2e_mail.cjs')], env=dict(env, TEST_URL='http://127.0.0.1:8765', SMTP_PORT=str(smtp.server_address[1])), cwd=root)
    finally:
        server.terminate()
        try: server.wait(timeout=15)
        except subprocess.TimeoutExpired: server.kill()
        smtp.shutdown(); smtp.server_close()
    msgs = [BytesParser(policy=policy.default).parsebytes(m) for m in smtp.messages]
    delta = [m for m in msgs if 'delta-e2e.example' in str(m['To'])]
    leads = [m for m in msgs if 'e2e.example' in str(m['To']) and 'delta-e2e.example' not in str(m['To'])]
    print('SMTP przyjął wiadomości:', len(msgs), '— do firm:', len(leads))
    first = [m for m in leads if not str(m['Subject']).startswith('Re: ')]
    reminders = [m for m in leads if str(m['Subject']).startswith('Re: ')]
    print('Pierwsze wiadomości:', len(first), '· przypomnienia:', len(reminders))
    ok = result.returncode == 0 and len(first) == 3 and len(reminders) == 3
    alfa = next((m for m in first if 'alfa-e2e' in str(m['To'])), None)
    ok = ok and alfa is not None and str(alfa['Cc']) == 'biuro@alfa-e2e.example'
    print('  DW dla alfa:', alfa and alfa['Cc'])
    for m in reminders:
        html = m.get_body(('html',)).get_content()
        imgs = [x for x in m.walk() if x.get_content_type() == 'image/png']
        checks = {'In-Reply-To': bool(m['In-Reply-To']), 'Od: profil': 'Anna Testowa' in str(m['From']), 'podpis profilu': 'Anna Testowa' in m.get_body(('plain',)).get_content(),
                  'logo cid': bool(imgs) and 'cid:' in html, 'cytat': 'blockquote' in html}
        print(' ', m['To'], 'przypomnienie ·', ', '.join(k + (' OK' if v else ' BŁĄD') for k, v in checks.items()))
        ok = ok and all(checks.values())
    leads = first
    for m in leads:
        text = m.get_body(('plain',)).get_content(); html = m.get_body(('html',))
        checks = {'katalog': 'https://tabal.pl/katalog-alufence.pdf' in text, 'sygnatura': 'Jędrzej Moraczewski' in text,
                  'bez starego podpisu': 'Zespół TABAL' not in text, 'html': bool(html) and '<b>Jędrzej Moraczewski</b>' in html.get_content() and '<script' not in html.get_content()}
        print(' ', m['To'], '·', ', '.join(k + (' OK' if v else ' BŁĄD') for k, v in checks.items()))
        ok = ok and all(checks.values())
    # 3.9: the message signed by a fixed profile leaves from that profile's own address, in the new message pattern
    ok = ok and len(delta) == 1
    for m in delta:
        text = m.get_body(('plain',)).get_content()
        checks = {'Od: adres profilu': 'pszewczak@tabal.pl' in str(m['From']) and 'Paweł Szewczak' in str(m['From']), 'Message-ID z domeny profilu': str(m['Message-ID']).endswith('@tabal.pl>'),
                  'język korzyści': 'Jako producent' in text and 'Dla firmy wykonawczej' in text and 'szybki termin realizacji' in text,
                  'lista linków': 'Galeria realizacji: https://tabal.pl/tabal-alufence/realizacje/' in text, 'podpis profilu': 'Z poważaniem\nPaweł Szewczak\nDoradca techniczno-handlowy' in text.replace('\r\n', '\n'),
                  'krótka nazwa raz': text.count('Ogrodzenia Delta') == 1 and 'Jakub Stefaniak' not in text}
        print(' ', m['To'], '[3.9 profil stały] ·', ', '.join(k + (' OK' if v else ' BŁĄD') for k, v in checks.items()))
        ok = ok and all(checks.values())
        (root / 'test-results/e2e-mail-v39-przyklad.eml').write_bytes(smtp.messages[msgs.index(m)])
    tests_to_profile = [m for m in msgs if str(m['To']) == 'pszewczak@tabal.pl']
    tos = {str(m['To']) for m in leads}
    ok = ok and 'o.nowak@alfa-e2e.example' in tos and 'biuro@alfa-e2e.example' not in tos
    print('WYNIK E2E:', 'OK' if ok else 'BŁĄD')
    sys.exit(0 if ok else 1)
