"""WSGI entrypoint. Run one process with threads (one SMTP worker)."""
import atexit,hmac,json,os,re,secrets,threading
from pathlib import Path
from urllib.parse import urlsplit
from server.storage import Store,Conflict,core,ROOT
from server.mailer import Outbox,imap_check,find_replies
from server import embed
from server import smtpcheck

def _load_env_file(path):
    """Minimal .env reader for local runs (serve.py / Windows). Real environment variables win."""
    try:text=Path(path).read_text(encoding='utf-8')
    except OSError:return
    for line in text.splitlines():
        line=line.strip()
        if not line or line.startswith('#') or '=' not in line:continue
        k,v=line.split('=',1);k=k.strip();v=v.strip().strip('"').strip("'")
        if k.startswith('TABAL_'):os.environ.setdefault(k,v)
_load_env_file(ROOT/'.env')

DATA=Path(os.environ.get('TABAL_DATA_DIR',str(ROOT/'.runtime')))
ORIGIN=os.environ.get('TABAL_ORIGIN','http://127.0.0.1:8765').rstrip('/')
parsed=urlsplit(ORIGIN)
if parsed.scheme not in ('http','https') or not parsed.netloc or parsed.path:raise RuntimeError('TABAL_ORIGIN: pełny adres bez ścieżki.')
if parsed.scheme!='https' and parsed.hostname not in ('localhost','127.0.0.1'):raise RuntimeError('Dla serwera zdalnego wymagany TABAL_ORIGIN=https://...')
store=Store(DATA/'app.sqlite3');outbox=Outbox(DATA/'mail.sqlite3',config_path=DATA/'smtp.json')
# Default sender for TABAL: bok@tabal.pl. Password only from environment or typed in the panel (memory only).
SMTP_HOST=os.environ.get('TABAL_SMTP_HOST','').strip()
def _int(name,default):
    try:return int(os.environ.get(name,'') or default)
    except ValueError:return default
outbox.defaults=dict(host=SMTP_HOST,port=_int('TABAL_SMTP_PORT',465),security=os.environ.get('TABAL_SMTP_SECURITY','ssl') or 'ssl',
    username=os.environ.get('TABAL_SMTP_USER','bok@tabal.pl') or 'bok@tabal.pl',sender_name=os.environ.get('TABAL_SMTP_SENDER_NAME','TABAL — Biuro Obsługi Klienta') or 'TABAL — Biuro Obsługi Klienta',
    sender_email=os.environ.get('TABAL_SMTP_SENDER','bok@tabal.pl') or 'bok@tabal.pl',interval=_int('TABAL_SMTP_INTERVAL',30))
def smtp_hosts():
    return [h.strip() for h in os.environ.get('TABAL_SMTP_HOSTS','').split(',') if h.strip()]+([SMTP_HOST] if SMTP_HOST else [])
if SMTP_HOST and os.environ.get('TABAL_SMTP_PASSWORD'):
    try:outbox.configure(dict(outbox.defaults,password=os.environ['TABAL_SMTP_PASSWORD']))
    except ValueError as e:print('SMTP z .env nie został skonfigurowany:',e,flush=True)
# 3.5: settings saved from the panel (without password unless the operator chose to remember it) survive a restart.
outbox.load_saved(os.environ.get('TABAL_SMTP_PASSWORD',''))
def host_allowed(host,sender=''):
    """3.5: the panel may use the administrator's list, hosts in the sender's own domain, well-known mail providers
    and hosts found by auto-detection. TABAL_SMTP_ALLOW_ANY=1 lifts the restriction. IP addresses only from the list."""
    host=(host or '').strip().lower() if isinstance(host,str) else ''
    if host and host in [h.lower() for h in smtp_hosts()]:return True
    if not smtpcheck.host_ok(host):return False
    if re.fullmatch(r'[0-9.]+',host) or host in ('localhost',):return False
    if os.environ.get('TABAL_SMTP_ALLOW_ANY')=='1' or host in outbox.detected_hosts:return True
    domain=(sender or '').split('@')[-1].strip().lower()
    if domain and (host==domain or host.endswith('.'+domain)):return True
    return any(host==s or host.endswith('.'+s) for s in smtpcheck.PROVIDER_SUFFIXES)
def mail_key(m):return (m['lead_id'],m.get('kind') or 'lead',m['to'].lower(),(m.get('cc') or '').lower(),m['subject'].strip(),m['body'].strip(),(m.get('html') or '').strip(),(m.get('from_email') or '').lower())
def known_password(host,username):
    """Password already held by the server for this host + login: the shared mailbox or a person's mailbox (3.9)."""
    for box in [outbox.config or {}]+list(outbox.accounts.values()):
        if box.get('password') and box.get('username')==username and (not host or box.get('host')==host or box.get('imap_host')==host):return box['password']
    return ''
def job_still_approved(job):
    """Unattended sending: the job must still match the message computed from the CURRENT stored data."""
    with store.lock:current=store.get()
    return mail_key(job) in {mail_key(m) for m in core('candidates',state=current['state'])}
outbox.validator=job_still_approved
worker=threading.Thread(target=outbox.work,daemon=True);worker.start()
atexit.register(outbox.stop.set)
MAX_BODY=50_000_000

NOLOGIN_CSRF=secrets.token_urlsafe(32)
NOLOGIN_SESSION={'csrf':NOLOGIN_CSRF,'name':'TABAL','role':'admin','token':'nologin-'+NOLOGIN_CSRF}

class HTTPError(Exception):
    def __init__(self,status,message):self.status=status;self.message=message

def application(env,start):
    nonce=secrets.token_urlsafe(24)
    def reply(status,data,ctype='application/json; charset=utf-8',extra=()):
        if isinstance(data,(dict,list)):data=json.dumps(data,ensure_ascii=False)
        if isinstance(data,str):
            if ctype.startswith('text/html'):data=data.replace('<script>','<script nonce="'+nonce+'">')
            data=data.encode()
        headers=[('Content-Type',ctype),('Content-Length',str(len(data))),('Cache-Control','no-store'),('X-Content-Type-Options','nosniff'),('Referrer-Policy','no-referrer'),('X-Frame-Options','DENY'),('Content-Security-Policy',f"default-src 'none'; script-src 'nonce-{nonce}'; style-src 'unsafe-inline'; img-src 'self' data: https:; connect-src 'self'; form-action 'self'; base-uri 'none'; frame-ancestors 'none'")]+list(extra)
        if parsed.scheme=='https':headers.append(('Strict-Transport-Security','max-age=31536000'))
        start(str(status)+' '+{200:'OK',302:'Found',400:'Bad Request',401:'Unauthorized',403:'Forbidden',404:'Not Found',405:'Method Not Allowed',409:'Conflict',413:'Payload Too Large',500:'Internal Server Error'}[status],headers)
        return [data]
    try:
        if env.get('HTTP_HOST','')!=parsed.netloc:raise HTTPError(403,'Niedozwolony adres serwera.')
        path=env.get('PATH_INFO','/');method=env.get('REQUEST_METHOD','GET')
        if method not in ('GET','POST'):raise HTTPError(405,'Niedozwolona metoda.')
        if path=='/healthz' and method=='GET':return reply(200,{'status':'ok','version':'3.9.0'})
        raw={}
        if method=='POST':
            if env.get('HTTP_ORIGIN')!=ORIGIN:raise HTTPError(403,'Niedozwolone pochodzenie żądania.')
            if env.get('CONTENT_TYPE','').split(';')[0]!='application/json':raise HTTPError(400,'Wymagany JSON.')
            try:size=int(env.get('CONTENT_LENGTH','0'))
            except ValueError:raise HTTPError(400,'Błędny rozmiar.')
            if not 0<size<=MAX_BODY:raise HTTPError(413,'Limit danych: 50 MB.')
            raw=json.loads(env['wsgi.input'].read(size))
            if not isinstance(raw,dict):raise HTTPError(400,'Wymagany obiekt JSON.')
        # Wersja BEZ LOGOWANIA: każda osoba, która ma dostęp do adresu aplikacji,
        # pracuje jako administrator. Zachowujemy kontrolę Host/Origin i token CSRF.
        session=NOLOGIN_SESSION
        if path=='/api/login':raise HTTPError(404,'Logowanie jest wyłączone w tej wersji.')
        if path=='/login' and method=='GET':return reply(302,b'',extra=[('Location','/')])
        if method=='POST' and not hmac.compare_digest(env.get('HTTP_X_TABAL_TOKEN',''),session['csrf']):raise HTTPError(403,'Nieprawidłowy token sesji.')
        if path=='/api/logout' and method=='POST':return reply(200,{'ok':True,'auth':'disabled'})
        if method=='GET':
            if path in ('/','/START.html'):
                runtime={'csrf':session['csrf'],'user':session['name'],'role':session['role']}
                script='window.TABAL_SERVER='+json.dumps(runtime).replace('<','\\u003c')+';window.TABAL_MAIL={token:window.TABAL_SERVER.csrf};'
                return reply(200,(ROOT/'START.html').read_text(encoding='utf-8').replace('/*__MAIL_RUNTIME__*/',script),'text/html; charset=utf-8')
            if path=='/INSTRUKCJA.html':return reply(200,(ROOT/'INSTRUKCJA.html').read_text(encoding='utf-8'),'text/html; charset=utf-8')
            if path=='/api/workspace':
                with store.lock:
                    current=store.get();receipts=core('receipts',state=current['state'],jobs=outbox.jobs())
                    if receipts['changed']:store.put(receipts['state'],current['revision'],'smtp','receipts')
                    return reply(200,store.get())
            if path=='/api/state':return reply(200,outbox.snapshot())
            raise HTTPError(404,'Nie znaleziono zasobu.')
        if path=='/api/workspace':
            if not isinstance(raw.get('revision'),int):raise HTTPError(400,'Brak wersji danych.')
            with store.lock,outbox.lock:
                # 3.5: saving is allowed during sending — the message being sent is already frozen ('sending');
                # queued messages whose data changed are cancelled below (and re-checked again right before sending).
                # Merge accepted receipts before any browser state is committed.
                valid=core('receipts',state=raw.get('state'),jobs=outbox.jobs())['state']
                result=store.put(valid,raw['revision'],session['name'])
                candidates=core('candidates',state=valid)
                allowed={mail_key(m) for m in candidates}
                with outbox.db:
                    for j in outbox.jobs():
                        if j['status']=='queued' and j.get('kind')!='test' and mail_key(j) not in allowed:
                            outbox.db.execute("UPDATE jobs SET status='cancelled',error='Dane zmieniono na serwerze.' WHERE id=?",(j['id'],))
                return reply(200,result)
        owner=session['token'][:24]+':'+str(raw.get('owner',''))[:60]
        # 3.5: diagnostics and auto-detection run outside the data locks (network, up to ~45 s).
        if path=='/api/smtp-check':
            host=str(raw.get('host','')).strip()
            if not host_allowed(host,str(raw.get('sender_email',''))):raise HTTPError(403,'Ten host nie jest dopuszczony. Użyj „Wykryj ustawienia” albo poproś administratora o wpis w TABAL_SMTP_HOSTS (lub TABAL_SMTP_ALLOW_ANY=1).')
            cfg=outbox.config or {}
            password=raw.get('password') or known_password(host,raw.get('username'))
            send_to=str(raw.get('send_to','')).strip()
            if send_to:
                from server.mailer import email as valid_email
                send_to=valid_email(send_to)
            return reply(200,smtpcheck.diagnose(host,raw.get('port',465),raw.get('security','ssl'),str(raw.get('username','')),password,send_to,str(raw.get('sender_email','')),str(raw.get('sender_name','TABAL'))))
        if path=='/api/imap-check':
            # 3.6 (TABAL 29.10): test the copy in "Sent" — connection, login, folder and a test copy stored in that folder.
            cfg=outbox.config or {}
            sender=str(raw.get('sender_email') or cfg.get('sender_email') or '').strip()
            smtp_host=str(raw.get('host') or cfg.get('host') or '').strip()
            host=str(raw.get('imap_host') or '').strip() or smtp_host
            if not host_allowed(host,sender):raise HTTPError(403,'Host IMAP nie jest dopuszczony. Użyj hosta w domenie nadawcy lub tego samego co SMTP.')
            username=str(raw.get('username') or cfg.get('username') or '')
            password=raw.get('password') or known_password('',username)
            if not password:raise HTTPError(400,'Wpisz hasło skrzynki (albo najpierw zapisz ustawienia SMTP).')
            domain=sender.split('@')[-1].lower() if '@' in sender else ''
            extra=[h for h in ([smtp_host]+([f'imap.{domain}',f'mail.{domain}'] if domain else [])) if h and h!=host and host_allowed(h,sender)]
            try:port=int(raw.get('imap_port') or 993)
            except (TypeError,ValueError):raise HTTPError(400,'Port IMAP musi być liczbą (zwykle 993).')
            if port not in (993,143):raise HTTPError(400,'Port IMAP: 993 (SSL) albo 143 (STARTTLS).')
            r=imap_check(host,port,username,password,str(raw.get('imap_folder') or '').strip()[:120],sender,str(raw.get('sender_name') or 'TABAL'),True,extra)
            if r.get('host'):outbox.detected_hosts.add(r['host'].lower())
            if r.get('ok'):outbox.imap_last=dict(ok=True,note='test kopii w „Wysłanych”: zapisano ('+r.get('folder_label','')+')',at=__import__('server.mailer',fromlist=['stamp']).stamp())
            return reply(200,r)
        if path=='/api/embed-images':
            # 3.7 (TABAL 2.11 #7): images of a pasted signature are downloaded once and embedded — they show in every mail program.
            return reply(200,embed.embed_html(str(raw.get('html',''))[:2_000_000]))
        if path=='/api/check-replies':
            if not outbox.config:raise HTTPError(400,'Najpierw skonfiguruj skrzynkę (Wysyłka → krok 1).')
            # 3.9: every connected mailbox is checked for replies to the messages sent from it.
            jobs=outbox.jobs();main=outbox.config['sender_email'].lower();boxes=outbox.mailboxes()
            found={'replies':[],'checked':0,'note':''};notes=[]
            for box in boxes:
                addr=box['sender_email'].lower()
                mine=[j for j in jobs if (j.get('sender_email') or main).lower()==addr]
                if not mine and addr!=main:continue
                try:part=find_replies(box,mine)
                except ValueError as e:
                    if len(boxes)==1:raise
                    notes.append(box['sender_email']+': '+str(e));continue
                found['replies']+=part['replies'];found['checked']+=part['checked']
                if part.get('note') and addr==main and len(boxes)==1:found['note']=part['note']
            if notes:found['note']=' · '.join(notes)
            waiting=sorted({(j.get('sender_email') or '').lower() for j in jobs if j.get('status')=='sent'}-{b['sender_email'].lower() for b in boxes}-{''})
            if waiting:found['note']=(found['note']+' · ' if found['note'] else '')+'Nie sprawdzono (skrzynka bez hasła): '+', '.join(waiting)
            with store.lock:
                current=store.get();r=core('replies',state=current['state'],replies=found['replies'])
                if r['changed']:store.put(r['state'],current['revision'],'imap','replies')
            return reply(200,{**found,'changed':r['changed'],'revision':store.get()['revision']})
        if path=='/api/smtp-detect':
            sender=str(raw.get('sender_email','')).strip()
            from server.mailer import email as valid_email
            valid_email(sender)
            hint=str(raw.get('host','')).strip()
            if hint and not host_allowed(hint,sender):hint=''
            password=raw.get('password') or ((outbox.config or {}).get('password','') if (outbox.config or {}).get('username')==raw.get('username') else '')
            found=smtpcheck.detect(sender,str(raw.get('username','') or sender),password,hint)
            if found.get('found'):outbox.detected_hosts.add(found['found']['host'].lower())
            return reply(200,found)
        with store.lock,outbox.lock:
            if path=='/api/config':
                if session['role']!='admin':raise HTTPError(403,'SMTP konfiguruje administrator.')
                if not host_allowed(raw.get('host'),str(raw.get('sender_email',''))):raise HTTPError(403,'Host SMTP nie jest dopuszczony. Użyj „Wykryj ustawienia”, hosta w domenie nadawcy albo poproś administratora o wpis w TABAL_SMTP_HOSTS.')
                return reply(200,outbox.configure(raw))
            if path=='/api/test':
                if session['role']!='admin':raise HTTPError(403,'Test skrzynki wykonuje administrator.')
                return reply(200,outbox.test_message(owner,str(raw.get('account') or '')))
            if path=='/api/account':
                # 3.9 (TABAL 3–4.11): a person's own mailbox — messages signed by that profile leave from its address.
                if session['role']!='admin':raise HTTPError(403,'Skrzynki konfiguruje administrator.')
                if raw.get('action')=='remove':return reply(200,outbox.remove_account(raw.get('sender_email')))
                sender=str(raw.get('sender_email','')).strip();old=outbox.accounts.get(sender.lower(),{})
                host=str(raw.get('host') or '').strip() or old.get('host') or (outbox.config or outbox.defaults or {}).get('host') or ''
                if not host_allowed(host,sender):raise HTTPError(403,'Host SMTP tej skrzynki nie jest dopuszczony. Użyj hosta w domenie adresu (np. mail.'+(sender.split('@')[-1] or 'domena.pl')+'), znanego dostawcy poczty albo poproś administratora o wpis w TABAL_SMTP_HOSTS.')
                imap=str(raw.get('imap_host') or '').strip()
                if imap and not host_allowed(imap,sender):raise HTTPError(403,'Host IMAP tej skrzynki nie jest dopuszczony.')
                return reply(200,outbox.configure_account(raw))
            if path in ('/api/enqueue','/api/sync','/api/control'):
                current=store.get()
                if raw.get('revision')!=current['revision'] and not (path=='/api/control' and raw.get('action')=='pause'):
                    if outbox.owner==owner and not outbox.unattended:outbox.paused=True
                    raise Conflict('Dane na serwerze zmieniły się. Odśwież panel przed dalszą wysyłką.')
                candidates=core('candidates',state=current['state'])
                if path=='/api/enqueue':
                    msgs=raw.get('messages');good={m['lead_id']:m for m in candidates}
                    if not isinstance(msgs,list) or any(m not in candidates for m in msgs):raise HTTPError(400,'Wiadomość nie odpowiada zatwierdzonym danym w bazie.')
                    snap=outbox.enqueue(msgs,owner)
                    # 3.5: add + start in ONE request, so closing the tab right after the click cannot leave the queue unstarted.
                    if raw.get('start_unattended') is True:snap=outbox.control('resume','',owner,True)
                    return reply(200,snap)
                if path=='/api/sync':
                    allowed=raw.get('allowed',[])
                    if not isinstance(allowed,list):raise HTTPError(400,'Błędna lista wiadomości.')
                    keys={mail_key(m) for m in candidates}
                    checked=[j['id'] for j in outbox.jobs() if j['id'] in allowed and (j.get('kind')=='test' or mail_key(j) in keys)]
                    return reply(200,outbox.sync(owner,checked,raw.get('writable') is True,raw.get('observed',[])))
                return reply(200,outbox.control(raw.get('action'),raw.get('id',''),owner,raw.get('unattended') is True))
        raise HTTPError(404,'Nieznana operacja.')
    except HTTPError as e:return reply(e.status,{'error':e.message})
    except Conflict as e:return reply(409,{'error':str(e)})
    except (ValueError,TypeError,KeyError) as e:return reply(400,{'error':str(e) if isinstance(e,ValueError) else 'Nieprawidłowe dane.'})
    except Exception:
        import traceback;traceback.print_exc()
        with outbox.lock:outbox.paused=True
        return reply(500,{'error':'Błąd serwera. Zapis lub wysyłka nie zostały potwierdzone; sprawdź stan i log serwera.'})
