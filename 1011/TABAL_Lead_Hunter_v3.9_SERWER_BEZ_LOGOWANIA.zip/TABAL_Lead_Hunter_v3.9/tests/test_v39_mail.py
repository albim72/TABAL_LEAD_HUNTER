"""3.9 (TABAL 3–4.11.2026): mailboxes of people — a message signed by a profile leaves from that profile's address."""
import json
import sys
import tempfile
import unittest
from email import policy
from email.parser import BytesParser
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from server.mailer import Outbox, build_message, message  # noqa: E402
from tests.test_mail import raw, CONFIG, Transport  # noqa: E402

OWNER = 'test-owner-39-123456'
PAWEL = 'pszewczak@example.com'


class AccountsV39(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.dir = Path(self.tmp.name)
        self.transport = Transport()
        self.now = 100
        self.box = Outbox(self.dir / 'mail.sqlite3', self.transport, lambda: self.now, config_path=self.dir / 'smtp.json')
        self.box.configure(CONFIG)

    def tearDown(self):
        self.box.close()
        self.tmp.cleanup()

    def run_queue(self):
        ids = [j['id'] for j in self.box.jobs() if j['status'] == 'queued']
        self.box.sync(OWNER, ids)
        self.box.control('resume', owner=OWNER)
        done = 0
        while self.box.run_one():
            done += 1
            self.now += 11
        return done

    def test_message_accepts_only_one_valid_sender_address(self):
        self.assertEqual(message({**raw(), 'from_email': 'PSzewczak@Example.com'})['from_email'], PAWEL)
        self.assertNotIn('from_email', message({**raw(), 'from_email': ''}))
        for bad in ('zly adres', 'a@example.com, b@example.com', 'a@example.com\r\nBcc: x@example.com'):
            with self.assertRaises(ValueError):
                message({**raw(), 'from_email': bad})

    def test_unconnected_mailbox_is_refused_never_redirected(self):
        with self.assertRaises(ValueError) as e:
            self.box.enqueue([{**raw(), 'from_email': PAWEL}], OWNER)
        self.assertIn(PAWEL, str(e.exception))
        self.assertIn('Skrzynki osób', str(e.exception))
        self.assertEqual(self.box.jobs(), [])

    def test_profile_address_sends_with_its_own_mailbox(self):
        snap = self.box.configure_account(dict(sender_email=PAWEL, password='PAWEL-SECRET'))
        acc = snap['accounts'][0]
        self.assertEqual((acc['sender_email'], acc['username'], acc['host'], acc['port'], acc['security'], acc['ready']), (PAWEL, PAWEL, 'localhost', 465, 'ssl', True))
        self.assertNotIn('PAWEL-SECRET', json.dumps(snap))
        self.box.enqueue([{**raw(), 'from_email': PAWEL, 'from_name': 'Paweł Szewczak | TABAL', 'profile_id': 'tabal-pszewczak'}, raw('second@example.com', 'lead-2')], OWNER)
        jobs = {j['to']: j for j in self.box.jobs()}  # both were added in the same second — order by recipient, not by id
        self.assertEqual((jobs['first@example.com']['sender_email'], jobs['second@example.com']['sender_email']), (PAWEL, 'test@example.com'))
        self.assertTrue(jobs['first@example.com']['message_id'].endswith('@example.com>'))
        self.assertEqual(self.run_queue(), 2)
        sent = {job['to']: (cfg, job) for cfg, job in self.transport.sent}
        (cfg1, job1), (cfg2, job2) = sent['first@example.com'], sent['second@example.com']
        self.assertEqual((cfg1['username'], cfg1['password'], cfg1['sender_email'], cfg1['sender_name']), (PAWEL, 'PAWEL-SECRET', PAWEL, 'Paweł Szewczak | TABAL'))
        self.assertEqual((cfg2['username'], cfg2['password'], cfg2['sender_email']), ('test@example.com', 'TEST-SECRET-UNIQUE', 'test@example.com'))
        self.assertEqual(cfg1['interval'], CONFIG['interval'])
        msg = BytesParser(policy=policy.default).parsebytes(build_message(cfg1, job1).as_bytes())
        self.assertIn(PAWEL, str(msg['From']))
        self.assertIn('Paweł Szewczak', str(msg['From']))

    def test_profile_with_shared_address_needs_no_account(self):
        self.box.enqueue([{**raw(), 'from_email': 'TEST@example.com', 'from_name': 'Jędrzej Moraczewski | TABAL'}], OWNER)
        self.assertEqual(self.box.jobs()[0]['sender_email'], 'test@example.com')
        with self.assertRaises(ValueError):
            self.box.configure_account(dict(sender_email='test@example.com', password='x'))

    def test_other_server_and_validation(self):
        snap = self.box.configure_account(dict(sender_email='biuro@premium.example', username='biuro', host='mail.premium.example', port=587, password='P', imap_host='imap.premium.example'))
        acc = snap['accounts'][0]
        self.assertEqual((acc['host'], acc['port'], acc['security'], acc['username'], acc['imap_host']), ('mail.premium.example', 587, 'starttls', 'biuro', 'imap.premium.example'))
        box = self.box.mailbox_for('biuro@premium.example')
        self.assertEqual((box['host'], box['port'], box['security'], box['password'], box['imap_host']), ('mail.premium.example', 587, 'starttls', 'P', 'imap.premium.example'))
        for bad in (dict(sender_email='x@premium.example'), dict(sender_email='x@premium.example', password='p', host='https://zly/host'), dict(sender_email='x@premium.example', password='p', port=993), dict(sender_email='zly', password='p')):
            with self.assertRaises(ValueError):
                self.box.configure_account(bad)
        # changing only the folder keeps the stored password; changing the login requires it again
        self.box.configure_account(dict(sender_email='biuro@premium.example', username='biuro', imap_folder='Sent'))
        self.assertEqual(self.box.mailbox_for('biuro@premium.example')['password'], 'P')
        with self.assertRaises(ValueError):
            self.box.configure_account(dict(sender_email='biuro@premium.example', username='inny'))

    def test_password_survives_restart_only_when_remembered(self):
        self.box.configure_account(dict(sender_email=PAWEL, password='PAWEL-SECRET', remember_password=True))
        self.box.configure_account(dict(sender_email='anna@example.com', password='ANNA-SECRET'))
        saved = (self.dir / 'smtp.json').read_text(encoding='utf-8')
        self.assertIn('PAWEL-SECRET', saved)
        self.assertNotIn('ANNA-SECRET', saved)
        self.assertNotIn('TEST-SECRET-UNIQUE', saved)
        self.assertEqual((self.dir / 'smtp.json').stat().st_mode & 0o777, 0o600)
        again = Outbox(self.dir / 'mail2.sqlite3', self.transport, lambda: self.now, config_path=self.dir / 'smtp.json')
        try:
            again.defaults = dict(host='localhost')
            self.assertTrue(again.load_saved('TEST-SECRET-UNIQUE'))
            ready = {a['sender_email']: a['ready'] for a in again.snapshot()['accounts']}
            self.assertEqual(ready, {PAWEL: True, 'anna@example.com': False})
            with self.assertRaises(ValueError):
                again.enqueue([{**raw(), 'from_email': 'anna@example.com'}], OWNER)
        finally:
            again.close()

    def test_mailbox_lost_before_sending_stops_the_queue(self):
        self.box.configure_account(dict(sender_email=PAWEL, password='PAWEL-SECRET'))
        self.box.enqueue([{**raw(), 'from_email': PAWEL}], OWNER)
        self.box.accounts[PAWEL]['password'] = ''  # as after a restart without a remembered password
        ids = [j['id'] for j in self.box.jobs()]
        self.box.sync(OWNER, ids)
        self.box.control('resume', owner=OWNER)
        self.assertTrue(self.box.run_one())
        job = self.box.jobs()[0]
        self.assertEqual(job['status'], 'failed')
        self.assertIn(PAWEL, job['error'])
        self.assertEqual(self.transport.sent, [])
        self.assertTrue(self.box.paused)

    def test_remove_and_test_message(self):
        self.box.configure_account(dict(sender_email=PAWEL, password='PAWEL-SECRET'))
        self.box.test_message(OWNER, PAWEL)
        job = self.box.jobs()[0]
        self.assertEqual((job['kind'], job['to'], job['sender_email']), ('test', PAWEL, PAWEL))
        with self.assertRaises(ValueError):
            self.box.remove_account(PAWEL)  # a queued message of this mailbox
        self.assertEqual(self.run_queue(), 1)
        self.assertEqual(self.transport.sent[0][0]['username'], PAWEL)
        self.assertEqual(self.box.remove_account(PAWEL)['accounts'], [])
        with self.assertRaises(ValueError):
            self.box.test_message(OWNER, PAWEL)

    def test_changing_shared_sender_ignores_jobs_of_people(self):
        self.box.configure_account(dict(sender_email=PAWEL, password='PAWEL-SECRET'))
        self.box.enqueue([{**raw(), 'from_email': PAWEL}], OWNER)
        self.box.configure({**CONFIG, 'sender_email': 'nowy@example.com'})
        self.assertEqual(self.box.config['sender_email'], 'nowy@example.com')
        with self.assertRaises(ValueError):
            self.box.configure({**CONFIG, 'sender_email': PAWEL})


if __name__ == '__main__':
    unittest.main()
