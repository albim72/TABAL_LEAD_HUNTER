// TABAL Lead Hunter 3.6 — uwagi TABAL z 29–30.10.2026 (WhatsApp „AI dla TABAL”, J. Moraczewski, P. Frankiewicz).
const test=require('node:test'),a=require('node:assert/strict'),C=require('../src/core.js');
function base(){const s=C.makeState('pilot');s.config.search_depth='full';s.config.fill_target=false;return s;}
function strat(s,extra={}){const st=C.strategy({...s.strategies[0],product_id:'profiles',...extra});s.strategies=[st];return st;}
const T=C.today();
function src(d){return [{url:'https://'+d+'/',title:'Strona',quote:'Firma '+d,checked_at:T,verified:true}];}
function person(name,role,email){return {type:'person',name,role,reason:'Osoba ze strony kontakt',email,url:'https://x.example/kontakt',quote:`${name} ${role} ${email}`,checked_at:T,verified:true};}
function general(email,role=''){return {type:'general',name:'',role,reason:'Ogólny kontakt',email,url:'https://x.example/kontakt',quote:email,checked_at:T,verified:true};}
function lead(s,st,x={}){return C.validateLead({company:'Firma testowa',domain:x.domain||'x.example',sources:src(x.domain||'x.example'),contacts:[],criteria:{},...x},s,st);}

// ---------- 1. Signature (29.10: „Nadal w mailach nie wyświetla się sygnatura z poczty”) ----------
test('SYGNATURA 3.6: domyślne „Zespół TABAL” to nie sygnatura — wysyłka wstrzymana z jasnym komunikatem',()=>{
 const s=base(),st=strat(s);a.equal(C.signatureReady(s.config),false);
 const l=lead(s,st,{contacts:[general('biuro@x.example')]});l.status='TO_CONTACT';l.draft={subject:'Temat',body:'Dzień dobry,\n\nTreść.\n\nPozdrawiam,\nZespół TABAL'};
 const m=C.mailCandidate(l,s.config,'pilot',s.products);a.equal(m.message,null);a.ok(m.reasons.some(r=>/Brak sygnatury firmowej/.test(r)));
 a.ok(C.mailCandidate(l,{...s.config,require_signature:false},'pilot',s.products).message,'można świadomie wyłączyć wymóg');
});
test('SYGNATURA 3.6: kreator sygnatury — HTML z danymi, wersja tekstowa, logo tylko https, bez wstrzykiwania HTML',()=>{
 const r=C.signatureFromFields({name:'Jędrzej Moraczewski',position:'Specjalista ds. sprzedaży',company:'TABAL Sp. z o.o.',phone:'81 000 00 00',email:'bok@tabal.pl',website:'tabal.pl',address:'ul. Energetyków 14, 20-468 Lublin',logo_url:'https://tabal.pl/logo.png'});
 a.match(r.text,/^Jędrzej Moraczewski\nSpecjalista ds\. sprzedaży\nTABAL Sp\. z o\.o\.\ntel\. 81 000 00 00\nbok@tabal\.pl · tabal\.pl\nul\. Energetyków 14/);
 a.match(r.html,/<img src="https:\/\/tabal\.pl\/logo\.png"/);a.match(r.html,/href="mailto:bok@tabal\.pl"/);a.match(r.html,/href="https:\/\/tabal\.pl"/);
 const bad=C.signatureFromFields({name:'<script>alert(1)</script>Jan',logo_url:'http://evil.example/x.png'});a.ok(!/<script/.test(bad.html));a.ok(!/evil/.test(bad.html));
 const s=base();s.config=C.settings({...s.config,signature:r.text,signature_html:r.html});a.equal(C.signatureReady(s.config),true);
 a.equal(C.settings({signature_fields:{logo_url:'http://x.pl/a.png',name:'Jan'}}).signature_fields.logo_url,'');
});
test('WIADOMOŚĆ 3.6: zawsze wersja HTML (zwykła czcionka zamiast maszynowej), sygnatura tekstowa też w HTML, stary podpis usunięty',()=>{
 const s=base(),st=strat(s);s.config.signature='Jan Kowalski\nTABAL Sp. z o.o.\ntel. 81 000 00 00';
 const l=lead(s,st);l.draft={subject:'Profile konstrukcyjne — poszerzenie oferty z TABAL',body:'Dzień dobry,\n\nTreść https://tabal.pl/aluminiowe-systemy-konstrukcyjne/\n\nPozdrawiam,\nZespół TABAL'};
 const m=C.composeMessage(l,s.config,s.products);
 a.match(m.html,/font-family:Arial/);a.match(m.html,/Jan Kowalski<br>TABAL Sp\. z o\.o\.<br>tel\. 81 000 00 00/);a.ok(!m.body.includes('Zespół TABAL'));a.ok(!m.html.includes('Zespół TABAL'));
 a.match(m.html,/<a href="https:\/\/tabal\.pl\/aluminiowe-systemy-konstrukcyjne\/">/);a.ok(m.body.endsWith('tel. 81 000 00 00'));
});

// ---------- 2. Recipient (29.10: „program nadal wybiera pierwszy lepszy kontakt z firmy”) ----------
test('ODBIORCA 3.6: zakupy przed sprzedażą, zarządem, biurem i przypadkową osobą — niezależnie od kolejności kontaktów',()=>{
 const s=base(),st=strat(s,{product_id:'panel'});
 const contacts=[person('Paweł Szewczak','Inżynier aplikacji','p.szewczak@x.example'),general('biuro@x.example'),person('Ewa Nowak','Dyrektor handlowy','e.nowak@x.example'),person('Anna Kowal','Specjalista ds. zakupów','a.kowal@x.example'),person('Jan Prezes','Prezes zarządu','j.prezes@x.example')];
 const l=lead(s,st,{contacts});let r=C.mailRecipient(l,s.config,s.products);a.equal(r.p.email,'a.kowal@x.example');a.equal(r.weak,false);
 l.contacts=l.contacts.filter(p=>p.email!=='a.kowal@x.example');r=C.mailRecipient(l,s.config,s.products);a.equal(r.p.email,'e.nowak@x.example');a.match(r.why,/handlow/);
 l.contacts=l.contacts.filter(p=>p.email!=='e.nowak@x.example');r=C.mailRecipient(l,s.config,s.products);a.equal(r.p.email,'j.prezes@x.example');
 l.contacts=l.contacts.filter(p=>p.email!=='j.prezes@x.example');r=C.mailRecipient(l,s.config,s.products);a.equal(r.p.email,'biuro@x.example','adres ogólny firmy przed osobą o nieznanej funkcji');a.equal(r.weak,true);
});
test('ODBIORCA 3.6: marketing, kadry, księgowość i serwis na końcu; adres zakupy@ wygrywa z osobą z marketingu',()=>{
 const s=base(),st=strat(s,{product_id:'panel'});
 const l=lead(s,st,{contacts:[person('Marta Mark','Marketing Manager','m.mark@x.example'),general('rekrutacja@x.example'),general('zakupy@x.example','Dział zakupów')]});
 a.equal(C.mailRecipient(l,s.config,s.products).p.email,'zakupy@x.example');
 l.contacts=l.contacts.filter(p=>p.email!=='zakupy@x.example');l.contacts.push(general('info@x.example'));a.equal(C.mailRecipient(l,s.config,s.products).p.email,'info@x.example');
 a.equal(C.recipientRank(person('A','Księgowa','a@x.example'),[]).tier,'avoid');
});
test('ODBIORCA 3.6: role produktu w podanej kolejności; ręczny wybór na karcie ma pierwszeństwo',()=>{
 const s=base(),st=strat(s,{product_id:'profiles'});s.products.find(p=>p.id==='profiles').contact_roles='konstruktor; zakupy';
 const l=lead(s,st,{contacts:[person('Kupiec','Kierownik zakupów','k@x.example'),person('Konstr','Główny konstruktor','g@x.example')]});
 let r=C.mailRecipient(l,s.config,s.products);a.equal(r.p.email,'g@x.example');a.equal(r.role,'konstruktor');
 l.primary_contact=C.contactKey(l.contacts[0]);r=C.mailRecipient(l,s.config,s.products);a.equal(r.p.email,'k@x.example');a.equal(r.primary,true);a.match(r.why,/ręcznie/);
});

// ---------- 3. Area (29.10: „Poznań +50 km — program wyszukał firmy z Rudy Śląskiej czy Gliwic”) ----------
test('OBSZAR 3.6: Poznań +50 km — Ruda Śląska i Gliwice poza obszarem, Poznań i Swarzędz w obszarze',()=>{
 const s=base(),st=strat(s,{province:'wielkopolskie',region:'wielkopolskie',city:'Poznań',radius_km:50});
 const at=(city,pc,d)=>{const l=lead(s,st,{domain:d,address:`ul. Testowa 1, ${pc} ${city}`,city,postal_code:pc});return C.areaCheck(l,l.profile,s.config);};
 a.equal(at('Ruda Śląska','41-700','ruda.example').state,'outside');a.equal(at('Gliwice','44-100','gliwice.example').state,'outside');
 a.equal(at('Poznań','61-001','poznan.example').state,'inside');a.equal(at('Swarzędz','62-020','swarzedz.example').state,'inside');
 const l=lead(s,st,{domain:'r.example',address:'ul. A 1, 41-700 Ruda Śląska',city:'Ruda Śląska',postal_code:'41-700'});const sc=C.score(l,s.config);
 a.ok(sc.blocks.some(b=>/Poza obszarem strategii: Ruda Śląska/.test(b)));a.equal(sc.checks.region==='ok',false);
});
test('OBSZAR 3.6: siedziba poza obszarem + oddział w Poznaniu = POZA OBSZAREM (domyślnie); tryb „oddział wystarcza” zostaje do wyboru',()=>{
 const s=base(),st=strat(s,{province:'wielkopolskie',city:'Poznań',radius_km:50});
 const l=lead(s,st,{domain:'astor.example',address:'ul. Smoleńsk 29, 31-112 Kraków',city:'Kraków',postal_code:'31-112',branches:[{name:'Biuro Poznań',address:'ul. Głogowska 1, 60-001 Poznań',city:'Poznań'}]});
 const seat=C.areaCheck(l,l.profile,s.config);a.equal(seat.state,'outside');a.match(seat.note,/tylko oddział \(Poznań\)/);
 a.equal(C.areaCheck(l,l.profile,{...s.config,area_mode:'branch'}).state,'inside');
 a.equal(C.settings({}).area_mode,'seat');a.equal(C.settings({area_mode:'branch'}).area_mode,'branch');
 a.equal(C.areaBranch(l,s.config).city,'Poznań','kontakty z oddziału w obszarze mają pierwszeństwo');
});
test('OBSZAR 3.6: siedziba z KRS/CEIDG ma pierwszeństwo przed adresem oddziału wpisanym jako główny (stara instrukcja „najbliżej TABAL”)',()=>{
 const s=base(),st=strat(s,{province:'wielkopolskie',city:'Poznań',radius_km:50});
 const l=lead(s,st,{domain:'g.example',address:'ul. Poznańska 1, 61-001 Poznań',city:'Poznań',postal_code:'61-001',registry:{type:'KRS',status:'active',address:'ul. Zwycięstwa 1, 44-100 Gliwice'}});
 const r=C.areaCheck(l,l.profile,s.config);a.equal(r.state,'outside');a.match(r.note,/Gliwice.*wg KRS\/CEIDG/);
 const ok=lead(s,st,{domain:'p.example',address:'ul. A 1, 41-700 Ruda Śląska',city:'Ruda Śląska',postal_code:'41-700',registry:{type:'KRS',status:'active',address:'ul. B 2, 62-020 Swarzędz'}});
 a.equal(C.areaCheck(ok,ok.profile,s.config).state,'inside');
});
test('OBSZAR 3.6: ręczne potwierdzenie operatora („siedziba jest w obszarze”) przetrwa zapis; śmieciowa wartość jest usuwana',()=>{
 const s=base(),st=strat(s,{province:'wielkopolskie',city:'Poznań',radius_km:50});
 const l=lead(s,st,{domain:'m.example',address:'ul. A 1, 41-700 Ruda Śląska',city:'Ruda Śląska',postal_code:'41-700'});l.area_override='inside';l.area_override_at=C.now();s.leads=[l];
 const back=C.restore(C.backup(s),'pilot');a.equal(C.areaCheck(back.leads[0],back.leads[0].profile,back.config).state,'inside');a.equal(C.score(back.leads[0],back.config).checks.area,'inside');
 s.leads[0].area_override='cokolwiek';a.equal(C.restore(C.backup(s),'pilot').leads[0].area_override,undefined);
});
test('ZADANIE WORK 3.6: adres = SIEDZIBA, firmy tylko z oddziałem w obszarze odrzucane, kolejność ról zakupy → handel → zarząd',()=>{
 const s=base(),st=strat(s,{province:'wielkopolskie',city:'Poznań',radius_km:50,mode:'open'});const t=C.task(s,st,'r');
 a.match(t,/SIEDZIBA firmy musi leżeć w obszarze/);a.match(t,/siedziba poza obszarem/);a.match(t,/nie adres oddziału/);a.doesNotMatch(t,/oddział położony NAJBLIŻEJ TABAL/);
 a.match(t,/działu zakupów \/ zaopatrzenia, potem z działu handlowego \/ sprzedaży, potem właściciel lub zarząd/);a.match(t,/NIE wybieraj osób z marketingu/);
 s.config.area_mode='branch';a.match(C.task(s,st,'r'),/siedzibę albo oddział w obszarze/);
});
test('MIGRACJA 3.6: dane 3.5 wczytują się bez zmian statusów; domyślnie „siedziba”, wymóg sygnatury włączony',()=>{
 const s=base(),st=strat(s);const l=lead(s,st);l.status='TO_CONTACT';s.leads=[l];const old=JSON.parse(C.backup(s));old.app_version='3.5.0';delete old.state.config.area_mode;delete old.state.config.require_signature;delete old.state.config.signature_fields;
 const r=C.restore(JSON.stringify(old),'pilot');a.equal(r.leads[0].status,'TO_CONTACT');a.equal(r.config.area_mode,'seat');a.equal(r.config.require_signature,true);a.equal(r.app_version,C.VERSION);
});
