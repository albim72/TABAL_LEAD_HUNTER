// TABAL Lead Hunter 3.3 — regressions for TABAL change list of 14.10.2026 (J. Moraczewski) and G. Bartosik's request.
const {test}=require('node:test'),a=require('node:assert/strict'),C=require('../src/core.js');
function base(){const s=C.makeState('pilot');s.config.search_depth='full';s.config.fill_target=false;return s;}
function alu(s,extra={}){const st=C.strategy({...s.strategies.find(x=>x.id==='aluminium'),country:'Polska',province:'lubelskie',region:'lubelskie, Polska',...extra});s.strategies[s.strategies.findIndex(x=>x.id==='aluminium')]=st;return st;}
const src='https://firma.example/oferta';
function lead(s,st,{company='Firma',dom='firma.example',criteria={},extra={}}={}){
 const quote='Oferta firmy — fragment ze strony.';
 const cr={};for(const k of [...C.CRITERIA,'exclusion'])cr[k]={value:'unknown',evidence:'',url:''};
 for(const [k,v] of Object.entries(criteria))cr[k]={value:v,evidence:k+': '+v+' — dowód',url:src.replace('firma.example',dom)};
 return C.validateLead({company,domain:dom,is_demo:false,region:'lubelskie',sources:[{url:src.replace('firma.example',dom),title:'Oferta',quote,checked_at:C.today(),verified:true}],
  contacts:[{type:'general',email:'biuro@'+dom,phone:'',url:'https://'+dom+'/kontakt',quote:'biuro@'+dom,checked_at:C.today(),verified:true}],criteria:cr,...extra},s,st);
}

test('TRAFNOŚĆ: firma meblowa (fit=unrelated) jest blokowana i dostaje 0 za produkt, segment i klienta — nawet gdy Work dał TAK',()=>{
 const s=base(),st=alu(s);
 const steelove=lead(s,st,{company:'STEELOVE',dom:'steelove.example',criteria:{client:'yes',segment:'yes',region:'yes'},extra:{business_profile:{core_activity:'produkcja mebli stalowych',fit:'unrelated',reason:'Oferta: stoły, krzesła, regały; „montaż ogrodzeń” tylko na liście usług'}}});
 const sc=C.score(steelove,s.config);
 for(const k of ['product','segment','client'])a.equal(sc.parts.find(p=>p.key===k).points,0,k);
 a.equal(sc.qualified,false);a.ok(sc.blocks.some(b=>/Profil działalności niezgodny/.test(b)));a.ok(sc.parts.some(p=>p.key==='mismatch'&&p.points<0));
});
test('SCORING: firma ogrodzeniowa bez ogrodzeń aluminiowych = oferta pokrewna (nie 0 pkt), wyżej niż niezgodna',()=>{
 const s=base(),st=alu(s);
 const panel=lead(s,st,{company:'Ogrodzenia Panel',dom:'panel.example',criteria:{segment:'yes',region:'yes',product:'no'},extra:{business_profile:{core_activity:'montaż ogrodzeń panelowych',fit:'related'}}});
 const sc=C.score(panel,s.config),p=sc.parts.find(x=>x.key==='product');
 a.equal(sc.checks.product,'related');a.ok(p.points>0&&p.points<p.max);a.match(p.reason,/OFERTA POKREWNA/);
 a.ok(!sc.blocks.some(b=>/^Produkt/.test(b)),'pokrewna oferta nie blokuje');a.ok(sc.warnings.some(w=>/pokrewne/.test(w)));
 const explicit=lead(s,st,{company:'Bramy',dom:'bramy.example',criteria:{product:'related',segment:'yes'}});a.equal(C.score(explicit,s.config).checks.product,'related');
 const steel=lead(s,st,{company:'Meble',dom:'meble.example',criteria:{client:'yes',region:'yes'},extra:{business_profile:{core_activity:'meble',fit:'unrelated'}}});
 a.ok(sc.points>C.score(steel,s.config).points);
});
test('SCORING: udział oferty pokrewnej ustawialny; brak branży = brak inferencji',()=>{
 const s=base(),st=alu(s);const l=lead(s,st,{dom:'x.example',criteria:{segment:'yes',product:'no'}});
 const max=C.score(l,s.config).parts[0].max;
 s.config=C.settings({...s.config,related_share:75});a.equal(Math.round(C.score(l,s.config).parts[0].points*100),Math.round(max*0.75*100));
 const l2=lead(s,st,{dom:'y.example',criteria:{product:'no'}});a.equal(C.score(l2,s.config).checks.product,'no');
});
test('SCORING KLIENT: typ klienta liczy się tylko w branży strategii (przypadek STEELOVE)',()=>{
 const s=base(),st=alu(s);
 const outside=lead(s,st,{dom:'a.example',criteria:{client:'yes',segment:'no'}});a.equal(C.score(outside,s.config).parts.find(p=>p.key==='client').points,0);
 const unknown=lead(s,st,{dom:'b.example',criteria:{client:'yes'}});const cu=C.score(unknown,s.config).parts.find(p=>p.key==='client');a.equal(cu.state,'partial');a.equal(cu.points,cu.max/2);
 const fence=lead(s,st,{dom:'c.example',criteria:{client:'yes',segment:'yes'}});const cf=C.score(fence,s.config).parts.find(p=>p.key==='client');a.equal(cf.points,cf.max);
 a.ok(cf.points>C.score(outside,s.config).parts.find(p=>p.key==='client').points);
});
test('PORTAL: lead tylko z katalogu dostaje połowę za źródło i ostrzeżenie; brak strony (sprawdzony) — pełne punkty',()=>{
 const s=base(),st=alu(s);
 const raw={company:'Ogrody X',identity_url:'https://www.oferteo.pl/ogrody-x/firma/123',is_demo:false,sources:[{url:'https://www.oferteo.pl/ogrody-x/firma/123',quote:'Ogrodzenia',checked_at:C.today(),verified:true}],contacts:[],criteria:{}};
 const l=C.validateLead(raw,s,st),sc=C.score(l,s.config);a.equal(sc.checks.source,'partial');a.ok(sc.warnings.some(w=>/stronie firmy/.test(w)));
 const l2=C.validateLead({...raw,website_check:{status:'not_found',note:'Brak strony; sprawdzono Google, CEIDG'}},s,st);a.equal(C.score(l2,s.config).checks.source,'ok');
});
test('CEIDG/KRS: rejestr uzupełnia NIP, wykreślona firma jest nieaktywna i zablokowana',()=>{
 const s=base(),st=alu(s);
 const l=lead(s,st,{dom:'r.example',extra:{registry:{type:'ceidg',status:'aktywny',nip:'123-456-78-90',url:'https://aplikacja.ceidg.gov.pl/x'}}});a.equal(l.nip,'1234567890');a.equal(l.registry.type,'CEIDG');a.equal(l.active_status,'active');
 const d=lead(s,st,{dom:'d.example',extra:{registry:{type:'KRS',status:'wykreślona'}}});a.equal(d.active_status,'inactive');a.ok(C.score(d,s.config).blocks.some(b=>/wykreślona/.test(b)));
 a.equal(C.sourceKind('https://aplikacja.ceidg.gov.pl/x',l),'registry');a.equal(C.sourceKind('https://www.facebook.com/firma',l),'social');a.equal(C.sourceKind('https://r.example/kontakt',l),'website');a.equal(C.sourceKind('https://www.panoramafirm.pl/x',l),'catalog');
});
test('ODDZIAŁY: wybór oddziału najbliższego TABAL (Lublin); kontakt z tego oddziału ma pierwszeństwo',()=>{
 const s=base(),st=alu(s);
 const l=lead(s,st,{dom:'o.example',extra:{city:'Warszawa',branches:[{city:'Radom',address:'ul. A 1'},{city:'Zamość',address:'ul. B 2'}]}});
 const near=C.nearestBranch(l,s.config);a.equal(near.city,'Zamość');a.ok(near.km>50&&near.km<110);
 l.contacts=[{type:'general',email:'radom@o.example',url:'https://o.example/kontakt',quote:'radom@o.example',checked_at:C.today(),verified:true,branch:'Radom'},{type:'general',email:'zamosc@o.example',url:'https://o.example/kontakt',quote:'zamosc@o.example',checked_at:C.today(),verified:true,branch:'Zamość'}];
 a.equal(C.bestContact(l,s.config).p.email,'zamosc@o.example');
 s.config=C.settings({...s.config,tabal_locations:['Radom']});a.equal(C.nearestBranch(l,s.config).city,'Radom');
});
test('KONTAKTY: kontakt ogólny jest wystarczający — 8/10, stan OK, brak ostrzeżenia o kontakcie',()=>{
 const s=base(),st=alu(s),l=lead(s,st,{dom:'g.example'});const sc=C.score(l,s.config),p=sc.parts.find(x=>x.key==='contact');
 a.equal(p.state,'ok');a.equal(Math.round(p.points/p.max*10),8);a.ok(!sc.warnings.some(w=>/kontakt/i.test(w)));
});
test('WIADOMOŚCI: import usuwa uwagi robocze i cytaty ze strony, zachowuje je w notatkach szkicu',()=>{
 const s=base(),st=alu(s);
 const body='Dzień dobry,\n\nNa stronie STEELOVE znalazłem informację: „Montaż ogrodzeń”. Szukamy partnerów montażowych dla ogrodzeń aluminiowych.\n\nTABAL z Lublina (według strony również oddziały w Radomiu, Zamościu, Siedlcach i Olsztynie) oferuje Alufence. Źródło: https://tabal.pl/ — przed wysyłką potwierdź aktualność informacji.\n\nCzy możemy porozmawiać?\n\nPozdrawiam\nZespół TABAL';
 const l=lead(s,st,{dom:'w.example',extra:{draft:{subject:'Współpraca (do weryfikacji)',body}}});
 a.doesNotMatch(l.draft.body,/znalazłem|według strony|przed wysyłką|Montaż ogrodzeń”|Źródło/);a.match(l.draft.body,/Szukamy partnerów/);a.match(l.draft.body,/Czy możemy porozmawiać\?/);a.match(l.draft.body,/Pozdrawiam\nZespół TABAL/);
 a.match(l.draft.notes,/przed wysyłką/);a.equal(l.draft.subject,'Współpraca');a.deepEqual(C.draftIssues(l.draft),[]);
 a.ok(C.draftIssues({body}).length>=2);
});
test('WIADOMOŚCI: szkic lokalny — krótki, bez cytatu, bez opisu TABAL i oddziałów, z powodem i jednym elementem oferty',()=>{
 const s=base(),st=alu(s);
 const l=lead(s,st,{company:'Ogrodzenia Kowalski',dom:'k.example',criteria:{segment:'yes',product:'yes',client:'yes',region:'yes'},extra:{business_profile:{core_activity:'montaż i sprzedaż ogrodzeń',fit:'core'}}});
 const d=C.draft(l,s.config,s.products),words=d.body.split(/\s+/).length;
 a.match(d.body,/zajmują się Państwo montażem i sprzedażą ogrodzeń/);a.match(d.body,/Jako producent/);a.match(d.body,/ogrodzeń aluminiowych/);a.ok(words<160,String(words));
 a.doesNotMatch(d.body,/Radom|Olsztyn|1990|znalazłem|„/);a.deepEqual(C.draftIssues(d),[]);
 const rel=lead(s,st,{company:'Panele',dom:'p.example',criteria:{segment:'yes',product:'no'}});const dr=C.draft(rel,s.config,s.products);a.match(dr.body,/poszerzenie oferty/);a.match(dr.subject,/poszerzenie/);
});
test('OFERTA: migracja 3.2 → 3.3 usuwa listę oddziałów i adnotację roboczą, zostawia własny tekst',()=>{
 const s=base();s.config.offer=C.OLD_TABAL_OFFER;const old={...s,migrations:s.migrations.filter(m=>m!=='v33-offer-clean')};
 const r=C.restore(C.backup(old),'pilot');a.equal(r.config.offer,C.TABAL_OFFER);a.doesNotMatch(r.config.offer,/Radom|przed wysyłką/);
 s.config.offer='Nasza oferta (według strony również oddziały w X). Źródło: https://tabal.pl/ — przed wysyłką potwierdź aktualność informacji.';
 const r2=C.restore(C.backup({...s,migrations:s.migrations.filter(m=>m!=='v33-offer-clean')}),'pilot');a.equal(r2.config.offer,'Nasza oferta.');
});
test('UZUPEŁNIANIE: lead_ref trafia na właściwą kartę, także gdy Work znalazł nową własną domenę firmy z katalogu',()=>{
 const s=base(),st=alu(s);
 const cat=C.validateLead({company:'Ogrody X',identity_url:'https://www.oferteo.pl/ogrody-x/firma/123',is_demo:false,sources:[{url:'https://www.oferteo.pl/ogrody-x/firma/123',quote:'Ogrodzenia',checked_at:C.today(),verified:true}],contacts:[],criteria:{}},s,st);s.leads=[cat];
 const raw={lead_ref:cat.id,strategy_id:st.id,company:'Ogrody X',domain:'ogrodyx.example',is_demo:false,website_check:{status:'verified',url:'https://ogrodyx.example/'},sources:[{url:'https://ogrodyx.example/oferta',quote:'Montaż ogrodzeń',checked_at:C.today(),verified:true}],contacts:[{type:'general',phone:'600 100 200',url:'https://ogrodyx.example/kontakt',quote:'tel. 600 100 200',checked_at:C.today(),verified:true}],criteria:{}};
 const r=C.merge(s,[raw],st,{refresh:true});a.equal(r.added,0);a.equal(r.duplicates,1);a.equal(r.leads.length,1);
 const l=r.leads[0];a.equal(l.domain,'ogrodyx.example');a.equal(l.contacts.length,1);a.equal(l.website_check.status,'verified');
 const bad=C.merge({...s,leads:[{...cat,nip:'1111111111'}]},[{...raw,nip:'2222222222'}],st);a.equal(bad.errors.length,1);
});
test('UZUPEŁNIANIE: rekordy z różnych strategii w jednym pliku zachowują swoją strategię',()=>{
 const s=base(),a1=alu(s),panel=s.strategies.find(x=>x.id==='panels');
 const r=C.merge(s,[{...C.sample(panel,s,false),company:'P1',domain:'p1.example',strategy_id:panel.id},{...C.sample(a1,s,false),company:'A1',domain:'a1.example'}],a1);
 a.equal(r.added,2);a.equal(r.leads.find(l=>l.company==='P1').strategy_id,'panels');a.equal(r.leads.find(l=>l.company==='A1').strategy_id,'aluminium');
});
test('UZUPEŁNIANIE: tryb refresh poprawia kryteria i profil, zwykłe ponowne odkrycie tylko uzupełnia braki',()=>{
 const s=base(),st=alu(s);const l=lead(s,st,{dom:'f.example',criteria:{product:'yes'}});s.leads=[l];
 const raw={company:'Firma',domain:'f.example',is_demo:false,sources:l.sources,contacts:[],criteria:{product:{value:'related',evidence:'tylko panele',url:l.sources[0].url}},business_profile:{core_activity:'montaż ogrodzeń panelowych',fit:'related'}};
 const plain=C.merge(s,[raw],st);a.equal(plain.leads[0].criteria.product.value,'yes');a.equal(plain.leads[0].business_profile.fit,'related');
 const fresh=C.merge(s,[raw],st,{refresh:true});a.equal(fresh.leads[0].criteria.product.value,'related');
});
test('ZADANIE WORK: trafność, strona własna, CEIDG/KRS, pogłębione kontakty, oddziały, social, wiadomości, lead_ref',()=>{
 const s=base(),st=alu(s,{limit:0,batch_size:0});const run=C.createResearchRun(st);s.runs.push(run);const t=C.prepareResearchBatch(s,run);
 for(const re of [/TRAFNOŚĆ — PROFIL DZIAŁALNOŚCI/,/fit=unrelated/,/meble/,/pielęgnacja ogrodów/,/research_report\.rejected/,/PORTAL → WŁASNA STRONA/,/Oferteo/,/website_check/,/REJESTRY CEIDG \/ KRS/,/POGŁĘBIONE WYSZUKIWANIE/,/Polityka prywatności/,/DRUGIE PRZEJŚCIE/,/ODDZIAŁY: address\/city\/postal_code to zawsze SIEDZIBA firmy[^\n]*siedziba TABAL to Lublin/,/PROFILE SPOŁECZNOŚCIOWE/,/value "related"/,/v3\.\d/])a.match(t,re);
 const full=C.strategy({...st,mode:'targeted',research_stage:'full',targets:'lead_ref=abc | Firma | f.pl | strategy_id=aluminium'});const t2=C.task(s,full,'run');
 a.match(t2,/lead_ref i strategy_id/);a.match(t2,/ZAKAZANE w body/);a.match(t2,/draft\.notes/);a.match(t2,/"lead_ref"/);a.doesNotMatch(t2,/DRUGIE PRZEJŚCIE/);
 const rep=C.researchReport({stop_reason:'pool_exhausted',rejected:[{company:'STEELOVE',domain:'steelove.pl',reason:'meble'}]});a.equal(rep.rejected[0].company,'STEELOVE');
});
test('ZGODNOŚĆ: stare rekordy bez nowych pól liczą się jak dotąd (poza oferta pokrewną) i nie zmieniają kształtu kontaktów',()=>{
 const s=base(),st=alu(s);const r={...C.sample(st,s,false),address:'ul. Przykładowa 1, 20-001 Lublin',city:'Lublin'};const l=C.validateLead(r,s,st);
 a.equal(l.business_profile,undefined);a.equal(l.registry,undefined);a.deepEqual(Object.keys(l.contacts[0]).sort(),['checked_at','email','name','phone','quote','reason','role','type','url','verified'].sort());
 a.equal(C.score(l,s.config).qualified,true);
});
