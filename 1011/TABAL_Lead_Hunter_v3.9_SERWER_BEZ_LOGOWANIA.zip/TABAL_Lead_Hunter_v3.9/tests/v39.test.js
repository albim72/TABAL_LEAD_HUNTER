// TABAL Lead Hunter 3.9 — uwagi TABAL z 3–7.11.2026 (grupa „AI dla TABAL”, e-mail „Profile w Lead Hunterze”):
// stałe profile i adres nadawcy z profilu, wiadomości językiem korzyści, liczba leadów bliżej zadanej puli.
const test=require('node:test'),a=require('node:assert/strict'),C=require('../src/core.js');
const T=C.today();
function base(){const s=C.makeState('pilot');s.config.signature='Zespół TABAL\nbok@tabal.pl';return s;}
function strat(s,id='panel',extra={}){const st=C.strategy({...s.strategies[0],product_id:id,...extra});s.strategies=[st];return st;}
const src=d=>[{url:'https://'+d+'/',title:'Strona',quote:'Firma '+d,checked_at:T,verified:true}];
const general=email=>({type:'general',name:'',role:'',reason:'Ogólny kontakt',email,url:'https://x.example/kontakt',quote:email,checked_at:T,verified:true});
function lead(s,st,x={}){return C.validateLead({company:'ASTOR Sp. z o.o.',domain:'astor.example',sources:src('astor.example'),contacts:[general('biuro@astor.example')],criteria:{},...x},s,st);}

// ---------- profile stałe ----------
test('PROFILE 3.9: siedem stałych profili TABAL z sygnaturą i własnym adresem nadawcy',()=>{
 const s=base(),ps=s.config.profiles;
 a.deepEqual(ps.map(p=>p.email),['pszewczak@tabal.pl','bok@tabal.pl','biuro@premiumresin.pl','sbochen@tabal.pl','pcholewa@tabal.pl','klatuszynski@tabal.pl','mmilanowska@tabal.pl']);
 for(const p of ps){a.ok(C.isBuiltinProfile(p));a.equal(p.own_address,true);a.equal(C.fromAddress(p),p.email);a.ok(C.signatureReady({...s.config,signature:p.signature,signature_html:p.signature_html}),p.name);a.ok(p.signature.includes(p.name)&&p.signature.includes(p.email));}
 const pawel=ps[0];a.equal(pawel.position,'Doradca techniczno-handlowy | TABAL ALUFENCE');a.match(pawel.signature,/\+48 665 010 292/);a.match(pawel.signature,/KRS: 0000655991/);
 const michal=ps[2];a.equal(michal.sender_name,'Michał Zieliński | Premium Resin');a.doesNotMatch(michal.signature,/Tabal Sp\. z o\.o\./);a.match(michal.signature,/premium-resin\.pl/);
 a.equal(C.isBuiltinProfile({id:'p123'}),false);
});
test('PROFILE 3.9: aktualizacja z 3.8 dodaje stałe profile raz, nie dubluje osoby i nie nadpisuje jej sygnatury',()=>{
 const s=base();s.migrations=s.migrations.filter(x=>!x.startsWith('v39-'));
 s.config.profiles=[C.profileOf({id:'pjm',name:'Jędrzej Moraczewski',position:'Opiekun klienta',email:'bok@tabal.pl',sender_name:'Jędrzej Moraczewski | TABAL',signature:'Jędrzej Moraczewski\nWłasna sygnatura z logo'})];
 for(const p of s.products){delete p.arguments;delete p.topic;delete p.acc;delete p.gallery_url;}
 const r=C.restore(C.backup(s),'pilot');
 a.equal(r.config.profiles.length,7);a.equal(r.config.profiles.filter(p=>C.norm(p.name)===C.norm('Jędrzej Moraczewski')).length,1);
 const own=r.config.profiles.find(p=>p.id==='pjm');a.match(own.signature,/Własna sygnatura z logo/);a.equal(own.own_address,true);
 a.match(r.products.find(p=>p.id==='alu').arguments,/Jako producent/);a.equal(r.products.find(p=>p.id==='alu').gallery_url,'https://tabal.pl/tabal-alufence/realizacje/');
 // second pass changes nothing; a profile removed by hand does not come back
 r.config.profiles=r.config.profiles.filter(p=>p.id!=='tabal-sbochen');const again=C.restore(C.backup(r),'pilot');a.equal(again.config.profiles.length,6);
});
test('NADAWCA 3.9: wiadomość niesie adres wybranego profilu; bez własnego adresu i bez profilu — skrzynka wspólna',()=>{
 const s=base(),st=strat(s),l=lead(s,st);l.status='TO_CONTACT';l.draft={subject:'Temat',body:'Dzień dobry,\n\nTreść.\n\nZ poważaniem'};
 a.equal(C.mailCandidate(l,s.config,'pilot',s.products).message.from_email,'');
 const m=C.mailCandidate({...l,mail_profile:'tabal-pszewczak'},s.config,'pilot',s.products).message;
 a.equal(m.from_email,'pszewczak@tabal.pl');a.equal(m.from_name,'Paweł Szewczak | TABAL');a.match(m.body,/Z poważaniem\nPaweł Szewczak\nDoradca techniczno-handlowy/);
 const off={...s.config,profiles:s.config.profiles.map(p=>p.id==='tabal-pszewczak'?{...p,own_address:false}:p)};
 const m2=C.mailCandidate({...l,mail_profile:'tabal-pszewczak'},off,'pilot',s.products).message;a.equal(m2.from_email,'');a.equal(m2.from_name,'Paweł Szewczak | TABAL');
 a.equal(C.fromAddress({own_address:true,email:'to nie adres'}),'');
});
test('NADAWCA 3.9: przypomnienie wychodzi ze skrzynki, z której wyszła pierwsza wiadomość',()=>{
 const s=base(),st=strat(s),l=lead(s,st);l.status='TO_CONTACT';l.mail_profile='tabal-pcholewa';
 const job={id:'j1',status:'sent',lead_id:l.id,to:'biuro@astor.example',subject:'Temat',body:'Treść',sent_at:new Date(Date.now()-4*86400000).toISOString(),message_id:'<j1@tabal.pl>',profile_id:'tabal-pcholewa',from_email:'pcholewa@tabal.pl',sender_email:'pcholewa@tabal.pl'};
 a.ok(C.applyMailReceipt(l,job));a.equal(l.mail_events[0].from,'pcholewa@tabal.pl');a.equal(l.status,'CONTACTED');
 const f=C.followupCandidate(l,s.config,'pilot',s.products).message;a.equal(f.from_email,'pcholewa@tabal.pl');a.equal(f.kind,'followup');
 // a message sent before 3.9 (no sender stored) is followed up from the shared mailbox, even if the profile now has its own address
 const old=lead(s,st,{domain:'old.example',sources:src('old.example'),contacts:[general('biuro@old.example')]});old.status='CONTACTED';old.mail_profile='tabal-pcholewa';
 old.mail_events=[{id:'j0',to:'biuro@old.example',cc:'',kind:'lead',subject:'Temat',body:'Treść',sent_at:new Date(Date.now()-4*86400000).toISOString(),message_id:'<j0@tabal.pl>'}];
 a.equal(C.followupCandidate(old,s.config,'pilot',s.products).message.from_email,'');
});

// ---------- wiadomości: język korzyści ----------
test('WIADOMOŚĆ 3.9: producent, kompletność oferty, termin — a argument zależy od typu odbiorcy',()=>{
 const s=base(),st=strat(s,'alu');
 const mk=(client_type,core,fit='core')=>lead(s,st,{company:'Ogrodzenia Fajsławice Jakub Stefaniak',client_type,criteria:{product:{value:fit==='related'?'related':'yes',evidence:'Firma astor.example',url:'https://astor.example/'}},business_profile:{core_activity:core,fit}});
 const inst=C.draft(mk('firma montażowa','montaż ogrodzeń'),s.config,s.products).body,dist=C.draft(mk('dystrybutor','sprzedaż ogrodzeń'),s.config,s.products).body,prod=C.draft(mk('producent','produkcja bram'),s.config,s.products).body;
 for(const b of [inst,dist,prod]){a.match(b,/w imieniu firmy TABAL z propozycją współpracy w zakresie ogrodzeń aluminiowych/);a.match(b,/Jako producent/);a.match(b,/kompletny/);a.match(b,/szybki termin realizacji/);a.ok(b.trim().endsWith('Z poważaniem'));a.deepEqual(C.draftIssues({body:b}),[]);
  a.doesNotMatch(b,/Jakub Stefaniak/);a.equal(b.split('Ogrodzenia Fajsławice').length,2,'krótka nazwa dokładnie raz');a.doesNotMatch(b,/wdzięczny|zauważyłem|znalazłem/);}
 a.match(inst,/Dla firmy wykonawczej/);a.match(dist,/Dla dystrybutora/);a.match(prod,/Dla firmy produkcyjnej/);a.equal(new Set([inst,dist,prod]).size,3);
 a.deepEqual(['firma montażowa','dystrybutor','producent maszyn','biuro projektowe','deweloper',''].map(client_type=>C.recipientKind({client_type})),['installer','reseller','producer','designer','builder','other']);
 a.equal(C.recipientKind({client_type:'',business_profile:{core_activity:'sprzedaż i montaż ogrodzeń'},profile:{client:'Producent'}}),'installer');
 const rel=C.draft(mk('firma montażowa','montaż ogrodzeń panelowych','related'),s.config,s.products);a.match(rel.body,/poszerzenie oferty o ogrodzenia aluminiowe bez inwestowania we własną produkcję/);a.match(rel.subject,/poszerzenie oferty z TABAL/);
 a.doesNotMatch(C.draft(mk('dystrybutor','sprzedaż ogrodzeń'),{...s.config,lead_time_text:''},s.products).body,/termin realizacji/);
 a.equal(C.settings({}).lead_time_text,C.LEAD_TIME_TEXT);a.equal(C.settings({lead_time_text:''}).lead_time_text,'');
});
test('WIADOMOŚĆ 3.9: profil innej firmy pisze w jej imieniu; własne argumenty produktu mają pierwszeństwo',()=>{
 const s=base(),st=strat(s,'alu'),l=lead(s,st,{client_type:'dystrybutor'});
 a.match(C.draft({...l,mail_profile:'premium-mzielinski'},s.config,s.products).body,/w imieniu firmy Premium Resin/);
 s.products.find(p=>p.id==='alu').arguments='Własny akapit z argumentami handlowca.';a.match(C.draft(l,s.config,s.products).body,/Własny akapit z argumentami handlowca\./);
 const custom={id:'c1',name:'Stoły żywiczne',description:'',url:'',pitch:'stoły z żywicy epoksydowej na wymiar'};s.products.push(custom);const st2=C.strategy({...s.strategies[0],id:'s2',name:'Stoły',product_id:'c1'});s.strategies.push(st2);
 const b=C.draft(lead(s,st2,{domain:'meble.example',sources:src('meble.example')}),s.config,s.products).body;a.match(b,/w zakresie oferty: stoły żywiczne/);a.match(b,/W ofercie mamy stoły z żywicy epoksydowej na wymiar\./);
});
test('NAZWA 3.9: jednoosobowa firma z nazwą własną — bez imienia i nazwiska właściciela',()=>{
 for(const [full,short] of [['Ogrodzenia Fajsławice Jakub Stefaniak','Ogrodzenia Fajsławice'],['Zakład Ślusarski Marek Nowak-Kowalski','Zakład Ślusarski'],['Meble Biurowe Nowy Styl','Meble Biurowe Nowy Styl'],['Jan Kowalski','Jan Kowalski'],['Montujemyogrodzenia.pl','Montujemyogrodzenia.pl'],['ASTOR Sp. z o.o.','ASTOR']])a.equal(C.shortCompany(full),short,full);
});
test('LINKI 3.9: kilka linków produktu = krótka lista przed zwrotem grzecznościowym; jeden link = jeden wiersz jak dotąd',()=>{
 const s=base(),st=strat(s,'alu'),l=lead(s,st);l.draft={subject:'T',body:'Dzień dobry,\n\nTreść.\n\nZ poważaniem'};
 const m=C.composeMessage({...l,mail_profile:'tabal-jmoraczewski'},s.config,s.products).body;
 a.match(m,/Zachęcam do zapoznania się z naszą ofertą:\n• Oferta — Ogrodzenia aluminiowe: https:\/\/tabal\.pl\/tabal-alufence\/\n• Galeria realizacji: https:\/\/tabal\.pl\/tabal-alufence\/realizacje\/\n• Katalog — Ogrodzenia aluminiowe: https:\/\/tabal\.pl\/tabal-alufence\/do-pobrania\/\n\nZ poważaniem\nJędrzej Moraczewski/);
 const st2=strat(s,'panel'),l2=lead(s,st2);l2.draft=l.draft;const one=C.composeMessage(l2,s.config,s.products).body;a.match(one,/Katalog — Ogrodzenia panelowe: https:\/\/tabal\.pl\/ogrodzenia-techfence\/\n\nZ poważaniem/);a.doesNotMatch(one,/Zachęcam/);
 l.draft={subject:'T',body:'Dzień dobry,\n\nOferta: https://tabal.pl/tabal-alufence/\n\nZ poważaniem'};a.equal(C.composeMessage(l,s.config,s.products).body.split('https://tabal.pl/tabal-alufence/\n').length,2,'link z treści nie jest powtarzany');
 a.equal(C.composeMessage(l,{...s.config,auto_catalog:false},s.products).body.includes('realizacje'),false);
});

// ---------- wyszukiwanie: liczba leadów bliżej puli ----------
test('ZADANIE 3.9: domyślnie szybkie odkrywanie i cel liczbowy jako zobowiązanie; pełne badanie na życzenie',()=>{
 const s=base(),st=strat(s,'alu',{limit:100,country:'Polska',province:'lubelskie'});
 a.equal(s.config.search_depth,'lean');a.equal(s.config.fill_target,true);
 const lean=C.task(s,st,'r');
 a.match(lean,/TRYB SZYBKI — OSZCZĘDZAJ LIMIT WORK/);a.match(lean,/CEL LICZBOWY TO ZOBOWIĄZANIE/);a.match(lean,/firma pokrewna to pełnowartościowy lead do poszerzenia oferty i LICZY SIĘ do celu/);a.match(lean,/NIE dodawaj firm o innej głównej działalności/);
 a.doesNotMatch(lean,/JAKOŚĆ ZAMIAST LICZBY|REJESTRY CEIDG \/ KRS: dla każdej firmy|PROFILE SPOŁECZNOŚCIOWE:|KONTAKTY — POGŁĘBIONE WYSZUKIWANIE|DRUGIE PRZEJŚCIE/);
 a.match(lean,/TRAFNOŚĆ — PROFIL DZIAŁALNOŚCI/);a.match(lean,/SIEDZIBA firmy musi leżeć w obszarze/);
 const schema=JSON.parse(lean.slice(lean.lastIndexOf('{\n "schema_version"'))).leads[0];
 for(const k of ['registry','branches','social','contact_search','website_check','draft'])a.equal(k in schema,false,k);for(const k of ['company','address','postal_code','sources','contacts','business_profile','criteria'])a.ok(k in schema,k);
 s.config.search_depth='full';s.config.fill_target=false;const full=C.task(s,st,'r');
 a.match(full,/JAKOŚĆ ZAMIAST LICZBY/);a.match(full,/REJESTRY CEIDG \/ KRS: dla każdej firmy/);a.match(full,/KONTAKTY — POGŁĘBIONE WYSZUKIWANIE/);a.doesNotMatch(full,/TRYB SZYBKI/);a.ok(lean.length<full.length);
 a.ok('registry' in JSON.parse(full.slice(full.lastIndexOf('{\n "schema_version"'))).leads[0]);
});
test('ZADANIE 3.9: uzupełnianie wskazanych firm i etap pełny zawsze badają dokładnie; Work pisze językiem korzyści',()=>{
 const s=base(),st=strat(s,'alu',{research_stage:'full'});
 const full=C.task(s,st,'r');a.doesNotMatch(full,/TRYB SZYBKI/);a.match(full,/JĘZYKIEM KORZYŚCI/);a.match(full,/PRODUCENT, KOMPLETNOŚĆ OFERTY/);a.match(full,/SZYBKI TERMIN REALIZACJI/);a.match(full,/NAZWA FIRMY ODBIORCY: najwyżej RAZ/);a.match(full,/Zakończ treść zwrotem „Z poważaniem”/);a.match(full,/"product_arguments":"Jako producent/);
 const targeted=C.task(s,C.strategy({...st,mode:'targeted',research_stage:'discovery',targets:'lead_ref=1 | ASTOR | astor.example'}),'r');a.doesNotMatch(targeted,/TRYB SZYBKI/);a.match(targeted,/KONTAKTY — POGŁĘBIONE WYSZUKIWANIE/);a.doesNotMatch(targeted,/CEL LICZBOWY TO ZOBOWIĄZANIE/);
});
test('IMPORT 3.9: rekord z szybkiego odkrywania (bez rejestru, oddziałów i social) przechodzi walidację i scoring',()=>{
 const s=base(),st=s.strategies[0],raw=C.sample(st,s,false);for(const k of ['registry','branches','social','contact_search','website_check','draft'])delete raw[k];
 const l=C.validateLead(raw,s,st),sc=C.score(l,s.config);a.ok(Number.isFinite(sc.points));a.equal(sc.checks.source,'ok');
});
