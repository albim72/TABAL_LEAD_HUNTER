"""TABAL Lead Hunter 3.5 — SMTP diagnostics and auto-detection run from the panel (TABAL 23.10 #4).

Every step is reported in plain Polish with a concrete fix. The password is never returned or logged.
Typical TABAL problems this module explains:
  * port 993 / 995 / 143 / 110 — these are mailbox (IMAP/POP3) ports, not sending ports;
  * 465 needs SSL/TLS, 587 needs STARTTLS (a mismatch ends in a TLS error);
  * the TLS certificate is issued for the hosting server name (e.g. serwerXXXX.home.pl), not mail.tabal.pl;
  * the host was not allowed by the server administrator.
"""
import os
import random
import re
import smtplib
import socket
import ssl
import struct
import tempfile
import time
from email.message import EmailMessage
from email.utils import formataddr, formatdate, make_msgid

READ_PORTS = {993: 'IMAP (SSL)', 143: 'IMAP', 995: 'POP3 (SSL)', 110: 'POP3'}
SEND_MODES = [(465, 'ssl'), (587, 'starttls')]
# Mail hosting / providers used in Poland — hosts under these domains may be configured from the panel.
PROVIDER_SUFFIXES = ('home.pl', 'nazwa.pl', 'cyberfolks.pl', 'cyber-folks.pl', 'ovh.net', 'office365.com', 'outlook.com',
                     'gmail.com', 'googlemail.com', 'zenbox.pl', 'linuxpl.com', 'hostinger.com', 'hostido.pl', 'lh.pl',
                     'dhosting.pl', 'mydevil.net', 'webd.pl', 'az.pl', 'atthost.pl', 'kei.pl', 'iq.pl', 'interia.pl',
                     'wp.pl', 'o2.pl', 'onet.pl', 'zoho.eu', 'zoho.com', 'ionos.com', 'ionos.de', 'strato.de', 'seohost.pl',
                     'hekko.pl', 'superhost.pl', 'smtp2go.com', 'sendgrid.net', 'mailgun.org', 'amazonaws.com', 'yandex.com')


def security_for(port):
    return 'ssl' if int(port) == 465 else 'starttls'


def host_ok(host):
    return isinstance(host, str) and 0 < len(host) <= 253 and re.fullmatch(r'[A-Za-z0-9.-]+', host or '') is not None and '.' in host


def decode_cert(der):
    """Subject CN, issuer and SAN names from a DER certificate, without extra packages."""
    pem = ssl.DER_cert_to_PEM_cert(der)
    with tempfile.NamedTemporaryFile('w', suffix='.pem', delete=False) as f:
        f.write(pem)
        name = f.name
    try:
        info = ssl._ssl._test_decode_cert(name)  # stdlib helper; read-only
    except Exception:
        return {}, []
    finally:
        os.unlink(name)
    subject = {k: v for part in info.get('subject', ()) for k, v in part}
    sans = [v for k, v in info.get('subjectAltName', ()) if k == 'DNS']
    issuer = dict(x for part in info.get('issuer', ()) for x in part).get('organizationName', '')
    return {'cn': subject.get('commonName', ''), 'issuer': issuer, 'not_after': info.get('notAfter', '')}, sans


def _connect(host, port, security, context, timeout):
    if security == 'ssl':
        s = smtplib.SMTP_SSL(host, port, timeout=timeout, context=context)
        s.ehlo()
        return s
    s = smtplib.SMTP(host, port, timeout=timeout)
    s.ehlo()
    if not s.has_extn('starttls'):
        s.close()
        raise smtplib.SMTPNotSupportedError('no-starttls')
    s.starttls(context=context)
    s.ehlo()
    return s


def _cert_names(host, port, security, timeout, cafile=None):
    loose = ssl.create_default_context(cafile=cafile)
    loose.check_hostname = False
    loose.verify_mode = ssl.CERT_NONE
    try:
        probe = _connect(host, port, security, loose, timeout)
        meta, sans = decode_cert(probe.sock.getpeercert(binary_form=True))
        probe.close()
        names = [n for n in (sans or [meta.get('cn', '')]) if n]
        return names, meta
    except Exception:
        return [], {}


def diagnose(host, port, security, username='', password='', send_to='', sender_email='', sender_name='TABAL',
             timeout=12, cafile=None):
    """Step-by-step check. Returns dict(ok, steps=[{step, ok, detail, hint}], suggestion={host?, port?, security?})."""
    steps, suggestion = [], {}

    def add(step, ok, detail, hint=''):
        steps.append(dict(step=step, ok=ok, detail=detail, hint=hint))
        return ok

    def result():
        return dict(ok=all(s['ok'] for s in steps), steps=steps, suggestion=suggestion)

    try:
        port = int(port)
    except (TypeError, ValueError):
        add('Port', False, 'Port musi być liczbą.', 'Do wysyłki: 465 (SSL/TLS) albo 587 (STARTTLS).')
        return result()
    if port in READ_PORTS:
        add('Port', False, f'Port {port} to port odbioru poczty — {READ_PORTS[port]}, nie wysyłki.',
            'Wysyłka (SMTP) działa na porcie 465 z szyfrowaniem SSL/TLS albo 587 ze STARTTLS. Port 993 można podać tylko w opcji „kopia w folderze Wysłane”.')
        suggestion.update(port=465, security='ssl')
        return result()
    expected = security_for(port) if port in (465, 587) else security
    if security != expected:
        add('Szyfrowanie', False, f'Port {port} wymaga {"SSL/TLS" if expected == "ssl" else "STARTTLS"}, a wybrano {"SSL/TLS" if security == "ssl" else "STARTTLS"}.',
            'Aplikacja ustawi właściwe szyfrowanie automatycznie po zapisaniu.')
        suggestion.update(security=expected)
        security = expected
    if not (isinstance(host, str) and re.fullmatch(r'[A-Za-z0-9.-]{1,253}', host or '')):
        add('Host', False, 'Podaj nazwę serwera SMTP bez https://, ścieżki i spacji, np. serwer1234.home.pl.', '')
        return result()
    try:
        ips = sorted({x[4][0] for x in socket.getaddrinfo(host, port, proto=socket.IPPROTO_TCP)})
        add('DNS', True, f'{host} → {", ".join(ips[:4])}')
    except OSError:
        add('DNS', False, f'Nazwa {host} nie istnieje albo serwer nie ma dostępu do DNS.', 'Sprawdź pisownię hosta (bez https://). Użyj „Wykryj ustawienia”.')
        return result()
    try:
        with socket.create_connection((host, port), timeout=min(timeout, 8)):
            add('Połączenie', True, f'Port {port} otwarty.')
    except OSError:
        other = 587 if port == 465 else 465
        add('Połączenie', False, f'Port {port} zamknięty lub zablokowany z serwera aplikacji.',
            f'Spróbuj portu {other} ({"STARTTLS" if other == 587 else "SSL/TLS"}). Jeśli oba są zamknięte, dostawca serwera aplikacji blokuje wychodzący SMTP — poproś o odblokowanie.')
        suggestion.update(port=other, security=security_for(other))
        return result()
    smtp = None
    context = ssl.create_default_context(cafile=cafile)
    try:
        smtp = _connect(host, port, security, context, timeout)
        add('Certyfikat TLS', True, 'Szyfrowane połączenie i certyfikat zgodny z nazwą hosta.')
    except ssl.SSLCertVerificationError as e:
        names, meta = _cert_names(host, port, security, timeout, cafile)
        good = [n for n in names if '*' not in n]
        add('Certyfikat TLS', False, f'Certyfikat nie pasuje do „{host}” ({e.verify_message}).' + (f' Wystawiony dla: {", ".join(names[:6])}.' if names else ''),
            'Na hostingu współdzielonym certyfikat jest wystawiony na nazwę serwera. ' + (f'Wpisz jako host: {good[0]} — przycisk „Użyj tej nazwy”.' if good else 'Zapytaj dostawcę poczty o nazwę serwera SMTP z certyfikatem.'))
        if good:
            suggestion.update(host=good[0])
        return result()
    except smtplib.SMTPNotSupportedError:
        add('Szyfrowanie', False, f'Serwer na porcie {port} nie oferuje STARTTLS.', 'Użyj portu 465 z SSL/TLS.')
        suggestion.update(port=465, security='ssl')
        return result()
    except (ssl.SSLError, OSError, smtplib.SMTPException) as e:
        wrong = 'WRONG_VERSION' in str(e).upper() or 'record layer' in str(e).lower()
        add('Szyfrowanie', False, f'Nie udało się nawiązać TLS ({type(e).__name__}).',
            'Para port/szyfrowanie jest niezgodna: 465 = SSL/TLS, 587 = STARTTLS.' if wrong else 'Sprawdź port i szyfrowanie: 465 = SSL/TLS, 587 = STARTTLS.')
        return result()
    try:
        auth = smtp.esmtp_features.get('auth', '').upper().split()
        if not add('Logowanie dostępne', bool(auth), ('Serwer przyjmuje logowanie: ' + ' '.join(auth)) if auth else 'Serwer nie oferuje logowania (AUTH) na tym porcie.',
                   '' if auth else 'Zmień port (465/587) albo zapytaj dostawcę o serwer wysyłkowy.'):
            return result()
        if not password:
            add('Hasło', False, 'Nie podano hasła — sprawdzono połączenie bez logowania.', 'Wpisz hasło skrzynki (albo hasło aplikacji) i sprawdź ponownie.')
            return result()
        try:
            smtp.login(username, password)
            add('Logowanie', True, f'Zalogowano jako {username}.')
        except smtplib.SMTPAuthenticationError as e:
            add('Logowanie', False, f'Serwer odrzucił login lub hasło (kod {e.smtp_code}).',
                'Login to zwykle pełny adres (np. bok@tabal.pl). Sprawdź hasło skrzynki; w Microsoft 365 włącz „Uwierzytelniony SMTP” dla skrzynki, w Google użyj hasła aplikacji.')
            return result()
        except smtplib.SMTPException as e:
            add('Logowanie', False, f'Logowanie nieudane ({type(e).__name__}).', 'Sprawdź login, hasło i czy skrzynka ma włączony SMTP.')
            return result()
        finally:
            password = None
        if send_to:
            msg = EmailMessage()
            msg['From'] = formataddr((sender_name or 'TABAL', sender_email or username))
            msg['To'] = send_to
            msg['Subject'] = 'TABAL Lead Hunter — wiadomość testowa'
            msg['Date'] = formatdate(localtime=False)
            msg['Message-ID'] = make_msgid(domain=(sender_email or username).split('@')[-1])
            msg.set_content('To wiadomość testowa z TABAL Lead Hunter 3.5.\nJeśli ją widzisz, wysyłka z tej skrzynki działa. Sprawdź także folder SPAM.')
            try:
                refused = smtp.send_message(msg, from_addr=sender_email or username, to_addrs=[send_to])
                add('Wiadomość testowa', not refused, f'Serwer przyjął wiadomość do {send_to}. Sprawdź skrzynkę i folder SPAM.' if not refused else 'Serwer odrzucił odbiorcę.')
            except smtplib.SMTPSenderRefused:
                add('Wiadomość testowa', False, f'Serwer nie pozwala wysyłać jako {sender_email} z loginu {username}.', 'Adres nadawcy musi należeć do logowanego konta (albo mieć uprawnienie „Wyślij jako”).')
            except smtplib.SMTPException as e:
                add('Wiadomość testowa', False, f'Wysyłka nieudana ({type(e).__name__}).', 'Sprawdź limity skrzynki i adres odbiorcy.')
        return result()
    finally:
        try:
            smtp.quit()
        except Exception:
            pass


def _nameservers():
    out = []
    try:
        for line in open('/etc/resolv.conf', encoding='utf-8'):
            p = line.split()
            if len(p) >= 2 and p[0] == 'nameserver' and re.fullmatch(r'[0-9.]+', p[1]):
                out.append(p[1])
    except OSError:
        pass
    return out + ['1.1.1.1', '8.8.8.8']


def mx_hosts(domain, timeout=3.0):
    """Minimal DNS MX query (stdlib only). Returns host names sorted by preference; [] when DNS over UDP is unavailable."""
    if not host_ok(domain):
        return []
    qid = random.randint(0, 65535)
    q = struct.pack('>HHHHHH', qid, 0x0100, 1, 0, 0, 0) + b''.join(bytes([len(p)]) + p.encode('idna') for p in domain.split('.')) + b'\0' + struct.pack('>HH', 15, 1)

    def name(buf, i):
        parts, jumped, end = [], False, None
        for _ in range(64):
            n = buf[i]
            if n == 0:
                i += 1
                break
            if n & 0xC0 == 0xC0:
                if not jumped:
                    end = i + 2
                i = ((n & 0x3F) << 8) | buf[i + 1]
                jumped = True
                continue
            parts.append(buf[i + 1:i + 1 + n].decode('ascii', 'replace'))
            i += 1 + n
        return '.'.join(parts), (end if jumped else i)

    for ns in _nameservers()[:3]:
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
                s.settimeout(timeout)
                s.sendto(q, (ns, 53))
                buf, _ = s.recvfrom(4096)
            rid, flags, qd, an = struct.unpack('>HHHH', buf[:8])
            if rid != qid:
                continue
            i = 12
            for _ in range(qd):
                _, i = name(buf, i)
                i += 4
            res = []
            for _ in range(an):
                _, i = name(buf, i)
                typ, _, _, ln = struct.unpack('>HHIH', buf[i:i + 10])
                i += 10
                if typ == 15:
                    pref = struct.unpack('>H', buf[i:i + 2])[0]
                    host, _ = name(buf, i + 2)
                    res.append((pref, host.rstrip('.').lower()))
                i += ln
            return [h for _, h in sorted(res)]
        except (OSError, struct.error, IndexError, ValueError):
            continue
    return []


def provider_hint(mx):
    """Known providers: (smtp host, port, security, note)."""
    for h in mx:
        if h.endswith('mail.protection.outlook.com'):
            return 'smtp.office365.com', 587, 'starttls', 'Microsoft 365: włącz „Uwierzytelniony SMTP” dla skrzynki (często domyślnie wyłączony).'
        if h.endswith('google.com') or h.endswith('googlemail.com'):
            return 'smtp.gmail.com', 465, 'ssl', 'Google Workspace: użyj hasła aplikacji (wymaga weryfikacji dwuetapowej).'
        if h.endswith('mail.ovh.net') or h.endswith('ovh.net'):
            return 'ssl0.ovh.net', 465, 'ssl', 'OVH: login = pełny adres e-mail.'
    return None


def detect(sender_email, username='', password='', host_hint='', timeout=8, budget=45.0, cafile=None):
    """Tries likely hosts × (465 SSL, 587 STARTTLS). Returns dict(found={host,port,security}|None, tried=[...], note)."""
    start = time.monotonic()
    domain = (sender_email or username or '').split('@')[-1].strip().lower()
    mx = mx_hosts(domain) if domain else []
    hint = provider_hint(mx)
    hosts, tried, note = [], [], ''
    if host_hint:
        hosts.append(host_hint.strip().lower())
    if hint:
        hosts.append(hint[0])
        note = hint[3]
    hosts += [f'mail.{domain}', f'smtp.{domain}'] + mx[:2] + ([domain] if domain else [])
    seen = []
    for h in hosts:
        if host_ok(h) and h not in seen:
            seen.append(h)
    queue = list(seen)
    while queue and time.monotonic() - start < budget and len(tried) < 16:
        h = queue.pop(0)
        try:
            socket.getaddrinfo(h, 465)
        except OSError:
            tried.append(dict(host=h, port=None, result='brak w DNS'))
            continue
        for port, sec in ([(hint[1], hint[2])] if hint and h == hint[0] else SEND_MODES):
            if time.monotonic() - start >= budget:
                break
            try:
                with socket.create_connection((h, port), timeout=min(timeout, 6)):
                    pass
            except OSError:
                tried.append(dict(host=h, port=port, result='port zamknięty'))
                continue
            try:
                s = _connect(h, port, sec, ssl.create_default_context(cafile=cafile), timeout)
            except ssl.SSLCertVerificationError:
                names, _ = _cert_names(h, port, sec, timeout, cafile)
                good = [n for n in names if '*' not in n and n not in seen]
                tried.append(dict(host=h, port=port, result='certyfikat dla: ' + ', '.join(names[:4])))
                for n in good[:2]:
                    seen.append(n)
                    queue.insert(0, n)
                break
            except Exception as e:
                tried.append(dict(host=h, port=port, result=f'błąd TLS ({type(e).__name__})'))
                continue
            try:
                auth = bool(s.esmtp_features.get('auth'))
                login = None
                if auth and password:
                    try:
                        s.login(username or sender_email, password)
                        login = True
                    except smtplib.SMTPException:
                        login = False
                tried.append(dict(host=h, port=port, result='OK' + ('' if auth else ' (bez AUTH)') + (' · logowanie OK' if login else ' · logowanie odrzucone' if login is False else '')))
                if auth and login is not False:
                    return dict(found=dict(host=h, port=port, security=sec), tried=tried, note=note, mx=mx[:3], login=login)
            finally:
                try:
                    s.quit()
                except Exception:
                    pass
    return dict(found=None, tried=tried, note=note or 'Nie znaleziono działającego serwera. Zapytaj administratora poczty TABAL o host SMTP (panel hostingu → poczta → konfiguracja programu pocztowego).', mx=mx[:3], login=None)
