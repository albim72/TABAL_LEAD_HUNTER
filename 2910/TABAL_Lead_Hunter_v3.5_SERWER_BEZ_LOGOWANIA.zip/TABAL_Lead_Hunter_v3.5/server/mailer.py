"""Server SMTP outbox. Password is held in memory (or, only on explicit request, in a 0600 file next to the database).

3.5 (TABAL 23.10 #4, #5, #9):
  * unattended sending — the queue keeps working after the panel is closed; every message is re-checked against
    the stored data right before sending (changed status / draft / address = cancelled, never sent);
  * daily limit, interval down to 10 s, batches up to 300 messages per request;
  * optional HTML part (company signature), optional copy in the mailbox "Sent" folder (IMAP) or Bcc to the sender;
  * port / encryption checks with explanations (993 = IMAP, 465 = SSL/TLS, 587 = STARTTLS);
  * non-secret SMTP settings survive a restart (smtp.json in the data directory).
"""
import imaplib
import json
import os
import re
import smtplib
import sqlite3
import ssl
import threading
import time
import uuid
from datetime import datetime, timedelta, timezone
from email.message import EmailMessage
from email.utils import formataddr, formatdate
from pathlib import Path

READ_PORTS = {993: 'IMAP (SSL)', 143: 'IMAP', 995: 'POP3 (SSL)', 110: 'POP3'}
MAX_BATCH = 300
CHANGED = 'Dane firmy, szkic lub status zmieniły się od zatwierdzenia — wiadomość anulowano przed wysyłką. Dodaj aktualną wiadomość ponownie.'


def stamp():
    return datetime.now(timezone.utc).isoformat(timespec='seconds')


def require(ok, message):
    if not ok:
        raise ValueError(message)


def email(value):
    require(isinstance(value, str) and len(value) <= 254 and re.fullmatch(r"[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Za-z0-9](?:[A-Za-z0-9.-]*[A-Za-z0-9])?\.[A-Za-z]{2,63}", value), 'Podaj jeden prawidłowy adres e-mail (bez nazwy i listy odbiorców).')
    return value.strip()


def clean(value, label, limit):
    require(isinstance(value, str) and value.strip() and len(value) <= limit, 'Sprawdź pole: ' + label)
    require('\x00' not in value, 'Niedozwolony znak w polu: ' + label)
    return value.strip()


def message(raw):
    require(isinstance(raw, dict), 'Nieprawidłowa wiadomość.')
    require(raw.get('mode') == 'pilot' and raw.get('is_demo') is False, 'Wysyłka tylko ze zbioru Mój pilot.')
    require(raw.get('status') == 'TO_CONTACT' and raw.get('do_not_contact') is False, 'Lead musi mieć status DO KONTAKTU bez blokady kontaktu.')
    require(raw.get('verified_email') is True, 'Brak potwierdzonego e-maila.')
    subject = clean(raw.get('subject'), 'temat', 300)
    require('\n' not in subject and '\r' not in subject, 'Temat musi być jednowierszowy.')
    html = raw.get('html') or ''
    require(isinstance(html, str) and len(html) <= 200000 and '\x00' not in html, 'Nieprawidłowa wersja HTML wiadomości.')
    out = dict(lead_id=clean(raw.get('lead_id'), 'ID firmy', 150), company=clean(raw.get('company'), 'firma', 500),
               to=email(raw.get('to')), subject=subject, body=clean(raw.get('body'), 'treść', 12000))
    if html:
        out['html'] = html
    return out


class DeliveryError(Exception):
    def __init__(self, status, reason):
        super().__init__(reason)
        self.status = status


def build_message(config, job):
    msg = EmailMessage()
    msg['From'] = formataddr((config['sender_name'], config['sender_email']))
    msg['To'] = job['to']
    msg['Subject'] = job['subject']
    msg['Date'] = formatdate(localtime=False)
    msg['Message-ID'] = job['message_id']
    msg.set_content(job['body'])
    if job.get('html'):
        msg.add_alternative('<!doctype html><html><body>' + job['html'] + '</body></html>', subtype='html')
    return msg


def imap_copy(config, msg):
    """Stores the sent message in the mailbox "Sent" folder. Never raises; returns a short status."""
    host = config.get('imap_host') or config['host']
    try:
        port = int(config.get('imap_port') or 993)
        box = imaplib.IMAP4_SSL(host, port, ssl_context=ssl.create_default_context(), timeout=20)
    except Exception as e:
        return f'kopia w „Wysłanych”: brak połączenia IMAP ({type(e).__name__})'
    try:
        box.login(config['username'], config['password'])
        folder = config.get('imap_folder') or ''
        if not folder:
            typ, rows = box.list()
            names = []
            for row in rows or []:
                line = row.decode('utf-8', 'replace') if isinstance(row, bytes) else str(row)
                m = re.match(r'\((?P<flags>[^)]*)\)\s+(?:"[^"]*"|NIL)\s+(?P<name>.+)$', line)
                if m:
                    names.append((m.group('flags'), m.group('name').strip()))
            flagged = [n for f, n in names if '\\Sent' in f]
            guess = [n for f, n in names if re.search(r'sent|wys&aui-ane|wys.?ane|elementy wys', n, re.I)]
            folder = (flagged or guess or ['Sent'])[0]
        if not folder.startswith('"'):
            folder = '"' + folder.replace('"', '') + '"'
        typ, _ = box.append(folder, '\\Seen', imaplib.Time2Internaldate(time.time()), msg.as_bytes())
        return 'kopia w „Wysłanych”: zapisano' if typ == 'OK' else 'kopia w „Wysłanych”: serwer odmówił zapisu'
    except Exception as e:
        return f'kopia w „Wysłanych”: nie zapisano ({type(e).__name__})'
    finally:
        try:
            box.logout()
        except Exception:
            pass


class SMTPTransport:
    def send(self, config, job):
        smtp = None
        attempted = False
        note = ''
        try:
            context = ssl.create_default_context()
            if config['security'] == 'ssl':
                smtp = smtplib.SMTP_SSL(config['host'], config['port'], timeout=20, context=context)
            else:
                smtp = smtplib.SMTP(config['host'], config['port'], timeout=20)
                smtp.ehlo()
                smtp.starttls(context=context)
                smtp.ehlo()
            smtp.login(config['username'], config['password'])
            msg = build_message(config, job)
            recipients = [job['to']] + ([config['sender_email']] if config.get('bcc_self') and job.get('kind') != 'test' else [])
            attempted = True
            refused = smtp.send_message(msg, from_addr=config['sender_email'], to_addrs=recipients)
            if refused and job['to'] in refused:
                raise DeliveryError('failed', 'Serwer SMTP odrzucił odbiorcę. Sprawdź adres i ustawienia.')
            if config.get('imap_copy') and job.get('kind') != 'test':
                note = imap_copy(config, msg)
            return note
        except DeliveryError:
            raise
        except smtplib.SMTPAuthenticationError:
            raise DeliveryError('failed', 'Serwer odrzucił logowanie. Sprawdź login, hasło aplikacji i dostęp SMTP (Wysyłka → Sprawdź połączenie).') from None
        except (smtplib.SMTPRecipientsRefused, smtplib.SMTPSenderRefused, smtplib.SMTPDataError):
            raise DeliveryError('failed', 'SMTP jawnie odrzucił wiadomość. Sprawdź adresy i ograniczenia skrzynki.') from None
        except ssl.SSLCertVerificationError:
            raise DeliveryError('failed', 'Certyfikat serwera SMTP nie pasuje do hosta. Użyj „Sprawdź połączenie” — pokaże właściwą nazwę serwera.') from None
        except Exception:
            # Do not leak SMTP replies, password or credentials via diagnostics.
            status = 'uncertain' if attempted else 'failed'
            reason = ('Brak pewności, czy SMTP przyjął wiadomość. Sprawdź skrzynkę lub logi operatora; nie ponawiaj automatycznie.'
                      if attempted else 'Nie udało się połączyć lub zalogować przez TLS. Użyj „Sprawdź połączenie” w zakładce Wysyłka — pokaże, który krok zawodzi.')
            raise DeliveryError(status, reason) from None
        finally:
            if smtp:
                try:
                    smtp.close()  # QUIT errors must not turn an accepted message into a failure.
                except Exception:
                    pass


class Outbox:
    def __init__(self, path, transport=None, clock=time.monotonic, config_path=None):
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(path, check_same_thread=False)
        self.db.row_factory = sqlite3.Row
        self.lock = threading.RLock()
        self.clock = clock
        self.transport = transport or SMTPTransport()
        self.config = None
        self.defaults = {}
        self.paused = True
        self.owner = None
        self.heartbeat = -1000
        self.allowed = set()
        self.next_send = 0
        self.running = False
        self.unattended = False
        self.limit_wait = False
        self.validator = None
        self.config_path = Path(config_path) if config_path else None
        self.detected_hosts = set()
        self.stop = threading.Event()
        with self.db:
            self.db.execute('CREATE TABLE IF NOT EXISTS jobs (id TEXT PRIMARY KEY, email_key TEXT, status TEXT, payload TEXT, created_at TEXT, sent_at TEXT, error TEXT, attempts INTEGER DEFAULT 0)')
            cols = {r['name'] for r in self.db.execute('PRAGMA table_info(jobs)')}
            if 'note' not in cols:
                self.db.execute("ALTER TABLE jobs ADD COLUMN note TEXT DEFAULT ''")
            self.db.execute("UPDATE jobs SET status='uncertain',error='Przerwano proces podczas wysyłki. Sprawdź przyjęcie wiadomości przez SMTP przed dalszym kontaktem.' WHERE status='sending'")

    # ---------- state ----------
    def jobs(self):
        with self.lock:
            return [dict(json.loads(row['payload']), id=row['id'], status=row['status'], created_at=row['created_at'], sent_at=row['sent_at'], error=row['error'], attempts=row['attempts'], note=row['note'] or '')
                    for row in self.db.execute('SELECT * FROM jobs ORDER BY created_at,id')]

    def sent_last_24h(self):
        since = (datetime.now(timezone.utc) - timedelta(hours=24)).isoformat(timespec='seconds')
        return self.db.execute("SELECT COUNT(*) FROM jobs WHERE status IN ('sent','uncertain','sending') AND sent_at<>'' AND sent_at>=? AND email_key NOT LIKE 'test:%'", (since,)).fetchone()[0]

    def snapshot(self):
        with self.lock:
            jobs = self.jobs()
            queued = sum(j['status'] == 'queued' for j in jobs)
            interval = (self.config or {}).get('interval', 30)
            return dict(configured=bool(self.config), paused=self.paused, active=self.running, unattended=self.unattended,
                        connected=self.clock()-self.heartbeat < 15, limit_wait=self.limit_wait,
                        sent_24h=self.sent_last_24h(), queued=queued, eta_seconds=queued*interval,
                        config={k: v for k, v in (self.config or {}).items() if k != 'password'},
                        remembered=bool(self.config and self.config.get('remember_password')),
                        defaults=dict(self.defaults), jobs=jobs)

    # ---------- configuration ----------
    def configure(self, raw):
        with self.lock:
            require(not self.running and self.paused, 'Najpierw wstrzymaj kolejkę i poczekaj na zakończenie bieżącej wysyłki.')
            cfg = {k: clean(raw.get(k), k, limit) for k, limit in [('host',253),('username',254),('sender_name',150)]}
            require(re.fullmatch(r'[A-Za-z0-9.-]+', cfg['host']), 'Host SMTP: podaj nazwę bez https:// i ścieżki.')
            require('\r' not in cfg['sender_name'] and '\n' not in cfg['sender_name'], 'Nazwa nadawcy musi być jednowierszowa.')
            cfg['sender_email'] = email(raw.get('sender_email'))
            try:
                cfg['port'] = int(raw.get('port', 0))
                cfg['interval'] = int(raw.get('interval', 30))
                cfg['daily_limit'] = int(raw.get('daily_limit', 200) if raw.get('daily_limit') not in (None, '') else 200)
            except (TypeError, ValueError):
                raise ValueError('Port, odstęp i limit dzienny muszą być liczbami.') from None
            require(cfg['port'] not in READ_PORTS, f'Port {cfg["port"]} to port odbioru poczty ({READ_PORTS.get(cfg["port"], "")}), nie wysyłki. Do wysyłki użyj 465 (SSL/TLS) albo 587 (STARTTLS).')
            cfg['security'] = raw.get('security')
            require(cfg['security'] in ('ssl', 'starttls'), 'Wymagane szyfrowanie SSL/TLS lub STARTTLS.')
            notes = []
            if cfg['port'] == 465 and cfg['security'] != 'ssl':
                cfg['security'] = 'ssl'; notes.append('Port 465 wymaga SSL/TLS — ustawiono automatycznie.')
            if cfg['port'] in (587, 25, 2525) and cfg['security'] != 'starttls':
                cfg['security'] = 'starttls'; notes.append(f'Port {cfg["port"]} wymaga STARTTLS — ustawiono automatycznie.')
            require(1 <= cfg['port'] <= 65535 and 10 <= cfg['interval'] <= 3600 and 0 <= cfg['daily_limit'] <= 5000, 'Port: 1–65535; odstęp: 10–3600 sekund; limit dzienny: 0–5000 (0 = bez limitu).')
            cfg['bcc_self'] = raw.get('bcc_self') in (True, 'on', 'true', '1')
            cfg['imap_copy'] = raw.get('imap_copy') in (True, 'on', 'true', '1')
            imap_host = str(raw.get('imap_host') or '').strip()
            require(not imap_host or re.fullmatch(r'[A-Za-z0-9.-]+', imap_host), 'Host IMAP: podaj nazwę bez https:// i ścieżki.')
            cfg['imap_host'] = imap_host
            try:
                cfg['imap_port'] = int(raw.get('imap_port') or 993)
            except (TypeError, ValueError):
                raise ValueError('Port IMAP musi być liczbą (zwykle 993).') from None
            cfg['imap_folder'] = str(raw.get('imap_folder') or '').strip()[:120]
            cfg['remember_password'] = raw.get('remember_password') in (True, 'on', 'true', '1')
            same = self.config and self.config.get('host') == cfg['host'] and self.config.get('username') == cfg['username']
            cfg['password'] = raw.get('password') or ((self.config or {}).get('password', '') if same or not self.config else '')
            require(isinstance(cfg['password'],str) and 0 < len(cfg['password']) <= 2000, 'Podaj hasło SMTP lub hasło aplikacji.')
            # Sender is frozen into every job; changes never redirect an approved batch.
            for job in self.jobs():
                if job['status'] in ('queued','failed'):
                    require(job['sender_email'] == cfg['sender_email'], 'Anuluj oczekujące/błędne wiadomości przed zmianą adresu nadawcy.')
            self.config = cfg
            self.save_config()
            snap = self.snapshot()
            snap['notes'] = notes
            return snap

    def save_config(self):
        if not self.config_path or not self.config:
            return
        data = {k: v for k, v in self.config.items() if k != 'password'}
        if self.config.get('remember_password'):
            data['password'] = self.config['password']
        tmp = self.config_path.with_suffix('.tmp')
        fd = os.open(str(tmp), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False)
        os.replace(tmp, self.config_path)
        try:
            os.chmod(self.config_path, 0o600)
        except OSError:
            pass

    def load_saved(self, env_password=''):
        """Restores panel settings after restart. Password: remembered one, else the .env one for the same host."""
        if not self.config_path or not self.config_path.exists():
            return False
        try:
            data = json.loads(self.config_path.read_text(encoding='utf-8'))
        except (OSError, ValueError):
            return False
        password = data.get('password') or (env_password if env_password and data.get('host') == self.defaults.get('host') else '')
        saved = {k: v for k, v in data.items() if k != 'password'}
        if not password:
            self.defaults = dict(self.defaults, **saved)
            return False
        try:
            with self.lock:
                self.config = None
                self.configure(dict(data, password=password))
            return True
        except ValueError:
            self.defaults = dict(self.defaults, **saved)
            return False

    # ---------- queue ----------
    def enqueue(self, raw, owner):
        with self.lock:
            require(self.config, 'Najpierw skonfiguruj SMTP.')
            self.claim(owner, force=True)
            require(isinstance(raw, list) and 1 <= len(raw) <= MAX_BATCH, f'Jedna partia: 1–{MAX_BATCH} wiadomości.')
            checked = [message(item) for item in raw]
            require(len({m['to'].lower() for m in checked}) == len(checked), 'Powtórzony adres w partii. Zostaw jedną wiadomość na skrzynkę.')
            for m in checked:
                require(not self.db.execute("SELECT 1 FROM jobs WHERE email_key=? AND status IN ('queued','sending','sent','uncertain')", (m['to'].lower(),)).fetchone(), 'Adres jest już w kolejce, został obsłużony albo ma niepewny wynik: '+m['to'])
            with self.db:
                for m in checked:
                    jobid = str(uuid.uuid4())
                    m.update(sender_email=self.config['sender_email'], sender_name=self.config['sender_name'], message_id=f'<{jobid}@{self.config["sender_email"].split("@")[1]}>')
                    self.db.execute('INSERT INTO jobs (id,email_key,status,payload,created_at,sent_at,error) VALUES (?,?,?,?,?,?,?)',
                                    (jobid,m['to'].lower(),'queued',json.dumps(m,ensure_ascii=False),stamp(),'',''))
            self.paused = True
            # Explicit resume after review; enqueue itself never starts delivery.
            return self.snapshot()

    def test_message(self, owner):
        with self.lock:
            require(self.config, 'Najpierw skonfiguruj SMTP.')
            self.claim(owner, force=True)
            require(not self.running and not any(j['status']=='queued' for j in self.jobs()), 'Test wykonaj przy pustej kolejce oczekujących wiadomości.')
            jobid=str(uuid.uuid4())
            data=dict(kind='test',lead_id='smtp-test:'+jobid,company='Test własnej skrzynki',to=self.config['sender_email'],sender_email=self.config['sender_email'],sender_name=self.config['sender_name'],subject='TABAL Lead Hunter — test SMTP',body='To wiadomość testowa wysłana przez moduł TABAL Lead Hunter v3.5.',message_id=f'<{jobid}@{self.config["sender_email"].split("@")[1]}>')
            with self.db:
                self.db.execute('INSERT INTO jobs (id,email_key,status,payload,created_at,sent_at,error) VALUES (?,?,?,?,?,?,?)',(jobid,'test:'+jobid,'queued',json.dumps(data),stamp(),'',''))
            self.paused=True
            return self.snapshot()

    def active_other(self, owner):
        return self.owner not in (None, owner) and self.clock()-self.heartbeat < 15

    def claim(self, owner, force=False):
        """3.5: an explicit operator action (add to queue, start, test, retry) takes the queue over — safe, because every
        message is re-checked against the stored data right before sending. Background syncs of other tabs never take over."""
        require(isinstance(owner, str) and 10 <= len(owner) <= 100, 'Brak identyfikatora sesji.')
        require(force or not self.active_other(owner), 'Kolejkę obsługuje inna karta. Wstrzymaj ją lub zamknij i odczekaj 15 sekund.')
        if self.owner != owner:
            if not self.unattended:
                self.paused = True
            self.allowed.clear()
        self.owner = owner

    def sync(self, owner, allowed, writable=True, observed=None):
        with self.lock:
            if self.active_other(owner):
                # Another tab operates the queue: read-only view, nothing is cancelled or taken over.
                return self.snapshot()
            self.claim(owner)
            require(isinstance(allowed,list) and len(allowed) <= 20000, 'Nieprawidłowa lista kolejki.')
            observed = set(observed) if observed is not None else {j['id'] for j in self.jobs()}
            self.heartbeat = self.clock()
            self.allowed = set(allowed) if writable else set()
            if not writable:
                self.paused = True
            # A changed status/address/draft or removed lead invalidates its pending approval.
            with self.db:
                for job in self.jobs():
                    if job['status'] == 'queued' and job['id'] in observed and job['id'] not in self.allowed:
                        self.db.execute("UPDATE jobs SET status='cancelled',error='Zmieniono dane, szkic lub status firmy. Dodaj aktualną wiadomość ponownie.' WHERE id=?",(job['id'],))
            return self.snapshot()

    def control(self, action, jobid='', owner='', unattended=False):
        with self.lock:
            if action == 'pause':
                self.paused = True
            elif action == 'resume':
                self.claim(owner, force=True)
                require(self.config, 'Najpierw skonfiguruj i sprawdź skrzynkę SMTP.')
                if unattended:
                    require(self.validator is not None, 'Wysyłka bez otwartego panelu jest niedostępna w tym trybie uruchomienia.')
                    require(any(j['status'] == 'queued' for j in self.jobs()), 'Brak wiadomości w kolejce.')
                    self.unattended = True
                else:
                    require(self.clock()-self.heartbeat < 15, 'Połącz panel i skonfiguruj SMTP przed wznowieniem.')
                    require(self.allowed, 'Brak zatwierdzonych wiadomości. Odśwież kolejkę.')
                    self.unattended = False
                self.paused = False
            elif action == 'cancel':
                with self.db:
                    row = self.db.execute("UPDATE jobs SET status='cancelled',error='Anulowano przez operatora.' WHERE id=? AND status IN ('queued','failed')",(jobid,))
                    require(row.rowcount, 'Można anulować tylko oczekującą lub błędną wiadomość. Trwającej wysyłki nie można cofnąć.')
            elif action == 'cancel-all':
                with self.db:
                    self.db.execute("UPDATE jobs SET status='cancelled',error='Anulowano przez operatora (cała kolejka).' WHERE status='queued'")
                self.paused = True
            elif action == 'retry':
                require(self.paused, 'Wstrzymaj kolejkę przed ponowieniem.')
                self.claim(owner, force=True)
                job = next((j for j in self.jobs() if j['id']==jobid),None)
                require(job and job['status']=='failed', 'Ponowienie tylko po jednoznacznym błędzie, nigdy dla niepewnego wyniku.')
                require(jobid in self.allowed, 'Treść lub status firmy zmieniły się. Anuluj i dodaj aktualną wiadomość.')
                require(not self.db.execute("SELECT 1 FROM jobs WHERE email_key=? AND id<>? AND status IN ('queued','sending','sent','uncertain')",(job['to'].lower(),jobid)).fetchone(),'Ten adres ma już inną aktywną lub wysłaną wiadomość.')
                with self.db:
                    self.db.execute("UPDATE jobs SET status='queued',error='' WHERE id=?",(jobid,))
            else:
                raise ValueError('Nieznana operacja kolejki.')
            return self.snapshot()

    def run_one(self):
        with self.lock:
            if not self.unattended and self.clock()-self.heartbeat >= 15:
                self.paused = True
            if self.paused or not self.config or self.running or self.clock() < self.next_send:
                return False
            limit = int(self.config.get('daily_limit') or 0)
            if limit and self.sent_last_24h() >= limit:
                self.limit_wait = True
                return False
            self.limit_wait = False
            job = next((j for j in self.jobs() if j['status']=='queued' and (self.unattended or j['id'] in self.allowed)),None)
            if not job:
                if self.unattended:
                    self.paused = True
                    self.unattended = False
                return False
            self.running = True
            # 3.5: with a validator (server), EVERY message is re-checked against stored data right before sending.
            check = self.validator is not None and job.get('kind') != 'test'
        try:
            if check:
                try:
                    valid = bool(self.validator(job)) if self.validator else False
                except Exception:
                    valid = False
                if not valid:
                    with self.lock:
                        with self.db:
                            self.db.execute("UPDATE jobs SET status='cancelled',error=? WHERE id=? AND status='queued'",(CHANGED,job['id']))
                        self.running = False
                    return True
            with self.lock:
                row = self.db.execute('SELECT status FROM jobs WHERE id=?',(job['id'],)).fetchone()
                if self.paused or not self.config or not row or row['status'] != 'queued':
                    self.running = False
                    return False
                cfg = dict(self.config, sender_email=job['sender_email'], sender_name=job['sender_name'])
                with self.db:
                    self.db.execute("UPDATE jobs SET status='sending',attempts=attempts+1 WHERE id=?",(job['id'],))
        except BaseException:
            with self.lock:
                self.running = False
            raise
        status, error, sent_at, note = 'sent', '', '', ''
        try:
            note = self.transport.send(cfg, job) or ''
            sent_at = stamp()
        except DeliveryError as exc:
            status, error = exc.status, str(exc)
        except Exception:
            status, error = 'uncertain', 'Nieznany wynik wysyłki. Sprawdź logi skrzynki; automatyczne ponowienie zablokowane.'
        finally:
            with self.lock:
                with self.db:
                    self.db.execute('UPDATE jobs SET status=?,sent_at=?,error=?,note=? WHERE id=?',(status,sent_at,error,str(note)[:300],job['id']))
                self.running = False
                self.next_send = self.clock()+cfg['interval']
                if status != 'sent':
                    self.paused = True
                    self.unattended = False
        return True

    def work(self):
        while not self.stop.wait(0.5):
            try:
                self.run_one()
            except Exception:
                # A persistence failure must never cause automatic resend.
                with self.lock:
                    self.paused = True
                    self.running = False
                    self.unattended = False

    def close(self):
        self.stop.set()
        with self.lock:
            self.db.close()
