# Raport testów — TABAL Lead Hunter 3.5 (28.10.2026)

| Zestaw | Polecenie | Wynik | Plik |
|---|---|---|---|
| Logika (przeglądarka + walidator serwera) | `npm test` | 142 / 142 (nowe 3.5: 15) | `test-results/core-v35.tap` |
| Serwer, kolejka SMTP, diagnostyka | `python -m pytest tests/test_mail.py tests/test_server.py tests/test_smtp_diag.py tests/test_smtp_env.py tests/test_v35_mail.py` | 64 / 64 (nowe 3.5: 17) | `test-results/server-v35.txt` |
| Przeglądarka (Playwright, Gunicorn) | `npm run test:browser` | 33 / 33 | `test-results/browser-v35.txt`, `browser-v35.json` |
| Restart Gunicorn i kopia baz | `python tests/deployment_smoke.py` | 2 / 2 | `test-results/deployment-v35.txt` |
| Pełny proces wysyłki (lokalny SMTP z TLS) | `npm run test:e2e-mail` | 6 / 6, 3 wiadomości sprawdzone | `test-results/e2e-mail-v35.txt`, `e2e-mail-v35.json`, `e2e-mail-v35-przyklad.eml`, zrzuty `scenariusz-v35-*.png` |

## Co obejmują nowe testy (uwagi z 23.10)
1. Import: schema_version jako tekst, tekst i ``` wokół JSON, pola companies / data.leads, komentarze i przecinki, źródła jako tekst, kontakt jako obiekt, polskie klucze kryteriów, ucięty plik (odzyskanie rekordów), JSON Lines, kilka bloków JSON, lead bez sources; w przeglądarce: nieznany batch_id = ostrzeżenie w podglądzie, anulowanie nic nie zapisuje.
2. Terra: tryb wyczerpujący w zadaniu, model i pokrycie zapytań w raporcie importu, zadanie uzupełniające tylko dla niesprawdzonych miejscowości.
3. Link do katalogu przed pozdrowieniem, bez dublowania; strona produktu gdy brak katalogu.
4. Port 993 → wyjaśnienie; szyfrowanie wg portu; diagnostyka na prawdziwym serwerze TLS: pełny sukces z testem, certyfikat wystawiony na inną nazwę (podpowiedź hosta), zła para port/szyfrowanie; polityka hostów; zapis ustawień (hasło tylko na żądanie, plik 600).
5. Sygnatura tekst + HTML (oczyszczanie skryptów, javascript:, zdarzeń), wiadomość multipart, zastępowanie starego podpisu.
6. Odbiorca wg roli (zaopatrzeniowiec przed biurem i prezesem), ręczny wybór, adres „do weryfikacji” tylko po zatwierdzeniu (zachowane po zapisie).
7. Odznaczanie po zmianie statusu i po dodaniu do kolejki (przeglądarka, e2e).
8. Bielawa 58-260 przy Warszawa +50 km = poza obszarem, kara, archiwum; wieś Bielawa 05-520 = „nie sprawdzono” bez kary; oddział w obszarze wystarcza; strategia wojewódzka.
9. Wysyłka po zamknięciu panelu z ponownym sprawdzeniem każdej wiadomości, anulowanie zmienionych, limit dobowy, 300 w partii, anulowanie całej kolejki, przejęcie kolejki po odświeżeniu / przez drugą osobę, dodanie + start w jednym żądaniu.

## Granice
Dane syntetyczne i lokalny serwer SMTP z TLS. Nie uruchamiano rzeczywistego researchu w Work ani wysyłki z bok@tabal.pl.
