#!/usr/bin/env python3
"""TABAL Lead Hunter 3.5 — diagnostyka SMTP skrzynki nadawczej (np. bok@tabal.pl).

Sprawdza po kolei: nazwę hosta (DNS), otwarte porty 465/587, certyfikat TLS (czy pasuje do hosta),
możliwości serwera (EHLO/AUTH), logowanie i — opcjonalnie — wysyła jedną wiadomość testową.
Hasło nie jest nigdzie wypisywane ani zapisywane.

Użycie (w katalogu aplikacji, z wpisami w .env albo z parametrami):
  python3 scripts/smtp_diag.py                         # DNS, porty, TLS, EHLO (bez logowania)
  python3 scripts/smtp_diag.py --login                 # + logowanie (hasło z TABAL_SMTP_PASSWORD albo pytanie)
  python3 scripts/smtp_diag.py --login --send-to adres@tabal.pl
  python3 scripts/smtp_diag.py --host serwer.example.pl --port 587 --security starttls --login
Windows: py scripts\\smtp_diag.py --login
"""
import argparse, getpass, os, smtplib, socket, ssl, sys, tempfile
from email.message import EmailMessage
from email.utils import formataddr, formatdate, make_msgid
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OK, BAD, INFO = '  [OK] ', '  [!!] ', '  [..] '


def env_file():
    try:
        for line in (ROOT / '.env').read_text(encoding='utf-8').splitlines():
            line = line.strip()
            if line and not line.startswith('#') and '=' in line:
                k, v = line.split('=', 1)
                if k.strip().startswith('TABAL_'):
                    os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))
    except OSError:
        pass


def decode_cert(der):
    """Subject CN and SAN names from a DER certificate, without extra packages."""
    pem = ssl.DER_cert_to_PEM_cert(der)
    with tempfile.NamedTemporaryFile('w', suffix='.pem', delete=False) as f:
        f.write(pem)
        name = f.name
    try:
        info = ssl._ssl._test_decode_cert(name)  # stdlib helper; read-only
    except Exception:
        return {}, []
    finally:
        os.unlink(name)
    subject = {k: v for part in info.get('subject', ()) for k, v in part}
    sans = [v for k, v in info.get('subjectAltName', ()) if k == 'DNS']
    return {'cn': subject.get('commonName', ''), 'issuer': dict(x for part in info.get('issuer', ()) for x in part).get('organizationName', ''),
            'not_after': info.get('notAfter', '')}, sans


def connect(host, port, security, context, timeout=15):
    if security == 'ssl':
        s = smtplib.SMTP_SSL(host, port, timeout=timeout, context=context)
        s.ehlo()
        return s
    s = smtplib.SMTP(host, port, timeout=timeout)
    s.ehlo()
    if not s.has_extn('starttls'):
        s.close()
        raise smtplib.SMTPNotSupportedError('Serwer nie ogłasza STARTTLS na tym porcie.')
    s.starttls(context=context)
    s.ehlo()
    return s


def main():
    env_file()
    ap = argparse.ArgumentParser(description='Diagnostyka SMTP dla TABAL Lead Hunter')
    ap.add_argument('--host', default=os.environ.get('TABAL_SMTP_HOST', ''))
    ap.add_argument('--port', type=int, default=int(os.environ.get('TABAL_SMTP_PORT') or 465))
    ap.add_argument('--security', choices=['ssl', 'starttls'], default=os.environ.get('TABAL_SMTP_SECURITY') or 'ssl')
    ap.add_argument('--user', default=os.environ.get('TABAL_SMTP_USER') or 'bok@tabal.pl')
    ap.add_argument('--sender', default=os.environ.get('TABAL_SMTP_SENDER') or 'bok@tabal.pl')
    ap.add_argument('--sender-name', default=os.environ.get('TABAL_SMTP_SENDER_NAME') or 'TABAL — Biuro Obsługi Klienta')
    ap.add_argument('--login', action='store_true', help='sprawdź logowanie (hasło: TABAL_SMTP_PASSWORD albo pytanie)')
    ap.add_argument('--send-to', default='', help='wyślij jedną wiadomość testową na ten adres (wymaga --login)')
    ap.add_argument('--cafile', default='', help='(testy) własny plik CA')
    a = ap.parse_args()
    if not a.host:
        print('Brak hosta SMTP. Podaj --host albo wpisz TABAL_SMTP_HOST w .env (od administratora poczty TABAL).')
        return 2
    problems = []
    print(f'\nTABAL Lead Hunter 3.5 — diagnostyka SMTP\nHost: {a.host} · port {a.port} · {a.security.upper()} · login {a.user} · nadawca {a.sender}\n')

    print('1. Nazwa hosta (DNS)')
    try:
        ips = sorted({x[4][0] for x in socket.getaddrinfo(a.host, a.port, proto=socket.IPPROTO_TCP)})
        print(OK + 'adresy: ' + ', '.join(ips))
    except OSError as e:
        print(BAD + f'host nie istnieje lub brak DNS ({e}). Sprawdź pisownię — bez https:// i bez ścieżki.')
        return 1
    domain = a.sender.split('@')[-1]
    print(INFO + f'MX domeny {domain}: sprawdź poleceniem  nslookup -type=mx {domain}  (Windows/Mac/Linux) — wskazuje serwer poczty firmy.')

    print('\n2. Porty')
    for port in sorted({465, 587, a.port}):
        try:
            with socket.create_connection((a.host, port), timeout=6):
                print(OK + f'{port} otwarty' + (' ← używany' if port == a.port else ''))
        except OSError:
            print((BAD if port == a.port else INFO) + f'{port} zamknięty / zablokowany' + (' ← UŻYWANY — zmień port albo sprawdź firewall serwera aplikacji' if port == a.port else ''))
            if port == a.port:
                problems.append(f'Port {port} niedostępny z tego komputera/serwera.')
    if problems:
        print('\nWYNIK: ' + ' '.join(problems))
        return 1

    print('\n3. Szyfrowanie i certyfikat')
    verify = ssl.create_default_context(cafile=a.cafile or None)
    loose = ssl.create_default_context(cafile=a.cafile or None)
    loose.check_hostname = False
    loose.verify_mode = ssl.CERT_NONE
    smtp = None
    try:
        smtp = connect(a.host, a.port, a.security, verify)
        print(OK + 'połączenie TLS i certyfikat zgodny z nazwą hosta')
    except ssl.SSLCertVerificationError as e:
        print(BAD + f'certyfikat NIE pasuje do hosta albo jest niezaufany: {e.verify_message}')
        try:
            probe = connect(a.host, a.port, a.security, loose)
            meta, sans = decode_cert(probe.sock.getpeercert(binary_form=True))
            probe.close()
            names = sans or [meta.get('cn', '?')]
            print(INFO + f'certyfikat wystawiono dla: {", ".join(names[:8])}' + (f' (wystawca: {meta.get("issuer")})' if meta.get('issuer') else ''))
            print(INFO + 'ROZWIĄZANIE: w TABAL_SMTP_HOST (i TABAL_SMTP_HOSTS) wpisz jedną z powyższych nazw — zwykle nazwę serwera hostingu, nie mail.tabal.pl.')
        except Exception:
            pass
        problems.append('Certyfikat TLS nie pasuje do hosta — aplikacja odmówi połączenia (to celowe zabezpieczenie).')
    except smtplib.SMTPNotSupportedError as e:
        print(BAD + str(e) + ' Spróbuj --port 465 --security ssl.')
        problems.append('Brak STARTTLS.')
    except (ssl.SSLError, OSError, smtplib.SMTPException) as e:
        hint = ' (465 wymaga ssl, 587 wymaga starttls)' if 'WRONG_VERSION' in str(e).upper() or 'wrong version' in str(e) else ''
        print(BAD + f'nie udało się nawiązać TLS: {type(e).__name__}{hint}')
        problems.append('Błąd TLS — sprawdź parę port/szyfrowanie: 465+ssl albo 587+starttls.')
    if smtp is None:
        print('\nWYNIK: ' + ' '.join(problems))
        return 1
    try:
        meta, sans = decode_cert(smtp.sock.getpeercert(binary_form=True))
        if meta.get('not_after'):
            print(INFO + f'certyfikat ważny do: {meta["not_after"]}')
    except Exception:
        pass

    print('\n4. Możliwości serwera (EHLO)')
    auth = smtp.esmtp_features.get('auth', '').upper().split()
    size = smtp.esmtp_features.get('size', '')
    print((OK if auth else BAD) + 'AUTH: ' + (' '.join(auth) or 'brak — serwer nie przyjmie logowania na tym porcie'))
    if size:
        print(INFO + f'maks. rozmiar wiadomości: {int(size)//1024} KB')
    if not auth:
        problems.append('Serwer nie oferuje logowania (AUTH).')

    if a.login:
        print('\n5. Logowanie')
        password = os.environ.get('TABAL_SMTP_PASSWORD') or getpass.getpass(f'Hasło skrzynki {a.user} (nie będzie wyświetlane): ')
        try:
            smtp.login(a.user, password)
            print(OK + f'zalogowano jako {a.user}')
        except smtplib.SMTPAuthenticationError as e:
            print(BAD + f'serwer odrzucił login/hasło (kod {e.smtp_code}). Sprawdź: pełny adres jako login, hasło skrzynki lub hasło aplikacji, czy SMTP jest włączony dla skrzynki.')
            problems.append('Logowanie odrzucone.')
        except smtplib.SMTPException as e:
            print(BAD + f'logowanie nieudane: {type(e).__name__}')
            problems.append('Logowanie nieudane.')
        finally:
            password = None
        if a.send_to and not problems:
            print('\n6. Wiadomość testowa')
            msg = EmailMessage()
            msg['From'] = formataddr((a.sender_name, a.sender))
            msg['To'] = a.send_to
            msg['Subject'] = 'TABAL Lead Hunter — test SMTP (diagnostyka)'
            msg['Date'] = formatdate(localtime=False)
            msg['Message-ID'] = make_msgid(domain=a.sender.split('@')[-1])
            msg.set_content('Wiadomość testowa ze skryptu diagnostycznego TABAL Lead Hunter 3.5.\nJeśli ją widzisz, wysyłka z tej skrzynki działa. Sprawdź też folder SPAM.')
            try:
                refused = smtp.send_message(msg, from_addr=a.sender, to_addrs=[a.send_to])
                if refused:
                    print(BAD + 'serwer odrzucił odbiorcę.')
                    problems.append('Odbiorca odrzucony.')
                else:
                    print(OK + f'serwer przyjął wiadomość do {a.send_to} ({msg["Message-ID"]}). Sprawdź skrzynkę i SPAM.')
                    print(INFO + 'Kopia NIE trafia automatycznie do „Wysłanych” skrzynki — historia jest w zakładce Wysyłka.')
            except smtplib.SMTPSenderRefused:
                print(BAD + f'serwer nie pozwala wysyłać jako {a.sender} z loginu {a.user} (nadawca musi zgadzać się z kontem).')
                problems.append('Nadawca odrzucony.')
            except smtplib.SMTPException as e:
                print(BAD + f'wysyłka nieudana: {type(e).__name__}')
                problems.append('Wysyłka nieudana.')
    try:
        smtp.quit()
    except Exception:
        pass

    print('\nWYNIK: ' + ('wszystko działa.' if not problems else ' '.join(problems)))
    if not problems:
        print('\nWpisy do .env (hasło wpisz w zakładce Wysyłka albo TABAL_SMTP_PASSWORD, plik chmod 600):')
        print(f'TABAL_SMTP_HOST={a.host}\nTABAL_SMTP_HOSTS={a.host}\nTABAL_SMTP_PORT={a.port}\nTABAL_SMTP_SECURITY={a.security}\nTABAL_SMTP_USER={a.user}\nTABAL_SMTP_SENDER={a.sender}')
    return 0 if not problems else 1


if __name__ == '__main__':
    sys.exit(main())
