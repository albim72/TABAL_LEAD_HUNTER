"""3.5 (TABAL 23.10 #4, #5, #9): SMTP ports, diagnostics, unattended sending, daily limit, HTML signature, Sent copy, saved settings."""
import json
import os
import socketserver
import ssl
import subprocess
import sys
import tempfile
import threading
import unittest
from email import policy
from email.parser import BytesParser
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from server import smtpcheck  # noqa: E402
from server.mailer import Outbox, SMTPTransport, message, build_message, imap_copy  # noqa: E402
from tests.test_mail import TLSServer, SMTPHandler, raw, CONFIG, OWNER  # noqa: E402


class Transport:
    def __init__(self):
        self.sent = []

    def send(self, cfg, job):
        self.sent.append((dict(cfg), dict(job)))
        return 'kopia w „Wysłanych”: zapisano' if cfg.get('imap_copy') else ''


class OutboxV35(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = Path(self.tmp.name) / 'mail.sqlite3'
        self.cfgpath = Path(self.tmp.name) / 'smtp.json'
        self.t = Transport()
        self.now = 100
        self.box = Outbox(self.path, self.t, lambda: self.now, config_path=self.cfgpath)

    def tearDown(self):
        self.box.close()
        self.tmp.cleanup()

    def test_01_port_993_is_explained_and_security_follows_port(self):
        with self.assertRaisesRegex(ValueError, 'odbioru poczty.*465'):
            self.box.configure({**CONFIG, 'port': 993})
        snap = self.box.configure({**CONFIG, 'port': 465, 'security': 'starttls'})
        self.assertEqual(snap['config']['security'], 'ssl')
        self.assertTrue(snap['notes'])
        self.box.config = None
        self.assertEqual(self.box.configure({**CONFIG, 'port': 587, 'security': 'ssl'})['config']['security'], 'starttls')

    def test_02_settings_survive_restart_password_only_when_remembered(self):
        self.box.configure({**CONFIG, 'daily_limit': 150})
        data = json.loads(self.cfgpath.read_text(encoding='utf-8'))
        self.assertNotIn('password', data)
        self.assertEqual(data['daily_limit'], 150)
        if os.name == 'posix':
            self.assertEqual(self.cfgpath.stat().st_mode & 0o777, 0o600)
        other = Outbox(self.path, self.t, lambda: self.now, config_path=self.cfgpath)
        self.assertFalse(other.load_saved())
        self.assertIsNone(other.config)
        self.assertEqual(other.defaults['host'], CONFIG['host'])
        other.close()
        self.box.configure({**CONFIG, 'remember_password': True})
        self.assertIn('password', json.loads(self.cfgpath.read_text(encoding='utf-8')))
        again = Outbox(self.path, self.t, lambda: self.now, config_path=self.cfgpath)
        self.assertTrue(again.load_saved())
        self.assertNotIn(CONFIG['password'], json.dumps(again.snapshot()))
        again.close()

    def test_03_unattended_sends_without_open_panel_and_rechecks_each_message(self):
        self.box.configure(CONFIG)
        self.box.validator = lambda job: job['to'] != 'changed@example.com'
        self.box.enqueue([raw('a@example.com', 'l1'), raw('changed@example.com', 'l2'), raw('b@example.com', 'l3')], OWNER)
        self.box.sync(OWNER, [j['id'] for j in self.box.jobs()])
        self.box.control('resume', owner=OWNER, unattended=True)
        self.now += 1000  # panel closed long ago — no heartbeat
        for _ in range(6):
            self.box.run_one()
            self.now += 11
        st = {j['to']: j['status'] for j in self.box.jobs()}
        self.assertEqual(st, {'a@example.com': 'sent', 'changed@example.com': 'cancelled', 'b@example.com': 'sent'})
        self.assertEqual(len(self.t.sent), 2)
        self.assertTrue(self.box.paused)  # queue drained → stops
        self.assertFalse(self.box.unattended)

    def test_04_attended_mode_still_pauses_without_heartbeat(self):
        self.box.configure(CONFIG)
        self.box.enqueue([raw()], OWNER)
        self.box.sync(OWNER, [self.box.jobs()[0]['id']])
        self.box.control('resume', owner=OWNER)
        self.now += 16
        self.assertFalse(self.box.run_one())
        self.assertTrue(self.box.paused)

    def test_05_daily_limit_waits_instead_of_sending(self):
        self.box.configure({**CONFIG, 'daily_limit': 1})
        self.box.validator = lambda job: True
        self.box.enqueue([raw('a@example.com', 'l1'), raw('b@example.com', 'l2')], OWNER)
        self.box.control('resume', owner=OWNER, unattended=True)
        self.assertTrue(self.box.run_one())
        self.now += 11
        self.assertFalse(self.box.run_one())
        snap = self.box.snapshot()
        self.assertTrue(snap['limit_wait'])
        self.assertEqual(snap['sent_24h'], 1)
        self.assertEqual(snap['queued'], 1)

    def test_06_batch_of_300_accepted_301_rejected(self):
        self.box.configure(CONFIG)
        self.box.enqueue([raw(f'r{i}@example.com', f'l{i}') for i in range(300)], OWNER)
        self.assertEqual(len(self.box.jobs()), 300)
        with self.assertRaises(ValueError):
            self.box.enqueue([raw(f's{i}@example.com', f'm{i}') for i in range(301)], OWNER)

    def test_07_unattended_requires_validator_and_queued_messages(self):
        self.box.configure(CONFIG)
        with self.assertRaises(ValueError):
            self.box.control('resume', owner=OWNER, unattended=True)
        self.box.validator = lambda job: True
        with self.assertRaisesRegex(ValueError, 'Brak wiadomości'):
            self.box.control('resume', owner=OWNER, unattended=True)

    def test_09_refresh_or_second_person_can_add_and_start_by_explicit_action(self):
        # A refreshed page / second operator: background sync is read-only, an explicit click takes the queue over.
        self.box.configure(CONFIG)
        self.box.validator = lambda job: True
        self.box.enqueue([raw('a@example.com', 'l1')], OWNER)
        self.box.sync(OWNER, [self.box.jobs()[0]['id']])
        other = 'other-tab-1234567'
        self.box.sync(other, [])
        self.assertEqual(self.box.jobs()[0]['status'], 'queued')
        self.box.enqueue([raw('b@example.com', 'l2')], other)
        self.assertEqual(self.box.owner, other)
        self.box.control('resume', owner=other, unattended=True)
        self.assertTrue(self.box.run_one())

    def test_10_attended_mode_also_rechecks_with_validator(self):
        self.box.configure(CONFIG)
        self.box.validator = lambda job: False
        self.box.enqueue([raw()], OWNER)
        self.box.sync(OWNER, [self.box.jobs()[0]['id']])
        self.box.control('resume', owner=OWNER)
        self.box.run_one()
        self.assertEqual(self.box.jobs()[0]['status'], 'cancelled')
        self.assertEqual(self.t.sent, [])

    def test_08_cancel_all(self):
        self.box.configure(CONFIG)
        self.box.enqueue([raw('a@example.com', 'l1'), raw('b@example.com', 'l2')], OWNER)
        self.box.control('cancel-all', owner=OWNER)
        self.assertEqual({j['status'] for j in self.box.jobs()}, {'cancelled'})


class MessageV35(unittest.TestCase):
    def test_html_part_and_bcc(self):
        job = {**message({**raw(), 'html': '<p>Treść</p><div><b>Jędrzej</b></div>'}), 'message_id': '<x@example.com>'}
        msg = build_message({**CONFIG}, job)
        parsed = BytesParser(policy=policy.default).parsebytes(msg.as_bytes())
        self.assertEqual(parsed.get_content_type(), 'multipart/alternative')
        self.assertIn('Jędrzej', parsed.get_body(('html',)).get_content())
        self.assertIn('Dzień dobry', parsed.get_body(('plain',)).get_content())
        with self.assertRaises(ValueError):
            message({**raw(), 'html': 'x' * 200001})

    def test_imap_copy_to_sent_folder(self):
        calls = {}

        class FakeIMAP:
            def __init__(self, host, port, ssl_context=None, timeout=None):
                calls['host'] = (host, port)

            def login(self, u, p):
                calls['login'] = u

            def list(self):
                return 'OK', [b'(\\HasNoChildren) "." "INBOX"', b'(\\HasNoChildren \\Sent) "." "INBOX.Wys&AUI-ane"']

            def append(self, folder, flags, date, data):
                calls['append'] = (folder, flags, len(data))
                return 'OK', [b'']

            def logout(self):
                pass

        job = {**message(raw()), 'message_id': '<x@example.com>'}
        with patch('server.mailer.imaplib.IMAP4_SSL', FakeIMAP):
            note = imap_copy({**CONFIG, 'imap_port': 993}, build_message(CONFIG, job))
        self.assertIn('zapisano', note)
        self.assertEqual(calls['host'], ('localhost', 993))
        self.assertEqual(calls['append'][0], '"INBOX.Wys&AUI-ane"')
        with patch('server.mailer.imaplib.IMAP4_SSL', side_effect=OSError('x')):
            self.assertIn('brak połączenia', imap_copy(CONFIG, build_message(CONFIG, job)))


class DiagnoseV35(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory()
        d = Path(cls.tmp.name)
        cls.good = (d / 'good.pem', d / 'good.key')
        cls.other = (d / 'other.pem', d / 'other.key')
        for (cert, key), cn, san in [(cls.good, 'localhost', 'DNS:localhost,IP:127.0.0.1'), (cls.other, 'serwer1234.example.test', 'DNS:serwer1234.example.test')]:
            subprocess.run(['openssl', 'req', '-x509', '-newkey', 'rsa:2048', '-nodes', '-keyout', str(key), '-out', str(cert), '-days', '1', '-subj', '/CN=' + cn, '-addext', 'subjectAltName=' + san], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    @classmethod
    def tearDownClass(cls):
        cls.tmp.cleanup()

    def serve(self, pair, implicit=True):
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx.load_cert_chain(*pair)
        srv = TLSServer(('127.0.0.1', 0), SMTPHandler)
        srv.context = ctx
        srv.implicit = implicit
        srv.drop = False
        srv.messages = []
        th = threading.Thread(target=srv.serve_forever, daemon=True)
        th.start()
        return srv, th

    def stop(self, srv, th):
        srv.shutdown()
        th.join()
        srv.server_close()

    def test_01_imap_port_explained_without_network(self):
        r = smtpcheck.diagnose('smtp.example.test', 993, 'ssl', 'bok@tabal.pl', 'x')
        self.assertFalse(r['ok'])
        self.assertIn('IMAP', r['steps'][0]['detail'])
        self.assertEqual(r['suggestion'], {'port': 465, 'security': 'ssl'})

    def test_02_full_success_with_login_and_test_message(self):
        srv, th = self.serve(self.good)
        try:
            r = smtpcheck.diagnose('localhost', srv.server_address[1], 'ssl', 'bok@tabal.pl', 'secret', 'test@example.com', 'bok@tabal.pl', 'TABAL', cafile=str(self.good[0]))
            self.assertTrue(r['ok'], r)
            self.assertEqual([s['step'] for s in r['steps']], ['DNS', 'Połączenie', 'Certyfikat TLS', 'Logowanie dostępne', 'Logowanie', 'Wiadomość testowa'])
            self.assertEqual(len(srv.messages), 1)
            self.assertNotIn('secret', json.dumps(r))
        finally:
            self.stop(srv, th)

    def test_03_certificate_for_hosting_server_name_is_suggested(self):
        srv, th = self.serve(self.other)
        try:
            r = smtpcheck.diagnose('localhost', srv.server_address[1], 'ssl', 'bok@tabal.pl', 'secret', cafile=str(self.other[0]))
            self.assertFalse(r['ok'])
            self.assertIn('serwer1234.example.test', r['steps'][-1]['detail'])
            self.assertEqual(r['suggestion']['host'], 'serwer1234.example.test')
        finally:
            self.stop(srv, th)

    def test_04_wrong_security_for_port_reported(self):
        srv, th = self.serve(self.good, implicit=False)
        try:
            r = smtpcheck.diagnose('localhost', srv.server_address[1], 'ssl', 'bok@tabal.pl', 'secret', cafile=str(self.good[0]))
            self.assertFalse(r['ok'])
            self.assertIn('465 = SSL/TLS, 587 = STARTTLS', r['steps'][-1]['hint'])
        finally:
            self.stop(srv, th)


class HostPolicyV35(unittest.TestCase):
    def test_policy(self):
        script = r'''
import sys,json;sys.path.insert(0,sys.argv[1])
from server import web
cases=[('serwer1234.home.pl','bok@tabal.pl'),('mail.tabal.pl','bok@tabal.pl'),('smtp.office365.com','bok@tabal.pl'),('evil.example','bok@tabal.pl'),('10.0.0.5','bok@tabal.pl'),('localhost','bok@tabal.pl'),('smtp.example.test','x@y.pl')]
print(json.dumps([web.host_allowed(h,s) for h,s in cases]))'''
        with tempfile.TemporaryDirectory() as tmp:
            env = {k: v for k, v in os.environ.items() if not k.startswith('TABAL_')}
            env.update(TABAL_DATA_DIR=tmp, TABAL_ORIGIN='http://127.0.0.1:8765', TABAL_SMTP_HOSTS='smtp.example.test')
            p = subprocess.run([sys.executable, '-c', script, str(ROOT)], env=env, capture_output=True, text=True, timeout=60)
            self.assertEqual(p.returncode, 0, p.stderr)
            self.assertEqual(json.loads(p.stdout.strip().splitlines()[-1]), [True, True, True, False, False, False, True])


if __name__ == '__main__':
    unittest.main(verbosity=2)
