// TABAL Lead Hunter 3.2 — regressions for the 9.10.2026 change list.
const {test}=require('node:test'),a=require('node:assert/strict'),C=require('../src/core.js');
function base(){const s=C.makeState('pilot');return s;}
function lub(s,extra={}){return C.strategy({...s.strategies[0],country:'Polska',province:'lubelskie',region:'lubelskie, Polska',...extra});}
// 3.5: lubelskie strategies need a lubelskie address — the app now checks the area by address and postal code.
function raw(s,st,i,extra={}){const r=C.sample(st,s,false);return {...r,address:'ul. Przykładowa 1, 20-001 Lublin',city:'Lublin',company:'Firma '+i,domain:'firma-'+i+'.example',...extra};}

test('LIMITY: cel 0 = bez limitu, partia 0 = cała pula, cele powyżej 100 są dozwolone',()=>{
 const s=base();a.equal(lub(s,{limit:0,batch_size:0}).limit,0);a.equal(lub(s,{limit:5000}).limit,5000);a.equal(lub(s,{limit:250,batch_size:250}).batch_size,250);
 a.throws(()=>lub(s,{limit:C.MAX+1}),/Cel kampanii/);a.throws(()=>lub(s,{limit:-1}),/Cel kampanii/);a.equal(C.MAX,10000);
});
test('LIMITY: lubelskie bez limitu — jedno zadanie z pełnym planem, bez partii po 20',()=>{
 const s=base(),st=lub(s,{limit:0,batch_size:0});s.strategies[0]=st;const run=C.createResearchRun(st);s.runs.push(run);
 const t=C.prepareResearchBatch(s,run),plan=C.researchPlan(s,st);
 a.match(t,/BEZ LIMITU/);a.match(t,/PEŁNA PULA/);a.match(t,/nie dziel pracy na partie po 20/);
 for(const area of plan.areas)a.ok(t.includes(area),area);for(const c of plan.counties)a.ok(t.includes(c),c);
 a.equal(run.batches[0].size,0);a.equal(run.batches[0].queries.length,plan.queries.length);a.ok(plan.queries.length>=300);
 const p=C.researchProgress(run);a.equal(p.unlimited,true);a.equal(p.complete,false);a.equal(p.remaining,null);
});
test('LIMITY: import 250 firm w jednej partii i baza ponad 2000 firm',()=>{
 const s=base(),st=lub(s,{limit:0});s.strategies[0]=st;const run=C.createResearchRun(st);s.runs.push(run);C.prepareResearchBatch(s,run);
 const r=C.merge(s,Array.from({length:250},(_,i)=>raw(s,st,i)),st);a.equal(r.added,250);s.leads=r.leads;C.recordResearchImport(run,r,{batch_id:run.batches[0].id},'x.json');
 a.equal(C.researchProgress(run).found,250);a.equal(run.status,'needs_more');a.doesNotThrow(()=>C.prepareResearchBatch(s,run));
 const big=C.merge(s,Array.from({length:2300},(_,i)=>raw(s,st,1000+i)),st);a.equal(big.added,2300);a.equal(big.errors.length,0);
});
test('LIMITY: cel 100 i cała pula — jedno zadanie o rozmiarze 100',()=>{
 const s=base(),st=lub(s,{limit:100,batch_size:0}),run=C.createResearchRun(st);s.runs.push(run);const t=C.prepareResearchBatch(s,run);
 a.equal(run.batches[0].size,100);a.match(t,/CEL TEGO ZADANIA: 100 — pełna brakująca pula/);
});
test('WYSZUKIWANIE: miasto + promień dobiera miejscowości w promieniu',()=>{
 const s=base(),st=lub(s,{city:'Lublin',radius_km:30}),plan=C.researchPlan(s,st);
 a.equal(plan.areas[0],'Lublin');a.ok(plan.areas.includes('Świdnik'));a.ok(!plan.areas.includes('Zamość'));a.ok(plan.radius.known);
 a.match(C.task(s,st,'r'),/w promieniu 30 km/);
 const other=C.researchPlan(s,C.strategy({name:'X',country:'Polska',city:'Nieznanowo Testowe',radius_km:20}));a.deepEqual(other.areas,['Nieznanowo Testowe','okolice Nieznanowo Testowe (do 20 km)']);
});
test('WYSZUKIWANIE: kraj Słowacja/Czechy blokuje województwo i używa języka lokalnego',()=>{
 const s=base(),sk=C.strategy({...s.strategies[0],country:'Słowacja',province:'lubelskie',region:''});a.equal(sk.province,'');
 const plan=C.researchPlan(s,sk);a.ok(plan.areas.includes('Bratislava'));a.ok(plan.terms.some(t=>/plot/.test(t)));
 const t=C.task(s,sk,'r');a.match(t,/Województw nie stosuj/);a.match(t,/słowackim/);
 const cz=C.strategy({...s.strategies[0],country:'Czechy',region:''});a.ok(C.researchPlan(s,cz).areas.includes('Brno'));
});
test('WYSZUKIWANIE: zadanie żąda adresów, aktualności źródeł, opisu z tabal.pl i typu klienta',()=>{
 const s=base(),t=C.task(s,lub(s),'r');
 for(const x of ['DANE ADRESOWE','postal_code','AKTUALNOŚĆ','2013–2023','updated_year','https://tabal.pl/','product_url','client_type','uncertain','type "general"'])a.ok(t.includes(x),x);
});
test('KONTAKTY: aliasy pól, kontakt na poziomie firmy i błędny e-mail nie usuwają firmy',()=>{
 const s=base(),st=lub(s),r=raw(s,st,1,{contacts:[{full_name:'Jan Kowalski',position:'Kierownik zakupów',mail:'jan@firma-1.example',tel:'+48 600 100 200',source_url:'https://firma-1.example/kontakt'},{type:'general',email:'biuro@firma-1.example, handel@firma-1.example'}],email:'info@firma-1.example'});
 const res=C.merge(s,[r],st);a.equal(res.added,1);const l=res.leads[0];
 a.equal(l.contacts[0].name,'Jan Kowalski');a.equal(l.contacts[0].role,'Kierownik zakupów');a.equal(l.contacts[0].email,'jan@firma-1.example');a.equal(l.contacts[0].phone,'+48 600 100 200');a.equal(l.contacts[0].type,'person');
 a.equal(l.contacts[1].email,'biuro@firma-1.example');a.equal(l.contacts[1].uncertain,true);a.ok(l.contacts.some(p=>p.email==='info@firma-1.example'&&p.type==='general'));
});
test('KONTAKTY: ponowne znalezienie dopisuje kontakty i adres do głównej karty, zachowując obsługę',()=>{
 const s=base(),st=lub(s);let res=C.merge(s,[raw(s,st,1,{contacts:[],address:'',city:''})],st);s.leads=res.leads;
 s.leads[0].status='CONTACTED';s.leads[0].notes='Ważne';s.leads[0].criteria.client={value:'unknown',evidence:'',url:''};
 const enrich=raw(s,st,1);res=C.merge(s,[enrich],st);
 a.equal(res.duplicates,1);a.equal(res.enriched,1);const l=res.leads[0];
 a.equal(l.status,'CONTACTED');a.equal(l.notes,'Ważne');a.equal(l.contacts.length,1);a.equal(l.contacts[0].name,'Anna Przykładowa');a.equal(l.city,'Lublin');a.equal(l.criteria.client.value,'yes');
 a.ok(l.history.some(h=>h.action==='ENRICH'));a.equal(C.bestContact(l,s.config).person,true);
});
test('KONTAKTY: scoring stopniowany — 10/10 osoba, 8/10 ogólny (3.3), 5/10 do weryfikacji, 0 bez kanału',()=>{
 const s=base(),st=lub(s),l=C.validateLead(raw(s,st,1),s,st),part=()=>C.score(l,s.config).parts.find(p=>p.key==='contact');
 a.equal(part().points/part().max,1);a.match(part().reason,/10\/10/);
 l.contacts[0].type='general';a.equal(Math.round(part().points/part().max*10),8);a.match(part().reason,/wystarczający/);
 l.contacts[0].verified=false;a.equal(part().points/part().max,0.5);a.match(part().reason,/5\/10.*weryfikacji/);
 s.config=C.settings({...s.config,allow_uncertain_contacts:false});a.equal(part().points,0);
 l.contacts=[];a.equal(part().points,0);
});
test('SCORING: równe wagi domyślnie, migracja wag 3.1, własne wagi zachowane',()=>{
 const s=base();a.ok(Object.values(s.config.weights).every(v=>v===10));
 a.deepEqual(C.settings({weights:C.OLD_DEFAULT_WEIGHTS}).weights,C.DEFAULT_WEIGHTS);
 const custom={...C.OLD_DEFAULT_WEIGHTS,product:40};a.equal(C.settings({weights:custom}).weights.product,40);
 const migrated=C.settings({weights:C.OLD_DEFAULT_WEIGHTS});a.deepEqual(C.settings({...migrated,weights:C.OLD_DEFAULT_WEIGHTS}).weights,C.OLD_DEFAULT_WEIGHTS,'po migracji użytkownik może świadomie wrócić do wag 3.1');
});
test('SCORING: dodatkowe kryteria liczone tylko po zaznaczeniu',()=>{
 const s=base(),off=lub(s,{extra:'Montaż bram',use_extra:false}),on=lub(s,{extra:'Montaż bram',use_extra:true});
 const l1=C.validateLead(raw(s,off,1),s,off),l2=C.validateLead(raw(s,on,1),s,on);l1.criteria.extra.value='no';l2.criteria.extra.value='no';
 a.equal(C.score(l1,s.config).checks.extra,'na');a.equal(C.score(l1,s.config).qualified,true);
 a.equal(C.score(l2,s.config).checks.extra,'no');a.equal(C.score(l2,s.config).qualified,false);
 a.ok(!C.task(s,off,'r').includes('"extra":"Montaż bram"'));a.match(C.task(s,on,'r'),/DODATKOWE KRYTERIA SĄ UWZGLĘDNIANE/);
});
test('SCORING: częściowe dopasowanie pokazuje, które kryterium nie pasuje (produkt ✓, segment ✗)',()=>{
 const s=base(),st=lub(s),l=C.validateLead(raw(s,st,1),s,st);l.criteria.segment={value:'no',evidence:'Firma sprzedaje wyłącznie meble.',url:l.sources[0].url};
 const r=C.score(l,s.config);a.equal(r.checks.product,'ok');a.equal(r.checks.segment,'no');a.ok(r.blocks.some(b=>/Segment.*niezgodność/.test(b)));
 a.match(r.parts.find(p=>p.key==='segment').reason,/NIEZGODNOŚĆ: Firma sprzedaje wyłącznie meble/);a.equal(r.parts.find(p=>p.key==='segment').points,0);
});
test('SCORING: spójność — podobne firmy dostają ten sam wynik; URL różniący się ukośnikiem/www jest tym samym dowodem',()=>{
 const s=base(),st=lub(s),l1=C.validateLead(raw(s,st,1),s,st),l2=C.validateLead(raw(s,st,2),s,st);
 for(const k of C.CRITERIA)l2.criteria[k].url='https://www.example.com/oferta/';
 a.equal(C.score(l1,s.config).points,C.score(l2,s.config).points);a.equal(C.score(l2,s.config).checks.product,'ok');
 l2.criteria.product.value='unknown';a.match(C.score(l2,s.config).parts[0].reason,/OFERTA POKREWNA/);l2.criteria.segment.value='unknown';a.match(C.score(l2,s.config).parts[0].reason,/Nie ustalono/);
});
test('AKTUALNOŚĆ: strona nieaktualizowana od lat nie potwierdza działalności',()=>{
 const s=base(),st=lub(s),r=raw(s,st,1);r.sources[0].updated_year=2023;const l=C.validateLead(r,s,st),sc=C.score(l,s.config);
 a.equal(sc.checks.source,'no');a.ok(sc.parts.some(p=>/nieaktualizowana od 2023/.test(p.reason)));a.equal(sc.qualified,false);
 r.sources[0].updated_year=Number(C.today().slice(0,4));a.equal(C.score(C.validateLead(r,s,st),s.config).checks.source,'ok');
});
test('PROJEKTY: migracja kampanii 3.1 do projektów, łączenie strategii, usuwanie leadów z projektu',()=>{
 const s=base(),st=lub(s);const res=C.merge(s,[raw(s,st,1),raw(s,st,2)],st);s.leads=res.leads;
 const old={...s,projects:undefined,migrations:[],runs:[{id:'r1',strategy_id:st.id,profile:st,target:100,created_at:'2026-10-01T10:00:00.000Z',status:'needs_more',added:2,result_ids:res.addedIds,batches:[],imports:[]}]};
 const restored=C.restore(C.backup(old),'pilot');a.equal(restored.projects.length,1);a.deepEqual(restored.projects[0].lead_ids,res.addedIds);a.equal(restored.runs[0].project_id,restored.projects[0].id);
 const p2=C.createProject(restored,'Drugi');C.addToProject(restored,p2,[res.addedIds[0]]);C.mergeProjects(restored,restored.projects[0].id,[p2.id]);a.equal(restored.projects.length,1);
 C.removeFromProject(restored,restored.projects[0],[res.addedIds[0]]);a.deepEqual(restored.projects[0].lead_ids,[res.addedIds[1]]);a.equal(restored.leads.length,2);
 a.deepEqual(C.restore(C.backup(restored),'pilot'),restored);
});
test('PROJEKTY: archiwizacja i wczytanie pliku projektu do innej bazy bez duplikatów',()=>{
 const s=base(),st=lub(s);s.leads=C.merge(s,[raw(s,st,1),raw(s,st,2)],st).leads;const p=C.createProject(s,'Lubelskie X');C.addToProject(s,p,s.leads.map(l=>l.id));p.archived=true;
 const file=C.projectExport(s,p),other=base();other.leads=C.merge(other,[raw(other,st,1)],st).leads;
 const r=C.importProject(other,file);a.equal(r.added,1);a.equal(r.matched,1);a.equal(other.leads.length,2);a.equal(r.project.archived,false);a.equal(r.project.lead_ids.length,2);
 a.doesNotThrow(()=>C.restore(C.backup(other),'pilot'));
});
test('LEADY: statusy archiwum/usunięty, kolor, data ostatniej edycji, automatyczna archiwizacja, trwałe usunięcie',()=>{
 const s=base(),st=lub(s);s.leads=C.merge(s,[raw(s,st,1),raw(s,st,2)],st).leads;
 a.ok(s.leads[0].updated_at);a.equal(C.STATUS_COLOR.NEW,'green');a.equal(C.STATUS_COLOR.REVIEW,'yellow');a.equal(C.STATUS_COLOR.REJECTED,'red');
 let l=C.statusChange(s.leads[0],'DELETED','test');a.equal(l.status_before,'NEW');a.equal(C.score(l,s.config).qualified,false);s.leads[0]=l;
 s.leads[1]=C.statusChange(s.leads[1],'REJECTED','Zła branża: test');s.leads[1].updated_at='2026-08-01T00:00:00.000Z';
 a.equal(C.autoArchive(s,'2026-10-13'),1);a.equal(s.leads[1].status,'ARCHIVED');a.ok(s.leads[1].history.at(-1).action==='AUTO_ARCHIVE');
 a.doesNotThrow(()=>C.restore(C.backup(s),'pilot'));const p=C.createProject(s,'P');C.addToProject(s,p,[s.leads[0].id]);
 a.equal(C.deleteLeads(s,[s.leads[0].id]),1);a.equal(s.leads.length,1);a.deepEqual(p.lead_ids,[]);
});
test('EKSPORT: dokumenty NoSQL (_id) w JSON i JSON Lines',()=>{
 const s=base(),st=lub(s);s.leads=C.merge(s,[raw(s,st,1),raw(s,st,2)],st).leads;C.createProject(s,'P');
 const lines=C.exportNoSQL(s,{format:'ndjson'}).trim().split('\n').map(JSON.parse);a.equal(lines.length,2);a.ok(lines.every(d=>d._id&&d.status.color&&d.score.parts.length&&d.updated_at));
 const doc=JSON.parse(C.exportNoSQL(s,{format:'json'}));a.equal(doc.kind,'tabal-lead-hunter-nosql');a.equal(doc.collections.leads.length,2);a.ok(doc.collections.projects[0]._id);a.equal(doc.collections.projects[0].id,undefined);
});
test('PRODUKTY: opisy z tabal.pl uzupełniają puste pola przy aktualizacji 3.1 → 3.2, nie nadpisują własnych',()=>{
 const s=base();s.products[0].description='';s.products[1].description='Mój opis';s.config.offer='';
 const old={...s,migrations:s.migrations.filter(m=>m!=='v32-tabal-offer')};const r=C.restore(C.backup(old),'pilot');
 a.match(r.products[0].description,/Techfence/);a.equal(r.products[1].description,'Mój opis');a.match(r.config.offer,/Lublin/);
});

test('WOJEWÓDZTWA: każde z 16 ma pełny plan z rejestru TERYT (miasta, gminy wiejskie, powiaty)',()=>{
 const s=base();a.equal(C.PROVINCES.length,16);let counties=0;
 for(const pv of C.PROVINCES){const st=C.strategy({...s.strategies[0],country:'Polska',province:pv,region:pv+', Polska',limit:0});const plan=C.researchPlan(s,st);
  a.ok(plan.areas.length>=35,pv+' miasta');a.ok(plan.gminy.length>=30,pv+' gminy');a.ok(plan.counties.length>=12,pv+' powiaty');counties+=plan.counties.length;
  const run=C.createResearchRun(st);s.runs.push(run);const t=C.prepareResearchBatch(s,run);a.match(t,/BEZ LIMITU/);for(const x of [...plan.areas,...plan.gminy,...plan.counties])a.ok(t.includes(x),pv+': '+x);}
 a.equal(counties,380);
 for(const [pv,cities] of [['mazowieckie',['Warszawa','Radom','Płock','Siedlce']],['śląskie',['Katowice','Gliwice','Bielsko-Biała']],['wielkopolskie',['Poznań','Kalisz','Piła']],['podkarpackie',['Rzeszów','Krosno']],['zachodniopomorskie',['Szczecin','Koszalin']]])
  {const plan=C.researchPlan(s,C.strategy({name:pv,country:'Polska',province:pv}));for(const c of cities)a.ok(plan.areas.includes(c),pv+': '+c);}
});
test('WOJEWÓDZTWA: rozpoznanie z samego regionu, cała Polska, promień poza lubelskim',()=>{
 const s=base();a.ok(C.researchPlan(s,C.strategy({name:'w',region:'wielkopolskie'})).areas.includes('Poznań'));
 a.ok(C.researchPlan(s,C.strategy({name:'w',region:'woj. małopolskie, Polska'})).areas.includes('Kraków'));
 const pl=C.researchPlan(s,C.strategy({name:'pl',country:'Polska'}));a.equal(pl.areas.length,66);a.equal(pl.counties.length,314);
 const waw=C.researchPlan(s,C.strategy({name:'r',country:'Polska',province:'mazowieckie',city:'Warszawa',radius_km:20}));a.ok(waw.radius.known);a.ok(waw.areas.includes('Pruszków'));a.ok(!waw.areas.includes('Radom'));
 const krk=C.researchPlan(s,C.strategy({name:'r',country:'Polska',city:'Kraków',radius_km:25}));a.ok(krk.areas.includes('Wieliczka'));a.ok(!krk.areas.includes('Tarnów'));
 const cz=C.researchPlan(s,C.strategy({name:'c',country:'Czechy',city:'Brno',radius_km:20}));a.ok(cz.radius.known);a.ok(!cz.areas.includes('Praha'));
 a.ok(!C.researchPlan(s,C.strategy({name:'s',country:'Słowacja'})).areas.includes('Petržalka'));
});
