// TABAL Lead Hunter 3.5 — regressions for TABAL remarks of 23.10.2026 (J. Moraczewski, meeting 22.10).
const {test}=require('node:test'),a=require('node:assert/strict'),C=require('../src/core.js');
const today=C.today();
function base(){return C.makeState('pilot');}
function strat(s,extra={}){const st=C.strategy({...s.strategies.find(x=>x.id==='aluminium'),country:'Polska',province:'lubelskie',region:'lubelskie, Polska',...extra});s.strategies[s.strategies.findIndex(x=>x.id==='aluminium')]=st;return st;}
function raw(dom,extra={}){
 const src='https://'+dom+'/oferta',cr={};for(const k of [...C.CRITERIA,'exclusion'])cr[k]={value:'yes',evidence:'Montaż ogrodzeń aluminiowych',url:src};cr.exclusion={value:'no',evidence:'Brak',url:src};
 return {company:'Firma '+dom,domain:dom,is_demo:false,region:'lubelskie',address:'ul. Długa 1, 20-001 Lublin',city:'Lublin',postal_code:'20-001',business_profile:{core_activity:'montaż ogrodzeń',fit:'core'},
  sources:[{url:src,title:'Oferta',quote:'Montaż ogrodzeń aluminiowych w Lublinie.',checked_at:today,verified:true}],
  contacts:[{type:'general',email:'biuro@'+dom,phone:'+48 81 100 20 30',url:'https://'+dom+'/kontakt',quote:'biuro@'+dom+' tel. +48 81 100 20 30',checked_at:today,verified:true}],criteria:cr,...extra};
}

// ---------- 1. Import of files from different models (GPT 5.6 Terra / GPT 6.1 Sol) ----------
test('IMPORT 3.5: schema_version jako tekst, tekst wokół JSON i pole „companies” — wczytane z opisem ujednoliceń',()=>{
 const s=base(),st=strat(s);
 const body=JSON.stringify({schema_version:'2.0',strategy_id:st.id,companies:[raw('alfa.example')]});
 const r=C.parseImport('Oto wynik badania:\n```json\n'+body+'\n```\nDaj znać, czy coś poprawić.');
 a.equal(r.data.schema_version,2);a.equal(r.data.leads.length,1);
 a.ok(r.notes.some(n=>/```/.test(n)));a.ok(r.notes.some(n=>/companies/.test(n)));a.ok(r.notes.some(n=>/schema_version/.test(n)));
 const m=C.merge(s,r.data.leads,st);a.equal(m.added,1);a.equal(m.errors.length,0);
});
test('IMPORT 3.5: zagnieżdżone data.leads, komentarze i przecinki na końcu, źródła jako tekst, kontakt jako obiekt, polskie klucze kryteriów',()=>{
 const s=base(),st=strat(s);const l=raw('beta.example');
 const odd={...l,sources:['https://beta.example/oferta'],contacts:l.contacts[0],criteria:{produkt:{value:'tak',evidence:'x',url:'https://beta.example/oferta'},klient:'tak',wykluczenia:{value:'nie'}}};
 const text='{"result":{"schema_version":2,"run_id":"r1", // komentarz modelu\n "data":{"leads":['+JSON.stringify(odd)+',]}}}';
 const r=C.parseImport(text);a.equal(r.data.run_id,'r1');a.equal(r.data.leads.length,1);
 const x=r.data.leads[0];a.equal(x.sources[0].url,'https://beta.example/oferta');a.ok(Array.isArray(x.contacts));a.equal(x.criteria.product.value,'tak');a.equal(x.criteria.client.value,'tak');a.equal(x.criteria.exclusion.value,'nie');
 const m=C.merge(s,r.data.leads,st);a.equal(m.errors.length,0,JSON.stringify(m.errors));a.equal(m.leads[0].criteria.product.value,'yes');
});
test('IMPORT 3.5: ucięty plik (np. limit odpowiedzi modelu) — odzyskane kompletne rekordy, ostatni urwany pominięty',()=>{
 const full=JSON.stringify({schema_version:2,run_id:'run-9',batch_id:'b-1',leads:[raw('a1.example'),raw('a2.example'),raw('a3.example')]});
 const cut=full.slice(0,full.lastIndexOf('a3.example')+5);
 const r=C.parseImport(cut);a.equal(r.data.leads.length,2);a.equal(r.data.run_id,'run-9');a.equal(r.data.batch_id,'b-1');a.ok(r.notes.some(n=>/odzyskano 2/.test(n)));
 a.throws(()=>C.parseImport('to nie jest json'),/Nieprawidłowy JSON/);
});
test('IMPORT 3.5: JSON Lines i kilka bloków JSON w jednej odpowiedzi',()=>{
 const r=C.parseImport([raw('l1.example'),raw('l2.example')].map(x=>JSON.stringify(x)).join('\n'));a.equal(r.data.leads.length,2);
 const two='Część 1:\n```json\n'+JSON.stringify({schema_version:2,run_id:'x',leads:[raw('p1.example')]})+'\n```\nCzęść 2:\n```json\n'+JSON.stringify({leads:[raw('p2.example')]})+'\n```';
 const t=C.parseImport(two);a.equal(t.data.leads.length,2);a.equal(t.data.run_id,'x');
});
test('IMPORT 3.5: lead bez tablicy sources, ale z adresem strony — źródło niesprawdzone, firma nie przepada',()=>{
 const s=base(),st=strat(s);const l=raw('gamma.example');delete l.sources;l.website='https://gamma.example/';
 const r=C.parseImport(JSON.stringify({leads:[l]}));a.equal(r.data.leads[0].sources[0].verified,false);
 const m=C.merge(s,r.data.leads,st);a.equal(m.added,1);a.equal(m.errors.length,0);
});

// ---------- 2. Terra vs Sol ----------
test('MODEL 3.5: Terra — tryb wyczerpujący w zadaniu; Sol bez niego; model zapisany w raporcie importu',()=>{
 const s=base(),st=strat(s,{limit:50});
 const terra=C.createResearchRun(st,'','terra');s.runs.push(terra);const t=C.prepareResearchBatch(s,terra);a.match(t,/TRYB WYCZERPUJĄCY/);a.match(t,/Wykonaj WSZYSTKIE zapytania/);
 const sol=C.createResearchRun(st,'','sol');s.runs.push(sol);a.doesNotMatch(C.prepareResearchBatch(s,sol),/TRYB WYCZERPUJĄCY/);
 const res=C.merge(s,[raw('m1.example')],st);s.leads=res.leads;const rep=C.recordResearchImport(terra,res,{batch_id:terra.batches[0].id,research_report:{queries:[{query:'ogrodzenia Lublin',area:'Lublin'}]}},'x.json');
 a.equal(rep.model,'GPT-5.6 Terra');a.equal(rep.coverage.executed,1);a.ok(rep.coverage.planned>100);
});
test('MODEL 3.5: zadanie uzupełniające obejmuje tylko miejscowości, których Work nie sprawdził',()=>{
 const s=base(),st=strat(s,{limit:50});const run=C.createResearchRun(st,'','terra');s.runs.push(run);C.prepareResearchBatch(s,run);
 const plan=C.researchPlan(s,st),done=plan.areas.slice(0,10);
 const res=C.merge(s,[raw('f1.example')],st);s.leads=res.leads;
 C.recordResearchImport(run,res,{batch_id:run.batches[0].id,research_report:{queries:done.map(a=>({query:'ogrodzenia '+a,area:a})),remaining_areas:[plan.areas[3]]}},'x.json');
 const todo=C.uncheckedAreas(run,plan);a.ok(todo.includes(plan.areas[3]));a.ok(!todo.includes(plan.areas[0]));a.equal(todo.length,plan.areas.length-9);
 const t=C.prepareResearchBatch(s,run);a.match(t,/ZADANIE UZUPEŁNIAJĄCE/);a.ok(run.batches.at(-1).followup);a.equal(run.batches.at(-1).areas.length,todo.length);
 a.ok(!run.batches.at(-1).areas.includes(plan.areas[0]));
});

// ---------- 3 + 5. Catalog link and automatic signature ----------
test('WIADOMOŚĆ 3.5: link do katalogu przed pozdrowieniem, sygnatura na końcu, stary podpis nie jest dublowany',()=>{
 const s=base(),st=strat(s);const l=C.validateLead(raw('k1.example'),s,st);
 s.products.find(p=>p.id==='alu').catalog_url='https://tabal.pl/katalog-alufence.pdf';
 s.config.signature='Jędrzej Moraczewski\nOpiekun klienta | TABAL';
 l.draft={subject:'Ogrodzenia aluminiowe — współpraca',body:'Dzień dobry,\n\nTreść.\n\nPozdrawiam\nZespół TABAL'};
 const m=C.composeMessage(l,s.config,s.products);
 a.ok(m.body.includes('Katalog — Ogrodzenia aluminiowe: https://tabal.pl/katalog-alufence.pdf\n\nPozdrawiam\nJędrzej Moraczewski'));
 a.ok(!m.body.includes('Zespół TABAL'));a.ok(m.body.endsWith('Opiekun klienta | TABAL'));a.equal(m.html,'');
 const again=C.composeMessage({...l,draft:{subject:'x',body:m.body}},s.config,s.products);a.equal(again.body.split('katalog-alufence.pdf').length,2);a.equal(again.body.split('Jędrzej Moraczewski').length,2);
 const noCat=C.composeMessage(l,{...s.config,auto_catalog:false,auto_signature:false},s.products);a.ok(!noCat.body.includes('katalog'));
 s.products.find(p=>p.id==='alu').catalog_url='';a.ok(C.composeMessage(l,s.config,s.products).body.includes('https://tabal.pl/tabal-alufence/'));
});
test('WIADOMOŚĆ 3.5: sygnatura HTML — wersja HTML wiadomości, oczyszczona ze skryptów i niebezpiecznych linków',()=>{
 const dirty='<table><tr><td><img src="https://tabal.pl/logo.png" onerror="alert(1)" width="120"><script>alert(2)</script></td><td style="color:#133e40;background:url(javascript:x)"><b>Jędrzej</b><br><a href="javascript:alert(3)">x</a> <a href="https://tabal.pl">tabal.pl</a> &amp; <a href="mailto:bok@tabal.pl">bok@tabal.pl</a></td></tr></table><iframe src="https://evil"></iframe>';
 const clean=C.sanitizeHtml(dirty);
 for(const bad of ['<script','onerror','javascript:','<iframe','url('])a.ok(!clean.includes(bad),bad);
 for(const good of ['<img src="https://tabal.pl/logo.png"','<b>Jędrzej</b>','href="https://tabal.pl"','href="mailto:bok@tabal.pl"','&amp;'])a.ok(clean.includes(good),good);
 const s=base(),st=strat(s);s.config=C.settings({...s.config,signature_html:dirty,signature:''});a.equal(s.config.signature_html,clean);
 const l=C.validateLead(raw('h1.example'),s,st);l.draft={subject:'T',body:'Dzień dobry,\n\nTreść https://tabal.pl/x.\n\nPozdrawiam'};
 const m=C.composeMessage(l,s.config,s.products);a.ok(m.html.includes(clean));a.ok(m.html.includes('<a href="https://tabal.pl/x">'));a.ok(m.body.includes('Jędrzej'));
 a.equal(C.htmlToText('<p>A&amp;B</p><p>C<br>D</p>'),'A&B\nC\nD');
});
test('WIADOMOŚĆ 3.5: lokalny szkic kończy się „Pozdrawiam” (sygnaturę dodaje wysyłka); zadanie Work zakazuje podpisu w treści',()=>{
 const s=base(),st=strat(s,{research_stage:'full'});const l=C.validateLead(raw('d1.example'),s,st);
 a.ok(C.draft(l,s.config,s.products).body.trim().endsWith('Pozdrawiam'));
 a.match(C.task(s,st,'r'),/BEZ podpisu, danych kontaktowych i linku do katalogu/);
});

// ---------- 6. Main recipient by role ----------
test('ODBIORCA 3.5: zaopatrzeniowiec jest głównym odbiorcą przed kontaktem ogólnym i innymi osobami; ręczny wybór ma pierwszeństwo',()=>{
 const s=base(),st=strat(s);const k='https://o1.example/kontakt';
 const l=C.validateLead(raw('o1.example',{contacts:[
  {type:'general',email:'biuro@o1.example',url:k,quote:'biuro@o1.example',checked_at:today,verified:true},
  {type:'person',name:'Jan Prezes',role:'Prezes zarządu',reason:'Zarząd',email:'prezes@o1.example',url:k,quote:'Jan Prezes Prezes zarządu prezes@o1.example',checked_at:today,verified:true},
  {type:'person',name:'Ola Nowak',role:'Zaopatrzeniowiec',reason:'Odpowiada za zakupy materiałów',email:'o.nowak@o1.example',url:k,quote:'Ola Nowak Zaopatrzeniowiec o.nowak@o1.example',checked_at:today,verified:true}]}),s,st);
 let r=C.mailRecipient(l,s.config,s.products);a.equal(r.p.email,'o.nowak@o1.example');a.equal(r.role,'zaopatrzeniowiec');
 a.equal(C.bestContact(l,s.config,undefined,s.products).p.email,'o.nowak@o1.example');
 l.primary_contact=C.contactKey(l.contacts.find(p=>p.email==='biuro@o1.example'));r=C.mailRecipient(l,s.config,s.products);a.equal(r.p.email,'biuro@o1.example');a.ok(r.primary);
 a.ok(C.roleScore({role:'Kierownik działu zakupów'},C.splitRoles('kierownik zakupów')));a.ok(C.roleScore({type:'general',email:'zakupy@x.pl'},C.splitRoles('zakupy')));
 const t=C.task(s,st,'r');a.match(t,/OSOBA WŁAŚCIWA DLA PRODUKTU „Ogrodzenia aluminiowe”/);a.match(t,/zaopatrzeniowiec/);
});
test('ODBIORCA 3.5: adres „do weryfikacji” trafia do wysyłki tylko po zatwierdzeniu przez operatora (i przetrwa zapis)',()=>{
 const s=base(),st=strat(s);const l=C.validateLead(raw('u1.example',{contacts:[{type:'general',email:'kontakt@u1.example',uncertain:true,reason:'z katalogu'}]}),s,st);
 l.status='TO_CONTACT';l.draft={subject:'Temat',body:'Dzień dobry,\n\nTreść.\n\nPozdrawiam'};
 a.equal(C.mailCandidate(l,s.config,'pilot',s.products).message,null);
 l.contacts[0].operator_ok=true;s.leads=[l];
 const back=C.restore(C.backup(s),'pilot');a.equal(back.leads[0].contacts[0].operator_ok,true);
 const m=C.mailCandidate(back.leads[0],back.config,'pilot',back.products).message;a.equal(m.to,'kontakt@u1.example');a.equal(m.verified_email,true);
 a.equal(C.mailCandidate(back.leads[0],{...back.config,allow_operator_emails:false},'pilot',back.products).message,null);
});

// ---------- 8. Area check (Bielawa for Warszawa +50 km) ----------
test('OBSZAR 3.5: Bielawa (58-260, dolnośląskie) przy „Warszawa +50 km” — poza obszarem, kara, archiwum przy imporcie',()=>{
 const s=base(),st=strat(s,{province:'mazowieckie',region:'mazowieckie, Polska',city:'Warszawa',radius_km:50});
 const out=C.validateLead(raw('bielawa.example',{address:'ul. Wolności 1, 58-260 Bielawa',city:'Bielawa',postal_code:'58-260',region:'dolnośląskie'}),s,st);
 const inn=C.validateLead(raw('piaseczno.example',{address:'ul. Puławska 1, 05-500 Piaseczno',city:'Piaseczno',postal_code:'05-500',region:'mazowieckie'}),s,st);
 const so=C.score(out,s.config),si=C.score(inn,s.config);
 a.equal(so.checks.area,'outside');a.equal(so.checks.region,'no');a.ok(so.blocks.some(b=>/Poza obszarem strategii: Bielawa/.test(b)));a.ok(so.points<s.config.threshold);
 a.equal(si.checks.area,'inside');a.equal(si.checks.region,'ok');a.ok(si.points>=s.config.threshold);
 s.leads=[out,inn];const q=C.importQuality(s,s.leads,[out.id,inn.id]);a.equal(q.outside.length,1);a.equal(q.weak[0].id,out.id);
 a.equal(C.archiveWeak(s,q.weak.map(w=>w.id)),1);a.equal(s.leads[0].status,'ARCHIVED');
});
test('OBSZAR 3.5: wieś o tej samej nazwie z kodem 05-xxx — „nie sprawdzono” zamiast kary; oddział w obszarze wystarcza',()=>{
 const s=base(),st=strat(s,{province:'mazowieckie',city:'Warszawa',radius_km:50});
 const vil=C.validateLead(raw('wies.example',{address:'Bielawa 12, 05-520 Bielawa',city:'Bielawa',postal_code:'05-520'}),s,st);
 const sv=C.score(vil,s.config);a.equal(sv.checks.area,'unknown');a.ok(!sv.parts.some(p=>p.key==='area'));
 const br=C.validateLead(raw('oddzial.example',{address:'ul. Polna 1, 30-001 Kraków',city:'Kraków',postal_code:'30-001',branches:[{name:'Oddział',city:'Pruszków',address:'ul. X 1, 05-800 Pruszków'}]}),s,st);
 a.equal(C.areaCheck(br).state,'inside');
 const prov=strat(s,{city:'',radius_km:0});const far=C.validateLead(raw('far.example',{address:'ul. A 1, 58-260 Bielawa',city:'Bielawa',postal_code:'58-260'}),s,prov);a.equal(C.areaCheck(far).state,'outside');
 const near=C.validateLead(raw('near.example',{address:'ul. A 1, 21-040 Świdnik',city:'Świdnik',postal_code:'21-040'}),s,prov);a.equal(C.areaCheck(near).state,'inside');
 a.match(C.task(s,{...st,mode:'open'},'r'),/LOKALIZACJA — SPRAWDZA JĄ APLIKACJA/);
});

// ---------- Migration from 3.4 ----------
test('MIGRACJA 3.5: kopia z 3.4 — produkty dostają osoby właściwe, sygnatura = dotychczasowy podpis; szkice i statusy bez zmian',()=>{
 const s=base();s.migrations=s.migrations.filter(m=>!m.startsWith('v35'));for(const p of s.products){delete p.contact_roles;delete p.catalog_url;}delete s.config.signature;s.config.sender='Jan Kowalski\nTABAL';
 const st=strat(s);const l=C.validateLead(raw('mig.example'),s,st);l.status='TO_CONTACT';l.draft={subject:'S',body:'B',origin:'work'};s.leads=[l];
 const r=C.restore(C.backup(s),'pilot');
 a.ok(r.products.find(p=>p.id==='alu').contact_roles.includes('zaopatrzeniowiec'));a.equal(r.products.find(p=>p.id==='alu').catalog_url,'');
 a.equal(r.config.signature,'Jan Kowalski\nTABAL');a.equal(r.config.auto_signature,true);a.equal(r.leads[0].status,'TO_CONTACT');a.equal(r.leads[0].draft.body,'B');a.equal(r.app_version,'3.5.0');
});
