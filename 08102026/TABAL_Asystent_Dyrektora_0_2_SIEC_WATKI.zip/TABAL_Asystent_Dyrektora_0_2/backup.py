import argparse,sqlite3
from pathlib import Path
from datetime import datetime
p=argparse.ArgumentParser();p.add_argument('--data-dir',default=str(Path(__file__).resolve().parent/'.runtime'));p.add_argument('--out',default='kopie');a=p.parse_args()
src=Path(a.data_dir)/'knowledge.sqlite3'
if not src.is_file():raise SystemExit('Nie znaleziono bazy. Najpierw uruchom aplikację i zaimportuj materiały.')
Path(a.out).mkdir(parents=True,exist_ok=True);target=Path(a.out)/('wiedza_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f')+'.sqlite3')
with sqlite3.connect(src) as s,sqlite3.connect(target) as d:s.backup(d)
print('Kopia zapisana: '+str(target.resolve()))
