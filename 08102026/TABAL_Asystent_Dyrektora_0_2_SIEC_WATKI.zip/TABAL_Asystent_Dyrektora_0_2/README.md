# TABAL — Asystent wiedzy dyrektora

Działający prototyp lokalnego przekazywania wiedzy. Importuje archiwum materiałów, wyszukuje fragmenty związane z pytaniem i pozwala prowadzić listę spraw do przejęcia z odnośnikami do dowodów. Wersja 0.2, 7 października 2026. Zachowuje poprawkę kodowania Windows z wersji 0.1.1.

**To wyszukiwarka wiedzy z cytatami, bez generatywnego modelu językowego.** Nie odtwarza całej wiedzy poprzedniego dyrektora, nie podejmuje za niego decyzji i nie udaje tej osoby. Nie potrzebuje klucza API ani abonamentu. Aplikacja nie wysyła treści do zewnętrznego API. Przy indeksowaniu dysku sieciowego kopiuje obsługiwane pliki do lokalnej bazy na komputerze operatora. Do pierwszej instalacji bibliotek potrzebne jest połączenie z internetem.

## Uruchomienie

1. Rozpakuj cały ZIP do osobnego folderu na komputerze.
2. Zainstaluj Python 3.10 lub nowszy. W Windows zaznacz dodanie Pythona do PATH.
3. Windows: uruchom `URUCHOM_WINDOWS.bat`. macOS/Linux: w terminalu w folderze aplikacji wykonaj `sh URUCHOM_MAC_LINUX.command`.
4. Otwórz **http://127.0.0.1:8770**. Okno terminala pozostaw otwarte. Zakończ aplikację przez Ctrl+C.

Ręcznie, Windows:

```bat
python -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt
.venv\Scripts\python.exe serve.py --open
```

Ręcznie, macOS/Linux:

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python serve.py --open
```

Gdy port jest zajęty, dodaj `--port 8771` i otwórz adres z portem 8771. Jeśli Python nie istnieje w poleceniu Windows, sprawdź instalację/PATH lub użyj `py -3` przy tworzeniu środowiska. Po instalacji można uruchamiać bezpośrednio `serve.py` powyższym poleceniem, bez ponownego pobierania bibliotek.

## Pierwsza próba — pięć minut

1. Wybierz **Materiały źródłowe → Wczytaj DEMO** i potwierdź. Pakiet zawiera siedem fikcyjnych dokumentów; nazwy i ustalenia nie opisują rzeczywistych klientów TABAL.
2. Zapytaj: **Jakie terminy dostawy ustalono dla Orion?** Zobaczysz pierwotny termin 10 października i propozycję 15 października bez potwierdzenia klienta. Aplikacja nie rozstrzyga automatycznie, która wersja obowiązuje.
3. Otwórz źródło. Sprawdź treść, lokalizację fragmentu oraz SHA-256. Pobierz oryginał, jeśli potrzebujesz pełnego kontekstu.
4. Dodaj sprawę do przejęcia: „Potwierdzić termin Orion”, właściciela, termin i uwagę. Status „Potwierdzone” oznacza deklarację użytkownika, nie weryfikację systemu.
5. W zakładce spraw zmień status i wyeksportuj listę do JSON.
6. Zapytaj o wynagrodzenie prezesa — przykładowe materiały nie zawierają odpowiedzi.

## Własne materiały

Najpierw zakończ demo. Dla rzeczywistych danych uruchom aplikację z osobnym katalogiem, np. Windows:

```bat
.venv\Scripts\python.exe serve.py --data-dir dane_tabalu --open
```

macOS/Linux:

```sh
.venv/bin/python serve.py --data-dir dane_tabalu --open
```

Używaj tego samego parametru przy każdym kolejnym uruchomieniu. Wczytuj wybrane materiały służbowe udostępnione nowemu dyrektorowi. W zakładce materiałów wybierz pliki i uruchom import. Sprawdź raport dodanych, pominiętych i błędnych plików; częściowy import ZIP może zawierać zarówno sukcesy, jak i błędy. Identyczny plik jest pomijany po skrócie treści; zmieniona wersja tego samego pliku pozostaje osobnym źródłem.

| Materiał | Obsługa i ograniczenia |
|---|---|
| E-maile | EML, MBOX; nagłówki, tekst oraz obsługiwane załączniki. Duże archiwum MBOX podziel na partie. PST/OST/MSG wymagają wcześniejszego eksportu do EML/MBOX. |
| Dokumenty | DOCX: akapity i tabele. Nie gwarantuje odczytu obrazów, nagłówków, przypisów ani komentarzy. Stary DOC wymaga konwersji. |
| PDF | Tylko warstwa tekstowa; wskazanie strony. Brak OCR skanów, szyfrowane PDF nie są obsługiwane. |
| Arkusze | XLSX, CSV, TSV; lokalizacja arkusza/wiersza. Formuły XLSX pokazywane jako tekst, nie są obliczane. XLS wymaga konwersji. |
| SMS | XML z elementami `sms` (eksport SMS Backup & Restore). MMS i załączniki multimedialne nie są obsługiwane. |
| Wiadomości JSON | Tablica lub obiekt `messages`/`sms`; tekst w `body`/`text`/`content`, opcjonalnie `sender`/`from`/`address` i `date`. |
| Tekst | TXT, MD, HTML; bez wykonywania skryptów HTML. |
| Paczka | ZIP z powyższymi formatami. Import w pamięci, bez wypakowywania ścieżek archiwum na dysk. |

Limity prototypu: 20 MB na plik wejściowy, 60 MB po rozpakowaniu ZIP, 1000 elementów archiwum, 250 dokumentów na import, 2 mln znaków na dokument i 20 000 fragmentów w bazie. Skan dysku sieciowego przetwarza pliki kolejno w tle. Nie testowano wydajności na maksymalnych rozmiarach ani wszystkich wariantów eksportów pocztowych.

## Dysk sieciowy - odczyt i odświeżanie

1. Najpierw zamontuj firmowy udział w systemie na koncie, które ma prawo czytać te materiały. Windows: połącz dysk sieciowy w Eksploratorze (np. `Z:\Wiedza`) albo użyj ścieżki UNC `\\serwer\udzial\Wiedza`. macOS: Finder -> Idź -> Połącz z serwerem (`smb://serwer/udzial`); po połączeniu wskaż folder, np. `/Volumes/udzial/Wiedza`. Uprawnienia i logowanie do udziału obsługuje system, nie aplikacja.
2. W aplikacji otwórz **Materiały źródłowe -> Dysk sieciowy**, wpisz pełną ścieżkę zamontowanego folderu i kliknij **Zapisz folder i skanuj**. Skan jest ręczny; **Odśwież dysk** sprawdza zmiany. Nie ma automatycznego zapisu ani usuwania plików na udziale.
3. Program czyta obsługiwane formaty w podfolderach, pomija dowiązania symboliczne, pliki ukryte i nieobsługiwane rozszerzenia. Zapisuje oryginały i tekst w lokalnej bazie, a nazwa źródła zawiera względną ścieżkę z udziału. Powtórny skan pomija pliki o niezmienionym rozmiarze i czasie modyfikacji; zmieniony plik zostaje nową wersją źródła. Limit pojedynczego skanu: 10 000 plików. Wybierz węższy folder, gdy trzeba.
4. Gdy udział zostanie odłączony, wcześniej skopiowane materiały pozostają dostępne lokalnie. Plik usunięty z udziału oznaczany jest jako brakujący, ale nie kasuje archiwalnej wiedzy. W razie błędów sprawdź postęp i komunikaty w panelu.

Ścieżka udziału jest zapisywana w katalogu danych aplikacji. Nie zapisujemy hasła do SMB/NAS. Jeśli folder zawiera dane o różnym poziomie dostępu, wskaż tylko podfolder udostępniony temu operatorowi. Ta wersja nie ma indywidualnych uprawnień per dokument.

## Analiza rozległego wątku

W zakładce **Zapytaj o wiedzę** wpisz nazwę klienta, projektu lub numer sprawy i wybierz **Analizuj rozległy wątek**. Program przeszukuje całą zaindeksowaną bazę, zbiera do czterech pasujących fragmentów na źródło i układa źródła według znanych dat. Widok pokazuje liczbę dopasowanych dokumentów, fragmentów, cytaty, odnośniki do oryginałów i proste sygnały: propozycje zmian, niepotwierdzone ustalenia oraz brakujące materiały. Kolejne wyniki odsłaniasz przyciskiem **Pokaż kolejne fragmenty**.

Daty EML pochodzą z nagłówków. W TXT/MD program rozpoznaje datę w pierwszych dwóch liniach, jeśli ma czytelny polski lub ISO format. Nieznana data trafia na koniec chronologii. Widok obejmuje najwyżej 200 najlepiej dopasowanych dokumentów i pokazuje, gdy źródeł jest więcej. To lokalna analiza cytatów i słów kluczowych, bez modelu GPT; nie wyciąga automatycznie prawnie wiążących wniosków ani nie rozstrzyga, która wersja ustalenia obowiązuje.

Trzy fikcyjne materiały do sprawdzenia wątku Brzozy są w folderze `examples/`. Możesz wskazać ten folder jako źródło testowe. Oczekiwane: uzgodniony termin 12 października, propozycja 15 października bez potwierdzenia oraz późniejszy raport spraw otwartych.

## Jak interpretować odpowiedzi

Wyszukiwanie działa leksykalnie: normalizuje polskie znaki, skraca słowa, stosuje kilka grup synonimów i ranking zbliżony do BM25. Nazwy zapisane wielką literą, jeśli występują w indeksie i nie są zbyt częste, zawężają wyniki. Przycisk **Znajdź cytaty** zwraca maksymalnie sześć fragmentów i dwa na dokument; osobny tryb analizy wątku ma szerszy zakres opisany powyżej. To nie jest wyszukiwanie semantyczne ani gwarancja kompletności. W razie braku wyniku spróbuj nazwy projektu, firmy lub słowa użytego w źródłach.

Treść cytatu jest zachowana wraz z lokalizacją, nazwą dokumentu i identyfikatorem źródła. Widoczna data pochodzi z metadanych, jeśli importer potrafi ją odczytać; nie stanowi dowodu obowiązywania ustalenia. System nie wykrywa automatycznie wszystkich sprzeczności, nie określa ważności umów i nie wymyśla brakujących odpowiedzi. Informacje zawarte w dokumentach są danymi, a nie instrukcjami wykonywanymi przez aplikację.

## Dane, kopia i odtworzenie

Oryginały, tekst, historia pytań i sprawy znajdują się w bazie `knowledge.sqlite3` w `.runtime` lub katalogu wskazanym przez `--data-dir`. Baza nie jest szyfrowana przez aplikację; korzystaj z chronionego konta i szyfrowanego dysku. Komputer i procesy tego samego użytkownika mają dostęp do danych. Token lokalnej sesji nie zastępuje kont i uprawnień.

Kopia (Windows; macOS/Linux zamień ścieżkę interpretera na `.venv/bin/python`):

```bat
.venv\Scripts\python.exe backup.py --data-dir dane_tabalu --out kopie
```

Kopia SQLite obejmuje oryginały i sprawy, działa także podczas pracy programu. Aby odtworzyć: zatrzymaj program, utwórz pusty katalog `odtworzone`, skopiuj wybraną kopię do `odtworzone/knowledge.sqlite3`, uruchom z `--data-dir odtworzone`. Nie nadpisuj czynnej bazy. Eksport spraw JSON jest raportem, nie pełną kopią do odtworzenia.

Usunięcie źródła usuwa jego wpis, fragmenty i związane sprawy z aktywnej bazy. Historia pytań, wpis audytowy z nazwą pliku oraz wcześniejsze kopie pozostają. To nie jest bezpieczne wymazywanie danych z dysku. Aby rozpocząć od zera, użyj nowego katalogu danych.

## Zakres wdrożenia

Prototyp działa na jednym komputerze dla jednego operatora i nasłuchuje tylko na 127.0.0.1. Nie wystawiaj go bezpośrednio do internetu ani nie obchodź tego ograniczenia tunelem. Wersja współdzielona na serwerze wymaga kont, uprawnień do dokumentów, TLS, kontroli dostępu, kolejek importu i przetestowanych kopii. W tej paczce nie wdrożono tych funkcji.

Nie podłączono modelu językowego. Etap generatywnego asystenta wymaga osobnego wdrożenia wybranego modelu i testów odpowiedzi na rzeczywistych materiałach. W tej sesji nie utworzono klucza API i aplikacja nie ma pola do jego wpisywania.

## Sprawdzenie i zawartość

Testy Python:

```sh
python tests/test_app.py
```

Użyj interpretera ze środowiska `.venv`. Testy przeglądarkowe: Node.js z pakietem `playwright`, zainstalowany Chromium (`npx playwright install chromium`); uruchom aplikację na osobnym, pustym katalogu danych, następnie `node tests/browser.cjs`. Test importuje DEMO i wykonuje operacje na bazie testowej. Nie uruchamiaj go na bazie firmowej. Opcjonalne zmienne: `TEST_URL`, `CHROMIUM_PATH`.

W `test-results/` znajduje się wynik testów Python. `RAPORT_TESTOW.md` podaje zakres i ograniczenia. Testy tej wersji wykonano na Linux/Python z symulowanym zamontowanym folderem; test przeglądarkowy nie wystartował w tym środowisku z powodu niedostępnej binarki Chromium. Ustaw `TEST_NETWORK_DIR` na folder `examples/`, aby włączyć dodatkowy scenariusz 10 testu interfejsu. Rzeczywisty udział TABAL wymaga konfiguracji na komputerze uprawnionego operatora. Skrypty Windows i macOS są dołączone, ale nie były uruchamiane na tych systemach; `demo/make_demo.py` służy jedynie do regeneracji danych przykładowych i dodatkowo wymaga `reportlab`; gotowe pliki DEMO są już w paczce.
