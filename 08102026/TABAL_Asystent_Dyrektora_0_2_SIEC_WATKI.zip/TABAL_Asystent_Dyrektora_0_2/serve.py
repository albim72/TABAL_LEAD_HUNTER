#!/usr/bin/env python3
import base64,json,os,secrets,threading,argparse
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit,parse_qs,quote
from app.knowledge import Knowledge
from app.network import NetworkSource
ROOT=Path(__file__).resolve().parent

def make_handler(kb,token,port,network=None):
 class Handler(BaseHTTPRequestHandler):
  def log_message(self,*args):pass
  def send(self,status,data,kind='application/json; charset=utf-8',headers=None):
   if isinstance(data,(dict,list)):data=json.dumps(data,ensure_ascii=False).encode()
   elif isinstance(data,str):data=data.encode()
   self.send_response(status);self.send_header('Content-Type',kind);self.send_header('Content-Length',str(len(data)));self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff');self.send_header('X-Frame-Options','DENY');self.send_header('Referrer-Policy','no-referrer');self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self' data:; object-src 'none'; base-uri 'none'; frame-ancestors 'none'")
   for key,value in (headers or {}).items():self.send_header(key,value)
   self.end_headers();self.wfile.write(data)
  def check(self,api=False):
   host=self.headers.get('Host','')
   if host not in (f'127.0.0.1:{port}',f'localhost:{port}'):raise PermissionError('Nieprawidłowy adres serwera.')
   if api and not secrets.compare_digest(self.headers.get('X-Director-Token',''),token):raise PermissionError('Nieprawidłowy token sesji. Odśwież panel.')
   origin=self.headers.get('Origin')
   if origin and origin not in (f'http://127.0.0.1:{port}',f'http://localhost:{port}'):raise PermissionError('Niedozwolone pochodzenie żądania.')
  def do_GET(self):
   try:
    self.check();u=urlsplit(self.path);path=u.path
    if path=='/':return self.send(200,(ROOT/'static/index.html').read_text(encoding='utf-8').replace('__TOKEN__',token),'text/html; charset=utf-8')
    if path=='/static/docs.css':return self.send(200,(ROOT/'static/docs.css').read_bytes(),'text/css; charset=utf-8')
    if path in ('/app.js','/style.css'):return self.send(200,(ROOT/'static'/path[1:]).read_bytes(),'text/javascript; charset=utf-8' if path.endswith('.js') else 'text/css; charset=utf-8')
    if path=='/INSTRUKCJA.html':return self.send(200,(ROOT/'INSTRUKCJA.html').read_bytes(),'text/html; charset=utf-8')
    if path.startswith('/api/'):
     self.check(True)
     if path=='/api/state':return self.send(200,{'stats':kb.stats(),'documents':kb.documents(),'notes':kb.notes(),'network':network.info() if network else None})
     if path=='/api/network':return self.send(200,network.info() if network else {'path':'','available':False,'status':{'running':False}})
     if path=='/api/source':return self.send(200,kb.source(parse_qs(u.query).get('id',[''])[0]))
     if path=='/api/export':return self.send(200,kb.export())
     if path=='/api/original':
      ident=parse_qs(u.query).get('id',[''])[0]
      with kb.lock:row=kb.db.execute('SELECT name,raw FROM documents WHERE id=?',(ident,)).fetchone()
      if not row:raise ValueError('Nie znaleziono oryginału.')
      return self.send(200,row['raw'],'application/octet-stream',{'Content-Disposition':"attachment; filename*=UTF-8''"+quote(Path(row['name']).name)})
    return self.send(404,{'error':'Nie znaleziono zasobu.'})
   except PermissionError as e:self.send(403,{'error':str(e)})
   except ValueError as e:self.send(400,{'error':str(e)})
  def do_POST(self):
   try:
    self.check(True)
    if self.headers.get('Origin') not in (f'http://127.0.0.1:{port}',f'http://localhost:{port}'):raise PermissionError('Brak poprawnego Origin.')
    if self.headers.get('Content-Type','').split(';')[0]!='application/json':raise ValueError('Wymagany JSON.')
    size=int(self.headers.get('Content-Length','0'))
    if not 0<size<29_000_000:raise ValueError('Zbyt duże żądanie. Maksymalnie 20 MB danych jednego pliku.')
    raw=json.loads(self.rfile.read(size));path=urlsplit(self.path).path
    if not isinstance(raw,dict):raise ValueError('Nieprawidłowy format danych.')
    if path=='/api/import':
     data=base64.b64decode(raw.get('data',''),validate=True)
     return self.send(200,kb.ingest(str(raw.get('name','plik')),data))
    if path=='/api/ask':return self.send(200,kb.ask(str(raw.get('question','')),str(raw.get('kind',''))))
    if path=='/api/thread':return self.send(200,kb.thread(str(raw.get('question','')),str(raw.get('kind',''))))
    if path=='/api/network/config':
     if not network:raise ValueError('Indeksowanie folderu nie zostało uruchomione.')
     return self.send(200,network.configure(raw.get('path','')))
    if path=='/api/network/scan':
     if not network:raise ValueError('Indeksowanie folderu nie zostało uruchomione.')
     return self.send(200,network.start())
    if path=='/api/note':return self.send(200,{'id':kb.note(raw)})
    if path=='/api/delete':kb.delete(str(raw.get('id','')));return self.send(200,{'ok':True})
    if path=='/api/demo':
     if not raw.get('confirm'):raise ValueError('Potwierdź import fikcyjnych danych.')
     reports=[kb.ingest(p.name,p.read_bytes()) for p in sorted((ROOT/'demo').iterdir()) if p.suffix in ('.eml','.docx','.xlsx','.xml','.json','.pdf')]
     return self.send(200,{'reports':reports})
    return self.send(404,{'error':'Nieznana operacja.'})
   except PermissionError as e:self.send(403,{'error':str(e)})
   except (ValueError,TypeError,KeyError) as e:self.send(400,{'error':str(e)})
   except Exception:
    self.send(500,{'error':'Nie udało się przetworzyć danych. Oryginalny plik pozostał bez zmian. Sprawdź format i raport importu.'})
 return Handler

def main():
 p=argparse.ArgumentParser();p.add_argument('--open',action='store_true');p.add_argument('--port',type=int,default=8770);p.add_argument('--data-dir',default=str(ROOT/'.runtime'));args=p.parse_args()
 # Bind before opening databases to prevent accidental second server start.
 http=ThreadingHTTPServer(('127.0.0.1',args.port),BaseHTTPRequestHandler)
 kb=Knowledge(Path(args.data_dir)/'knowledge.sqlite3');network=NetworkSource(kb,args.data_dir);http.RequestHandlerClass=make_handler(kb,secrets.token_urlsafe(32),args.port,network)
 print(f'TABAL — Asystent wiedzy dyrektora: http://127.0.0.1:{args.port}',flush=True);print('Tryb lokalny, odpowiedzi źródłowe, bez API. Zakończ Ctrl+C.',flush=True)
 if args.open:
  import webbrowser
  threading.Timer(.7,lambda:webbrowser.open(f'http://127.0.0.1:{args.port}')).start()
 try:http.serve_forever()
 except KeyboardInterrupt:pass
 finally:http.server_close();kb.db.close()
if __name__=='__main__':main()
