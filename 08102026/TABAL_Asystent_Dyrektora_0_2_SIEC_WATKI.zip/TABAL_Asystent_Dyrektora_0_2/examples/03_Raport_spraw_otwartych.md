# Raport spraw otwartych — 1 października 2026 r.

**DEMO: wszystkie dane poniżej są fikcyjne. Nie opisują rzeczywistych spraw TABAL.**

## Reklamacja Wrzos

Reklamacja Wrzos, numer WR-2026-09: klient zgłosił uszkodzenie 8 słupków podczas transportu. Opiekun reklamacji: Paweł Modelowy, pawel.modelowy@example.com. Dokumentacja zdjęciowa wpłynęła 30 września 2026 r. Brakuje protokołu szkody od przewoźnika. Paweł ma uzyskać protokół do 5 października 2026 r. Decyzja o wymianie towaru lub rekompensacie nie została jeszcze podjęta. Nowy dyrektor powinien rozpatrzyć reklamację po otrzymaniu pełnej dokumentacji.

## Klient Brzoza

Klient Brzoza: na 1 października brak potwierdzenia propozycji przesunięcia dostawy z 12 na 15 października 2026 r. Za uzyskanie potwierdzenia odpowiada Anna Przykładowa. Termin zadania: 2 października 2026 r. Nie przedstawiać 15 października jako uzgodnionej daty dostawy. Szczegóły propozycji są w e-mailu z 30 września.

## Projekt Latarnia

Projekt Latarnia: protokół odbioru instalacji elektrycznej nadal nie wpłynął. Maria Wzorcowa ma go pozyskać do 7 października 2026 r. Plan uruchomienia 22 października pozostaje warunkowy. Nowy dyrektor ma zatwierdzić uruchomienie dopiero po sprawdzeniu protokołu. W raporcie nie odnotowano nowych zatwierdzonych wydatków; budżet pozostaje zgodny z notatką przekazania.

## Dostawca Modrzew

Dostawca Modrzew: 1 października telefonicznie podtrzymał termin dostawy 8 października. Tomasz Testowy ma uzyskać potwierdzenie pisemne do 2 października. Nie ma jeszcze podstaw do uruchomienia zamówienia u dostawcy rezerwowego.

## Zakres informacji

Raport nie zawiera wynagrodzenia poprzedniego dyrektora, haseł do systemów, numerów rachunków ani wyników finansowych całej firmy. Nie należy dopowiadać tych informacji.
