@echo off
set PYTHONUTF8=1
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe python -m venv .venv
if not exist .venv\Scripts\python.exe goto error
.venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 goto error
.venv\Scripts\python.exe -X utf8 serve.py --open
pause
exit /b
:error
echo Sprawdz instalacje Python 3.10+ i polaczenie z internetem do pobrania bibliotek.
pause
