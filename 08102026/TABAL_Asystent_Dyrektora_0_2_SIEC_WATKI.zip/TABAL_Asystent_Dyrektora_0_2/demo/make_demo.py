from pathlib import Path
from email.message import EmailMessage
from docx import Document
from openpyxl import Workbook
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
import json
r=Path(__file__).resolve().parent
for name,date,subject,text in [
 ('01_Orion_pierwotny_termin.eml','Mon, 14 Sep 2026 09:00:00 +0200','DEMO — Orion: pierwotny termin dostawy','DANE FIKCYJNE DO TESTÓW.\nKlient Orion: wstępny termin dostawy paneli ustalono na 10 października 2026. Warunki płatności: 30 dni od wystawienia faktury. Opiekunem klienta jest Jan Testowy.\nUstalenie wymaga potwierdzenia dostępności transportu.'),
 ('02_Orion_propozycja_zmiany.eml','Wed, 23 Sep 2026 14:10:00 +0200','DEMO — Orion: propozycja przesunięcia dostawy','DANE FIKCYJNE DO TESTÓW.\nProponujemy zmianę terminu dostawy dla Orion z 10 na 15 października 2026, ponieważ przewoźnik nie potwierdził auta. Klient NIE POTWIERDZIŁ jeszcze nowego terminu. Przed uznaniem 15 października za obowiązujący Jan Testowy musi uzyskać akceptację klienta.\nDotychczasowe warunki płatności: 30 dni.')]:
 m=EmailMessage();m['Subject']=subject;m['From']='dyrektor-demo@example.com';m['To']='opiekun-demo@example.com';m['Date']=date;m.set_content(text);(r/name).write_bytes(m.as_bytes())
d=Document();d.add_heading('DEMO — Notatka przekazania obowiązków',0)
d.add_paragraph('Wszystkie firmy, osoby i ustalenia w tym zestawie są fikcyjne.')
d.add_heading('Reklamacja Delta',1);d.add_paragraph('Reklamację klienta Delta prowadzi Marta Nowak DEMO. Numer sprawy: DEL-2026-17. Zgłoszono uszkodzenia powłoki na 12 elementach. Magazyn ma wykonać zdjęcia partii, a dział jakości potwierdzić przyczynę. Nie zatwierdzono jeszcze wymiany ani rekompensaty.')
d.add_heading('Projekt Hala Północ',1);d.add_paragraph('Ryzyko projektu Hala Północ: niezatwierdzony rysunek montażowy. Osoba odpowiedzialna: Piotr Testowy. Nie zamawiać elementów na podstawie wersji roboczej rysunku. Potrzebne podpisane zatwierdzenie od inwestora.')
d.add_heading('Relacja z Orion',1);d.add_paragraph('Orion oczekuje potwierdzenia nowego harmonogramu. Sprawdź korespondencję z 14 i 23 września: proponowane przesunięcie nie jest jeszcze zaakceptowaną zmianą.')
d.save(r/'03_Notatka_przekazania_DEMO.docx')
w=Workbook();s=w.active;s.title='Warunki klientów';s.append(['Klient DEMO','Płatność','Limit rabatu','Opiekun','Status warunków']);s.append(['Orion','30 dni od faktury','4%','Jan Testowy','Do ponownego potwierdzenia']);s.append(['Delta','14 dni od faktury','2%','Marta Nowak DEMO','Historyczne — stan 01.09.2026']);s=w.create_sheet('Kontrola');s.append(['Kwota DEMO','Formuła — nieprzeliczana']);s.append([1000,'=A2*0.04']);w.save(r/'04_Warunki_handlowe_DEMO.xlsx')
(r/'05_SMS_Hala_Polnoc_DEMO.xml').write_text('''<?xml version="1.0" encoding="UTF-8"?><smses count="2"><sms address="DEMO" contact_name="Piotr Testowy" readable_date="2026-09-24 10:30" body="DEMO: Hala Północ — ekipa montażowa zgłasza ryzyko opóźnienia o 2 dni. Termin nie jest jeszcze zatwierdzony."/><sms address="DEMO" contact_name="Dyrektor DEMO" readable_date="2026-09-24 10:35" body="DEMO: proszę uzyskać podpisany rysunek Hala Północ przed zamówieniem elementów."/></smses>''',encoding='utf8')
(r/'06_Wiadomosci_Delta_DEMO.json').write_text(json.dumps({'messages':[{'date':'2026-09-25 12:00','sender':'Marta Nowak DEMO','text':'DEMO: reklamacja Delta DEL-2026-17. Zdjęcia są w przygotowaniu. Decyzji o wymianie jeszcze nie podjęto.'}]},ensure_ascii=False,indent=2),encoding='utf-8')
font=Path('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf')
if font.exists():pdfmetrics.registerFont(TTFont('Demo',str(font)));fn='Demo'
else:fn='Helvetica'
c=canvas.Canvas(str(r/'07_Zasady_rabatowe_DEMO.pdf'));c.setFont(fn,13);y=790
for line in ['DEMO — fikcyjne zasady handlowe','Stan roboczy na 1 września 2026','Orion: maksymalny rabat 4%, po akceptacji dyrektora.','Delta: maksymalny rabat 2%.','Każdy wyjątek wymaga zapisanej decyzji.','To dane demonstracyjne, nie rzeczywista oferta TABAL.']:
 c.drawString(45,y,line);y-=32
c.save()
