"""Read-only indexing of an OS-mounted network share. No SMB credentials are stored."""
import hashlib,json,os,threading,uuid
from pathlib import Path
from app.extract import MAX_FILE,SUPPORTED
from app.knowledge import now

class NetworkSource:
 def __init__(self,kb,data_dir):
  self.kb=kb;self.data_dir=Path(data_dir);self.config=self.data_dir/'network_source.json'
  self.lock=threading.RLock();self.status={'running':False,'scanned':0,'added':0,'unchanged':0,'failed':0,'total':0,'errors':[]}
  with kb.lock,kb.db:
   kb.db.execute('''CREATE TABLE IF NOT EXISTS network_files(
     path TEXT PRIMARY KEY,mtime_ns INTEGER,size INTEGER,sha TEXT,document_id TEXT,
     seen TEXT,status TEXT,error TEXT)''')
 def root(self):
  if not self.config.exists():return None
  try:return Path(json.loads(self.config.read_text(encoding='utf-8'))['path'])
  except (ValueError,KeyError,OSError,TypeError):return None
 def info(self):
  root=self.root()
  with self.lock:status=dict(self.status);status['errors']=list(self.status['errors'])
  with self.kb.lock:
   count=self.kb.db.execute("SELECT COUNT(*) FROM network_files WHERE status='indexed'").fetchone()[0]
  return {'path':str(root) if root else '', 'available':bool(root and root.is_dir()),
          'indexed_files':count,'status':status}
 def configure(self,value):
  if not isinstance(value,str) or not value.strip() or '\x00' in value or len(value)>1000:
   raise ValueError('Wskaż pełną ścieżkę do zamontowanego folderu sieciowego.')
  try:root=Path(value.strip()).expanduser().resolve(strict=True)
  except (OSError,RuntimeError):raise ValueError('Folder nie istnieje lub dysk sieciowy nie jest zamontowany.') from None
  if not root.is_dir():raise ValueError('Ścieżka nie jest folderem. Najpierw zamontuj dysk w systemie.')
  with self.lock:
   if self.status['running']:raise ValueError('Poczekaj na zakończenie obecnego skanowania.')
   previous=self.root()
   temp=self.config.with_suffix('.tmp')
   fd=os.open(temp,os.O_WRONLY|os.O_CREAT|os.O_TRUNC,0o600)
   with os.fdopen(fd,'w',encoding='utf-8') as f:json.dump({'path':str(root)},f,ensure_ascii=False)
   os.replace(temp,self.config)
   if previous != root:
    # Relative paths in the scan table belong to a single configured root.
    # Retain already imported documents as historical sources.
    with self.kb.lock,self.kb.db:self.kb.db.execute('DELETE FROM network_files')
  return self.info()
 def start(self):
  root=self.root()
  if not root or not root.is_dir():raise ValueError('Dysk jest niedostępny. Zamontuj udział i wskaż jego folder.')
  with self.lock:
   if self.status['running']:return self.info()
   self.status={'running':True,'scanned':0,'added':0,'unchanged':0,'failed':0,'total':0,'errors':[]}
  threading.Thread(target=self._run,args=(root,),daemon=True,name='director-network-index').start()
  return self.info()
 def _error(self,rel,error):
  with self.lock:
   self.status['failed']+=1
   if len(self.status['errors'])<30:self.status['errors'].append({'path':rel,'message':str(error)[:300]})
 def _run(self,root):
  seen=uuid.uuid4().hex
  try:
   for directory,dirs,files in os.walk(root,followlinks=False):
    dirs[:]=sorted(d for d in dirs if not d.startswith('.') and not (Path(directory)/d).is_symlink())
    for name in sorted(files):
     path=Path(directory)/name
     if path.is_symlink() or path.suffix.lower() not in SUPPORTED or name.startswith('.'):continue
     rel=path.relative_to(root).as_posix()
     with self.lock:self.status['total']+=1
     try:
      if not path.resolve(strict=True).is_relative_to(root):raise ValueError('Plik wychodzi poza wskazany folder.')
      stat=path.stat()
      if not path.is_file() or stat.st_size>MAX_FILE:raise ValueError('Plik przekracza limit 20 MB.')
      with self.kb.lock:
       old=self.kb.db.execute('SELECT mtime_ns,size,document_id FROM network_files WHERE path=?',(rel,)).fetchone()
       present=old and old['document_id'] and self.kb.db.execute('SELECT 1 FROM documents WHERE id=?',(old['document_id'],)).fetchone()
      if old and present and old['mtime_ns']==stat.st_mtime_ns and old['size']==stat.st_size:
       with self.kb.lock,self.kb.db:self.kb.db.execute('UPDATE network_files SET seen=?,status=? WHERE path=?',(seen,'indexed',rel))
       with self.lock:self.status['unchanged']+=1
      else:
       data=path.read_bytes()
       if len(data)>MAX_FILE or path.stat().st_mtime_ns!=stat.st_mtime_ns:raise ValueError('Plik zmienił się podczas odczytu; spróbuj ponownie.')
       digest=hashlib.sha256(data).hexdigest()
       report=self.kb.ingest(name,data,source_label='Dysk sieciowy / '+rel)
       if report['errors']:raise ValueError('; '.join(x['message'] for x in report['errors']))
       with self.kb.lock,self.kb.db:
        row=self.kb.db.execute('SELECT id FROM documents WHERE sha=?',(digest,)).fetchone()
        self.kb.db.execute('''INSERT INTO network_files VALUES(?,?,?,?,?,?,?,?)
         ON CONFLICT(path) DO UPDATE SET mtime_ns=excluded.mtime_ns,size=excluded.size,sha=excluded.sha,
         document_id=excluded.document_id,seen=excluded.seen,status=excluded.status,error=excluded.error''',
         (rel,stat.st_mtime_ns,stat.st_size,digest,row['id'] if row else None,seen,'indexed',''))
       with self.lock:self.status['added']+=len(report['added'])
     except Exception as exc:self._error(rel,exc)
     with self.lock:self.status['scanned']+=1
     if self.status['total']>=10000:raise ValueError('Limit jednego skanowania: 10 000 plików. Wskaż węższy folder.')
   with self.kb.lock,self.kb.db:
    self.kb.db.execute("UPDATE network_files SET status='missing' WHERE seen<>?",(seen,))
  except Exception as exc:self._error(str(root),exc)
  finally:
   with self.lock:self.status['running']=False;self.status['finished']=now()
