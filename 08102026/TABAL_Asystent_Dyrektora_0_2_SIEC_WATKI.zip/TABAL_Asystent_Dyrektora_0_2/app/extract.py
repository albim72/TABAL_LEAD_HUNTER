"""Offline importers. Content is data: no macros, scripts or embedded commands run."""
import csv,hashlib,io,json,re,zipfile
from dataclasses import dataclass,field
from email import policy
from email.parser import BytesParser
from email.utils import parsedate_to_datetime
from html.parser import HTMLParser
from pathlib import PurePosixPath
from datetime import datetime,timezone
import xml.etree.ElementTree as ET

MAX_FILE=20*1024*1024;MAX_TOTAL=60*1024*1024;MAX_DOCS=250;MAX_TEXT=2_000_000
SUPPORTED={'.txt','.md','.csv','.tsv','.json','.xml','.html','.htm','.eml','.mbox','.pdf','.docx','.xlsx','.zip'}
@dataclass
class Document:
 name:str
 raw:bytes
 units:list
 kind:str
 date:str=''
 author:str=''
 title:str=''
 warnings:list=field(default_factory=list)
 @property
 def digest(self):return hashlib.sha256(self.raw).hexdigest()

def decode(data):
 for enc in ['utf-8-sig','cp1250','latin1']:
  try:return data.decode(enc)
  except UnicodeDecodeError:pass
 return data.decode('utf8',errors='replace')
class HTMLText(HTMLParser):
 def __init__(self):super().__init__();self.parts=[];self.skip=0
 def handle_starttag(self,tag,attrs):
  if tag in ('script','style','noscript'):self.skip+=1
  if tag in ('p','br','div','li','tr','h1','h2','h3'):self.parts.append('\n')
 def handle_endtag(self,tag):
  if tag in ('script','style','noscript') and self.skip:self.skip-=1
 def handle_data(self,data):
  if not self.skip:self.parts.append(data)
 def text(self):return re.sub(r'\n[ \t]*\n+', '\n\n',''.join(self.parts)).strip()
def html_text(s):p=HTMLText();p.feed(s);return p.text()
def lines(text):
 text=text.replace('\x00','').strip()
 if len(text)>MAX_TEXT:raise ValueError('Tekst przekracza limit 2 mln znaków.')
 return [(f'Wiersze {i+1}–{min(i+16,len(text.splitlines()))}', '\n'.join(text.splitlines()[i:i+16])) for i in range(0,len(text.splitlines()),16) if '\n'.join(text.splitlines()[i:i+16]).strip()]
def heading_date(text):
 head=' '.join(text.splitlines()[:2])[:220].lower()
 months={'stycznia':1,'lutego':2,'marca':3,'kwietnia':4,'maja':5,'czerwca':6,'lipca':7,'sierpnia':8,'września':9,'października':10,'listopada':11,'grudnia':12}
 match=re.search(r'\b(\d{1,2})\s+('+'|'.join(months)+r')\s+(\d{4})\b',head)
 if match:
  try:return datetime(int(match[3]),months[match[2]],int(match[1])).date().isoformat()
  except ValueError:return ''
 match=re.search(r'\b(20\d{2})-(\d{2})-(\d{2})\b',head)
 if match:
  try:return datetime(*map(int,match.groups())).date().isoformat()
  except ValueError:return ''
 return ''
def safe_zip(data):
 z=zipfile.ZipFile(io.BytesIO(data));items=z.infolist()
 if len(items)>1000 or sum(i.file_size for i in items)>MAX_TOTAL:raise ValueError('Archiwum przekracza limit 1000 elementów / 60 MB po rozpakowaniu.')
 for i in items:
  parts=PurePosixPath(i.filename.replace('\\','/')).parts
  if '..' in parts or i.filename.startswith(('/', '\\')):raise ValueError('Niedozwolona ścieżka w archiwum.')
  if i.flag_bits&1:raise ValueError('Archiwum szyfrowane — wyeksportuj pliki bez hasła do uprawnionego katalogu.')
  if i.file_size>MAX_FILE:raise ValueError('Plik w archiwum przekracza 20 MB.')
 return z

def extract(name,data,depth=0):
 if len(data)>MAX_FILE:raise ValueError('Limit jednego pliku: 20 MB.')
 if depth>3:raise ValueError('Zbyt wiele poziomów załączników / archiwów.')
 ext=PurePosixPath(name).suffix.lower();warn=[];date='';author='';title=PurePosixPath(name).name;units=[];extras=[]
 if ext not in SUPPORTED:raise ValueError('Nieobsługiwany format '+ext+'. Wyeksportuj do EML, PDF tekstowego, DOCX, XLSX, CSV, TXT albo JSON/XML wiadomości.')
 if ext=='.zip':
  out=[];z=safe_zip(data)
  for info in z.infolist():
   if info.is_dir() or info.filename.startswith('__MACOSX/') or PurePosixPath(info.filename).name.startswith('.'):continue
   try:out.extend(extract(name+' / '+info.filename,z.read(info),depth+1))
   except Exception as e:out.append(Document(name+' / '+info.filename,b'',[],'error',warnings=[str(e)]))
   if len(out)>MAX_DOCS:raise ValueError('Limit importu: 250 dokumentów.')
  return out
 if ext in ('.docx','.xlsx'):
  safe_zip(data).close()
 if ext in ('.txt','.md'):
  text=decode(data);units=lines(text);date=heading_date(text)
 elif ext in ('.html','.htm'):units=lines(html_text(decode(data)))
 elif ext=='.pdf':
  from pypdf import PdfReader
  r=PdfReader(io.BytesIO(data))
  if r.is_encrypted:raise ValueError('PDF zaszyfrowany. Użyj uprawnionego eksportu bez hasła.')
  if len(r.pages)>500:raise ValueError('Limit 500 stron PDF.')
  for i,p in enumerate(r.pages):
   t=p.extract_text() or ''
   if t.strip():units.append((f'Strona {i+1}',t))
  if not units:raise ValueError('Brak tekstu w PDF. To może być skan — wykonaj OCR przed importem.')
  if len(units)<len(r.pages):warn.append('Część stron nie ma warstwy tekstowej; tekst z obrazów nie został odczytany.')
 elif ext=='.docx':
  from docx import Document as Docx
  d=Docx(io.BytesIO(data))
  units=[(f'Akapit {i+1}',p.text) for i,p in enumerate(d.paragraphs) if p.text.strip()]
  for ti,t in enumerate(d.tables):
   for ri,row in enumerate(t.rows):units.append((f'Tabela {ti+1}, wiersz {ri+1}',' | '.join(c.text for c in row.cells)))
  warn.append('DOCX: odczytano akapity i tabele; obrazy, pola tekstowe i komentarze mogą wymagać osobnego eksportu.')
 elif ext=='.xlsx':
  from openpyxl import load_workbook
  book=load_workbook(io.BytesIO(data),read_only=True,data_only=False,keep_links=False)
  n=0
  for sheet in book:
   header=''
   for idx,row in enumerate(sheet.iter_rows(values_only=True),1):
    n+=1
    if n>50000:raise ValueError('Limit 50 000 wierszy arkusza.')
    cells=[str(x) if x is not None else '' for x in row]
    if not any(cells):continue
    if not header:header=' | '.join(cells)
    text=' | '.join(cells)
    units.append((f'Arkusz {sheet.title}, wiersz {idx}',(header+'\n' if idx>1 else '')+text))
  book.close();warn.append('Formuły pokazano jako zapis formuł, nie przeliczano ich. Brak OCR obrazów i interpretacji wykresów.')
 elif ext in ('.csv','.tsv'):
  text=decode(data)
  try:delimiter='\t' if ext=='.tsv' else csv.Sniffer().sniff(text[:5000],delimiters=',;\t').delimiter
  except csv.Error:delimiter=';'
  rows=list(csv.reader(io.StringIO(text),delimiter=delimiter))
  if len(rows)>50000:raise ValueError('Limit 50 000 wierszy CSV.')
  header=' | '.join(rows[0]) if rows else ''
  for i,row in enumerate(rows):
   if any(row):units.append((f'Wiersz {i+1}',(header+'\n' if i else '')+' | '.join(row)))
 elif ext=='.json':
  x=json.loads(decode(data));items=x if isinstance(x,list) else x.get('messages',x.get('sms',[])) if isinstance(x,dict) else []
  if not isinstance(items,list) or not items:raise ValueError('JSON: oczekiwana lista wiadomości lub obiekt messages/sms; pola text/body/content, sender/from/address, date/timestamp.')
  for i,m in enumerate(items):
   if not isinstance(m,dict):continue
   body=m.get('text',m.get('body',m.get('content','')))
   if not isinstance(body,str):continue
   who=str(m.get('sender',m.get('from',m.get('address',''))));when=str(m.get('date',m.get('timestamp','')))
   units.append((f'Wiadomość {i+1}',f'Data: {when}\nOd: {who}\n{body}'))
 elif ext=='.xml':
  text=decode(data)
  if re.search(r'<!\s*(DOCTYPE|ENTITY)',text,re.I):raise ValueError('XML z DTD/ENTITY jest niedozwolony.')
  root=ET.fromstring(text)
  for i,m in enumerate(root.iter('sms')):
   when=m.get('readable_date',m.get('date',''))
   if when.isdigit():
    try:when=datetime.fromtimestamp(int(when)/1000,timezone.utc).isoformat()
    except (ValueError,OverflowError,OSError):pass
   units.append((f'SMS {i+1}',f'Data: {when}\nKontakt: {m.get("contact_name", "")} {m.get("address", "")}\n{m.get("body", "")}'))
  if not units:raise ValueError('XML: obsługiwany eksport SMS Backup & Restore z elementami sms. MMS nie są odczytywane.')
 elif ext=='.mbox':
  # RFC mbox separators; escaped >From lines are restored in each message.
  starts=[m.start() for m in re.finditer(br'(?m)^From [^\r\n]+\r?\n',data)]
  if not starts:raise ValueError('Nie rozpoznano pliku MBOX.')
  out=[]
  for i,start in enumerate(starts):
   stop=starts[i+1] if i+1<len(starts) else len(data);chunk=data[start:stop].split(b'\n',1)[1];chunk=re.sub(br'(?m)^>From ',b'From ',chunk)
   out.extend(extract(name+f' / wiadomość_{i+1}.eml',chunk,depth+1))
   if len(out)>MAX_DOCS:raise ValueError('Limit 250 wiadomości / dokumentów na import; podziel eksport MBOX.')
  return out
 elif ext=='.eml':
  msg=BytesParser(policy=policy.default).parsebytes(data);title=str(msg.get('Subject','Bez tematu'));author=str(msg.get('From',''));date=str(msg.get('Date',''))
  try:date=parsedate_to_datetime(date).isoformat()
  except (ValueError,TypeError):pass
  body=msg.get_body(preferencelist=('plain','html'))
  text=body.get_content() if body else ''
  if isinstance(text,bytes):text=decode(text)
  if body and body.get_content_type()=='text/html':text=html_text(text)
  meta=f'Temat: {title}\nOd: {author}\nDo: {msg.get("To", "")}\nData: {date}\n'
  units=[(loc,meta+t) for loc,t in lines(text)]
  if not units:units=[('Nagłówki',meta)]
  for i,att in enumerate(msg.iter_attachments()):
   filename=att.get_filename() or f'zalacznik_{i+1}.bin';raw=att.get_payload(decode=True)
   if not raw:warn.append('Nie odczytano załącznika '+filename);continue
   try:extras.extend(extract(name+' / '+filename,raw,depth+1))
   except Exception as e:warn.append('Załącznik '+filename+': '+str(e))
 if sum(len(t) for _,t in units)>MAX_TEXT:raise ValueError('Dokument przekracza limit 2 mln znaków.')
 units=[(loc,t.replace('\x00','').strip()) for loc,t in units if t.strip()]
 if not units:raise ValueError('Nie znaleziono tekstu do indeksowania.')
 return [Document(name,data,units,ext[1:],date,author,title,warn)]+extras
