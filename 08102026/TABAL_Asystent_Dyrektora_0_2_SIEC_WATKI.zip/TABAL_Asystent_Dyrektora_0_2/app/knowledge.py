import collections,hashlib,json,math,re,sqlite3,threading,unicodedata,uuid
from pathlib import Path
from datetime import datetime,timezone
from app.extract import extract,MAX_DOCS,MAX_TOTAL

def now():return datetime.now(timezone.utc).isoformat(timespec='seconds')
def norm(s):return ''.join(c for c in unicodedata.normalize('NFKD',s.lower().replace('ł','l')) if not unicodedata.combining(c))
STOP=set('a i o w z na do od po za ze we nie czy co jak jaki jaka jakie jest sa byl byla bylo byly oraz sie dla to ten ta te tego tej mamy ma mam kto kiedy gdzie ile przez przy ktory ktora ktore ktorego ktorej prosze powiedz podaj znajdz pokaz wiadomosci dokument dokumenty dokumentach informacje informacji dotyczace dotyczy'.split())
def tokens(s):return [w if len(w)<=5 else w[:5] for w in re.findall(r'[a-z0-9]+',norm(s)) if w not in STOP and len(w)>1]
SYNONYMS={'platn':['platn','zapl','faktu','przel'],'termi':['termi','dostaw','opozn'],'ryzyk':['ryzyk','opozn','proble','rekla'],'kontakt':['konta','telef','email'],'rabat':['rabat','upust'],'umow':['umow','kontr'],'otwar':['otwar','ustal','zadani','spraw']}
def query_tokens(q):
 out=set(tokens(q))
 for key,values in SYNONYMS.items():
  if any(t.startswith(key) or key.startswith(t) for t in out):out.update(v[:5] for v in values)
 return out

def split_units(units):
 for loc,text in units:
  # Small adjacent paragraphs are combined later by the importer only where location stays exact.
  for i in range(0,len(text),1100):
   yield loc+(f' · fragment {i//1100+1}' if len(text)>1100 else ''),text[i:i+1300]

class Knowledge:
 def __init__(self,path):
  self.path=Path(path);self.path.parent.mkdir(parents=True,exist_ok=True);self.lock=threading.RLock();self.db=sqlite3.connect(path,check_same_thread=False)
  self.db.row_factory=sqlite3.Row;self.db.execute('PRAGMA foreign_keys=ON');self.db.execute('PRAGMA journal_mode=WAL')
  self.db.executescript('''CREATE TABLE IF NOT EXISTS documents(id TEXT PRIMARY KEY,sha TEXT UNIQUE,name TEXT,kind TEXT,title TEXT,date TEXT,author TEXT,imported TEXT,warnings TEXT,raw BLOB);
  CREATE TABLE IF NOT EXISTS chunks(id TEXT PRIMARY KEY,document_id TEXT REFERENCES documents(id) ON DELETE CASCADE,location TEXT,text TEXT);
  CREATE TABLE IF NOT EXISTS handover(id TEXT PRIMARY KEY,chunk_id TEXT REFERENCES chunks(id) ON DELETE CASCADE,title TEXT,owner TEXT,due TEXT,status TEXT,note TEXT,created TEXT,updated TEXT);
  CREATE TABLE IF NOT EXISTS questions(id TEXT PRIMARY KEY,question TEXT,created TEXT,count INTEGER);
  CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY,at TEXT,action TEXT,name TEXT);
  ''');self.cache=None
 def ingest(self,name,data,source_label=''):
  name=Path(name.replace('\\','/')).name[:240]
  docs=extract(name,data);report={'added':[],'duplicates':[],'errors':[],'warnings':[]}
  if len(docs)>MAX_DOCS or sum(len(d.raw) for d in docs)>MAX_TOTAL:raise ValueError('Zbyt duży import; podziel dane na mniejsze partie.')
  with self.lock,self.db:
   for d in docs:
    if source_label and d.kind!='error':d.name=source_label[:500]+(' / '+d.name if d.name!=name else '')
    if d.kind=='error':report['errors'].append({'name':d.name,'message':'; '.join(d.warnings)});continue
    existing=self.db.execute('SELECT name FROM documents WHERE sha=?',(d.digest,)).fetchone()
    if existing:report['duplicates'].append({'name':d.name,'existing':existing['name']});continue
    chunks=list(split_units(d.units))
    count=self.db.execute('SELECT COUNT(*) FROM chunks').fetchone()[0]
    if count+len(chunks)>20000:raise ValueError('Limit prototypu: 20 000 fragmentów. Import wycofano.')
    ident=uuid.uuid4().hex
    self.db.execute('INSERT INTO documents VALUES(?,?,?,?,?,?,?,?,?,?)',(ident,d.digest,d.name,d.kind,d.title,d.date,d.author,now(),json.dumps(d.warnings,ensure_ascii=False),d.raw))
    for loc,text in chunks:self.db.execute('INSERT INTO chunks VALUES(?,?,?,?)',(uuid.uuid4().hex,ident,loc,text))
    self.db.execute('INSERT INTO audit(at,action,name) VALUES(?,?,?)',(now(),'IMPORT',d.name));report['added'].append({'id':ident,'name':d.name,'chunks':len(chunks)})
    report['warnings'].extend({'name':d.name,'message':w} for w in d.warnings)
   self.cache=None
  return report
 def documents(self):
  with self.lock:
   return [dict(r,warnings=json.loads(r['warnings'])) for r in self.db.execute('SELECT d.id,d.sha,d.name,d.kind,d.title,d.date,d.author,d.imported,d.warnings,length(d.raw) bytes,(SELECT COUNT(*) FROM chunks c WHERE c.document_id=d.id) chunks FROM documents d ORDER BY imported DESC,name')]
 def source(self,ident):
  with self.lock:
   d=self.db.execute('SELECT id,name,title,kind,date,author,sha,warnings FROM documents WHERE id=?',(ident,)).fetchone()
   if not d:raise ValueError('Nie znaleziono dokumentu.')
   return dict(d,chunks=[dict(r) for r in self.db.execute('SELECT id,location,text FROM chunks WHERE document_id=?',(ident,))])
 def delete(self,ident):
  with self.lock,self.db:
   d=self.db.execute('SELECT name FROM documents WHERE id=?',(ident,)).fetchone()
   if not d:raise ValueError('Nie znaleziono dokumentu.')
   self.db.execute('DELETE FROM documents WHERE id=?',(ident,));self.db.execute('INSERT INTO audit(at,action,name) VALUES(?,?,?)',(now(),'DELETE',d['name']));self.cache=None
 def _index(self):
  if self.cache is not None:return self.cache
  rows=[dict(r) for r in self.db.execute('SELECT c.*,d.name,d.title,d.kind,d.date,d.author,d.sha FROM chunks c JOIN documents d ON d.id=c.document_id')]
  df=collections.Counter()
  for r in rows:
   r['_terms']=collections.Counter(tokens(r['text']+' '+r['title']));df.update(r['_terms'].keys())
  self.cache=(rows,df,sum(sum(r['_terms'].values()) for r in rows)/max(1,len(rows)))
  return self.cache
 def ask(self,question,kind='',record=True):
  question=question.strip()
  if not 3<=len(question)<=1500:raise ValueError('Pytanie musi mieć 3–1500 znaków.')
  terms=query_tokens(question);original=set(tokens(question));ranked=[]
  with self.lock:
   rows,df,avg=self._index();n=len(rows)
   # Named entities present in the corpus anchor a query to the requested subject.
   candidates={t for word in re.findall(r'\b[A-ZĄĆĘŁŃÓŚŹŻ][\w-]+',question) for t in tokens(word)}
   anchors={t for t in candidates if t in df and df[t]/max(n,1)<.6}
   counts=collections.Counter(r['document_id'] for r in rows)
   for r in rows:
    if kind and r['kind']!=kind:continue
    freq=r['_terms'];hits=original & set(freq)
    if not hits or (anchors and not anchors.issubset(freq)):continue
    if len(r['text'].strip())<35 and counts[r['document_id']]>1:continue
    score=0
    for term in terms:
     f=freq.get(term,0)
     if f:score+=math.log(1+(n-df[term]+.5)/(df[term]+.5))*f*2.2/(f+1.2*(.25+.75*sum(freq.values())/max(avg,1)))
    coverage=len(hits)/max(1,len(original));score*=.5+coverage
    if score>0:ranked.append((score,r))
   ranked.sort(key=lambda pair:pair[0],reverse=True)
   results=[];per_doc=collections.Counter()
   for score,r in ranked:
    if per_doc[r['document_id']]>=2:continue
    per_doc[r['document_id']]+=1
    results.append({k:v for k,v in r.items() if not k.startswith('_')})
    if len(results)==6:break
   for i,r in enumerate(results,1):r['citation']=i
   if record:
    with self.db:self.db.execute('INSERT INTO questions VALUES(?,?,?,?)',(uuid.uuid4().hex,question,now(),len(results)))
   return {'question':question,'mode':'extractive','answer':'Znalazłem fragmenty związane z pytaniem. Poniżej są cytaty z materiałów, nie wnioski modelu. Sprawdź ich daty i kontekst przed podjęciem decyzji.' if results else 'Nie znalazłem wystarczających informacji w zaimportowanych materiałach. Doprecyzuj nazwę firmy, projektu lub temat albo dodaj brakujące źródła.','results':results,'notice':'Rozbieżne wersje ustaleń mogą występować równocześnie. Późniejsza data pliku lub wiadomości nie oznacza automatycznie, że ustalenie zastępuje poprzednie.','indexed_documents':len(self.documents())}
 def thread(self,question,kind=''):
  question=question.strip()
  if not 3<=len(question)<=1500:raise ValueError('Pytanie musi mieć 3–1500 znaków.')
  original=set(tokens(question));terms=query_tokens(question)
  with self.lock:
   rows,df,avg=self._index();n=len(rows)
   docs=collections.defaultdict(list)
   for r in rows:
    if not kind or r['kind']==kind:docs[r['document_id']].append(r)
   candidates={t for word in re.findall(r'\b[A-ZĄĆĘŁŃÓŚŹŻ][\w-]+',question) for t in tokens(word)}
   anchors={t for t in candidates if t in df and df[t]/max(n,1)<.6}
   matching=[];matched_chunks=0
   for doc_id,parts in docs.items():
    full=set().union(*(set(p['_terms']) for p in parts))
    if anchors and not anchors.issubset(full):continue
    scored=[]
    for r in parts:
     freq=r['_terms'];hits=original & set(freq)
     if not hits and not (anchors and (anchors & set(freq))):continue
     score=0.0
     for term in terms:
      f=freq.get(term,0)
      if f:score+=math.log(1+(n-df[term]+.5)/(df[term]+.5))*f*2.2/(f+1.2*(.25+.75*sum(freq.values())/max(avg,1)))
     score*=.5+len(hits)/max(1,len(original))
     if score>0:scored.append((score,r))
    if scored:
     matched_chunks+=len(scored)
     # Multiple excerpts per source preserve a long thread without flooding the view.
     scored.sort(key=lambda x:x[0],reverse=True)
     selected=[r for _,r in scored[:4]]
     matching.append((max(x[0] for x in scored),parts[0],selected))
   matching.sort(key=lambda x:x[0],reverse=True)
   total_docs=len(matching);selected_docs=matching[:200]
   timeline=[]
   for score,doc,parts in selected_docs:
    for r in parts:
     timeline.append({k:r[k] for k in ('id','document_id','location','text','name','title','kind','date','author','sha')})
   timeline.sort(key=lambda r:(not bool(r['date']),r['date'] or '',r['name'],r['location']))
   signals=collections.Counter()
   for r in timeline:
    text=norm(r['text'])
    if re.search(r'nie potwierdz|bez potwierdzen|oczekuje na potwierdzen',text):signals['Niepotwierdzone ustalenia']+=1
    if re.search(r'propozycj|proponuj|przesunieci',text):signals['Propozycje zmian']+=1
    if re.search(r'brak protokol|brakuje|nie wplyn|nie dostarcz',text):signals['Brakujące materiały']+=1
   for i,r in enumerate(timeline,1):r['citation']=i
   with self.db:self.db.execute('INSERT INTO questions VALUES(?,?,?,?)',(uuid.uuid4().hex,question,now(),len(timeline)))
   return {'question':question,'mode':'thread','answer':
    f'Znalazłem {total_docs} źródeł i {matched_chunks} pasujących fragmentów. Poniżej chronologia cytatów, bez automatycznego rozstrzygania sprzeczności.' if timeline else
    'Nie znalazłem źródeł dla tego wątku. Spróbuj nazwy klienta, projektu lub numeru sprawy.',
    'results':timeline,'total_documents':total_docs,'shown_documents':len(selected_docs),
    'matched_chunks':matched_chunks,'truncated':total_docs>len(selected_docs),
    'signals':[{'label':key,'count':value} for key,value in signals.items()],
    'notice':'Daty pochodzą ze źródeł; brak daty oznacza nieustaloną kolejność. Sygnały są prostym oznaczeniem słów w cytatach. Sprawdź pełny dokument i status ustaleń przed decyzją.'}
 def note(self,raw):
  chunk=str(raw.get('chunk_id',''));title=str(raw.get('title','')).strip()[:250]
  if not title:raise ValueError('Podaj tytuł sprawy.')
  status=raw.get('status','open')
  if status not in ('open','verify','confirmed','closed'):raise ValueError('Nieznany status.')
  due=str(raw.get('due',''))
  if due:
   try:datetime.strptime(due,'%Y-%m-%d')
   except ValueError:raise ValueError('Termin: YYYY-MM-DD.')
  with self.lock,self.db:
   if not self.db.execute('SELECT 1 FROM chunks WHERE id=?',(chunk,)).fetchone():raise ValueError('Źródło zostało usunięte lub nie istnieje.')
   ident=raw.get('id') or uuid.uuid4().hex
   if raw.get('id') and not self.db.execute('SELECT 1 FROM handover WHERE id=?',(ident,)).fetchone():raise ValueError('Sprawa nie istnieje.')
   self.db.execute('INSERT INTO handover VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET title=excluded.title,owner=excluded.owner,due=excluded.due,status=excluded.status,note=excluded.note,updated=excluded.updated',(ident,chunk,title,str(raw.get('owner',''))[:200],due,status,str(raw.get('note',''))[:6000],now(),now()))
   return ident
 def notes(self):
  with self.lock:return [dict(r) for r in self.db.execute('SELECT h.*,c.document_id,c.location,c.text,d.name FROM handover h JOIN chunks c ON c.id=h.chunk_id JOIN documents d ON d.id=c.document_id ORDER BY h.updated DESC')]
 def stats(self):
  with self.lock:return {'documents':self.db.execute('SELECT COUNT(*) FROM documents').fetchone()[0],'chunks':self.db.execute('SELECT COUNT(*) FROM chunks').fetchone()[0],'handover':self.db.execute("SELECT COUNT(*) FROM handover WHERE status!='closed'").fetchone()[0],'questions':[dict(r) for r in self.db.execute('SELECT question,created,count FROM questions ORDER BY created DESC LIMIT 10')]}
 def export(self):return {'kind':'tabal-director-handover','generated':now(),'notes':self.notes(),'sources':self.documents(),'mode':'local-extractive'}
 def backup(self,path):
  with self.lock,sqlite3.connect(path) as dest:self.db.backup(dest)
