# Raport testów — TABAL Asystent wiedzy dyrektora 0.2

Data: 7 października 2026. Środowisko: Linux, Python 3, lokalny serwer HTTP na 127.0.0.1. Dane: wyłącznie fikcyjne DEMO, trzy przykładowe materiały Brzoza oraz pliki w tymczasowym folderze symulującym zamontowany udział.

## Wynik

- **36/36 testów Python przeszło.** Import EML, MBOX, DOCX, XLSX, PDF, tekstu, XML, JSON, ZIP; wyszukiwanie z cytatami, notatki, kopia bazy, kontrola tokenu i pochodzenia HTTP.
- **Nowe funkcje:** testy analizy wątku z trzech źródeł uporządkowanych datami, wyświetlania więcej niż sześciu źródeł, sygnału niepotwierdzonej propozycji, skanowania folderu tylko do odczytu, pomijania niezmienionych plików, zachowania historycznych wersji, zmiany folderu, ponownego importu usuniętej z bazy kopii, pomijania dowiązań symbolicznych, odłączonego folderu oraz nowych endpointów HTTP.
- `node --check static/app.js` zakończył się bez błędów składni.
- Test integracyjny trzech plików z `examples/`: trzy źródła zaindeksowane bez błędów; wątek Brzoza pokazał termin 12 października, propozycję 15 października bez potwierdzenia i późniejszy raport spraw otwartych.

Pełny log: `test-results/tests.txt`. Skrypt `tests/browser.cjs` ma dziesiąty scenariusz obejmujący nowy panel i wątek. **Nie został uruchomiony w tej sesji.** Środowisko nie zawierało Chromium; próba pobrania przez Playwright zwróciła archiwum o rozmiarze 0 MiB, którego nie dało się rozpakować. Nie dołączamy historycznych zrzutów jako dowodu testowania wersji 0.2.

Nie testowano prawdziwego udziału TABAL, uprawnień SMB, działania na Windows/macOS, dużego obciążenia ani odpowiedzi generatywnego modelu. Program wymaga wcześniejszego zamontowania udziału w systemie i obecnie wykonuje lokalne wyszukiwanie, chronologię oraz oznaczenia cytatów, bez modelu GPT. Widok może pominąć istotne dokumenty przy limitach lub niedopasowaniu słów; ustalenia i ich aktualność trzeba zweryfikować w oryginale.
