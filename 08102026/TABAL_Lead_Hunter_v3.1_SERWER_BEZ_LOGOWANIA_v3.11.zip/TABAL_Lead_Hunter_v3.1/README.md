# TABAL Lead Hunter v3.1 — SERWER — BEZ LOGOWANIA

Ta paczka uruchamia dokładnie tę samą aplikację serwerową v3.1, ale bez ekranu logowania i bez kont użytkowników w interfejsie. Po wejściu na adres aplikacji panel otwiera się od razu z uprawnieniami administratora, łącznie z konfiguracją SMTP.

## Szybki start lokalny

**Windows:** uruchom `URUCHOM_WINDOWS.bat`.

**macOS / Linux:** uruchom `URUCHOM_MAC_LINUX.command` albo `python3 serve.py`.

Domyślnie panel: `http://127.0.0.1:8765/`

Nie trzeba wykonywać `manage.py user`, tworzyć loginu ani wpisywać hasła do Lead Huntera. Login i hasło widoczne w zakładce Wysyłka dotyczą wyłącznie zewnętrznej skrzynki SMTP.

## Ważne przy serwerze zdalnym

Wersja bez logowania zakłada, że dostęp do samego adresu aplikacji jest już kontrolowany przez sieć, VPN, reverse proxy lub reguły IP. Każda osoba, która może otworzyć adres Lead Huntera, otrzymuje uprawnienia administratora. Nie wystawiaj tej wersji bezpośrednio do publicznego Internetu bez zewnętrznej ochrony dostępu.

Pozostają aktywne: kontrola hosta, wymóg poprawnego Origin dla zmian, token CSRF, HTTPS dla zdalnego `TABAL_ORIGIN`, walidacja danych, wersjonowanie wspólnej bazy i blokada konfliktów równoczesnego zapisu.

## Funkcje pozostające bez zmian

- wspólna baza SQLite i kontrola konfliktów zapisu,
- kampanie odkrywania v3.1, cel np. 100 firm i kolejne partie,
- import/eksport JSON oraz CSV,
- scoring, strategie, historia researchu i statusy handlowe,
- kolejka SMTP i test skrzynki,
- kopie baz przez `manage.py backup`.

## Docker

Skonfiguruj `.env`, a następnie:

```bash
docker compose build
docker compose up -d
```

Nie uruchamiaj `manage.py user`, ponieważ konta aplikacji są wyłączone w tym wariancie. Dla zdalnego `TABAL_ORIGIN` nadal wymagany jest HTTPS.

## Kopia serwera

```bash
docker compose exec lead-hunter python manage.py backup /data/backups
```

Eksport JSON z panelu jest kopią danych handlowych. Pełna kopia serwera obejmuje również bazę kolejki SMTP.

## Testy

```bash
npm test
python -m unittest tests.test_server -v
python -m unittest tests.test_mail -v
```

Test przeglądarkowy wymaga zależności deweloperskiej Playwright: `npm install`, a następnie `npm run test:browser`.
