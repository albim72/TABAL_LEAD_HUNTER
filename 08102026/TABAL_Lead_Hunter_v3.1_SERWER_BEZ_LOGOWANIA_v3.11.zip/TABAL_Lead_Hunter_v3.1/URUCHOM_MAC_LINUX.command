#!/bin/sh
export PYTHONUTF8=1
export PYTHONIOENCODING=utf-8
cd "$(dirname "$0")" || exit 1
python3 serve.py
