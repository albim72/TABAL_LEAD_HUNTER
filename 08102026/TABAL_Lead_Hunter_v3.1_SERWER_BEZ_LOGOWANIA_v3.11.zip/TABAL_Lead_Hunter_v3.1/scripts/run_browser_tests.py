#!/usr/bin/env python3
"""Starts isolated test database and Gunicorn; never touches production data."""
import os,subprocess,sys,tempfile,time,urllib.request
from pathlib import Path
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root))
with tempfile.TemporaryDirectory(prefix='tabal-tests-') as tmp:
 env=dict(os.environ,TABAL_DATA_DIR=tmp,TABAL_ORIGIN='http://127.0.0.1:8765',TABAL_SMTP_HOSTS='localhost',TABAL_TRUST_PROXY='0')
 # Never attach to a pre-existing service on this port.
 import socket
 with socket.socket() as check:
  try:check.bind(('127.0.0.1',8765))
  except OSError:raise SystemExit('Port 8765 zajęty. Zatrzymaj lokalną instancję przed testem.')
 try:
  import gunicorn  # noqa: F401
  command=[sys.executable,'-m','gunicorn','-c',str(root/'gunicorn.conf.py'),'--chdir',str(root),'--bind','127.0.0.1:8765','server.web:application']
 except ImportError:
  command=[sys.executable,str(root/'serve.py')]
 server=subprocess.Popen(command,env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 try:
  ready=False
  for _ in range(60):
   if server.poll() is not None:raise RuntimeError('Serwer testowy nie wystartował.')
   try:urllib.request.urlopen('http://127.0.0.1:8765/healthz',timeout=1);ready=True;break
   except Exception:time.sleep(.1)
  if not ready:raise RuntimeError('Brak gotowości serwera testowego.')
  env.update(TEST_URL='http://127.0.0.1:8765')
  result=subprocess.run(['node',str(root/'tests/browser.cjs')],env=env,cwd=root)
 finally:
  server.terminate()
  try:server.wait(timeout=15)
  except subprocess.TimeoutExpired:server.kill();server.wait()
 sys.exit(result.returncode)
