import os,urllib.request
from urllib.parse import urlsplit
host=urlsplit(os.environ.get('TABAL_ORIGIN','http://127.0.0.1:8765')).netloc
r=urllib.request.Request('http://127.0.0.1:8765/healthz',headers={'Host':host})
with urllib.request.urlopen(r,timeout=4) as response:
 if response.status!=200:raise SystemExit(1)
