from pathlib import Path
import json
root=Path(__file__).resolve().parents[1]
src=root/'src'
t=(src/'template.html').read_text(encoding='utf-8')
for k,f in [('STYLE','style.css'),('RESEARCH','research.js'),('CORE','core.js'),('APP','app.js')]:
    v=(src/f).read_text(encoding='utf-8')
    if k!='STYLE': v=v.replace('</script',r'<\/script')
    t=t.replace('/*__'+k+'__*/',v)
sample=json.loads((root/'data/probka_v1_2026-09-13.json').read_text(encoding='utf-8'))
t=t.replace('/*__FIXTURES__*/','window.V1_SAMPLE='+json.dumps(sample,ensure_ascii=False).replace('</script',r'<\/script')+';')
assert '/*__' not in t.replace('/*__MAIL_RUNTIME__*/','')
(root/'START.html').write_text(t,encoding='utf-8',newline='\n')
print('Built START.html:',len(t.encode()),'bytes; server build')
