const {test}=require('node:test'),a=require('node:assert/strict'),C=require('../src/core.js');
function fixture(){
 const s=C.makeState('pilot'),st=C.strategy({...s.strategies[0],region:'lubelskie, Polska',province:'lubelskie',limit:100,batch_size:20});
 s.strategies[0]=st;const run=C.createResearchRun(st);s.runs.push(run);C.prepareResearchBatch(s,run);
 const raw=i=>({...C.sample(st,s,false),company:'Firma testowa '+i,domain:'firma-'+i+'.example',contacts:[],criteria:{}});
 function commit(raws,meta={}){const result=C.merge(s,raws,st);s.leads=result.leads;C.recordResearchImport(run,result,{batch_id:run.batches.at(-1).id,...meta},'test.json');return result;}
 return {s,st,run,raw,commit};
}
test('8 of 100 remains incomplete, missing 92; next batch rotates searches',()=>{
 const {s,run,raw,commit}=fixture(),first=run.batches[0].queries.map(q=>q.query);
 commit(Array.from({length:8},(_,i)=>raw(i)));
 a.equal(run.status,'needs_more');a.equal(C.researchProgress(run).remaining,92);
 const text=C.prepareResearchBatch(s,run);a.match(text,/BRAKUJE: 92/);a.equal(run.batches[1].size,20);
 a.ok(run.batches[1].queries.every(q=>!first.includes(q.query)));
});
test('reopening prepared batch preserves its ID and searches',()=>{
 const {s,run}=fixture(),id=run.batches[0].id,text=run.task;
 a.equal(C.prepareResearchBatch(s,run),text);a.equal(run.batches.length,1);a.equal(run.batches[0].id,id);
});
test('only accepted new firms count, repeated imports and invalid rows do not inflate goal',()=>{
 const {run,raw,commit}=fixture();commit([raw(1),raw(1),{...raw(2),company:''}]);
 a.equal(C.researchProgress(run).found,1);a.equal(run.duplicates,1);a.equal(run.errors,1);
 commit([raw(1)]);a.equal(C.researchProgress(run).found,1);a.equal(run.status,'needs_more');
});
test('five batches can reach 100, final batch shrinks to remaining goal',()=>{
 const {s,run,raw,commit}=fixture();
 commit(Array.from({length:8},(_,i)=>raw(i)));
 for(let offset=8;offset<88;offset+=20){C.prepareResearchBatch(s,run);commit(Array.from({length:20},(_,i)=>raw(offset+i)));}
 C.prepareResearchBatch(s,run);a.equal(run.batches.at(-1).size,12);
 commit(Array.from({length:12},(_,i)=>raw(88+i)));a.equal(run.status,'goal_reached');
 a.equal(C.researchProgress(run).found,100);a.throws(()=>C.prepareResearchBatch(s,run),/osiągnięty/);
});
test('zero results with no search access remains incomplete and retains diagnostic',()=>{
 const {s,run,commit}=fixture();commit([],{research_report:{stop_reason:'no_access',limitations:'Brak wyszukiwania',queries:[]}});
 a.equal(C.researchProgress(run).remaining,100);a.equal(run.status,'needs_more');a.equal(run.research_report.stop_reason,'no_access');
 a.match(C.prepareResearchBatch(s,run),/Brak wyszukiwania/);
});
test('discovery accepts a sourced candidate with unknown qualification and no contact without qualifying it',()=>{
 const {s,raw,commit}=fixture();a.equal(commit([raw(1)]).added,1);
 a.equal(C.score(s.leads[0],s.config).qualified,false);a.equal(C.bestContact(s.leads[0],s.config),null);
 a.equal(C.mailCandidate(s.leads[0],s.config,'pilot').message,null);
});
test('Lubelskie uses 24 distinct starting areas and geographic scope is preserved',()=>{
 const {s,st}=fixture(),plan=C.researchPlan(s,st);
 a.equal(plan.areas.length,24);a.equal(new Set(plan.areas).size,24);a.ok(plan.areas.includes('Biała Podlaska'));
 a.ok(plan.queries.every(q=>q.query.includes('lubelskie')));
 a.deepEqual(C.researchPlan(s,C.strategy({...st,region:'Lublin'})).areas,['Lublin']);
 a.deepEqual(C.researchPlan(s,C.strategy({...st,region:'mazowieckie',province:'mazowieckie'})).areas,['mazowieckie']);
});
test('custom cities and terms override defaults and survive backup',()=>{
 const {s,st}=fixture();s.strategies[0]=C.strategy({...st,locations:'Puławy\nRyki',query_terms:'instalator bram\nserwis bram',batch_size:12});
 const restored=C.restore(C.backup(s),'pilot'),plan=C.researchPlan(restored,restored.strategies[0]);
 a.deepEqual(plan.areas,['Puławy','Ryki']);a.equal(plan.queries.length,4);a.equal(restored.strategies[0].batch_size,12);
});
test('candidate with only company-specific profile URL imports and deduplicates',()=>{
 const {s,st,raw}=fixture(),r=raw(1);r.domain='';r.identity_url='https://www.facebook.com/firma-testowa/?utm_source=test';
 r.sources=[{...r.sources[0],url:r.identity_url}];let result=C.merge(s,[r],st);a.equal(result.added,1);s.leads=result.leads;
 result=C.merge(s,[{...r,identity_url:'https://facebook.com/firma-testowa'}],st);a.equal(result.duplicates,1);
 a.equal(C.restore(C.backup(s),'pilot').leads[0].identity_url,'https://facebook.com/firma-testowa');
});
test('distinct public profiles never collapse to one company on a shared host',()=>{
 const {s,st,raw}=fixture();const rs=[1,2].map(i=>{const r=raw(i);r.domain='facebook.com';r.identity_url='https://facebook.com/firma-'+i;r.sources=[{...r.sources[0],url:r.identity_url}];return r;});
 a.equal(C.merge(s,rs,st).added,2);
});
test('root catalogue URL or unsourced profile cannot replace missing company identity',()=>{
 const {s,st,raw}=fixture(),r=raw(1);r.domain='';r.identity_url='https://facebook.com/';
 a.equal(C.merge(s,[r],st).errors.length,1);
 r.identity_url='https://facebook.com/company';a.equal(C.merge(s,[r],st).errors.length,1);
});
test('contact enrichment counts each existing firm once and preserves sales history',()=>{
 const {s,st,run,raw,commit}=fixture();commit([raw(1),raw(2)]);s.leads[0].notes='Nie zgub';s.leads[0].status='CONTACTED';
 const enrich=C.createResearchRun(C.strategy({...st,mode:'targeted',limit:2,targets:'Firma 1\nFirma 2'}));
 const result=C.merge(s,[raw(1),raw(1),raw(2)],enrich.profile);s.leads=result.leads;
 C.recordResearchImport(enrich,result,{},'enrich.json');a.equal(C.researchProgress(enrich).found,2);a.equal(enrich.status,'goal_reached');
 a.equal(s.leads[0].status,'CONTACTED');a.equal(s.leads[0].notes,'Nie zgub');a.equal(C.researchProgress(run).found,2);
});
test('campaign and all batch reports survive server validation round trip',()=>{
 const {s,run,raw,commit}=fixture();commit([raw(1)],{research_report:{queries:[{query:'montaż ogrodzeń Lublin',area:'Lublin'}],stop_reason:'budget'}});
 C.prepareResearchBatch(s,run);const restored=C.restore(C.backup(s),'pilot');
 a.equal(C.researchProgress(restored.runs[0]).remaining,99);a.equal(restored.runs[0].batches.length,2);
 a.equal(restored.runs[0].imports[0].research.queries[0].area,'Lublin');
});
test('legacy campaign imported with 8/100 can continue without resetting count',()=>{
 const {s,st}=fixture(),run={id:'legacy',profile:st,strategy_id:st.id,status:'imported',added:8,duplicates:2,errors:0};
 a.equal(C.researchProgress(run).remaining,92);a.match(C.prepareResearchBatch(s,run),/DOTYCHCZAS: 8/);
});
test('new discovery task separates contacts and drafts, carries batch IDs and partial result contract',()=>{
 const {run}=fixture();for(const text of ['NIE pisz wiadomości','contacts może być []','batch_id','stop_reason','no_access','NOWYCH unikalnych'])a.ok(run.task.includes(text));
 a.ok(run.task.includes(run.batches[0].id));
});
