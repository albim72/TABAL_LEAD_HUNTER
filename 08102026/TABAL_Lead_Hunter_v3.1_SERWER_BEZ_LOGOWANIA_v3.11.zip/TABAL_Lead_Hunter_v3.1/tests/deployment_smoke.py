"""Actual Gunicorn stop/start and backup test on temporary data."""
import json,os,re,subprocess,sys,tempfile,time,urllib.request,urllib.error,sqlite3,socket
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from server.storage import Store
with tempfile.TemporaryDirectory(prefix='tabal-restart-') as tmp:
 data=Path(tmp)/'data';s=Store(data/'app.sqlite3');s.db.close()
 with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
 base=f'http://127.0.0.1:{port}';env=dict(os.environ,TABAL_DATA_DIR=str(data),TABAL_ORIGIN=base)
 def start():
  p=subprocess.Popen([sys.executable,'-m','gunicorn','-c',str(ROOT/'gunicorn.conf.py'),'--chdir',str(ROOT),'--bind',f'127.0.0.1:{port}','server.web:application'],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
  for _ in range(50):
   if p.poll() is not None:raise RuntimeError('Gunicorn failed to start')
   try:urllib.request.urlopen(base+'/healthz',timeout=1);return p
   except Exception:time.sleep(.1)
  p.terminate();raise RuntimeError('Timeout')
 def stop(p):p.terminate();p.wait(timeout=15)
 def req(path,body=None,csrf=''):
  r=urllib.request.Request(base+path,data=None if body is None else json.dumps(body).encode(),headers={'Content-Type':'application/json','Origin':base,'X-Tabal-Token':csrf})
  return urllib.request.urlopen(r,timeout=20)
 p=start()
 try:
  html=req('/').read().decode();runtime=json.loads(re.search(r'window.TABAL_SERVER=(.*?);window.TABAL_MAIL',html).group(1));csrf=runtime['csrf']
  state=json.load(req('/api/workspace'));state['state']['config']['offer']='RESTART_PERSISTENCE_CHECK'
  saved=json.load(req('/api/workspace',state,csrf));assert saved['revision']==1
 finally:stop(p)
 p=start()
 try:
  got=json.load(req('/api/workspace'));assert got['revision']==1 and got['state']['config']['offer']=='RESTART_PERSISTENCE_CHECK'
  mail=json.load(req('/api/state'));assert mail['paused'] and not mail['configured']
 finally:stop(p)
 print('PASS actual Gunicorn restart: workspace revision and data persist; SMTP paused')
 out=subprocess.check_output([sys.executable,str(ROOT/'manage.py'),'--data-dir',str(data),'backup',str(Path(tmp)/'backups')],text=True).strip()
 for name in ['app.sqlite3','mail.sqlite3']:
  with sqlite3.connect(Path(out)/name) as db:assert db.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
 copied=Store(Path(out)/'app.sqlite3');assert copied.get()['state']['config']['offer']=='RESTART_PERSISTENCE_CHECK';copied.db.close()
 print('PASS CLI backup: both SQLite databases intact and stored data recovered')
