import io,json,os,tempfile,unittest,sys,threading,sqlite3
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
TMP=tempfile.TemporaryDirectory();os.environ['TABAL_DATA_DIR']=TMP.name;os.environ['TABAL_ORIGIN']='http://127.0.0.1:8765';os.environ['TABAL_SMTP_HOSTS']='localhost'
from server import web
from server.storage import Store,core,Conflict
class ServerTests(unittest.TestCase):
 def req(self,path,method='GET',body=None,token='',csrf='',origin=True,host='127.0.0.1:8765'):
  raw=json.dumps(body or {}).encode();env={'HTTP_HOST':host,'PATH_INFO':path,'REQUEST_METHOD':method,'wsgi.input':io.BytesIO(raw),'CONTENT_LENGTH':str(len(raw)),'CONTENT_TYPE':'application/json','REMOTE_ADDR':'127.0.0.1','HTTP_COOKIE':'tabal_session='+token,'HTTP_X_TABAL_TOKEN':csrf}
  if origin:env['HTTP_ORIGIN']='http://127.0.0.1:8765'
  output={}
  def start(status,headers):output.update(status=int(status.split()[0]),headers=dict(headers))
  output['body']=b''.join(web.application(env,start));return output
 def auth(self,name='admin'):
  return '',web.NOLOGIN_CSRF
 def test_01_no_login_and_private_files(self):
  self.assertEqual(self.req('/api/workspace')['status'],200)
  t,c=self.auth()
  for p in ['/.runtime/app.sqlite3','/server/web.py','/../manage.py','/src/app.js']:self.assertEqual(self.req(p,token=t)['status'],404)
 def test_02_security_headers_and_csrf(self):
  t,c=self.auth();r=self.req('/',token=t);self.assertEqual(r['status'],200);self.assertIn('nonce-',r['headers']['Content-Security-Policy']);self.assertEqual(self.req('/login')['status'],302);self.assertEqual(self.req('/api/login','POST',{'username':'x','password':'y'})['status'],404)
  self.assertEqual(self.req('/api/workspace','POST',{},t,'bad')['status'],403)
  self.assertEqual(self.req('/api/workspace','POST',{},t,c,origin=False)['status'],403)
  self.assertEqual(self.req('/',token=t,host='evil.example')['status'],403)
 def test_03_persistence_and_conflict(self):
  t,c=self.auth();x=json.loads(self.req('/api/workspace',token=t)['body']);x['state']['config']['sender']='Zapis trwały'
  r=self.req('/api/workspace','POST',x,t,c);self.assertEqual(r['status'],200)
  self.assertEqual(self.req('/api/workspace','POST',x,t,c)['status'],409)
  second=Store(Path(TMP.name)/'app.sqlite3');self.assertEqual(second.get()['state']['config']['sender'],'Zapis trwały');second.db.close()
 def test_04_validation_does_not_overwrite(self):
  t,c=self.auth();x=web.store.get();before=x['revision'];x['state']['leads']=[{'company':'broken'}]
  self.assertEqual(self.req('/api/workspace','POST',x,t,c)['status'],400);self.assertEqual(web.store.get()['revision'],before)
 def test_05_smtp_host_allowlist(self):
  t,c=self.auth();self.assertEqual(self.req('/api/config','POST',{'host':'unapproved.example'},t,c)['status'],403)
 def test_06_forged_messages_rejected(self):
  t,c=self.auth();r=self.req('/api/enqueue','POST',{'revision':web.store.get()['revision'],'messages':[{'to':'x@example.com'}]},t,c);self.assertEqual(r['status'],400)
 def test_07_logout_is_noop_in_nologin_mode(self):
  t,c=self.auth();self.assertEqual(self.req('/api/logout','POST',{},t,c)['status'],200);self.assertEqual(self.req('/api/workspace',token=t)['status'],200)
 def test_08_page_contains_no_login_form(self):
  body=self.req('/')['body'].decode();self.assertNotIn('Zaloguj się do wspólnej bazy',body);self.assertNotIn('Wyloguj',body);self.assertIn('BEZ LOGOWANIA',body)
 def test_09_backup_restore_integrity(self):
  target=Path(TMP.name)/'backup.sqlite3';web.store.backup(target)
  with sqlite3.connect(target) as d:self.assertEqual(d.execute('PRAGMA integrity_check').fetchone()[0],'ok');self.assertEqual(d.execute('SELECT revision FROM workspace').fetchone()[0],web.store.get()['revision'])
 def test_10_concurrent_updates_one_wins(self):
  current=web.store.get();results=[]
  def put():
   try:web.store.put(current['state'],current['revision'],'test');results.append('ok')
   except Conflict:results.append('conflict')
  ts=[threading.Thread(target=put) for _ in range(2)]
  for t in ts:t.start()
  for t in ts:t.join()
  self.assertCountEqual(results,['ok','conflict'])
 def test_11_storage_accounts_remain_unused_but_valid(self):
  web.store.add_user('legacy','Legacy-test-123456','admin');token=web.store.login('legacy','Legacy-test-123456','ratelimit-ip');self.assertIsNotNone(web.store.session(token))
 def test_12_unknown_methods(self):self.assertEqual(self.req('/api/workspace','DELETE')['status'],405)
 def test_13_http_queue_checks_database_and_persists_receipt(self):
  import subprocess
  class FakeTransport:
   def __init__(self):self.sent=[]
   def send(self,cfg,job):self.sent.append(job)
  web.outbox.stop.set();web.worker.join(timeout=2);web.outbox.transport=FakeTransport()
  t,c=self.auth();x=web.store.get()
  js="const C=require('./src/core.js'),s=C.makeState('pilot'),st=s.strategies[0],r=C.sample(st,s,false);r.draft={subject:'Test',body:'Only local test'};const l=C.validateLead(r,s,st);l.status='TO_CONTACT';s.leads=[l];console.log(JSON.stringify(s));"
  x['state']=json.loads(subprocess.check_output(['node','-e',js],cwd=Path(__file__).resolve().parents[1]))
  r=self.req('/api/workspace','POST',x,t,c);self.assertEqual(r['status'],200)
  rev=json.loads(r['body'])['revision'];owner='test-tab-123456'
  cfg=dict(host='localhost',port=465,security='ssl',username='test@example.com',password='Fake-only-test',sender_name='TEST',sender_email='test@example.com',interval=10)
  self.assertEqual(self.req('/api/config','POST',cfg,t,c)['status'],200)
  msgs=core('candidates',state=web.store.get()['state'])
  r=self.req('/api/enqueue','POST',dict(messages=msgs,revision=rev,owner=owner),t,c);self.assertEqual(r['status'],200)
  jobs=json.loads(r['body'])['jobs'];ids=[j['id'] for j in jobs]
  self.assertEqual(self.req('/api/sync','POST',dict(revision=rev,owner=owner,allowed=ids,observed=ids,writable=True),t,c)['status'],200)
  self.assertEqual(self.req('/api/control','POST',dict(action='resume',revision=rev,owner=owner),t,c)['status'],200)
  self.assertTrue(web.outbox.run_one());self.assertEqual(len(web.outbox.transport.sent),1)
  state=json.loads(self.req('/api/workspace',token=t)['body']);self.assertEqual(state['state']['leads'][0]['status'],'CONTACTED');self.assertEqual(len(state['state']['leads'][0]['mail_events']),1)
  state2=json.loads(self.req('/api/workspace',token=t)['body']);self.assertEqual(state2['revision'],state['revision'])
  self.assertEqual(self.req('/api/enqueue','POST',dict(messages=msgs,revision=state2['revision'],owner=owner),t,c)['status'],400)
 def test_14_stale_revision_blocks_queue(self):
  t,c=self.auth();self.assertEqual(self.req('/api/control','POST',dict(action='resume',revision=-1,owner='owner-123456'),t,c)['status'],409)
 def test_15_password_change_revokes_sessions(self):
  web.store.add_user('temporary','Temporary-test-123456','editor');token=web.store.login('temporary','Temporary-test-123456','temp');self.assertIsNotNone(web.store.session(token));web.store.add_user('temporary','Replacement-test-123456','editor');self.assertIsNone(web.store.session(token))
if __name__=='__main__':unittest.main(verbosity=2)
