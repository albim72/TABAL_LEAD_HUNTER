@echo off
cd /d "%~dp0"
set "PYTHONUTF8=1"
set "PYTHONIOENCODING=utf-8"
echo Test lokalny: wymagany Python 3.10+ i Node.js 22+.
echo Wersja BEZ LOGOWANIA: konto Lead Huntera nie jest potrzebne.
echo Panel: http://127.0.0.1:8765
python serve.py
pause
