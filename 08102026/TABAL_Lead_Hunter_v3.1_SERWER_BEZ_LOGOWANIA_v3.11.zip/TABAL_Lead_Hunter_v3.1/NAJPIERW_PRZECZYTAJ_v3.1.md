# TABAL Lead Hunter 3.1 — więcej firm w badaniu

Wydanie: 8 października 2026. Aktualizacja załączonej wersji serwerowej 3.0.

## Dlaczego cel 100 mógł kończyć się na ośmiu firmach?

W kodzie 3.0 znaleziono konkretne ograniczenia:

| Element 3.0 | Znaczenie | Poprawka 3.1 |
|---|---|---|
| Zadanie mówiło „do 100” | Osiem wyników mieściło się w tej instrukcji | Cel całej kampanii i licznik brakujących firm |
| Brak obsługi kolejnych partii | Po poprawnym imporcie cykl otrzymywał status „Zaimportowano”, niezależnie od liczby | Wynik częściowy i przycisk przygotowania kolejnej partii |
| Odkrywanie + kwalifikacja + osoby kontaktowe + wiadomości w jednym zadaniu | Większy nakład pracy na każdą firmę | Najpierw odkrywanie; uzupełnianie danych osobno |
| Ogólna instrukcja zmiany miast i zapytań | Nie było konkretnego planu rozdzielanego pomiędzy partie | Plan zapytań i 24 punkty startowe dla całego lubelskiego |
| Domena własna lub NIP były wymagane | Kandydat bez tych danych nie przechodził importu | Możliwość użycia pełnego URL konkretnej wizytówki ze źródeł |
| Cel wpisany w formularzu nie aktualizował zapisanego profilu | Formularz po odświeżeniu mógł znów pokazywać wcześniejszą liczbę | Cel, wielkość partii i frazy są zapisywane |

To ustalenia z kodu. Bez rzeczywistego JSON i logu z badania zwracającego osiem firm nie da się ustalić, jaki udział miało każde ograniczenie w tamtej sesji. Znaczenie mają też dostęp do wyszukiwania w Work, jego limity, czas badania, jakość publicznych źródeł, wąskość kryteriów, liczba duplikatów i wybrany filtr listy leadów.

## Ustawienia dla lubelskiego

1. Otwórz **Strategie** i wybierz właściwy produkt oraz typ klienta. Kraj: **Polska**, województwo: **lubelskie**, obszar: **lubelskie, Polska**. Jeśli wpiszesz wyłącznie Lublin, zakres pozostanie węższy.
2. W **Odkrywaniu** wybierz ten profil. Ustaw **cel kampanii: 100**, **firm w partii: 20**, etap **Najpierw odkryj firmy**. Własne lokalizacje i frazy możesz wpisać w rozwijanej sekcji; puste pola uruchamiają plan domyślny.
3. Kliknij **Rozpocznij nową kampanię**. Skopiuj zadanie do Work z dostępnym wyszukiwaniem internetu. Wykonaj badanie i pobierz kompletny JSON.
4. Wczytaj JSON, sprawdź podgląd, kliknij **Zapisz leady w Hunterze**. Zachowaj w pliku identyfikatory `run_id`, `batch_id` i `strategy_id` z zadania.
5. Jeśli wynik to **8 z 100 — brakuje 92**, kliknij **Przygotuj kolejną partię** w panelu postępu. Wykonaj nowe zadanie w Work i ponownie zaimportuj wynik. Nie rozpoczynaj za każdym razem nowej kampanii.
6. Kontynuuj do osiągnięcia celu albo do udokumentowanego ograniczenia. Raport pokazuje rzeczywiste liczby importu oraz informacje z Work: wykonane zapytania, brak dostępu, limit badania lub brak nowych trafień.
7. Użyj **Uzupełnij dane znalezionych firm**, aby osobno sprawdzić kontakty i dopasowanie. Uzupełnianie tworzy odrębną kampanię dla tych podmiotów. Research znanej firmy jest zachowywany w jej historii; na karcie wybierz **Użyj tego researchu w ocenie**, gdy ma zastąpić wcześniejszą ocenę.

### Co oznaczają liczniki?

- **Nowe** — unikalne firmy, których wcześniej nie było w całej bazie. Tylko one realizują cel otwartego odkrywania.
- **Ponowne** — rozpoznane firmy; ich historia zostaje zachowana, ale nie są kolejnymi nowymi firmami.
- **Błędy** — rekordy pominięte w ostatnim imporcie z konkretnym powodem. Pobierz raport i popraw dane.
- **Spełniają kryteria** — odrębna ocena oparta na źródłach, wagach i wykluczeniach. Sto kandydatów nie oznacza stu firm gotowych do kontaktu.

Brak e-maila lub nieustalone kryterium nie usuwa kandydata. Nie nadaje mu też potwierdzonej kwalifikacji. Adres wizytówki musi dotyczyć konkretnej firmy i występować w `sources`; nie wolno wpisywać strony głównej katalogu jako domeny firmy. Tożsamość i źródła nadal wymagają kontroli operatora.

Jeżeli na liście widzisz osiem firm, sprawdź również filtry **statusu**, **produktu**, **strategii** i **Do zrobienia**. Licznik pod tabelą pokazuje liczbę widoczną i rozmiar bazy. Scoring nie usuwa firm z rejestru.

## Aktualizacja istniejącej instalacji

### Test lokalny

1. W starej aplikacji pobierz **Kopię JSON**. Zatrzymaj stary serwer i zachowaj pełną kopię jego katalogu `.runtime`.
2. Rozpakuj wersję 3.1 w nowym katalogu. Aby zachować dane i historię wysyłek, przenieś kopię całego `.runtime` ze starej instalacji do nowej **przed pierwszym uruchomieniem**. Nie nadpisuj bazy innej, już używanej instalacji.
3. Uruchom `python3 serve.py` (Windows: `python serve.py`). Panel otworzy się bez logowania; nie twórz konta aplikacji.
4. Odśwież stronę w przeglądarce. W menu powinna być widoczna **WERSJA 3.1**. Sprawdź istniejące firmy i ostatnią kampanię. Starszą kampanię 8/100 można kontynuować z zachowaniem dotychczasowego licznika.

### Docker / serwer

1. Wstrzymaj wysyłkę i wykonaj dotychczasową procedurę kopii obu baz: `app.sqlite3` i `mail.sqlite3`. Zachowaj `.env`.
2. Podmień kod aplikacji w istniejącym katalogu wdrożenia. Zachowaj ten sam projekt Compose, konfigurację i wolumen danych. Zmiana katalogu projektu może utworzyć inny wolumen — nie uruchamiaj w nim nowej, pustej bazy przez pomyłkę.
3. Uruchom `docker compose up -d --build`, bez usuwania wolumenu. **Nie używaj `docker compose down -v`.**
4. Otwórz panel, sprawdź wersję, firmy i historię. Szczegółowa instrukcja serwera i kopii pozostaje w `README.md` oraz `INSTRUKCJA.html`.

Format kopii i importu pozostaje `schema_version: 2`. Nowe pola są dodatkami. Kopie z 3.0 są obsługiwane; przed powrotem do starszego kodu zachowaj także kopię nowych danych, ponieważ 3.0 nie obsługuje tożsamości wyłącznie przez wizytówkę i funkcji nowych kampanii.

## Granice tej poprawki

Panel nie wykonuje wyszukiwania sam w tle i nie korzysta z płatnego API. Każdą partię trzeba wykonać w Work i zaimportować wynik. W tej aktualizacji nie podłączono nowej usługi wyszukiwawczej ani skrzynki pocztowej.

Cel 100 nie jest obietnicą, że w regionie istnieje lub da się publicznie potwierdzić tyle firm spełniających dany profil. Automatyczne zbieranie wyników bez ręcznego przenoszenia plików wymagałoby dodatkowej integracji. Bieżące testy sprawdzają działanie programu na danych testowych; nie są badaniem rzeczywistego rynku lubelskiego.

Raport przeprowadzonych testów: `docs/RAPORT_TESTOW_v3.1.md`.
