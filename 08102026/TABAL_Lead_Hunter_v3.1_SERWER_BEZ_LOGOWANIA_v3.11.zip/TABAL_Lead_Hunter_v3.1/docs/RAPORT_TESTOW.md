# Raport testów — TABAL Lead Hunter 3.0

Data: 01.10.2026. Bazą jest przesłany ZIP 2.3 o SHA-256:
`f626d55e24d01ab8f7f1fe82418425eba7ff01df5331677c4caba0ae86b83bb0`.
Oba załączniki użytkownika zawierają identyczny plik.

## Wynik

**117 testów automatycznych zakończonych powodzeniem oraz 2 udane sprawdzenia restartu/kopii.** Brak błędów JavaScript w zakończonym teście przeglądarkowym.

| Zestaw | Wynik | Dowód |
|---|---:|---|
| Logika bazowa i nowe wymagania | 59/59 | `test-results/core-v3.tap` |
| Kolejka, SQLite, połączenia SMTP TLS i STARTTLS | 26/26 | `test-results/smtp-v3.txt` |
| Serwer, konta, sesje, CSRF, role, konflikty i pełna ścieżka kolejki | 15/15 | `test-results/server-v3.txt` |
| Przeglądarka: pełny proces, dwa konta i widok mobilny | 17/17 | `test-results/browser-v3.json` |
| Rzeczywisty stop/start procesu Gunicorn i trwałość danych | zaliczony | `test-results/deployment-v3.txt` |
| Polecenie kopii obu baz, integralność SQLite i odczyt danych z kopii | zaliczony | `test-results/deployment-v3.txt` |

## Co sprawdzono

- Tworzenie strategii z pustymi warunkami, wybór kraju i województwa.
- Wagi i obowiązkowość kryteriów, normalizację wyniku oraz uzasadnienia.
- Zachowanie leadów, historii i danych przy ponownym imporcie w innej strategii; filtrowanie po obu strategiach.
- Kontakty pod nazwiskiem; sprawdzanie adresu/telefonu w cytacie źródła; brak wysyłki na zgadnięty e-mail.
- Listę kontrolną firm, ujawnianie braków i prompt obejmujący ofertę, podpis oraz plan badania.
- Trzy style lokalnych szkiców, opisy produktów, zatwierdzoną ofertę i zapis wielowierszowego podpisu.
- Odczyt kopii poprzedniej wersji, zachowanie pól handlowych, eksport i ponowne odtworzenie schematu.
- Import JSON z podglądem; dane przed zatwierdzeniem nie trafiają do bazy.
- Zapis na serwerze, widoczność w drugiej sesji, konkurencyjny zapis: jedna zmiana przyjęta, druga odrzucona jako konflikt.
- Logowanie, wylogowanie, unieważnienie sesji po zmianie hasła, blokadę anonimowego dostępu i prywatnych ścieżek.
- Odrzucenie złego Origin, hosta, tokenu CSRF, niedozwolonej metody i błędnego stanu danych.
- Haszowanie haseł, limit prób logowania, rolę editor bez możliwości konfiguracji SMTP, listę dozwolonych hostów SMTP.
- Odrzucenie wiadomości podsuniętej do API, która nie odpowiada zapisanej karcie firmy.
- Zatwierdzenie partii, heartbeat, pauzę, ograniczenie jednej aktywnej karty kolejki, jednoznaczne błędy i niepewny wynik, brak automatycznego podwójnego wysyłania.
- Przyjęcie wiadomości przez lokalną skrzynkę TLS/STARTTLS i zapis potwierdzenia tylko raz, bez cofania późniejszego statusu handlowego.
- Teksty wyglądające jak HTML wyświetlane jako tekst; brak wykonania testowego zdarzenia XSS.
- Nawigację, raport, izolację DEMO, widok 1440×1000 oraz 390×844. Szeroka tabela na telefonie przewija się we własnym obszarze.
- Restart procesu Gunicorn: rewizja i zapisane dane pozostają; SMTP jest wstrzymane i bez hasła w RAM.

W toku kontroli poprawiono m.in. zachowanie wielowierszowego podpisu w panelu scoringu i szerokość filtrów na telefonie. Testy końcowe wykonano po tych poprawkach.

## Środowisko i granice testu

Linux, Node.js 24.19.0, Python 3, Gunicorn 26.2.0, Playwright z Chromium 133.0.6943.0. Testy używają tymczasowych baz i fikcyjnych kontaktów `example.com`. Zrzuty ekranu znajdują się w `test-results`.

**Nie wysłano wiadomości do klientów ani nie użyto rzeczywistego konta SMTP TABAL.** Testy protokołu używały lokalnej skrzynki testowej, a test pełnej ścieżki nowego API — kontrolowanego transportu testowego.

Nie wykonano: wdrożenia na docelowym serwerze TABAL, budowania obrazu Docker w tym środowisku (brak silnika Docker), rzeczywistej konfiguracji nginx/certyfikatu, testów w Safari/Firefox/Edge, audytu penetracyjnego, testu dużego obciążenia ani pomiaru kompletności realnego researchu Stalplast/Parkan. Te granice nie są ukryte pod liczbą zaliczonych testów.

Pliki Docker Compose i systemd są dostarczoną konfiguracją wdrożeniową. Aplikacja WSGI została uruchomiona i przetestowana z rzeczywistym Gunicorn. Ostateczny test odbiorczy na serwerze, w sieci i poczcie TABAL jest opisany w README.

## Powtórzenie testów

Podstawowe testy, z katalogu projektu:

```bash
node --test --test-reporter=tap tests/core.test.js tests/v3.test.js
python3 tests/test_mail.py
python3 tests/test_server.py
```

Testy lokalnego TLS wymagają `openssl`. Testy serwera wymagają Node.js w PATH. Podstawowy test aplikacji nie wymaga klucza OpenAI ani usług zewnętrznych.

Na Linux do testu restartu i przeglądarki:

```bash
python3 -m venv .venv
.venv/bin/pip install -r requirements.txt
npm install
npx playwright install chromium
.venv/bin/python tests/deployment_smoke.py
.venv/bin/python scripts/run_browser_tests.py
```

Runner przeglądarkowy tworzy odrębną bazę tymczasową i konta testowe, uruchamia własny Gunicorn i usuwa środowisko po zakończeniu. Wymaga wolnego portu 8765. Nie uruchamiaj `tests/browser.cjs` bezpośrednio przeciwko produkcji: scenariusz zmienia dane. `CHROMIUM_PATH` pozwala wskazać lokalny plik wykonywalny przeglądarki.
