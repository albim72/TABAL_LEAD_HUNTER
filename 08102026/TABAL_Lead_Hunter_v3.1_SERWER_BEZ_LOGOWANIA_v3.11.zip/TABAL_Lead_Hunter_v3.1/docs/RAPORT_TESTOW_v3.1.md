# TABAL Lead Hunter 3.1 — raport weryfikacji

Data: 8 października 2026. Testy lokalne na danych syntetycznych. Nie przeprowadzano badań rynku ani wysyłki wiadomości do rzeczywistych odbiorców.

| Zakres | Wynik | Dowód w paczce |
|---|---:|---|
| Logika aplikacji: dotychczasowe testy i nowe regresje wyszukiwania | 74/74 PASS | `test-results/core-v31.tap` |
| API, walidacja, zapis, uprawnienia i ochrona współbieżnych edycji | 15/15 PASS | `test-results/server-v31.txt` |
| Rzeczywista przeglądarka Chromium, interfejs i wspólny serwer | 22/22 PASS, 0 błędów JS | `test-results/browser-v31.json`, `test-results/browser-v31-console.txt` |
| Restart Gunicorn i odtworzenie danych; kopia obu baz | 2 scenariusze PASS | `test-results/deployment-v31.txt` |

## Najważniejsze regresje

1. Import 8 poprawnych kandydatów przy celu 100 pozostawia kampanię niepełną i wskazuje 92 brakujące firmy.
2. Kolejna partia używa kolejnych zapytań w planie lubelskiego, bez zerowania licznika. Ponowne otwarcie już przygotowanej partii nie przesuwa planu.
3. Ponowny import tej samej firmy, duplikat wewnątrz pliku oraz błędny rekord nie zwiększają licznika nowych firm.
4. Kolejne partie na syntetycznym zbiorze mogą osiągnąć 100; ostatnia partia ma rozmiar równy liczbie brakujących firm, gdy ta jest mniejsza od domyślnej partii.
5. Pusty wynik z powodem `no_access` zachowuje niezrealizowany cel i pokazuje ograniczenie.
6. Kandydat bez kontaktu i z kryteriami `unknown` zapisuje się w rejestrze, lecz nie uzyskuje sztucznej kwalifikacji ani gotowości do wysyłki.
7. 24 odrębne punkty startowe dla całego lubelskiego; wskazanie samego Lublina nie rozszerza zakresu do całego województwa. Można użyć własnych miejscowości i fraz.
8. Pełny URL firmowej wizytówki może zastąpić brak własnej domeny i NIP. Link musi występować w źródłach. Strona główna katalogu nie wystarcza.
9. Różne profile na wspólnym serwisie nie są scalane tylko dlatego, że mają domenę tego samego serwisu.
10. Oddzielne uzupełnianie znanych firm liczy unikalnie zbadane podmioty i zachowuje ich statusy oraz notatki.
11. Cel, wielkość partii, raporty i postęp przetrwały zapis, walidację kopii oraz przeładowanie panelu.
12. Import z nieznanym identyfikatorem partii jest blokowany bez zmiany bazy.
13. Migracja starszej kampanii z licznikiem 8/100 pozwala przygotować kolejną partię bez utraty postępu.

## Przeglądarka

Chromium 153.0.8010.0, Playwright; widoki komputerowy oraz telefon 390×844. Zrzuty: `test-results/discovery-v31-desktop.png` i `test-results/discovery-v31-mobile.png`. Zachowano pozostałe dotychczasowe testy: logowanie, uprawnienia, import i podgląd, kontakty, historie, filtry, kopie, konflikty zapisów, izolację DEMO oraz wylogowanie.

Pierwszy przebieg rozszerzonego testu zatrzymał się na asercji wyświetlenia błędu pliku, zanim asynchroniczny odczyt pliku dobiegł końca. Dodano oczekiwanie na komunikat. Końcowy pełny przebieg: 22/22 PASS. Weryfikacja nie korzystała z produkcyjnej bazy.

## Odtwarzanie

```bash
python3 scripts/build.py
npm test
python3 tests/test_server.py
python3 tests/deployment_smoke.py
npm run test:browser
```

Testy restartu wymagają zależności z `requirements.txt`. Testy przeglądarkowe wymagają `npm install` i przeglądarki Playwright (`npx playwright install chromium`), ewentualnie ścieżki istniejącej zgodnej przeglądarki w `CHROMIUM_PATH`. Runner tworzy tymczasową bazę, nie podłącza danych produkcyjnych. W środowisku weryfikacji użyto zewnętrznego pliku Chromium; nie jest on częścią paczki.

## Ograniczenia weryfikacji

Nie testowano liczby rzeczywistych firm, które Work odnajdzie dla konkretnej strategii lubelskiej, ponieważ nie uruchamiano takiej kampanii na koncie użytkownika i nie otrzymano JSON z ośmioma wynikami. Nie zweryfikowano docelowego serwera TABAL ani rzeczywistej poczty. Sto wyników testowych oznacza poprawność licznika i kontynuacji, a nie znalezienie stu rzeczywistych leadów.

Raporty bez oznaczenia `v31` pochodzą z historycznego wydania 3.0; nie stanowią dodatkowej weryfikacji tej aktualizacji.
