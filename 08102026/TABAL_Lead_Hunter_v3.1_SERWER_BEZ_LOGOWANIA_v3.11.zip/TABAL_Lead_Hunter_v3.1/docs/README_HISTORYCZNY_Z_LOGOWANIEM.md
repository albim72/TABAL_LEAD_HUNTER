# TABAL Lead Hunter v3.1 — wariant BEZ LOGOWANIA

> **Ten wariant nie używa logowania do aplikacji.** Każdy, kto ma dostęp do adresu panelu, działa jako administrator. Nie wykonuj poleceń `manage.py user` z dalszej części starszej instrukcji. Przy wdrożeniu zdalnym ogranicz dostęp przez VPN/reverse proxy/reguły IP. Szczegóły: `README_BEZ_LOGOWANIA.md`.

# TABAL Lead Hunter 3.1 — pakiet serwerowy

Wydanie 08.10.2026. Kod aplikacji, konfiguracja serwera, testy i instrukcja.
Wersja rozwija załączony Lead Hunter 3.0. Główna poprawka: kampanie, które po imporcie 8 firm przy celu 100 wymagają dalszego badania. Pełny opis: `NAJPIERW_PRZECZYTAJ_v3.1.md`.

**To pakiet do wdrożenia na serwerze TABAL. Nie został zainstalowany na serwerze docelowym:** nie otrzymaliśmy jego adresu, dostępu, domeny ani konfiguracji poczty. Weryfikacja lokalna nie zastępuje odbioru na infrastrukturze firmy.

## Najważniejsze zmiany 3.1

- Cel kampanii i licznik brakujących **nowych unikalnych firm**; duplikaty nie realizują celu odkrywania.
- Partie po 20 (zmienialne 1–50), kontynuacja tej samej kampanii oraz zachowanie celu po przeładowaniu.
- 24 punkty startowe dla całego województwa lubelskiego; rotacja zapytań, synonimy branży oraz własne miejscowości i frazy.
- Odkrywanie bez obowiązku pozyskania osoby kontaktowej lub napisania wiadomości; kwalifikacja i uzupełnianie jako osobny etap.
- Firmy bez własnej domeny i NIP można identyfikować pełnym adresem ich publicznej wizytówki z listy źródeł (`identity_url`).
- Diagnostyka: dodane firmy, duplikaty, błędy, faktyczne zapytania i zadeklarowany powód końca partii. Wynik modelu nie zastępuje niezależnej weryfikacji źródeł.
- Dotychczasowa architektura pozostaje: Work wykonuje wyszukiwanie, operator importuje pliki. Brak automatycznego wyszukiwania/API i gwarancji liczby firm.

## Zachowane funkcje

- Filtr leadów według strategii, także strategii zapisanych w historii ponownych odkryć.
- E-mail i telefon bezpośrednio pod osobą kontaktową. Niepotwierdzone dane mają oznaczenie „do weryfikacji”.
- Jedna karta firmy rozpoznawanej po NIP/domenie, wiele kontekstów i strategii. Ponowne znalezienie zapisuje badanie i ostrzeżenie; nie odrzuca leada. Status, notatki i kontakt handlowy pozostają. W historii można wybrać research do bieżącej oceny.
- Kraj i lista 16 województw (aktywna po wyborze Polski). Pozostałe warunki strategii są opcjonalne; wymagana jest nazwa i poprawne parametry techniczne zadania.
- Panel nazw kryteriów, wag, obowiązkowości i progu. Warunki definiuje strategia, wagi określają znaczenie; puste warunki lub waga 0 nie blokują kwalifikacji. Wynik pokazuje rozbicie punktów i powody wstrzymania.
- Lista kontrolna znanych firm i widoczne braki; rozszerzony prompt wymaga badania obszarów, synonimów i opisania pominięć. Samo wpisanie firmy na listę nie tworzy leada.
- Trzy style wiadomości, opis produktu, wspólna oferta TABAL i wielowierszowy podpis. Wygenerowane szkice wymagają przeglądu operatora.
- Wspólna baza SQLite na serwerze, indywidualne konta admin/editor, sesje, historia zapisów i ochrona przed nadpisaniem nowszych zmian.
- Zachowana kolejka SMTP z zatwierdzaniem partii; serwer porównuje wiadomości z zapisaną bazą. Administrator ogranicza dopuszczone hosty SMTP.
- Brak automatycznego połączenia z ChatGPT/OpenAI API. Research: zadanie → ChatGPT Work → JSON → import. Panel korzysta z własnego wewnętrznego API do zapisu danych; nie jest to odrzucona przez TABAL integracja ChatGPT API.

## Najszybszy start lokalny — Windows / Mac / Linux

Wymagane: **Python 3.10+ i Node.js 22+** w PATH. Do samego testu lokalnego nie trzeba instalować pakietów Python ani npm.

1. Rozpakuj ZIP i otwórz terminal w katalogu `TABAL_Lead_Hunter_v3.1`.
2. Utwórz pierwszego administratora:

```bash
python3 manage.py user admin --role admin
```

Wpisz dwukrotnie własne hasło, minimum 12 znaków. Hasło nie pojawia się w terminalu; nie ma fabrycznego loginu z gotowym hasłem.

3. Uruchom serwer:

```bash
python3 serve.py
```

4. Wklej w przeglądarkę **http://127.0.0.1:8765** i zaloguj się. Okno terminala pozostaw otwarte.

Na Windows użyj `python` zamiast `python3`; po utworzeniu konta możesz uruchomić `URUCHOM_WINDOWS.bat`. Na macOS można uruchomić `URUCHOM_MAC_LINUX.command`. Nie otwieraj START.html dwuklikiem: wersja 3.1 wymaga serwera. Ten wariant służy do testu na własnym komputerze; wdrożenie docelowe opisano poniżej.

## Wdrożenie docelowe — Linux, Docker Compose i HTTPS

Założenie: jeden serwer i jedna instancja aplikacji, niewielki zespół, do 2000 firm w zbiorze. Punkt startowy infrastruktury: 2 CPU, 2 GB RAM i 10 GB dysku (dobór operacyjny, nie wynik testu obciążeniowego). Kopie przechowuj poza serwerem. Potrzebne są Docker Engine z Compose, domena, certyfikat TLS i nginx lub równoważny reverse proxy. Aplikacja używa architektury CPU obsługiwanej przez obrazy Node/Python.

### 1. Przygotowanie

Skopiuj katalog na serwer. W jego wnętrzu:

```bash
cp .env.example .env
```

Ustaw w `.env`:

```dotenv
TABAL_ORIGIN=https://leady.twoja-domena.pl
TABAL_SMTP_HOSTS=smtp.twoj-operator.pl
TABAL_TRUST_PROXY=1
```

Zastąp przykłady rzeczywistymi wartościami administratora. Hosty SMTP rozdziel przecinkami, bez spacji. Puste `TABAL_SMTP_HOSTS` wyłącza możliwość konfiguracji wysyłki. Hasło SMTP wpisuje administrator w panelu, nie w `.env`. `TABAL_TRUST_PROXY=1` stosuj tylko gdy proxy nadpisuje `X-Real-IP`, a port aplikacji jest niedostępny z internetu.

### 2. Budowanie i konto

```bash
docker compose build
docker compose run --rm lead-hunter python manage.py user admin --role admin
docker compose up -d
```

Następnie utwórz osobne konta handlowców:

```bash
docker compose exec lead-hunter python manage.py user handlowiec1 --role editor
```

Każdy użytkownik ma własny login i hasło. Admin i editor widzą i edytują tę samą bazę; tylko admin konfiguruje SMTP i wykonuje test skrzynki. Zarządzanie kontami odbywa się przez terminal administratora serwera. Brak podziału firm między handlowców, SSO i 2FA w samej aplikacji.

### 3. HTTPS

Skopiuj i dostosuj `deploy/nginx.conf.example`: domena i ścieżki do ważnego certyfikatu. Sprawdź konfigurację i przeładuj nginx zgodnie ze standardem administratora. Proxy kieruje ruch na `127.0.0.1:8765`. Nie wystawiaj portu 8765 publicznie; udostępniaj 443. `TABAL_ORIGIN` musi dokładnie odpowiadać adresowi w przeglądarce (bez końcowego ukośnika i ścieżki).

```bash
docker compose ps
docker compose logs --tail=100 lead-hunter
```

Otwórz `https://leady.twoja-domena.pl`, zaloguj się, zapisz strategię i sprawdź ją w drugim koncie.
Nie zwiększaj liczby workerów Gunicorn ani replik kontenera: ta wersja ma jedną kolejkę SMTP i jeden proces aplikacji z 8 wątkami. Skalowanie wieloprocesowe wymaga oddzielnego workera kolejki.

### 4. Odbiór przed udostępnieniem handlowcom

- Sprawdź dostęp przez HTTPS, logowanie, trwałość zapisu po restarcie kontenera i blokowanie wejścia bez sesji.
- Przywróć kopię v2, porównaj liczbę firm, statusy, notatki, kontakty i strategie.
- Sprawdź jednoczesną edycję z dwóch kont: drugi zapis starej wersji ma być odrzucony, bez utraty pierwszego.
- Wykonaj kopię bazy i próbne odtworzenie na oddzielnej instancji.
- Wpisz SMTP i wyślij test **wyłącznie na własną skrzynkę nadawcy**; sprawdź odebranie, nadawcę i logi operatora.
- Potwierdź ofertę, podpis i kryteria TABAL, następnie wykonaj pilotaż według `docs/PILOT_TABAL.md`.

## Alternatywa bez Dockera — systemd

Wymagane Python 3.10+ i Node.js 22+ dostępne systemowo (także dla konta usługi, nie tylko przez profil interaktywnej powłoki).

1. Umieść kod w `/opt/tabal-lead-hunter`, utwórz konto systemowe `tabal` i katalog danych `/var/lib/tabal-lead-hunter` należący do tego konta.
2. W katalogu kodu:

```bash
python3 -m venv .venv
.venv/bin/pip install -r requirements.txt
python3 scripts/build.py
```

3. Utwórz `/etc/tabal-lead-hunter.env` z `TABAL_ORIGIN`, `TABAL_SMTP_HOSTS`, `TABAL_TRUST_PROXY`; uprawnienia pliku 600, właściciel root.
4. Utwórz konto aplikacji z prawami użytkownika usługi:

```bash
sudo -u tabal /opt/tabal-lead-hunter/.venv/bin/python /opt/tabal-lead-hunter/manage.py --data-dir /var/lib/tabal-lead-hunter user admin --role admin
```

5. Zainstaluj `deploy/tabal.service` w `/etc/systemd/system/`, potem:

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now tabal
sudo systemctl status tabal
```

6. Skonfiguruj nginx i HTTPS jak wyżej. Logi: `journalctl -u tabal`.

## Konta, hasła i sesje

`manage.py user LOGIN --role editor` tworzy konto lub zmienia jego hasło i rolę. Poprzednie sesje są unieważniane. `manage.py users` pokazuje loginy i role, a `manage.py delete-user LOGIN` usuwa konto. Nie usuwa jego zapisów handlowych. Nie usuwaj ostatniego administratora bez przygotowania nowego.

Hasła są haszowane PBKDF2-SHA256 z osobną solą (600 000 iteracji). Sesja trwa maksymalnie 8 godzin. Logowanie ma limit 8 błędnych prób z jednego IP przez 15 minut; przy wspólnym NAT limit dotyczy grupy korzystającej z tego samego adresu. Cookie ma HttpOnly, SameSite=Strict i Secure przy HTTPS. Mutacje wymagają zgodnego Origin oraz tokenu CSRF. Dziennik zapisów w `changes` zawiera użytkownika, czas, rewizję i operację; nie jest niezmienialnym dziennikiem audytowym.

## Zapis danych i konflikty

Mój pilot jest wspólną bazą na serwerze. DEMO i próbka v1 są lokalnymi zbiorami ćwiczeniowymi. Browser nie przechowuje kopii pilota w LocalStorage. Eksporty pobrane przez użytkownika zawierają dane handlowe.

Każdy zapis ma numer wersji. Jeżeli druga osoba wcześniej zapisze zmianę, stare dane nie nadpiszą nowych. Pojawi się ostrzeżenie: pobierz Kopię JSON swoich niezapisanych zmian, odśwież i wprowadź potrzebne poprawki ponownie. Nie przywracaj automatycznie całej starej kopii, bo zastąpi nowsze dane. Brak automatycznego scalania zmian i edycji współbieżnej tego samego formularza.

Czekaj na „Zapisano na serwerze”. W czasie wysyłania pojedynczego e-maila zapis bazy może być zablokowany; aplikacja poprosi o zachowanie zmian i odświeżenie. Odśwież stronę przed pracą, jeśli inni użytkownicy mogli zmienić bazę.

## Migracja z 2.3

1. W starej aplikacji wybierz Mój pilot i pobierz Kopię JSON.
2. W nowej: Profil i źródła → Dane i kopie → Przywróć kopię v1 / v2.
3. Sprawdź podgląd danych po przywróceniu i potwierdzenie zapisu na serwerze. Import kopii zastępuje wspólny zbiór, więc zrób to przed rozpoczęciem pracy zespołu.
4. Kopia JSON zachowuje firmy, research, strategie, statusy, notatki, szkice i zsynchronizowane potwierdzenia wysyłek.
5. Pełnej starej kolejki SMTP nie przenosi JSON. Jeżeli używano wysyłki v2.3: wstrzymaj ją, zamknij stary serwer i zachowaj `.runtime/mail.sqlite3`. Administrator może skopiować ten plik jako `/data/mail.sqlite3` przed pierwszym startem nowego serwera (właściciel UID 10001 w Dockerze). Nie zastępuj już używanej nowej bazy. Zachowanie dziennika zapobiega ponownej wysyłce do obsłużonych adresów. Wynik `uncertain` wymaga kontroli poczty.
6. Początkowe opisy produktów pozostają puste — TABAL musi dostarczyć zatwierdzone informacje. Nie wpisano fikcyjnych parametrów ani cudzych podpisów.

## Kopie, odtworzenie i aktualizacja

Pełna kopia obejmuje `app.sqlite3` (dane i konta) oraz `mail.sqlite3` (kolejka). Hasło SMTP pozostaje tylko w RAM.
Najpierw wstrzymaj wysyłkę, zaczekaj na brak trwającej wiadomości i ustal krótką przerwę w edycji. Polecenie kopii używa SQLite Backup API, nie kopiuje surowego otwartego pliku bazy:

```bash
docker compose exec lead-hunter python manage.py backup /data/backups
```

Polecenie wyświetli katalog kopii. Skopiuj konkretny katalog poza wolumen:

```bash
docker compose cp lead-hunter:/data/backups/NAZWA_KOPII ./NAZWA_KOPII
```

W wariancie systemd: uruchom `manage.py --data-dir /var/lib/tabal-lead-hunter backup KATALOG` jako użytkownik mający dostęp do danych. Zalecana codzienna kopia i kopia przed aktualizacją; retencję i zewnętrzny harmonogram ustala administrator. Sama paczka nie instaluje harmonogramu.

Odtworzenie: zatrzymaj usługę, zachowaj aktualny katalog danych jako osobną kopię, zastąp obie bazy plikami z tej samej kopii. Usuń stare pliki `-wal`/`-shm` tylko w zatrzymanym katalogu docelowym po jego zarchiwizowaniu. Nadaj prawidłowego właściciela. Przed restartem usuń rekordy `sessions` z odtwarzanej `app.sqlite3`, aby wymusić ponowne logowanie. Uruchom usługę, sprawdź integralność SQLite, liczbę firm i kolejkę. SMTP po restarcie jest wstrzymane; wpisz jego konfigurację ponownie. Nie uruchamiaj równocześnie dwóch instancji korzystających z tej samej bazy.

Aktualizacja: wstrzymaj kolejkę → kopia obu baz poza serwer → podmień kod → `docker compose up -d --build` → test odbiorczy. Nie wykonuj `docker compose down -v`, bo usunie wolumen danych. Wycofanie: poprzedni kod i zgodna kopia baz, po przerwie w pracy.

## Zakres i ograniczenia

- Brak automatycznego researchu w tle. Cykle w panelu są przypomnieniami; operator uruchamia badanie w Work.
- Brak gwarancji znalezienia wszystkich firm. Lista kontrolna, źródła i pilotaż służą pomiarowi braków, a nie deklaracji pełności rynku.
- Do 2000 kart firm, import researchu do 10 MB, kopia do 50 MB; historia zwiększa rozmiar. To aplikacja dla małego zespołu, bez testu masowego obciążenia.
- Wysyłka jest jedną wspólną kolejką obsługiwaną przez jedną aktywną kartę. Hasło SMTP trzeba ponownie wprowadzić po restarcie serwera. Obsługa login/hasło przez TLS; brak OAuth-only / Graph, załączników, automatycznych follow-upów, odczytu odpowiedzi i śledzenia otwarć.
- Przyjęcie wiadomości przez SMTP nie potwierdza doręczenia. Po niepewnym wyniku brak automatycznego ponowienia.
- Nie skonfigurowano rzeczywistej oferty TABAL, podpisów, serwera ani poczty — dane te wpisuje firma. Szczegóły: `docs/PILOT_TABAL.md`.

## Testy

Wyniki i zakres: `docs/RAPORT_TESTOW.md`. Podstawowa weryfikacja:

```bash
node --test --test-reporter=tap tests/core.test.js tests/v3.test.js tests/research.test.js
python3 tests/test_mail.py
python3 tests/test_server.py
```

Testy przeglądarkowe uruchamiaj wyłącznie na oddzielnej, pustej instancji testowej — tworzą i zmieniają dane. Instrukcja w raporcie. Nigdy nie kieruj tych testów na bazę firmową.
