# Pilotaż i odpowiedź na uwagi TABAL

Stan przygotowania: 01.10.2026, wydanie 3.0. Pakiet jest gotowy do przekazania administratorowi i odbioru na serwerze. Uruchomienie na serwerze TABAL oraz test realnego SMTP pozostają do wykonania po przekazaniu dostępu i parametrów.

## Odniesienie do maila z 24 września

| Uwaga | Realizacja / sposób sprawdzenia |
|---|---|
| Filtrowanie według strategii | Filtr „Wszystkie strategie” na liście leadów; obejmuje także historyczne researchy. |
| E-mail i telefon pod nazwiskiem | Oba pola w głównej tabeli; brak i niepotwierdzone dane są opisane. |
| Firma znaleziona wcześniej | Komunikat, licznik ponownych odkryć, zachowane konteksty i źródła; bez automatycznego odrzucania. Jedna karta firmy, wiele badań. |
| Województwa | Polska → aktywna lista 16 województw; dla innych krajów obszar wpisuje się ręcznie. |
| Puste pola strategii | Wszystkie merytoryczne warunki mogą pozostać puste; nazwa identyfikuje strategię, liczba wyników pozostaje 1–100. |
| Kryteria i scoring | Osobna zakładka Scoring i źródła: nazwy pięciu warunków biznesowych, wagi, obowiązkowość, próg, aktualność i kary. Warunki zmienia się w strategiach. Na karcie widać każdy składnik. To ocena pięciu grup kryteriów, a nie dowolny edytor formuł. |
| Stalplast, Parkan i kompletność | Lista kontrolna, raport braków, plan przeszukiwania i osobna weryfikacja każdego znanego podmiotu. Nie wpisano fikcyjnych leadów ani nie zadeklarowano znalezienia tych firm bez researchu. |
| Wiadomości i oferta TABAL | Styl doradczy / krótki / techniczny; opisy produktów, wspólna oferta i podpis przenoszą się do promptów i nowych szkiców lokalnych. |
| Brak integracji ChatGPT API | Zachowany ręczny przepływ zadania i JSON. Panel nie wywołuje płatnego modelu ani zewnętrznej integracji ChatGPT. Nie wymaga opłaty 12 tys. zł miesięcznie za API. |

## Zalecany plan i model

Rekomendacja do porównania w pilotażu: **ChatGPT Business dla zespołu**, osobne konta; **Plus do prób jednoosobowych**. W Work wybierz **GPT-6.1 Sol**, jeżeli jest dostępny na danym koncie. Zacznij od ustawienia domyślnego; dla bardziej złożonych badań sprawdź High i porównaj wyniki, czas oraz zużycie. Włącz wyszukiwanie publiczne. Do szerszych badań wykorzystaj Deep research, jeśli dostępny w koncie i workspace. Nie wybieraj modelu wyłącznie po nazwie — kluczowe są działające wyszukiwanie, źródła i kontrola pokrycia.

OpenAI opisuje GPT-6.1 Sol jako wariant do powtarzanej, dłuższej pracy o niższym koszcie niż Astra; wyższy poziom rozumowania może zwiększać czas i zużycie. Astra można porównać na trudniejszej próbie. Nie zmierzono jeszcze, który wariant daje najlepszy wynik dla TABAL.

Stan źródeł sprawdzony 01.10.2026:
- https://learn.chatgpt.com/docs/models
- https://learn.chatgpt.com/docs/pricing
- https://learn.chatgpt.com/docs/web-search

Cena referencyjna z oficjalnej strony: Plus 20 USD/mies.; Business 20 USD/użytk./mies. przy rozliczeniu rocznym lub 25 USD miesięcznie, od 2 użytkowników. Warunki lokalne, podatki i aktualną dostępność sprawdź przy zamówieniu. Limity zależą m.in. od modelu, rozumowania i narzędzi; nie ma uczciwej stałej ceny „za 20 leadów” bez pomiaru. Sam panel nie nalicza tokenów OpenAI API. Osobno pozostają infrastruktura, poczta i ewentualne dodatkowe kredyty używanego planu.

## Jak mierzyć kompletność

1. TABAL przekazuje 10–20 rzeczywistych firm kontrolnych, z domeną i obszarem działania. Dla Stalplast i Parkan potrzebne są dokładne podmioty/domeny, bo nazwy mogą być niejednoznaczne.
2. Badanie A: strategia bez listy znanych firm, aby zmierzyć samodzielne odkrywanie. Ustal obszar, czas i limit 20 wyników; zapisz model i ustawienia.
3. Porównaj wynik z kontrolną listą poza promptem: ile firm odnaleziono, ile pominięto i ile nie pasuje do kryteriów.
4. Badanie B: uzupełnij pole „Lista kontrolna” i sprawdź każdą brakującą firmę osobno. W `research_notes` wymagaj znaleziony / poza kryteriami / niepotwierdzony z uzasadnieniem i źródłami.
5. Powtórz badanie dla innego regionu, synonimów i modelu. Obie próby muszą mieć porównywalny zakres. Wyniki z podaną listą nie są miarą samodzielnego odkrywania.
6. Mierz osobno pokrycie listy kontrolnej, trafność leadów ocenioną przez handlowca, odsetek wiarygodnych kontaktów, czas i zużycie. Pokrycie próbki nie dowodzi kompletności całego rynku.

Propozycja kryterium odbioru do uzgodnienia: wszystkie firmy z listy kontrolnej sprawdzone i każda nieobecność uzasadniona; brak zmyślonych kontaktów; każda ocena i oferta możliwa do prześledzenia do źródła. Cel trafności i koszt jednego zaakceptowanego leada należy ustalić po pierwszej próbie, a nie deklarować bez danych.

## Materiały i decyzje od TABAL

- Adres docelowego serwera, system/administrator, domena i sposób dostępu do HTTPS.
- Lista użytkowników i ról. Hasła tworzy administrator poza korespondencją projektową.
- Dokładna lista kontrolna firm: nazwy, domeny, region, dlaczego powinny zostać znalezione.
- Zatwierdzony opis grup produktów, zastosowań i przewag; publiczne katalogi lub linki źródłowe. Ceny, terminy, certyfikaty tylko jeśli potwierdzone i dopuszczone do użycia.
- 3–5 wzorcowych wiadomości, preferowany ton, długość i cel pierwszego kontaktu.
- Podpis handlowy: osoba, stanowisko, e-mail, telefon; adres nadawcy SMTP może wymagać osobnego uzgodnienia z administratorem poczty.
- Kryteria obowiązkowe i punktowe, wykluczenia, wagi, próg oraz osoba odpowiedzialna za feedback.
- Parametry SMTP: host, port, SSL/TLS lub STARTTLS, metoda uwierzytelniania, dopuszczony nadawca. Hasło wpisywane w panelu; nie w dokumentacji.
- Wybór strategii do prób: np. „DZIAŁ TABLIC”, „DZIAŁ OAL”, „Ogrodzenia aluminiowe”, „Ogrodzenia panelowe”. Nie wymyślono szczegółów dwóch pierwszych grup — należy je dostarczyć i skonfigurować.

## Proponowany harmonogram

Harmonogram zależy od przekazania materiałów i gotowości serwera. To propozycja organizacyjna, nie potwierdzona rezerwacja terminów.

| Termin względem przekazania danych | Działanie |
|---|---|
| Dzień 0 | Przekazanie pakietu 3.0 i listy materiałów. |
| Dni robocze 1–2 | Instalacja przez administratora, konta, HTTPS, migracja i test własnej skrzynki. |
| Dzień 3 | Wspólne ustawienie kryteriów, ofert, podpisów i listy kontrolnej; test odbiorczy. |
| Kolejne 5 dni roboczych | Pilotaż 2–4 strategii, małe partie, feedback handlowców i pomiar kosztu/czasu. |
| Następne 1–2 dni | Omówienie wyników, korekta wag i promptów, decyzja o szerszym użyciu. |

## Scenariusz dla handlowca — około 20 minut bez wysyłki

1. Otwórz panel; wybierz DEMO. Otwórz firmę, sprawdź scoring i źródła. Zmień feedback oraz notatkę.
2. Wróć do Mojego pilota. W Strategiach dodaj profil „Ogrodzenia — lubelskie”; wybierz Polskę i lubelskie. Zostaw niepotrzebne pola puste. Dodaj listę kontrolną uzgodnioną z firmą.
3. W Produktach wprowadź zatwierdzony opis; w Wiadomościach i podpisie wpisz prawdziwy podpis i styl.
4. Przygotuj zadanie w Odkrywaniu, skopiuj do Work z aktywnym wyszukiwaniem, pobierz JSON. To etap ręczny, wymagający konta ChatGPT.
5. Wczytaj JSON, przejrzyj podgląd, zatwierdź. Sprawdź listę kontrolną i uzasadnienia braków w uwagach badania.
6. Na liście filtruj po strategii. Otwórz źródło kontaktu i potwierdź, że adres/telefon faktycznie występuje na stronie.
7. Zaimportuj ponownie wynik w drugim kontekście. Powinna pozostać jedna karta firmy z nowym wpisem researchu i informacją o ponownym znalezieniu.
8. Na karcie przygotuj lokalny szkic lub sprawdź szkic z Work. Zapisz. Nie ustawiaj DO KONTAKTU ani nie uruchamiaj wysyłki w tym ćwiczeniu.
9. Poczekaj na „Zapisano na serwerze”, odśwież stronę i sprawdź dane. Pobierz Kopię JSON.
10. Test prawdziwego SMTP wykonuje administrator wyłącznie na własny adres; dopiero potem operator zatwierdza rzeczywiste partie.
