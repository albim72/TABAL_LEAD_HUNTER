#!/usr/bin/env python3
"""Local smoke test only. Production uses Gunicorn behind nginx, see README."""
from wsgiref.simple_server import make_server
if __name__=='__main__':
 from server.web import application
 print('TABAL Lead Hunter 3.1 BEZ LOGOWANIA: http://127.0.0.1:8765 — zatrzymaj Ctrl+C',flush=True)
 with make_server('127.0.0.1',8765,application) as server:
  try:server.serve_forever()
  except KeyboardInterrupt:pass
