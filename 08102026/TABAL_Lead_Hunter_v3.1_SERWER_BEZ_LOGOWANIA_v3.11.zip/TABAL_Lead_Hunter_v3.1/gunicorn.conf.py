bind = '0.0.0.0:8765'
workers = 1  # One SMTP worker; do not scale processes/replicas.
threads = 8
worker_class = 'gthread'
timeout = 120
graceful_timeout = 70
keepalive = 5
accesslog = '-'
errorlog = '-'
# Do not trust forwarding headers at the application layer.
forwarded_allow_ips = ''
limit_request_line = 4094
limit_request_fields = 50
limit_request_field_size = 8190
control_socket_disable = True
