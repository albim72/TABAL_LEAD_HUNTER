# TABAL Lead Hunter v3.1 — SERWER — BEZ LOGOWANIA

Ta paczka uruchamia dokładnie tę samą aplikację serwerową v3.1, ale bez ekranu logowania i bez kont użytkowników w interfejsie. Po wejściu na adres aplikacji panel otwiera się od razu z uprawnieniami administratora, łącznie z konfiguracją SMTP.

## Szybki start lokalny

**Windows:** uruchom `URUCHOM_WINDOWS.bat`.

**macOS / Linux:** uruchom `URUCHOM_MAC_LINUX.command` albo `python3 serve.py`.

Domyślnie panel: `http://127.0.0.1:8765/`

Nie trzeba wykonywać `manage.py user`, tworzyć loginu ani wpisywać hasła do Lead Huntera. Login i hasło widoczne w zakładce Wysyłka dotyczą wyłącznie zewnętrznej skrzynki SMTP.

## Ważne przy serwerze zdalnym

Wersja bez logowania zakłada, że dostęp do samego adresu aplikacji jest już kontrolowany przez sieć, VPN, reverse proxy lub reguły IP. Każda osoba, która może otworzyć adres Lead Huntera, otrzymuje uprawnienia administratora. Nie wystawiaj tej wersji bezpośrednio do publicznego Internetu bez zewnętrznej ochrony dostępu.

Pozostają aktywne: kontrola hosta, wymóg poprawnego Origin dla zmian, token CSRF, HTTPS dla zdalnego `TABAL_ORIGIN`, walidacja danych, wersjonowanie wspólnej bazy i blokada konfliktów równoczesnego zapisu.
