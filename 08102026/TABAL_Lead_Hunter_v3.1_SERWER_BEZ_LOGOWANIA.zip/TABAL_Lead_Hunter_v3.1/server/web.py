"""WSGI entrypoint. Run one process with threads (one SMTP worker)."""
import atexit,hmac,json,os,secrets,threading
from pathlib import Path
from urllib.parse import urlsplit
from server.storage import Store,Conflict,core,ROOT
from server.mailer import Outbox

DATA=Path(os.environ.get('TABAL_DATA_DIR',str(ROOT/'.runtime')))
ORIGIN=os.environ.get('TABAL_ORIGIN','http://127.0.0.1:8765').rstrip('/')
parsed=urlsplit(ORIGIN)
if parsed.scheme not in ('http','https') or not parsed.netloc or parsed.path:raise RuntimeError('TABAL_ORIGIN: pełny adres bez ścieżki.')
if parsed.scheme!='https' and parsed.hostname not in ('localhost','127.0.0.1'):raise RuntimeError('Dla serwera zdalnego wymagany TABAL_ORIGIN=https://...')
store=Store(DATA/'app.sqlite3');outbox=Outbox(DATA/'mail.sqlite3')
worker=threading.Thread(target=outbox.work,daemon=True);worker.start()
atexit.register(outbox.stop.set)
MAX_BODY=50_000_000

NOLOGIN_CSRF=secrets.token_urlsafe(32)
NOLOGIN_SESSION={'csrf':NOLOGIN_CSRF,'name':'TABAL','role':'admin','token':'nologin-'+NOLOGIN_CSRF}

class HTTPError(Exception):
    def __init__(self,status,message):self.status=status;self.message=message

def application(env,start):
    nonce=secrets.token_urlsafe(24)
    def reply(status,data,ctype='application/json; charset=utf-8',extra=()):
        if isinstance(data,(dict,list)):data=json.dumps(data,ensure_ascii=False)
        if isinstance(data,str):
            if ctype.startswith('text/html'):data=data.replace('<script>','<script nonce="'+nonce+'">')
            data=data.encode()
        headers=[('Content-Type',ctype),('Content-Length',str(len(data))),('Cache-Control','no-store'),('X-Content-Type-Options','nosniff'),('Referrer-Policy','no-referrer'),('X-Frame-Options','DENY'),('Content-Security-Policy',f"default-src 'none'; script-src 'nonce-{nonce}'; style-src 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; form-action 'self'; base-uri 'none'; frame-ancestors 'none'")]+list(extra)
        if parsed.scheme=='https':headers.append(('Strict-Transport-Security','max-age=31536000'))
        start(str(status)+' '+{200:'OK',302:'Found',400:'Bad Request',401:'Unauthorized',403:'Forbidden',404:'Not Found',405:'Method Not Allowed',409:'Conflict',413:'Payload Too Large',500:'Internal Server Error'}[status],headers)
        return [data]
    try:
        if env.get('HTTP_HOST','')!=parsed.netloc:raise HTTPError(403,'Niedozwolony adres serwera.')
        path=env.get('PATH_INFO','/');method=env.get('REQUEST_METHOD','GET')
        if method not in ('GET','POST'):raise HTTPError(405,'Niedozwolona metoda.')
        if path=='/healthz' and method=='GET':return reply(200,{'status':'ok','version':'3.1.0'})
        raw={}
        if method=='POST':
            if env.get('HTTP_ORIGIN')!=ORIGIN:raise HTTPError(403,'Niedozwolone pochodzenie żądania.')
            if env.get('CONTENT_TYPE','').split(';')[0]!='application/json':raise HTTPError(400,'Wymagany JSON.')
            try:size=int(env.get('CONTENT_LENGTH','0'))
            except ValueError:raise HTTPError(400,'Błędny rozmiar.')
            if not 0<size<=MAX_BODY:raise HTTPError(413,'Limit danych: 50 MB.')
            raw=json.loads(env['wsgi.input'].read(size))
            if not isinstance(raw,dict):raise HTTPError(400,'Wymagany obiekt JSON.')
        # Wersja BEZ LOGOWANIA: każda osoba, która ma dostęp do adresu aplikacji,
        # pracuje jako administrator. Zachowujemy kontrolę Host/Origin i token CSRF.
        session=NOLOGIN_SESSION
        if path=='/api/login':raise HTTPError(404,'Logowanie jest wyłączone w tej wersji.')
        if path=='/login' and method=='GET':return reply(302,b'',extra=[('Location','/')])
        if method=='POST' and not hmac.compare_digest(env.get('HTTP_X_TABAL_TOKEN',''),session['csrf']):raise HTTPError(403,'Nieprawidłowy token sesji.')
        if path=='/api/logout' and method=='POST':return reply(200,{'ok':True,'auth':'disabled'})
        if method=='GET':
            if path in ('/','/START.html'):
                runtime={'csrf':session['csrf'],'user':session['name'],'role':session['role']}
                script='window.TABAL_SERVER='+json.dumps(runtime).replace('<','\\u003c')+';window.TABAL_MAIL={token:window.TABAL_SERVER.csrf};'
                return reply(200,(ROOT/'START.html').read_text().replace('/*__MAIL_RUNTIME__*/',script),'text/html; charset=utf-8')
            if path=='/INSTRUKCJA.html':return reply(200,(ROOT/'INSTRUKCJA.html').read_text(),'text/html; charset=utf-8')
            if path=='/api/workspace':
                with store.lock:
                    current=store.get();receipts=core('receipts',state=current['state'],jobs=outbox.jobs())
                    if receipts['changed']:store.put(receipts['state'],current['revision'],'smtp','receipts')
                    return reply(200,store.get())
            if path=='/api/state':return reply(200,outbox.snapshot())
            raise HTTPError(404,'Nie znaleziono zasobu.')
        if path=='/api/workspace':
            if not isinstance(raw.get('revision'),int):raise HTTPError(400,'Brak wersji danych.')
            with store.lock,outbox.lock:
                if outbox.running:raise Conflict('Trwa wysyłka wiadomości. Zapis wstrzymany; zachowaj kopię zmian i odśwież po wysyłce.')
                # Merge accepted receipts before any browser state is committed.
                valid=core('receipts',state=raw.get('state'),jobs=outbox.jobs())['state']
                result=store.put(valid,raw['revision'],session['name'])
                candidates=core('candidates',state=valid)
                allowed={(m['lead_id'],m['to'].lower(),m['subject'].strip(),m['body'].strip()) for m in candidates}
                with outbox.db:
                    for j in outbox.jobs():
                        if j['status']=='queued' and j.get('kind')!='test' and (j['lead_id'],j['to'].lower(),j['subject'],j['body']) not in allowed:
                            outbox.db.execute("UPDATE jobs SET status='cancelled',error='Dane zmieniono na serwerze.' WHERE id=?",(j['id'],))
                return reply(200,result)
        owner=session['token'][:24]+':'+str(raw.get('owner',''))[:60]
        with store.lock,outbox.lock:
            if path=='/api/config':
                if session['role']!='admin':raise HTTPError(403,'SMTP konfiguruje administrator.')
                hosts=os.environ.get('TABAL_SMTP_HOSTS','').split(',')
                if raw.get('host') not in hosts:raise HTTPError(403,'Host SMTP musi zostać dopuszczony w TABAL_SMTP_HOSTS przez administratora serwera.')
                return reply(200,outbox.configure(raw))
            if path=='/api/test':
                if session['role']!='admin':raise HTTPError(403,'Test skrzynki wykonuje administrator.')
                return reply(200,outbox.test_message(owner))
            if path in ('/api/enqueue','/api/sync','/api/control'):
                current=store.get()
                if raw.get('revision')!=current['revision'] and not (path=='/api/control' and raw.get('action')=='pause'):
                    if outbox.owner==owner:outbox.paused=True
                    raise Conflict('Dane na serwerze zmieniły się. Odśwież panel przed dalszą wysyłką.')
                candidates=core('candidates',state=current['state'])
                if path=='/api/enqueue':
                    msgs=raw.get('messages');good={m['lead_id']:m for m in candidates}
                    if not isinstance(msgs,list) or any(m not in candidates for m in msgs):raise HTTPError(400,'Wiadomość nie odpowiada zatwierdzonym danym w bazie.')
                    return reply(200,outbox.enqueue(msgs,owner))
                if path=='/api/sync':
                    allowed=raw.get('allowed',[])
                    if not isinstance(allowed,list):raise HTTPError(400,'Błędna lista wiadomości.')
                    keys={(m['lead_id'],m['to'].lower(),m['subject'].strip(),m['body'].strip()) for m in candidates}
                    checked=[j['id'] for j in outbox.jobs() if j['id'] in allowed and (j.get('kind')=='test' or (j['lead_id'],j['to'].lower(),j['subject'],j['body']) in keys)]
                    return reply(200,outbox.sync(owner,checked,raw.get('writable') is True,raw.get('observed',[])))
                return reply(200,outbox.control(raw.get('action'),raw.get('id',''),owner))
        raise HTTPError(404,'Nieznana operacja.')
    except HTTPError as e:return reply(e.status,{'error':e.message})
    except Conflict as e:return reply(409,{'error':str(e)})
    except (ValueError,TypeError,KeyError) as e:return reply(400,{'error':str(e) if isinstance(e,ValueError) else 'Nieprawidłowe dane.'})
    except Exception:
        import traceback;traceback.print_exc()
        with outbox.lock:outbox.paused=True
        return reply(500,{'error':'Błąd serwera. Zapis lub wysyłka nie zostały potwierdzone; sprawdź stan i log serwera.'})
