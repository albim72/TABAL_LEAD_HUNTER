"""SQLite store, account management, sessions and optimistic revisions."""
import hashlib,hmac,json,secrets,sqlite3,subprocess,threading,time
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
def core(op, **kwargs):
    p=subprocess.run(['node',str(ROOT/'server/validate.cjs')],input=json.dumps(dict(op=op,**kwargs)),text=True,capture_output=True,timeout=20)
    try: result=json.loads(p.stdout)
    except ValueError: raise ValueError('Nie udało się zweryfikować danych. Sprawdź Node.js i log serwera.') from None
    if not result.get('ok'): raise ValueError(result.get('error','Błędne dane.'))
    return result['result']

def password_hash(password,salt=None):
    if not isinstance(password,str) or not 12<=len(password)<=1024: raise ValueError('Hasło musi mieć 12–1024 znaków.')
    salt=salt or secrets.token_hex(16)
    return salt+':'+hashlib.pbkdf2_hmac('sha256',password.encode(),salt.encode(),600000).hex()
def verify(password,encoded):
    try:return hmac.compare_digest(password_hash(password,encoded.split(':')[0]),encoded)
    except (ValueError,AttributeError):return False

class Conflict(Exception):pass
class Store:
    def __init__(self,path):
        Path(path).parent.mkdir(parents=True,exist_ok=True)
        self.lock=threading.RLock();self.path=Path(path)
        self.db=sqlite3.connect(path,check_same_thread=False,timeout=30)
        self.db.row_factory=sqlite3.Row
        self.db.execute('PRAGMA journal_mode=WAL');self.db.execute('PRAGMA synchronous=FULL')
        self.db.executescript('''CREATE TABLE IF NOT EXISTS workspace(id INTEGER PRIMARY KEY CHECK(id=1),revision INTEGER NOT NULL,payload TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS users(name TEXT PRIMARY KEY,password TEXT NOT NULL,role TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY,name TEXT NOT NULL,csrf TEXT NOT NULL,expires REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS changes(id INTEGER PRIMARY KEY,at REAL,user TEXT,revision INTEGER,action TEXT);
        CREATE TABLE IF NOT EXISTS attempts(ip TEXT PRIMARY KEY,count INTEGER,until REAL);''')
        with self.db:
            if not self.db.execute('SELECT 1 FROM workspace').fetchone():self.db.execute('INSERT INTO workspace VALUES(1,0,?)',(json.dumps(core('initial')),))
    def add_user(self,name,password,role):
        import re
        if not re.fullmatch(r'[a-zA-Z0-9_.@-]{3,80}',name) or role not in ('admin','editor'):raise ValueError('Login 3–80 znaków: litery, cyfry, _.@-; rola admin/editor.')
        encoded=password_hash(password)
        with self.lock,self.db:
            self.db.execute('INSERT INTO users VALUES(?,?,?) ON CONFLICT(name) DO UPDATE SET password=excluded.password,role=excluded.role',(name,encoded,role))
            self.db.execute('DELETE FROM sessions WHERE name=?',(name,))
    def delete_user(self,name):
        with self.lock,self.db:
            self.db.execute('DELETE FROM sessions WHERE name=?',(name,));self.db.execute('DELETE FROM users WHERE name=?',(name,))
    def login(self,name,password,ip):
        with self.lock:
            now=time.time();a=self.db.execute('SELECT * FROM attempts WHERE ip=?',(ip,)).fetchone()
            if a and a['until']>now and a['count']>=8:raise ValueError('Zbyt wiele prób. Spróbuj ponownie za 15 minut.')
            row=self.db.execute('SELECT * FROM users WHERE name=?',(name,)).fetchone()
            valid=verify(password,row['password'] if row else '0'*32+':'+'0'*64)
            with self.db:
                self.db.execute('DELETE FROM sessions WHERE expires<?',(now,))
                self.db.execute('DELETE FROM attempts WHERE until<?',(now,))
                if not valid:
                    self.db.execute('INSERT INTO attempts VALUES(?,1,?) ON CONFLICT(ip) DO UPDATE SET count=count+1',(ip,now+900))
                    raise_login=True
                else:
                    raise_login=False;self.db.execute('DELETE FROM attempts WHERE ip=?',(ip,))
                    token=secrets.token_urlsafe(32);csrf=secrets.token_urlsafe(32)
                    self.db.execute('INSERT INTO sessions VALUES(?,?,?,?)',(hashlib.sha256(token.encode()).hexdigest(),name,csrf,now+8*3600))
            if raise_login:raise ValueError('Nieprawidłowy login lub hasło.')
            return token
    def session(self,token):
        with self.lock:
            row=self.db.execute('SELECT s.*,u.role FROM sessions s JOIN users u USING(name) WHERE token=? AND expires>?',(hashlib.sha256(token.encode()).hexdigest(),time.time())).fetchone()
            return dict(row) if row else None
    def logout(self,token):
        with self.lock,self.db:self.db.execute('DELETE FROM sessions WHERE token=?',(hashlib.sha256(token.encode()).hexdigest(),))
    def get(self):
        with self.lock:
            row=self.db.execute('SELECT * FROM workspace WHERE id=1').fetchone();return dict(revision=row['revision'],state=json.loads(row['payload']))
    def put(self,state,revision,user,action='save'):
        validated=core('validate',state=state)
        with self.lock,self.db:
            result=self.db.execute('UPDATE workspace SET revision=revision+1,payload=? WHERE id=1 AND revision=?',(json.dumps(validated,ensure_ascii=False),revision))
            if not result.rowcount:raise Conflict('Inny użytkownik zapisał zmiany. Pobierz kopię swoich zmian i odśwież stronę; zapis nie nadpisał pracy drugiej osoby.')
            self.db.execute('INSERT INTO changes(at,user,revision,action) VALUES(?,?,?,?)',(time.time(),user,revision+1,action))
        return dict(revision=revision+1)
    def backup(self,target):
        with self.lock,sqlite3.connect(target) as dest:self.db.backup(dest)
