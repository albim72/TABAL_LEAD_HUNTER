from pathlib import Path
import hashlib,zipfile
root=Path(__file__).resolve().parents[1]
exclude={'.runtime','.env','.venv','node_modules','__pycache__','.git'}
files=[p for p in root.rglob('*') if p.is_file() and not set(p.relative_to(root).parts)&exclude and p.suffix not in ('.pyc','.zip') and p.name!='SHA256SUMS.txt']
manifest=root/'SHA256SUMS.txt'
manifest.write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(root).as_posix()+'\n' for p in sorted(files)))
output=root.parent/'TABAL_Lead_Hunter_v3.1_SERWER_BEZ_LOGOWANIA.zip'
with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(files+[manifest]):z.write(p,root.name+'/'+p.relative_to(root).as_posix())
print(output)
