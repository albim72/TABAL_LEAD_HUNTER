#!/usr/bin/env python3
import argparse,getpass,os,sqlite3,shutil,json
from pathlib import Path
from datetime import datetime,timezone
from server.storage import Store,ROOT
p=argparse.ArgumentParser(description='Administracja TABAL Lead Hunter 3.0')
p.add_argument('--data-dir',default=os.environ.get('TABAL_DATA_DIR',str(ROOT/'.runtime')))
sub=p.add_subparsers(dest='command',required=True)
u=sub.add_parser('user');u.add_argument('name');u.add_argument('--role',choices=['admin','editor'],default='editor')
d=sub.add_parser('delete-user');d.add_argument('name')
sub.add_parser('users');b=sub.add_parser('backup');b.add_argument('directory')
a=p.parse_args();path=Path(a.data_dir);s=Store(path/'app.sqlite3')
if a.command=='user':
 password=getpass.getpass('Hasło (minimum 12 znaków): ')
 if password!=getpass.getpass('Powtórz hasło: '):raise SystemExit('Hasła różnią się.')
 s.add_user(a.name,password,a.role);print('Konto zapisane. Poprzednie sesje unieważniono.')
elif a.command=='delete-user':s.delete_user(a.name);print('Konto i sesje usunięte.')
elif a.command=='users':
 for r in s.db.execute('SELECT name,role FROM users ORDER BY name'):print(r['name'],r['role'])
elif a.command=='backup':
 dest=Path(a.directory)/datetime.now(timezone.utc).strftime('tabal_%Y%m%d_%H%M%S_%f');dest.mkdir(parents=True,mode=0o700)
 s.backup(dest/'app.sqlite3')
 if (path/'mail.sqlite3').exists():
  with sqlite3.connect(path/'mail.sqlite3') as src,sqlite3.connect(dest/'mail.sqlite3') as dst:src.backup(dst)
 (dest/'VERSION.txt').write_text('3.0.0\nKopia baz SQLite; przy aktywnej wysyłce możliwa różnica czasowa między bazami.\n')
 print(dest)
