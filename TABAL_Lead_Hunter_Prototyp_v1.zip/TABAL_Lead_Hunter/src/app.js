(function(){
 'use strict';
 const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
 const h=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const pct=x=>x===null?'—':x+'%';
 const labels={sample:'Próbka publiczna',demo:'DEMO',pilot:'Mój pilot'};
 const feedbackLabel={pending:'Do oceny',yes:'Warty kontaktu',no:'Odrzucony'};
 const enrichLabel={NOT_ATTEMPTED:'Nie sprawdzono',MISSING:'Brak danych',PARTIAL:'Częściowe dane',COMPLETE:'Osoba i kanał'};
 const key=mode=>'tabal-lead-hunter-v1-'+mode;
 let mode='sample', page='leads', filter='',search='',state, timer, selected=null;
 let memoryOnly=false;
 function demoRaw(){
   const raw=LH.clone(window.LH_DEMO); const now=LH.today();
   const shift=(n)=>new Date(Date.parse(now)+n*86400000).toISOString().slice(0,10);
   raw.forEach((l,i)=>{l.detected_at=now;l.signal_date=i===7?shift(-400):shift(-(i+1));if(l.deadline)l.deadline=shift(12);if(l.contact.verified_at)l.contact.verified_at=now;});
   return raw;
 }
 function fresh(){
   const s=LH.makeState(mode==='sample'?LH_SAMPLE:mode==='demo'?demoRaw():[],mode);
   if(mode==='demo')s.config.source_hosts.push('example.com');
   return s;
 }
 function storageWarning(message){$('#storage-warning').hidden=false;$('#storage-warning').textContent=message;}
 function load(){
   memoryOnly=false;$('#storage-warning').hidden=true;
   try {
     const raw=localStorage.getItem(key(mode));
     state=raw?LH.restore(raw,mode):fresh();
   }catch(e){
     state=fresh(); memoryOnly=true;
     storageWarning('Nie można odczytać zapisanej sesji. Dane w pamięci pozostają oddzielne; poprzedni zapis nie zostanie nadpisany. Pobierz kopię i otwórz panel w zwykłym oknie przeglądarki. '+e.message);
   }
 }
 function save(){
   state.updated_at=LH.timestamp();
   if(memoryOnly)return;
   try{localStorage.setItem(key(mode),LH.backup(state));}
   catch{memoryOnly=true;storageWarning('Przeglądarka nie pozwala zapisać danych lub pamięć jest pełna. Zmiany są tylko w bieżącej karcie. Pobierz kopię JSON przed jej zamknięciem.');}
 }
 function toast(message,error=false){clearTimeout(timer);$('#toast').textContent=message;$('#toast').className='toast'+(error?' error':'');$('#toast').hidden=false;timer=setTimeout(()=>$('#toast').hidden=true,error?10000:5500);}
 function download(name,text,type='application/json'){
   const url=URL.createObjectURL(new Blob([text],{type}));const a=document.createElement('a');a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1500);
 }
 async function copy(text){
   try{await navigator.clipboard.writeText(text);toast('Skopiowano do schowka.');}
   catch{const area=document.createElement('textarea');area.value=text;area.style.cssText='position:fixed;top:0;left:0';const parent=$('#detail').open?$('#detail'):document.body;parent.append(area);area.focus();area.select();const ok=document.execCommand('copy');area.remove();if(ok)toast('Skopiowano do schowka.');else{download('tekst-do-skopiowania.txt',text,'text/plain');toast('Schowek niedostępny. Pobrano plik z tekstem.');}}
 }
 function sourceLink(url,label='Otwórz źródło ↗'){return LH.safeUrl(url)?`<a class="source-link" target="_blank" rel="noopener noreferrer" href="${h(LH.safeUrl(url))}">${h(label)}</a>`:'<span class="muted">Brak źródła</span>';}
 function banner(){
   if(mode==='demo')return '<div class="notice demo"><strong>DEMO · dane fikcyjne.</strong> Ten zbiór służy do przećwiczenia procesu. Jego wyniki nie wchodzą do rzeczywistego pilota.</div>';
   if(mode==='sample')return '<div class="notice"><strong>Próbka z publicznych źródeł · stan 13.09.2026.</strong> Cztery sygnały do przetestowania kwalifikacji. Potrzeby zakupowe i osoby decyzyjne wymagają potwierdzenia. To nie jest pomiar skuteczności pilota.</div>';
   return '<div class="notice"><strong>Twój pilot.</strong> Odkrywaj sygnały w Work i importuj wyniki tutaj. Panel zapisuje dane w tej przeglądarce. Po każdej sesji pobierz kopię JSON.</div>';
 }
 function heading(eyebrow,title,subtitle,actions=''){return `<div class="page-heading"><div><div class="eyebrow">${h(eyebrow)}</div><h1>${h(title)}</h1><p class="lead-in">${h(subtitle)}</p></div><div class="actions">${actions}</div></div>`;}
 function metricsCards(m){return `<div class="stats"><div class="stat"><span class="label">Zebrane sygnały</span><span class="value">${m.total}</span><span class="foot">${m.assessed} ocenionych w panelu</span></div><div class="stat"><span class="label">Spełniają ICP</span><span class="value">${m.qualified}</span><span class="foot">Próg ${state.config.threshold}/100 i kryteria obowiązkowe</span></div><div class="stat featured"><span class="label">Gotowe do decyzji o kontakcie</span><span class="value">${m.actionable}</span><span class="foot">ICP + źródło kontaktu + akceptacja</span></div><div class="stat"><span class="label">Zapisane pierwsze kontakty</span><span class="value">${m.contacted}</span><span class="foot">Działania potwierdzone ręcznie</span></div></div>`;}
 function row(l){
   const s=LH.score(l,state.config);const status=!l.processed?'Oczekuje oceny':s.qualified?'Spełnia ICP':'Wstrzymany';
   const co=s.contact;const contact=co.email?'E-mail ze źródła':co.phone?'Telefon ze źródła':'Brak danych';
   return `<tr class="lead-row"><td><button class="company-btn" data-open="${h(l.id)}">${h(l.company)}</button><div class="project">${h(l.project)}</div><div class="tiny muted">${h(l.region||'brak regionu')} · ${h(l.signal_date||'brak daty')}</div></td><td><div class="score">${l.processed?s.points:'—'}<span>/100</span></div><div class="score-bar"><i style="width:${l.processed?s.points:0}%"></i></div></td><td><span class="tag ${!l.processed?'gray':s.qualified?'green':'amber'}">${status}</span><div class="tiny muted" style="margin-top:6px">${h(LH.SIGNALS[l.signal_type])}</div></td><td><span class="tag ${co.reachable?'green':'gray'}">${contact}</span><div class="tiny muted" style="margin-top:6px">${h(co.person?l.contact.name:'Osoba: brak danych')}</div></td><td><span class="tag gray">${h(l.status)}</span><div class="tiny muted" style="margin-top:6px">${h(l.do_not_contact?'Nie kontaktować':feedbackLabel[l.feedback])}</div></td><td><button class="small" data-open="${h(l.id)}" aria-label="Otwórz kartę ${h(l.company)}">Karta ↗</button></td></tr>`;
 }
 function visibleLeads(){
   return state.leads.filter(l=>{
     const s=LH.score(l,state.config);
     return (!search||LH.norm([l.company,l.project,l.region,l.evidence].join(' ')).includes(LH.norm(search)))&&(!filter||(filter==='qualified'&&l.processed&&s.qualified)||(filter==='hold'&&l.processed&&!s.qualified)||(filter==='ready'&&l.processed&&s.actionable)||(filter==='new'&&!l.processed));
   }).sort((a,b)=>LH.score(b,state.config).points-LH.score(a,state.config).points);
 }
 function renderRows(){
   const rows=visibleLeads();$('#lead-rows').innerHTML=rows.map(row).join('')||'<tr><td colspan="6"><div class="empty">Brak rekordów spełniających filtry.</div></td></tr>';$('#row-count').textContent=`${rows.length} z ${state.leads.length} rekordów`;
 }
 function leadsPage(){
   const m=LH.metrics(state.leads,state.config);
   $('#view').innerHTML=heading('01 / Rejestr sprzedażowy','Od sygnału do rozmowy.','Każdy lead z kontekstem, oceną i następnym krokiem.',`<button data-action="import">Importuj z Work</button><button class="primary" data-action="process" ${state.leads.length?'':'disabled'}>Oceń wszystkie →</button>`)+banner()+metricsCards(m)+
    `<div class="pipeline">${LH.STAGES.map(s=>`<span class="stage-chip">${s}<b>${state.leads.filter(l=>l.status===s).length}</b></span>`).join('')}</div><div class="toolbar"><div class="filters"><input id="search" aria-label="Szukaj leada" placeholder="Szukaj firmy, projektu, regionu…" value="${h(search)}"><select id="filter" aria-label="Filtr leadów"><option value="">Wszystkie leady</option><option value="new">Oczekujące oceny</option><option value="qualified">Spełniają ICP</option><option value="hold">Wstrzymane</option><option value="ready">Gotowe do kontaktu</option></select></div><div class="actions"><button class="small" data-action="add">+ Dodaj sygnał</button><button class="small" data-action="csv">Eksport CSV</button><button class="small" data-action="backup">Kopia JSON</button></div></div>`+
    (state.leads.length?'<div class="table-wrap"><table><thead><tr><th>Firma i inwestycja</th><th>Ocena</th><th>Kwalifikacja</th><th>Kontakt</th><th>Proces</th><th></th></tr></thead><tbody id="lead-rows"></tbody></table></div><div class="table-footer"><span id="row-count"></span><span>Scoring regułowy · kwalifikacja do sprawdzenia przez TABAL</span></div>':'<div class="panel empty"><div class="eyebrow">Gotowy na pierwszy cykl</div><h2>Dodaj pierwsze sygnały.</h2><p>W zakładce Odkrywanie skopiuj zadanie do Work. Zaimportuj otrzymany plik JSON lub dodaj własny sygnał.</p><button class="primary" data-page="discover">Przygotuj zadanie →</button></div>');
   $('#filter').value=filter;
   $('#search').addEventListener('input',e=>{search=e.target.value;if(state.leads.length)renderRows();});
   $('#filter').addEventListener('change',e=>{filter=e.target.value;if(state.leads.length)renderRows();});
   if(state.leads.length)renderRows();
 }
 function workTask(){
   return window.LH_WORKFLOW+'\n\nAKTUALNY PROFIL Z PANELU\n'+JSON.stringify(state.config,null,2)+
    '\n\nPOMIŃ ISTNIEJĄCE PARY FIRMA / PROJEKT\n'+JSON.stringify(state.leads.map(l=>({company:l.company,domain:l.domain,project:l.project,source_url:l.source_url})),null,2)+
    '\n\nWYKONAJ TERAZ\nZbadaj do 10 nowych sygnałów zgodnych z profilem. Użyj bieżącej daty '+LH.today()+'. Zwróć plik leady_work.json według kontraktu oraz krótką listę ograniczeń. Nie wysyłaj wiadomości. Jeżeli w tym środowisku brakuje wyszukiwania, powiedz o tym i nie twórz wyników.';
 }
 function discoverPage(){
   $('#view').innerHTML=heading('02 / Discover → Qualify → Enrich','Uruchom kolejny research.','Wyszukiwanie wykonuje agent w Work. Tutaj przygotujesz zadanie i odbierzesz wyniki.')+
    `<div class="grid2"><section class="panel"><h2>Zadanie z Twoim profilem</h2><p>Instrukcja zawiera listę dozwolonych źródeł, zasady dowodów oraz istniejące projekty, które agent ma pominąć.</p><div class="steps"><div class="step"><div><strong>Skopiuj zadanie</strong><p>Uwzględnia ustawienia z zakładki Profil i źródła.</p></div></div><div class="step"><div><strong>Wklej je w nowej rozmowie Work</strong><p>Agent wyszukuje publiczne sygnały i sprawdza dostępne źródła. Dostępność narzędzi zależy od środowiska.</p></div></div><div class="step"><div><strong>Zaimportuj wynik JSON</strong><p>Panel sprawdzi format, pominie duplikaty i wyliczy ocenę. Import nie nadpisuje istniejących kart.</p></div></div></div><div class="actions"><button class="primary" data-action="copy-work">Kopiuj zadanie do Work</button><button data-action="download-work">Pobierz zadanie .txt</button></div><hr class="divider"><span class="badge-outline">Bez kluczy API w panelu</span><p class="tiny">Ten plik HTML nie przeszukuje internetu w tle. Pełny cykl obejmuje wykonanie zadania w Work i import jego wyniku. Cykliczność można dołączyć po sprawdzeniu dostępnych integracji.</p></section>
    <section class="panel"><h2>Odbierz wyniki</h2><p>Wczytaj plik lub wklej JSON. Własne dane trafiają do aktualnie wybranego zbioru. Do pracy wybierz „Mój pilot”.</p><button data-action="import">Wybierz plik JSON</button><form id="json-form" class="form" style="margin-top:18px"><label>Wynik z Work<textarea id="json-text" rows="9" placeholder='{"schema_version":1,"leads":[…]}'></textarea></label><button class="primary" type="submit">Importuj wklejone dane</button></form><div id="import-result"></div><hr class="divider"><h3>Przykładowe kierunki wyszukiwania</h3><p class="tiny">Lista jest propozycją zapytań; źródła wyników nadal muszą być dopuszczone w profilu.</p><ul class="tiny"><li>site:panattonieurope.com rozpoczęcie budowy ${h(state.config.country)}</li><li>site:depenbrock.pl nowa inwestycja</li><li>site:ctp.eu Poland construction</li><li>site:ezamowienia.gov.pl ogrodzenie brama</li></ul><details><summary>Podgląd instrukcji</summary><pre class="code">${h(workTask())}</pre></details></section></div>`;
   $('#json-form').onsubmit=e=>{e.preventDefault();doImport($('#json-text').value);};
 }
 function doImport(text){
   try {
     const r=LH.merge(state.leads,LH.parseImport(text),mode);state.leads=r.leads;save();
     const msg=`Dodano: ${r.added}. Duplikaty pominięte: ${r.duplicates}. Błędne rekordy: ${r.errors.length}.`;
     if(page==='discover'){
       $('#import-result').innerHTML=`<div class="result-box">${h(msg)}${r.errors.length?'<ul>'+r.errors.map(e=>`<li>Rekord ${e.row}: ${h(e.error)}</li>`).join('')+'</ul>':''}</div>`;
     }else render();
     toast(msg+(r.errors.length?' '+r.errors.slice(0,3).map(e=>`Rekord ${e.row}: ${e.error}`).join(' '):''),r.errors.length>0);
   }catch(e){toast(e.message,true);}
 }
 function reportPage(){
   const m=LH.metrics(state.leads,state.config,LH.today(),state.cycles);
   const decision=mode!=='pilot'?'Zbiór testowy — bez decyzji biznesowej':m.feedback_cycles<3?'CONTINUE — zbierz 3 cykle feedbacku':'Dane do decyzji TABAL — omów GO / CONTINUE / STOP';
   const metric=(label,value,note)=>`<div class="panel"><span class="eyebrow">${h(label)}</span><h2 style="font-size:31px;margin:9px 0">${h(value)}</h2><span class="tiny muted">${h(note)}</span></div>`;
   $('#view').innerHTML=heading('03 / Wyniki procesu','Mierz lejek, oceniaj jakość.','Każdy wskaźnik pokazuje licznik i właściwy mianownik.',`<button data-action="report-file">Pobierz raport .md</button>`)+banner()+
    `<div class="report-grid">${metric('Signal yield',m.signal_yield===null?'—':m.signal_yield,'Nowe sygnały / zakończony cykl researchu; ręczny rejestr')}${metric('Qualification rate',pct(m.qualification_rate),`${m.qualified} kwalifikowanych / ${m.assessed} ocenionych`)}${metric('Enrichment coverage',pct(m.enrichment_rate),`${state.leads.filter(l=>LH.contacts(l,state.config).reachable).length} z kontaktem / ${m.total} sygnałów`)}${metric('Actionable rate',pct(m.actionable_rate),`${m.accepted} akceptacji TABAL / ${m.reviewed} ocen handlowca`)}${metric('Contact rate',pct(m.contact_rate),`${m.contacted} kontaktów / ${m.total} sygnałów`)}${metric('Human effort',m.human_minutes+' min','Czas operatora wpisany w rejestrze cykli')}</div>
    <div class="grid2"><section class="panel"><h2>Od kontaktu do okazji</h2><div class="metric-row"><span>Reply rate — odpowiedzi / kontakty</span><strong>${m.replied} / ${m.contacted} (${pct(m.reply_rate)})</strong></div><div class="metric-row"><span>Opportunity rate — okazje / kontakty</span><strong>${m.opportunities} / ${m.contacted} (${pct(m.opportunity_rate)})</strong></div><div class="metric-row"><span>Kontakt e-mail / telefon / osoba</span><strong>${m.email_count} / ${m.phone_count} / ${m.person_count}</strong></div><div class="metric-row"><span>Gotowe operacyjnie do kontaktu</span><strong>${m.actionable}</strong></div><h3>${h(decision)}</h3><p class="tiny">Prototyp nie podejmuje automatycznej decyzji inwestycyjnej. Próg opłacalności, koszt pozyskania i wymagana jakość są do uzgodnienia z TABAL. Dane DEMO i próbka nie dowodzą skuteczności rynkowej.</p><h3>Rejestr cykli (${state.cycles.length})</h3>${state.cycles.length?'<ul class="audit">'+state.cycles.map(c=>`<li><time>${h(c.date)} · ${h(c.kind)}</time>${h(c.note)} · ${c.minutes} min · ${c.signals} nowych sygnałów</li>`).join('')+'</ul>':'<p class="tiny">Nie zapisano jeszcze cykli.</p>'}</section>
    <section class="panel"><h2>Zapisz zakończony cykl</h2><form id="cycle-form" class="form"><div class="row"><label>Typ cyklu<select name="kind"><option value="research">Research</option><option value="feedback">Feedback z TABAL</option></select></label><label>Data<input type="date" name="date" required max="${LH.today()}" value="${LH.today()}"></label></div><div class="row"><label>Czas operatora w minutach<input type="number" name="minutes" min="0" max="10080" required value="15"></label><label>Nowe unikalne sygnały<input type="number" name="signals" min="0" max="1000" required value="0"></label></div><label>Wnioski z cyklu<textarea name="note" required placeholder="Co zaakceptowano, co odrzucono, co zmienić w profilu?"></textarea></label><button type="submit" class="primary">Zapisz cykl</button></form></section></div>`;
   $('#cycle-form').onsubmit=e=>{e.preventDefault();const f=new FormData(e.target);const item={date:f.get('date'),kind:f.get('kind'),minutes:Number(f.get('minutes')),signals:Number(f.get('signals')),note:String(f.get('note')).trim()};if(!LH.validDate(item.date)||LH.age(item.date)<0||!item.note||!Number.isFinite(item.minutes)||item.minutes<0||!Number.isInteger(item.signals)||item.signals<0)return toast('Sprawdź dane cyklu.',true);state.cycles.push(item);save();render();toast('Zapisano cykl.');};
 }
 function settingsPage(){
   const c=state.config;
   $('#view').innerHTML=heading('04 / Jeden ICP na start','Zdefiniuj dobrego klienta.','Profil startowy jest hipotezą do kalibracji podczas spotkania z TABAL.')+
    `<form id="settings-form" class="form"><div class="grid2"><section class="panel"><h2>Profil klienta</h2><div class="form"><label>Nazwa profilu<input name="name" value="${h(c.name)}" required></label><fieldset><legend>Segmenty jednego profilu zakupowego</legend>${Object.entries(LH.SEGMENTS).map(([k,v])=>`<label class="check"><input type="checkbox" name="segments" value="${k}" ${c.segments.includes(k)?'checked':''}><span>${v}</span></label>`).join('')}</fieldset><div class="row"><label>Kraj (kod)<input name="country" maxlength="2" value="${h(c.country)}" required></label><label>Produkt<select name="product"><option>Techfence</option><option>Alufence</option></select></label></div><label>Województwa — po przecinku<input name="regions" value="${h(c.regions.join(', '))}" placeholder="Puste = cały kraj"><small>Wymagane dokładne nazwy, np. lubelskie, mazowieckie.</small></label><div class="row"><label>Próg kwalifikacji (1–100)<input type="number" name="threshold" value="${c.threshold}" min="1" max="100" required></label><label>Maks. wiek sygnału (dni)<input type="number" name="max_age_days" value="${c.max_age_days}" min="1" max="730" required></label></div><label>Ważność sprawdzenia kontaktu (dni)<input type="number" name="contact_max_age_days" value="${c.contact_max_age_days}" min="1" max="730" required></label></div></section>
    <section class="panel"><h2>Źródła i pierwszy kontakt</h2><div class="form"><label>Dozwolone domeny — po jednej w wierszu<textarea name="source_hosts" rows="6" required>${h(c.source_hosts.join('\n'))}</textarea><small>Lista kontroluje kwalifikację dowodów. Dodanie domeny nie uruchamia pobierania jej treści.</small></label><label>Wykluczone firmy — domeny po jednej w wierszu<textarea name="excluded_domains" rows="2">${h(c.excluded_domains.join('\n'))}</textarea></label><label>Podpis w projekcie wiadomości<input name="sender" value="${h(c.sender)}" required></label><label class="check"><input name="icp_approved" type="checkbox" ${c.icp_approved?'checked':''}><span>TABAL zatwierdził ten profil klienta.</span></label><label class="check"><input name="contact_policy" type="checkbox" ${c.contact_policy?'checked':''}><span>TABAL ustalił zasady pierwszego kontaktu i dopuszczony kanał.</span></label><small>Panel przygotowuje tekst i zapisuje ręcznie wykonane działania. Nie wysyła wiadomości. Zmiana profilu zeruje wcześniejsze zatwierdzenie ICP.</small></div><hr class="divider"><div class="actions"><button class="primary" type="submit">Zapisz profil i przelicz</button><button type="button" data-action="config-file">Pobierz profil JSON</button></div></section></div></form><section class="panel danger-zone"><h2>Kopia sesji</h2><p>Pełna kopia przenosi leady, statusy, historię, profil i cykle. Dane pozostają oddzielne dla próbki, DEMO i pilota.</p><div class="actions"><button data-action="backup">Pobierz kopię JSON</button><button data-action="restore">Przywróć kopię</button><button class="danger" data-action="reset">Wyzeruj ten zbiór</button></div></section>`;
   $('#settings-form [name=product]').value=c.product;
   $('#settings-form').onsubmit=e=>{
     e.preventDefault();try{
       const f=new FormData(e.target),old=LH.clone(c);const next={};
       for(const k of ['name','country','product','sender','threshold','max_age_days','contact_max_age_days'])next[k]=f.get(k);
       next.segments=f.getAll('segments');next.regions=String(f.get('regions')).split(',').map(x=>x.trim()).filter(Boolean);
       for(const k of ['source_hosts','excluded_domains'])next[k]=String(f.get(k)).split(/\r?\n/).map(x=>LH.domain(x.trim())).filter(Boolean);
       next.icp_approved=f.has('icp_approved');next.contact_policy=f.has('contact_policy');
       const nc=LH.config(next);
       const changed=['name','country','product','regions','segments','threshold','max_age_days','contact_max_age_days','source_hosts','excluded_domains'].some(k=>JSON.stringify(old[k])!==JSON.stringify(nc[k]));
       if(changed)nc.icp_approved=false;
       state.config=nc;state.leads=state.leads.map(l=>l.processed?LH.processLead(l,nc):l);save();render();toast(changed?'Profil zmieniony i przeliczony. Zatwierdź nowy ICP po jego uzgodnieniu.':'Zapisano ustawienia.');
     }catch(err){toast(err.message,true);}
   };
 }
 function helpPage(){
   $('#view').innerHTML=heading('05 / Start w kilka minut','Na jutrzejsze spotkanie.','Panel działa po otwarciu pliku START.html. Nie wymaga instalacji ani klucza API.')+
    `<section class="panel instructions"><h2>Pokaz w 7 minut</h2><ol><li>Wybierz <strong>Próbka publiczna</strong> i kliknij <strong>Oceń wszystkie</strong>. Zobacz źródła, oceny i odrzucone sygnały.</li><li>Otwórz kartę Depenbrock. Pokaż dowód rozpoczęcia budowy, kontakt ogólny i hipotezę do rozmowy.</li><li>Pokaż CTP Iłowa: informacja o najmie nie potwierdza zakupu ogrodzenia.</li><li>Wybierz <strong>DEMO</strong>, oceń rekordy i zaakceptuj Northline. W Profil i źródła zaznacz zatwierdzenia wyłącznie dla demonstracyjnej sesji. Zapisz fikcyjny kontakt, odpowiedź i okazję.</li><li>Otwórz Raport pilota. Pokaż, jak statusy i feedback zmieniają wskaźniki.</li><li>W Odkrywanie skopiuj zadanie do Work. Wynik rzeczywistego researchu zaimportuj do <strong>Mój pilot</strong>.</li><li>Uzgodnij z TABAL ICP, region, źródła i kanał. Pobierz kopię JSON po sesji.</li></ol>
    <h2>Jak działa proces</h2><p>Work wykonuje research i analizę treści. Panel waliduje rekordy, liczy jawny scoring, przygotowuje szablon wiadomości z kontekstem inwestycji oraz prowadzi rejestr. Przeniesienie wyniku Work do panelu jest ręczne. W prototypie nie ma serwera, integracji ze skrzynką ani automatycznej wysyłki.</p>
    <h2>Jak interpretować ocenę</h2><p>25 pkt: ICP, 10: region, 25: sygnał, 15: aktualność, 15: produkt, 10: źródło. Duży wynik nie zastępuje kryteriów obowiązkowych. Nieaktualny termin, brak dowodu, sam najem lub ukończenie obiektu wstrzymują leada. Ocena jest rankingiem regułowym, a nie prawdopodobieństwem sprzedaży.</p>
    <h2>Dane i kopie</h2><p>Zapis odbywa się w pamięci tej przeglądarki. Tryb prywatny, wyczyszczenie danych lub przeniesienie pliku może zmienić dostępność sesji. Eksport CSV służy do Excela / CRM; pełny eksport JSON służy do odtworzenia sesji. Nie ma synchronizacji między komputerami.</p>
    <h2>Pierwszy kontakt</h2><p>Treść jest projektem do redakcji i zatwierdzenia. Źródło danych kontaktowych nie potwierdza zgody na komunikację. Uzgodnijcie zasady w TABAL. Status CONTACTED zapisuj dopiero po faktycznie wykonanym kontakcie, a nie po skopiowaniu tekstu.</p>
    <h2>Co dalej</h2><p>Wykonaj trzy cykle feedbacku na własnych przykładach dobrych i złych leadów. Zapisuj czas operatora i rzeczywiste działania. Decyzję GO / CONTINUE / STOP podejmijcie na wynikach pilota, zgodnie z ofertą z 28.08.2026.</p></section>`;
 }
 function openModal(title,body,eyebrow='Karta leada'){
   const el=$('#detail');el.innerHTML=`<div class="modal-header"><div><div class="eyebrow">${h(eyebrow)}</div><h2 id="modal-title">${h(title)}</h2></div><button class="close" data-action="close" aria-label="Zamknij">×</button></div><div class="modal-body">${body}</div>`;if(!el.open)el.showModal();
 }
 function openLead(id){
   selected=id;const l=state.leads.find(l=>l.id===id);if(!l)return;const s=LH.score(l,state.config),co=s.contact,d=LH.draft(l,state.config);
   const next=LH.STAGES[LH.STAGES.indexOf(l.status)+1];
   openModal(l.company,`<p class="lead-in">${h(l.project)}</p><div class="pipeline">${LH.STAGES.map(x=>`<span class="tag ${x===l.status?'green':'gray'}">${x}</span>`).join('')}</div><div class="toggleline"><span class="score">${l.processed?s.points:'—'}<span>/100</span></span><span class="tag ${s.qualified?'green':'amber'}">${l.processed?(s.qualified?'Spełnia ICP':'Wstrzymany'):'Oczekuje oceny'}</span></div>
    <h3>Sygnał i źródło</h3><p>${h(l.evidence)}</p>${sourceLink(l.source_url,l.source_title||'Otwórz źródło ↗')}<p class="tiny muted">Publikacja: ${h(l.signal_date||'brak danych')} · Wykrycie: ${h(l.detected_at)} · Źródło ${l.source_verified?'oznaczone jako sprawdzone przez badacza':'wymaga sprawdzenia'}</p>${l.quote?`<blockquote class="tiny">${h(l.quote)}</blockquote>`:''}<p class="status-note">${h(l.context)}</p>
    <h3>Uzasadnienie oceny</h3>${s.parts.map(p=>`<div class="reason"><div><strong>${h(p.label)}</strong><p>${h(p.reason)}</p></div><b>${p.points} / ${p.max}</b></div>`).join('')}
    ${s.blocks.length?'<div class="notice"><strong>Powody wstrzymania</strong><ul>'+s.blocks.map(b=>`<li>${h(b)}</li>`).join('')+'</ul></div>':''}${s.warnings.length?'<p class="status-note">'+s.warnings.map(h).join(' ')+'</p>':''}
    <h3>Dane kontaktowe · ${h(enrichLabel[co.status])}</h3><div class="factgrid"><div class="fact"><small>Osoba</small><strong>${h(co.person?l.contact.name:'brak danych')}</strong></div><div class="fact"><small>Stanowisko</small><strong>${h(co.role?l.contact.role:'brak danych')}</strong></div><div class="fact"><small>Służbowy e-mail</small><strong>${h(co.email?l.contact.email:'brak danych')}</strong></div><div class="fact"><small>Telefon</small><strong>${h(co.phone?l.contact.phone:'brak danych')}</strong></div></div>${sourceLink(l.contact.url,'Źródło danych kontaktowych ↗')}<p class="status-note">${h(co.warning)} ${h(l.enrichment_note)}</p><button class="small" data-action="edit">Uzupełnij dane / sprawdź źródło</button>
    <h3>Decyzja handlowca</h3><form id="feedback-form" class="form"><div class="row"><label>Ocena przydatności<select name="feedback">${Object.entries(feedbackLabel).map(([k,v])=>`<option value="${k}" ${l.feedback===k?'selected':''}>${v}</option>`).join('')}</select></label><label>Uzasadnienie<input name="note" value="${h(l.feedback_note)}" placeholder="Dlaczego warto / nie warto?"></label></div><button class="small" type="submit">Zapisz ocenę handlowca</button></form>
    <h3>Projekt pierwszej wiadomości</h3>${d.blocked?`<p class="muted">Najpierw usuń przyczyny wstrzymania. ${h(d.reason)}</p>`:`<p class="tiny muted">Szablon regułowy do redakcji · przygotowanie tekstu nie oznacza wykonania kontaktu.</p><strong>${h(d.subject)}</strong><div class="draft" id="draft-body">${h(d.body)}</div><div class="bottom-actions"><button class="small" data-action="copy-draft">Kopiuj wiadomość</button><button class="small" data-action="draft-file">Pobierz .txt</button></div>`}
    <h3>Kolejny krok</h3><p class="status-note">${!l.processed?'Uruchom ocenę leada.':!s.qualified?'Sprawdź kryteria wstrzymania; w razie potrzeby popraw dane.':!co.reachable?'Ustal kontakt w dopuszczonym źródle.':l.feedback!=='yes'?'Oceń z handlowcem, czy lead jest warty kontaktu.':!state.config.icp_approved||!state.config.contact_policy?'Przed kontaktem uzgodnij i zatwierdź ICP oraz politykę kontaktu w profilu.':'Wykonaj uzgodnione działanie, a następnie zapisz jego wynik.'}</p>
    ${next&&LH.STAGES.indexOf(next)>=3?`<form id="activity-form" class="form"><div class="row"><label>Data wykonanego działania<input name="date" type="date" value="${LH.today()}" max="${LH.today()}" min="${h(l.detected_at)}" required></label><label>Kanał<select name="channel"><option value="email">E-mail</option><option value="phone">Telefon</option><option value="other">Inny uzgodniony</option></select></label></div><label>Notatka z faktycznego działania<textarea name="note" required placeholder="Co wykonano i jaki był wynik?"></textarea></label><button type="submit" class="primary">Zapisz wykonane działanie: ${next}</button><small>Wpis do rejestru. Panel niczego nie wysyła.</small></form>`:''}
    <h3>Notatki i historia</h3><form id="notes-form" class="form"><textarea name="notes" aria-label="Notatki do leada">${h(l.notes)}</textarea><button class="small" type="submit">Zapisz notatki</button></form><ul class="audit">${[...l.history].reverse().map(x=>`<li><time>${h(x.at)}</time><b>${h(x.action)}</b> · ${h(x.note)}</li>`).join('')||'<li>Rekord oczekuje przetworzenia.</li>'}</ul><div class="bottom-actions"><button data-action="process-one">Przelicz tego leada</button><button class="danger" data-action="dnc">${l.do_not_contact?'Cofnij „nie kontaktować”':'Oznacz „nie kontaktować”'}</button></div>`,l.id+(l.is_demo?' · DEMO':''));
   $('#feedback-form').onsubmit=e=>{e.preventDefault();const f=new FormData(e.target);replace(LH.feedback(l,f.get('feedback'),f.get('note')));openLead(l.id);toast('Zapisano decyzję handlowca.');};
   $('#notes-form').onsubmit=e=>{e.preventDefault();const out=LH.clone(l);out.notes=LH.clean(new FormData(e.target).get('notes'));LH.log(out,'NOTE',out.notes);replace(out);openLead(l.id);toast('Zapisano notatki.');};
   if($('#activity-form'))$('#activity-form').onsubmit=e=>{e.preventDefault();try{const f=new FormData(e.target);const out=LH.changeStage(l,next,{date:f.get('date'),channel:f.get('channel'),note:f.get('note')},state.config);replace(out);openLead(l.id);toast('Zapisano ręczne potwierdzenie działania.');}catch(err){toast(err.message,true);}};
 }
 function replace(l){state.leads=state.leads.map(x=>x.id===l.id?l:x);save();render();}
 function leadForm(edit=false){
   const old=edit?state.leads.find(l=>l.id===selected):null;const l=old||{company:'',project:'',domain:'',country:state.config.country,region:'',signal_type:'construction',segment:'industrial',signal_date:LH.today(),detected_at:LH.today(),product:state.config.product,product_basis:'inferred',contact:{}};
   const field=(name,label,value,type='text',req=false)=>`<label>${label}<input name="${name}" type="${type}" value="${h(value||'')}" ${req?'required':''}></label>`;
   openModal(old?'Uzupełnij kartę':'Dodaj sygnał',`<form id="lead-form" class="form"><div class="row">${field('company','Firma',l.company,'text',true)}${field('domain','Domena firmy',l.domain,'text',true)}</div>${field('project','Nazwa inwestycji / projektu',l.project,'text',true)}<div class="row"><label>Segment<select name="segment">${Object.entries(LH.SEGMENTS).map(([k,v])=>`<option value="${k}" ${l.segment===k?'selected':''}>${v}</option>`).join('')}</select></label><label>Sygnał<select name="signal_type">${Object.entries(LH.SIGNALS).map(([k,v])=>`<option value="${k}" ${l.signal_type===k?'selected':''}>${v}</option>`).join('')}</select></label></div><div class="row">${field('country','Kraj (kod)',l.country,'text',true)}${field('region','Województwo',l.region)}</div><div class="row">${field('signal_date','Data publikacji (pusta = nieznana)',l.signal_date,'date')}${field('deadline','Termin odpowiedzi / przetargu',l.deadline,'date')}</div>${field('source_url','Adres źródła sygnału',l.source_url,'url',true)}${field('source_title','Nazwa źródła',l.source_title)}<label>Streszczenie dowodu<textarea name="evidence" required>${h(l.evidence)}</textarea></label><label class="check"><input type="checkbox" name="source_verified" ${l.source_verified?'checked':''}><span>Otworzyłem źródło i potwierdziłem opis sygnału.</span></label><div class="row"><label>Produkt<select name="product"><option ${l.product==='Techfence'?'selected':''}>Techfence</option><option ${l.product==='Alufence'?'selected':''}>Alufence</option></select></label><label>Podstawa produktu<select name="product_basis"><option value="inferred" ${l.product_basis==='inferred'?'selected':''}>Hipoteza zastosowania</option><option value="explicit" ${l.product_basis==='explicit'?'selected':''}>Potwierdzony zakres w źródle</option><option value="none" ${l.product_basis==='none'?'selected':''}>Brak podstawy</option></select></label></div><label>Uzasadnienie produktu<textarea name="product_reason" required>${h(l.product_reason)}</textarea></label><label>Kontekst / ograniczenia<textarea name="context">${h(l.context)}</textarea></label><h3>Enrichment ze źródła</h3><label class="check"><input type="checkbox" name="enrichment_attempted" ${l.enrichment_attempted?'checked':''}><span>Wykonano próbę znalezienia kontaktu.</span></label><div class="row">${field('contact_name','Osoba (jeśli ustalona)',l.contact.name)}${field('contact_role','Stanowisko ze źródła',l.contact.role)}</div><div class="row">${field('contact_email','Służbowy e-mail',l.contact.email,'email')}${field('contact_phone','Telefon',l.contact.phone)}</div>${field('contact_url','Adres źródła kontaktu',l.contact.url,'url')}<label>Krótki fragment źródła z danymi kontaktowymi<textarea name="contact_quote">${h(l.contact.quote)}</textarea><small>Panel wyświetli dane kontaktowe po sprawdzeniu ich obecności w tym fragmencie, daty i domeny. Nie zgaduj danych.</small></label><div class="row">${field('contact_verified_at','Data sprawdzenia kontaktu',l.contact.verified_at,'date')}<label>Rodzaj kontaktu<select name="contact_type">${[['general','Ogólny firmowy'],['procurement','Zakupy / projekt'],['leasing','Najem'],['press','PR / media'],['unknown','Nieustalony']].map(([k,v])=>`<option value="${k}" ${(l.contact.type||'general')===k?'selected':''}>${v}</option>`).join('')}</select></label></div><label class="check"><input type="checkbox" name="contact_reviewed" ${l.contact.reviewed?'checked':''}><span>Sprawdziłem w źródle, że dane dotyczą tej firmy / osoby.</span></label><label>Wynik próby enrichmentu<textarea name="enrichment_note">${h(l.enrichment_note)}</textarea></label><button type="submit" class="primary">${old?'Zapisz i przelicz':'Dodaj i oceń'} sygnał</button></form>`,'Dane i dowody');
   $('#lead-form').onsubmit=e=>{e.preventDefault();try{
     const f=new FormData(e.target),raw={};for(const [k,v]of f)if(!k.startsWith('contact_'))raw[k]=v;
     raw.is_demo=mode==='demo';raw.source_verified=f.has('source_verified');raw.enrichment_attempted=f.has('enrichment_attempted');raw.contact={};
     for(const k of ['name','role','email','phone','url','quote','verified_at','type'])raw.contact[k]=f.get('contact_'+k)||'';
     raw.contact.reviewed=f.has('contact_reviewed');raw.detected_at=l.detected_at;raw.quote=l.quote||'';
     if(!old&&state.leads.length>=1000)throw Error('Limit zbioru: 1000 rekordów. Zarchiwizuj sesję i rozpocznij nową.');
     const item=LH.validateLead(raw);
     if(state.leads.some(x=>(!old||x.id!==old.id)&&LH.key(x)===LH.key(item)))throw Error('Ten projekt tej firmy już istnieje.');
     if(old){for(const k of ['id','status','feedback','feedback_note','notes','do_not_contact','processed','history','milestones','activities'])item[k]=LH.clone(old[k]);item.feedback='pending';item.feedback_note='';LH.log(item,'EDIT','Zmieniono dane źródłowe; wymagana ponowna ocena handlowca.');}
     const processed=LH.processLead(item,state.config);
     if(old)replace(processed);else{while(state.leads.some(x=>x.id===processed.id))processed.id+='X';state.leads.push(processed);save();render();}
     openLead(processed.id);toast('Zapisano kartę.');
   }catch(err){toast(err.message,true);}};
 }
 function reportText(){const m=LH.metrics(state.leads,state.config,LH.today(),state.cycles);return `# TABAL Lead Hunter — raport sesji\n\nData: ${LH.today()}\nZbiór: ${labels[mode]}\nProfil: ${state.config.name}\n\n${mode==='pilot'?'Wskaźniki bieżącej sesji pilota.':'Zbiór testowy. Nie stanowi pomiaru efektywności sprzedażowej.'}\n\n| Wskaźnik | Wynik |\n|---|---:|\n| Sygnały | ${m.total} |\n| Ocenione | ${m.assessed} |\n| ICP / ocenione | ${m.qualified}/${m.assessed} (${pct(m.qualification_rate)}) |\n| E-mail / telefon / osoba | ${m.email_count}/${m.phone_count}/${m.person_count} |\n| Pokrycie kontaktem | ${pct(m.enrichment_rate)} |\n| Akceptacje / oceny handlowca | ${m.accepted}/${m.reviewed} (${pct(m.actionable_rate)}) |\n| Kontakty / sygnały | ${m.contacted}/${m.total} (${pct(m.contact_rate)}) |\n| Odpowiedzi / kontakty | ${m.replied}/${m.contacted} (${pct(m.reply_rate)}) |\n| Okazje / kontakty | ${m.opportunities}/${m.contacted} (${pct(m.opportunity_rate)}) |\n| Czas operatora | ${m.human_minutes} min |\n| Cykle feedbacku | ${m.feedback_cycles}/3 |\n| Sygnały na cykl researchu | ${m.signal_yield??'brak danych'} |\n\n## Wnioski i cykle\n\n${state.cycles.map(c=>`${c.date}: ${c.kind}; ${c.minutes} min; ${c.signals} sygnałów. ${c.note}`).join('\n\n')||'Nie zarejestrowano cykli.'}\n\n## Decyzja biznesowa\n\n${mode==='pilot'&&m.feedback_cycles>=3?'Do omówienia z TABAL: GO / CONTINUE / STOP.':'CONTINUE — potrzebne rzeczywiste cykle i oceny TABAL.'} Prototyp nie rozstrzyga automatycznie opłacalności.\n\n## Źródła i wyniki\n\n${state.leads.map(l=>`- ${l.company} / ${l.project}: ${LH.score(l,state.config).points}/100; ${l.status}. Źródło: ${l.source_url}`).join('\n')}`;}
 function render(){
   $$('.nav button').forEach(b=>{b.classList.toggle('active',b.dataset.page===page);if(b.dataset.page===page)b.setAttribute('aria-current','page');else b.removeAttribute('aria-current');});
   $('#date-label').textContent=new Intl.DateTimeFormat('pl-PL',{dateStyle:'long'}).format(new Date())+' · sesja lokalna';
   ({leads:leadsPage,discover:discoverPage,report:reportPage,settings:settingsPage,help:helpPage}[page]||leadsPage)();
 }
 const actions={
   close:()=>$('#detail').close(),
   process:()=>{state.leads=state.leads.map(l=>LH.processLead(l,state.config));save();render();toast(`Oceniono ${state.leads.length} rekordów. Nie wysłano wiadomości.`);},
   'process-one':()=>{const l=state.leads.find(x=>x.id===selected);replace(LH.processLead(l,state.config));openLead(selected);},
   import:()=>$('#import-file').click(), restore:()=>$('#restore-file').click(), add:()=>leadForm(),edit:()=>leadForm(true),
   backup:()=>download(`TABAL_kopia_${mode}_${LH.today()}.json`,LH.backup(state)),
   csv:()=>download(`TABAL_leady_${mode}_${LH.today()}.csv`,LH.csv(visibleLeads(),state.config),'text/csv;charset=utf-8'),
   'copy-work':()=>copy(workTask()),'download-work':()=>download('TABAL_zadanie_Work.txt',workTask(),'text/plain;charset=utf-8'),
   'config-file':()=>download('TABAL_profil_ICP.json',JSON.stringify(state.config,null,2)),
   'report-file':()=>download(`TABAL_raport_${mode}_${LH.today()}.md`,reportText(),'text/markdown;charset=utf-8'),
   'copy-draft':()=>{const l=state.leads.find(x=>x.id===selected),d=LH.draft(l,state.config);if(!d.blocked)copy(d.subject+'\n\n'+d.body);},
   'draft-file':()=>{const l=state.leads.find(x=>x.id===selected),d=LH.draft(l,state.config);if(!d.blocked)download(l.id+'_wiadomosc.txt',d.subject+'\n\n'+d.body,'text/plain;charset=utf-8');},
   dnc:()=>{const out=LH.clone(state.leads.find(x=>x.id===selected));out.do_not_contact=!out.do_not_contact;LH.log(out,'DO_NOT_CONTACT',out.do_not_contact?'Włączono blokadę kontaktu':'Cofnięto blokadę kontaktu');replace(out);openLead(selected);},
   reset:()=>{if(confirm('Wyzerować wybrany zbiór? Zapisz wcześniej kopię JSON. Próbka i DEMO wrócą do danych początkowych; pilot będzie pusty.')){state=fresh();memoryOnly=false;save();render();toast('Zresetowano wybrany zbiór.');}},
 };
 document.addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;if(b.dataset.page){page=b.dataset.page;render();window.scrollTo(0,0);}else if(b.dataset.open)openLead(b.dataset.open);else if(b.dataset.action&&actions[b.dataset.action]){try{actions[b.dataset.action]();}catch(err){toast(err.message,true);}}});
 $('#mode').onchange=e=>{save();mode=e.target.value;search='';filter='';selected=null;load();render();};
 $('#import-file').onchange=async e=>{const file=e.target.files[0];if(file){if(file.size>5*1024*1024)toast('Maksymalny rozmiar importu: 5 MB.',true);else doImport(await file.text());}e.target.value='';};
 $('#restore-file').onchange=async e=>{const file=e.target.files[0];if(file){try{if(file.size>5*1024*1024)throw Error('Maksymalny rozmiar kopii: 5 MB.');const next=LH.restore(await file.text(),mode);if(confirm('Przywrócić tę kopię i zastąpić bieżący zbiór?')){state=next;memoryOnly=false;save();render();toast('Przywrócono sesję.');}}catch(err){toast(err.message,true);}}e.target.value='';};
 load();render();
})();
