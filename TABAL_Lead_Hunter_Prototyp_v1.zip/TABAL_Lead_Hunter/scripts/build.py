from pathlib import Path
import json

root = Path(__file__).resolve().parents[1]
src = root / 'src'
template = (src / 'template.html').read_text(encoding='utf-8')
parts = {
 'STYLE': (src/'style.css').read_text(encoding='utf-8'),
 'CORE': (src/'core.js').read_text(encoding='utf-8'),
 'FIXTURES': (src/'fixtures.js').read_text(encoding='utf-8'),
 'WORKFLOW': 'window.LH_WORKFLOW='+json.dumps((root/'WORKFLOW_WORK.md').read_text(encoding='utf-8'),ensure_ascii=False)+';',
 'APP': (src/'app.js').read_text(encoding='utf-8'),
}
for key,content in parts.items():
 if key != 'STYLE': content=content.replace('</script',r'<\/script')
 template=template.replace('/*__'+key+'__*/',content)
if '/*__' in template: raise ValueError('Missing component')
(root/'START.html').write_text(template,encoding='utf-8')
print('START.html:',len(template.encode('utf-8')),'bytes; all assets inline; no network dependencies')
