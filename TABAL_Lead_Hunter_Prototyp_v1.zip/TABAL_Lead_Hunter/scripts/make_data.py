from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'data'
DATA.mkdir(exist_ok=True)
DAY = '2026-09-13'
pan_contact = dict(name='', role='', email='plinfo@panattoni.com', phone='+48 22 540 71 71',
    url='https://panattonieurope.com/pl-pl/kontakt/', quote='+48 22 540 71 71 plinfo@panattoni.com',
    verified_at=DAY, type='general', reviewed=True)
base = dict(country='PL', segment='industrial', product='Techfence', product_basis='inferred',
    product_reason='Ogrodzenie obiektu przemysłowego jest potencjalnym zastosowaniem Techfence; zakres zakupów nie został potwierdzony.',
    source_verified=True, detected_at=DAY, enrichment_attempted=True, is_demo=False,
    enrichment_note='Sprawdzono publiczną stronę kontaktową. Brak potwierdzonego kontaktu do osoby prowadzącej zakupy.',
    contact=pan_contact)
sample = [
    dict(base,company='Panattoni',domain='panattonieurope.com',project='City Logistics Łódź V',region='łódzkie',
        signal_type='construction',signal_date='2026-09-08',
        source_url='https://panattonieurope.com/pl-pl/aktualnosci/ruszyla-budowa-city-logistics-lodz-v-zadbano-wynajmuje-blisko-9-000-m-kw',
        source_title='Komunikat inwestora o budowie City Logistics Łódź V',
        evidence='Rozpoczęto realizację parku logistycznego o docelowej powierzchni ponad 42 700 m², z planowanym ukończeniem w I kwartale 2027.',
        quote='Panattoni rozpoczęło budowę City Logistics Łódź V.',
        context='Hipoteza sprzedażowa: ustalić, czy zamówienie na ogrodzenia i bramy pozostaje otwarte. Informacja o najmie Zadbano nie oznacza, że Zadbano kupuje ogrodzenie.'),
    dict(base,company='Depenbrock Polska',domain='depenbrock.pl',project='Panattoni Park Zgierz I — ostatni etap',region='łódzkie',
        segment='contractor',signal_type='construction',signal_date='2026-08-25',
        source_url='https://panattonieurope.com/pl-pl/aktualnosci/panattoni-rozwija-park-w-lucmierzu',
        source_title='Panattoni o ostatnim etapie parku w Lućmierzu',
        evidence='Inwestor poinformował o rozpoczęciu budowy kolejnych 16 400 m² w Lućmierzu i wskazał Depenbrock jako generalnego wykonawcę.',
        quote='Generalnym wykonawcą jest Depenbrock.',
        contact=dict(name='',role='',email='info@depenbrock.pl',phone='+48 61 65 65 660',url='https://depenbrock.pl/kontakt/',
            quote='+48 61 65 65 660 info@depenbrock.pl',verified_at=DAY,type='general',reviewed=True),
        context='Wykonawca jest wskazany w źródle. Wybór go jako pierwszego adresata jest hipotezą operacyjną; nie ustalono, czy ogrodzenie zostało już zakontraktowane.'),
    dict(base,company='CTP',domain='ctp.eu',project='CTPark Iłowa — nowe umowy najmu',region='lubuskie',
        signal_type='lease',signal_date='2026-09-09',
        source_url='https://ctp.eu/news/ctp-signs-104000-sqm-of-leases-at-ctpark-ilowa-as-asian-e-commerce-and-3pl-demand-accelerates/',
        source_title='CTP o nowych umowach najmu w Iłowej',
        evidence='Deweloper ogłosił nowe umowy najmu obejmujące łącznie ponad 104 000 m² w istniejącym parku w Iłowej.',
        quote='',contact={},product_basis='none',product_reason='Samo wynajęcie powierzchni nie potwierdza zakupu ogrodzenia.',
        enrichment_note='Otworzono ctp.eu/contact oraz komunikat. Nie ustalono kontaktu zakupowego dla tego zakresu; kontaktów medialnych i inwestorskich nie przypisano do zakupów.',
        context='Przypadek negatywny: duża powierzchnia i świeża data nie wystarczają do kwalifikacji. Pozostaje do obserwacji.'),
    dict(base,company='Panattoni',domain='panattonieurope.com',project='Panattoni Park Kraków East V — terminal BTS',region='małopolskie',
        signal_type='completed',signal_date='2026-08-05',source_url='https://panattonieurope.com/pl-pl/aktualnosci',
        source_title='Aktualności inwestora — terminal BTS w Krakowie',
        evidence='W komunikacie z 5 sierpnia inwestor opisał dostarczony już terminal logistyczny o powierzchni około 8 000 m².',quote='',
        context='Przypadek negatywny: obiekt został dostarczony. Bez dodatkowego sygnału nie należy traktować go jak nowej budowy wymagającej ogrodzenia.')
]
(DATA/'pierwsza_proba_2026-09-13.json').write_text(json.dumps({'schema_version':1,'dataset':'public_research_sample','as_of':DAY,'leads':sample},ensure_ascii=False,indent=2),encoding='utf-8')
demo=[]
scenarios=[
 ('Northline Logistics DEMO','industrial','construction','lubelskie','inferred',True),
 ('Vector Budownictwo DEMO','contractor','rfq','mazowieckie','explicit',True),
 ('Nova Park DEMO','industrial','expansion','łódzkie','inferred',False),
 ('Atlas Hale DEMO','contractor','tender','lubelskie','explicit',True),
 ('Domy Rzeka DEMO','residential','construction','lubelskie','inferred',True),
 ('Magazyn Gotowy DEMO','industrial','completed','łódzkie','inferred',True),
 ('Port Najmu DEMO','industrial','lease','pomorskie','none',True),
 ('Stara Inwestycja DEMO','industrial','construction','lubelskie','inferred',True),
 ('Delta Zakład DEMO','industrial','construction','śląskie','inferred',True),
 ('Bez Źródła DEMO','contractor','construction','lubelskie','inferred',True),
]
for i,(company,segment,signal,region,basis,has_contact) in enumerate(scenarios):
    d=dict(base,company=company,domain=f'firma-{i+1}.example.com',project=f'Projekt testowy {i+1:02d}',segment=segment,
        signal_type=signal,region=region,signal_date=DAY,source_url=f'https://example.com/sygnal/{i+1}',source_title='Fikcyjny scenariusz demonstracyjny',
        evidence='Fikcyjna inwestycja do sprawdzenia procesu. Wszystkie dane tego rekordu są demonstracyjne.',quote='',is_demo=True,product_basis=basis,
        product_reason='Scenariusz testowy dopasowania ogrodzenia do inwestycji.' if basis!='none' else 'Brak powiązania produktu.',
        context='DANE FIKCYJNE. Nie używać do działań sprzedażowych.',enrichment_note='Próba enrichmentu na danych fikcyjnych.',
        contact=dict(name='',role='',email=f'biuro{i+1}@example.com',phone='',url='https://example.com/kontakt',quote=f'biuro{i+1}@example.com',verified_at=DAY,reviewed=True,type='general') if has_contact else {})
    if signal=='tender':d['deadline']='2026-09-25'
    if i==7:d['signal_date']='2025-01-01'
    if i==8:d['contact']['quote']='Nie ma tu adresu kontaktowego.'
    if i==9:d['source_verified']=False
    demo.append(d)
(DATA/'scenariusze_demo.json').write_text(json.dumps({'schema_version':1,'leads':demo},ensure_ascii=False,indent=2),encoding='utf-8')
(ROOT/'src'/'fixtures.js').write_text('window.LH_SAMPLE='+json.dumps(sample,ensure_ascii=False)+';\nwindow.LH_DEMO='+json.dumps(demo,ensure_ascii=False)+';\n',encoding='utf-8')
print('Zapisano',len(sample),'rekordy publiczne i',len(demo),'scenariuszy DEMO.')
