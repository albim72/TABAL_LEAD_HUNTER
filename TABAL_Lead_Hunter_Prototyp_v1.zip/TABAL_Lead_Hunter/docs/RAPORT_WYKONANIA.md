# TABAL Lead Hunter — raport wykonania prototypu

Data: 13.09.2026. Wersja: 1.0.0. Przygotowanie: SYNAPSE X / Marcin Albiniak.

Powstała uruchamialna paczka do pierwszych testów Etapu 0 opisanego w załączonej ofercie. Zawiera panel lokalny, workflow badawczy dla Work, konfigurację jednego profilu klienta, sprawdzoną próbkę publicznych sygnałów i dane DEMO. Panel można otworzyć bez instalowania serwera. Pozwala wykonać i omówić proces od importu sygnału do zarejestrowanej okazji sprzedażowej.

## Co zostało wykonane

Odczytano załączoną ofertę v3 z 28.08.2026 i przełożono jej sześć etapów na workflow oraz karty leadów. Profil startowy to inwestorzy i wykonawcy obiektów przemysłowych w Polsce, z produktem Techfence. To założenie implementacyjne do wspólnej kalibracji, a nie deklaracja wcześniejszej akceptacji TABAL.

Zbudowano aplikację HTML, CSS i JavaScript bez zewnętrznych bibliotek. Wyszukiwanie, interpretacja kontekstu i enrichment są prowadzone w Work według dołączonej instrukcji. Zebrany JSON jest ręcznie importowany do panelu. Panel sprawdza format, usuwa duplikaty, liczy scoring, pokazuje ograniczenia, tworzy projekt wiadomości z kontekstem inwestycji i rejestruje decyzje handlowca oraz wykonane działania.

Przygotowano osobne zbiory próbki, DEMO i pilota, eksport CSV z neutralizacją formuł, pełną kopię JSON, odtwarzanie sesji i lokalne zapisywanie w przeglądarce. Kod źródłowy i testy są dołączone. Przygotowano instrukcję uruchomienia, scenariusz demonstracji, model danych i tabelę zgodności z ofertą.

## Pierwszy test na publicznych źródłach

Źródła zostały otwarte i sprawdzone 13.09.2026. Dane pochodzą z komunikatów inwestorów oraz oficjalnych stron firm. Potencjalna potrzeba ogrodzenia jest hipotezą wynikającą z charakteru inwestycji; nie przeprowadzono rozmów weryfikujących zakupy. Nie potwierdzono osoby decyzyjnej dla żadnego z czterech rekordów. Wybrano kontakty ogólne; brakującego kontaktu zakupowego nie uzupełniano domysłem.

| Rekord | Wynik 13.09.2026 | Wynik kwalifikacji | Co trzeba jeszcze sprawdzić |
|---|---:|---|---|
| Panattoni — City Logistics Łódź V | 87/100 | Spełnia roboczy ICP | Czy zakres ogrodzeń jest otwarty i kto go zamawia |
| Depenbrock — etap Panattoni Park Zgierz I | 87/100 | Spełnia roboczy ICP | Osoba odpowiedzialna i stan zamówienia ogrodzeń |
| CTP — nowe umowy najmu w Iłowej | 63/100 | Wstrzymany | Najem nie potwierdza nowego zakupu ogrodzenia |
| Panattoni — terminal Kraków East V | 62/100 | Wstrzymany | Obiekt opisano jako dostarczony; brak nowego zakresu |

Z dwóch pozytywnych sygnałów otrzymano karty z ogólnym kontaktem firmowym. Trzeci kontakt ogólny jest przy przypadku wstrzymanym. Znamy zatem kontakt dla 3/4 rekordów, ale nie znamy osób prowadzących zakupy. Te liczby opisują ręcznie dobraną próbkę, a nie skuteczność pozyskiwania leadów na rynku. Próbka jest mała, skoncentrowana na logistyce i dwóch domenach publikujących sygnały. Nie służy do obliczania ROI ani decyzji GO.

## Testy wykonane na końcowej wersji

**70 testów zakończonych powodzeniem: 49 testów reguł i 21 scenariuszy w przeglądarce.** Testy przeglądarkowe wykonano na Chromium 153.0.8010.0 w Linux, otwierając plik bezpośrednio przez `file://`. Szczegółową wersję i czas wykonania zawiera `test-results/ui-results.json`. Nie testowano osobno Windows, macOS ani Firefox. Nie testowano wysyłki e-mail, ponieważ prototyp jej nie implementuje.

Testy reguł sprawdziły kwalifikację próbki, obowiązkowe kryteria odrzucenia, stare i przyszłe daty, wygasłe przetargi, brakujące terminy, produkt, region, własną firmę, bezpieczne adresy źródeł, aktualność kontaktów i odróżnienie kontaktu PR od kontaktu użytecznego w sprzedaży. Sprawdzono także deduplikację, błędny i częściowo poprawny import, rozdzielenie DEMO i pilota, neutralizację formuł CSV, blokadę nieuprawnionych przejść statusu oraz pełną kopię sesji.

Scenariusze przeglądarkowe objęły uruchomienie bez serwera, ocenę i filtrowanie leadów, otwarcie karty, draft, eksport, odświeżenie i odtworzenie danych, import pliku Work, błędny JSON, ochronę przed wykonywaniem HTML z importu, generowanie zadania z profilu, pełny lejek CONTACTED → REPLIED → OPPORTUNITY na danych fikcyjnych, raport, ręczne dodanie, edycję i zmianę profilu. Sprawdzono widok 1440 px i 390 px. Zarejestrowano zero błędów JavaScript i zero zewnętrznych żądań sieciowych panelu podczas testów.

W trakcie kontroli doprecyzowano typ użytecznego kontaktu i ujednolicono limit całego zbioru do 1000 rekordów, aby kopię każdej obsługiwanej sesji dało się odtworzyć. Końcowy pakiet testów uruchomiono po tych zmianach.

## Co jest gotowe na jutro

Można zademonstrować działanie panelu offline, przejść proces na 10 scenariuszach DEMO, omówić źródła czterech rzeczywistych sygnałów, zmienić profil wspólnie z TABAL i wykonać nowy cykl w Work. Można też zapisać ręcznie potwierdzone wyniki rzeczywistych działań i wyeksportować rejestr do dalszej pracy.

Nie wykonano czterotygodniowego pilota ani trzech cykli feedbacku z klientem. Nie wysłano żadnej wiadomości do potencjalnych klientów. Nie zainstalowano harmonogramu, nie podłączono skrzynki, płatnych baz lub CRM i nie wdrożono backendu produkcyjnego. Zamknięty panel nie pracuje autonomicznie w tle. Integracje wymagają wyboru dostępnego i zatwierdzonego kanału oraz dalszej konfiguracji.

## Wdrożenie do pierwszego pilota

Marcin uruchamia START.html na komputerze demonstracyjnym i zachowuje kopię ZIP. TABAL wskazuje właściciela procesu. Wspólnie zatwierdzacie jeden profil, produkty, region, dozwolone źródła, politykę kontaktu oraz 10–20 przykładów dobrych i złych leadów. Przed pracą na prawdziwych danych wybieracie „Mój pilot”.

Operator generuje zadanie w Odkrywaniu, uruchamia je w Work, wczytuje wynik i ocenia próbkę z handlowcem. Handlowiec redaguje wiadomość, realizuje kontakt w uzgodnionym kanale i zapisuje rzeczywisty rezultat w karcie. Po sesji zapisujecie cykl i pełną kopię JSON. Powtarzacie proces trzy razy, korygując profil na podstawie odrzuceń, jakości kontaktów i nakładu pracy. Zmiana profilu wymaga ponownego zaznaczenia jego zatwierdzenia.

Przejście do pracy zespołowej i stałej automatyzacji powinno wynikać z tego, które źródła i czynności dały powtarzalny wynik. Wtedy projektuje się wspólną bazę, harmonogram, integrację kanału, monitoring i audyt. Paczka nie zakłada zakupu etapu produkcyjnego.

## Źródła wykorzystane do próbki i profilu

1. Oferta TABAL v3, załącznik użytkownika, 28.08.2026 — zakres procesu i kryteria odbioru.
2. [Techfence — oficjalna oferta TABAL](https://tabal.pl/ogrodzenia-panelowe/) — obszar produktu.
3. [Alufence — oficjalna oferta TABAL](https://tabal.pl/tabal-alufence/) — wariant produktu do późniejszej zmiany profilu.
4. [City Logistics Łódź V](https://panattonieurope.com/pl-pl/aktualnosci/ruszyla-budowa-city-logistics-lodz-v-zadbano-wynajmuje-blisko-9-000-m-kw) — sygnał budowy, publikacja 08.09.2026.
5. [Panattoni Park Zgierz I](https://panattonieurope.com/pl-pl/aktualnosci/panattoni-rozwija-park-w-lucmierzu) — sygnał budowy i wykonawca, publikacja 25.08.2026.
6. [Kontakt Panattoni](https://panattonieurope.com/pl-pl/kontakt/) — kontakt ogólny firmy.
7. [Kontakt Depenbrock](https://depenbrock.pl/kontakt/) — kontakt ogólny firmy.
8. [CTP — najem w Iłowej](https://ctp.eu/news/ctp-signs-104000-sqm-of-leases-at-ctpark-ilowa-as-asian-e-commerce-and-3pl-demand-accelerates/) — przypadek negatywny, publikacja 09.09.2026.
9. [Kontakt CTP](https://ctp.eu/contact/) — próba ustalenia kontaktu; nie przypisano kontaktu medialnego / inwestorskiego do zakupów.
10. [Aktualności Panattoni](https://panattonieurope.com/pl-pl/aktualnosci) — informacja o dostarczonym terminalu Kraków East V, pozycja z 05.08.2026.

Wszystkie źródła są dostępne także przy rekordach lub w pliku danych. Aktualność odzwierciedla datę badania, nie gwarantuje niezmienności strony.
