# Zgodność prototypu z ofertą TABAL v3

Punkt odniesienia: „TABAL_Autonomous_Lead_Hunter_MVP_Oferta_v3_editorial(3).docx”, oferta SYNAPSE X z 28.08.2026, Etap 0. Ta paczka umożliwia pierwsze testy procesu. Nie stanowi wykonania całego czterotygodniowego pilota, trzech cykli kalibracji ani odbioru usługi opisanej w ofercie.

| Element oferty | Implementacja na pierwsze testy | Granica |
|---|---|---|
| Warsztat, jeden ICP | Edytowalny profil inwestorów i wykonawców przemysłowych w Polsce | Hipoteza startowa do zatwierdzenia przez TABAL |
| Ontologia sygnałów | Zapytanie, przetarg, budowa, rozbudowa, partnerstwo, najem, ukończenie i inne | Kategoryzacja treści przez badacza / Work, scoring lokalny |
| Workflow ChatGPT Work | Pełna instrukcja i zadanie generowane z bieżącego profilu | Cykl uruchamia operator |
| Discover | Research Work; pierwsza publiczna próbka w paczce | HTML sam nie pobiera nowych stron; brak harmonogramu |
| Qualify i Score | Reguły ICP, geografia, intencja, aktualność, produkt, źródło | Ocena porządkowa; nie model prognostyczny |
| Enrich | Kontrakt źródłowego kontaktu, próba enrichmentu, daty i dowody | Wypełnia Work / operator; brak płatnej bazy |
| Karta leada | Wszystkie wymagane pola, braki jawnie wskazane | Domena i kontakt ogólny nie dowodzą osoby decyzyjnej |
| Outreach | Projekt wiadomości z kontekstem, kopia tekstu i zapis wykonania | Bez wysyłki i integracji poczty; kanał do uzgodnienia |
| Tracking | FOUND, QUALIFIED, ENRICHED, CONTACTED, REPLIED, OPPORTUNITY | Dalsze etapy na podstawie ręcznego wpisu działania |
| Audytowalność | Źródła, daty, uzasadnienia, zdarzenia, kopia JSON | Lokalna historia nie jest odporna na edycję pliku |
| Signal yield | Średnia liczby nowych sygnałów na zapisany cykl researchu | Ręczny rejestr; bez estymacji rynkowej na 4 rekordach |
| Qualification / enrichment / actionable | Liczniki i jasno opisane mianowniki w panelu | Próba, DEMO i pilot przechowywane oddzielnie |
| Contact / reply / opportunity | Liczniki oparte na zapisanych działaniach | Nie potwierdzają wysyłki w kanale zewnętrznym |
| Human effort | Wprowadzane minuty operatora | Brak automatycznego pomiaru pracy człowieka |
| Kalibracja, 3 cykle | Rejestr feedbacku i zmienny profil | Cykle trzeba przeprowadzić z TABAL |
| GO / CONTINUE / STOP | Raport i dane do decyzji | Brak automatycznej deklaracji opłacalności |
| Granice dostępu | Instrukcje Work i lista domen | Bez prywatnego scrapingu i obchodzenia zabezpieczeń |

## Co rozstrzygnąć na spotkaniu

Wybór segmentu zakupowego jest pierwszą decyzją. W próbce skierowano uwagę na nowe obiekty przemysłowe i generalnych wykonawców, ponieważ tworzą czytelną hipotezę zapotrzebowania na Techfence. TABAL może wybrać inny profil, np. deweloperów mieszkaniowych dla Alufence. Do takiej zmiany potrzebne będą nowe przykłady i kalibracja.

Następnie ustalcie region, rodzaje ogrodzeń i bram, wykluczenia, dozwolone źródła, właściwy kanał pierwszego kontaktu oraz osobę odpowiedzialną za ocenę kart. Przygotujcie 10–20 dobrych i złych przykładów zgodnie z ofertą. Proponowane 90 minut warsztatu można wykorzystać do ustawienia tych parametrów w panelu.
