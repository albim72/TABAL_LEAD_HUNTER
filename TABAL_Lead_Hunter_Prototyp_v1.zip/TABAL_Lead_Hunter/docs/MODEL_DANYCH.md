# Model danych i scoring

Kod domenowy znajduje się w `src/core.js`. Nie wykonuje żadnych żądań sieciowych. Operacje są testowane na rzeczywistych kształtach danych i scenariuszach błędnych. Warstwa UI jest w `src/app.js`; budowanie łączy ją z CSS, fixtures i workflow w jednym pliku START.html.

## Rekord i import

Plik researchu: obiekt `schema_version: 1` i tablica `leads`. Kontrakt pól i przykład znajdują się w `WORKFLOW_WORK.md`. Importer dopuszcza także samą tablicę. Limit zbioru i jednego importu: 1000 rekordów, plik do 5 MB. Błędne rekordy nie zatrzymują poprawnych; użytkownik dostaje numer wiersza i przyczynę. Importer nie ufa zewnętrznym statusom kontaktu ani akceptacji; nowe rekordy zaczynają w FOUND i pending.

Deduplikacja używa pary: znormalizowana domena firmy (lub jej nazwa, jeśli domeny nie podano) i nazwa projektu. Usuwa `www.`, różnice wielkości liter, polskie znaki diakrytyczne i nadmiarowe spacje. Firma z dwoma projektami to dwa leady. Taką samą inwestycję pod inną nazwą należy wychwycić w researchu / kontroli handlowca — nie ma dopasowania semantycznego. Gdy ten sam projekt ma inwestora i wykonawcę, to odrębne karty; trzeba koordynować działania, aby nie dublować kontaktów.

Istniejące rekordy nie są nadpisywane przez import. Aktualizacja odbywa się w edytorze karty i wymusza ponowny feedback handlowca. Punktacja jest przeliczana po zmianie danych i profilu. Historyczne wykonane działania pozostają w rejestrze także wtedy, gdy lead przestaje spełniać ICP.

## Punktacja

| Składowa | Maksimum | Reguła |
|---|---:|---|
| ICP | 25 | Segment występuje w wybranym profilu |
| Region | 10 | Kraj i wybrane województwa zgodne; pusta lista województw oznacza cały kraj |
| Sygnał | 25 | RFQ / przetarg 25; budowa 20; rozbudowa 18; partnerstwo 10; najem 3; ukończony / inny 0 |
| Aktualność | 15 | Do 30 dni: 15; do 60: 10; później w dopuszczonym okresie: 5; poza okresem / brak daty: 0 |
| Produkt | 15 | Wybrany produkt z uzasadnieniem: zakres potwierdzony 15, hipoteza 7, brak związku 0 |
| Dowód | 10 | Źródło oznaczone jako sprawdzone, bezpieczny URL i dozwolona domena |

Łącznie 100. Próg startowy 65, maksymalny wiek sygnału 90 dni. Kryteria obowiązkowe mogą wstrzymać nawet wynik 100/100: segment i geografia poza zakresem, nieznana / przyszła / stara data, przetarg bez terminu lub po terminie, brak źródła, sam najem, ukończony obiekt, brak uzasadnienia produktu, własna / wykluczona firma, brak domeny, odrzucenie przez handlowca, blokada kontaktu. To jawne reguły, które wymagają kalibracji na danych klienta.

Zapotrzebowanie na produkt ma osobną podstawę `explicit` / `inferred` / `none`. E-mail i telefon nie wpływają na punktację ICP; są osobnym warunkiem gotowości do działania.

## Kontakty

Kontakt obejmuje osobę, rolę, e-mail, telefon, URL, krótki fragment dowodu, datę sprawdzenia, typ i znacznik `reviewed`. Parser sprawdza format; panel uznaje dane za potwierdzone, jeżeli fragment zawiera te wartości, domena jest dopuszczona i weryfikacja nie jest starsza niż profilowe 30 dni ani przyszła. To kontrola spójności danych dostarczonych przez badacza, nie ponowne pobranie strony ani weryfikacja dostarczalności e-maila.

Kontakt typu `general` lub `procurement` z e-mailem lub telefonem spełnia warunek kanału. `press`, `leasing` oraz `unknown` nie dają gotowości zakupowej. E-mail / telefon ze źródła może być prawdziwy, a równocześnie dotyczyć niewłaściwego działu. Osoba i rola pojawiają się wyłącznie, gdy występują w zapisanym dowodzie. Ogólny kontakt może dać ENRICHED przy jednoczesnym statusie enrichmentu PARTIAL.

## Etapy, działania i metryki

Ocenianie ustawia FOUND / QUALIFIED / ENRICHED. CONTACTED wymaga kwalifikacji, akceptacji handlowca, aktualnego źródłowego kontaktu oraz zapisanych uzgodnień ICP i zasad kontaktu. Przejście CONTACTED → REPLIED → OPPORTUNITY wymaga notatki i daty działania. Panel zapisuje potwierdzenie operatora, nie wysyła wiadomości ani nie sprawdza skrzynki. Wygenerowanie lub skopiowanie draftu nie zmienia statusu.

Qualification rate = kwalifikowane / ocenione. Enrichment coverage = rekordy z użytecznym potwierdzonym kanałem / wszystkie rekordy. Actionable rate = akceptacje handlowca / jego oceny (yes+no). Contact rate = rekordy z zapisanym pierwszym kontaktem / wszystkie rekordy. Reply i opportunity rate liczone są względem zapisanych kontaktów. Czas to suma ręcznie wpisanych minut. Signal yield to średnia nowych sygnałów z ręcznie zapisanych cykli researchu. Feedback to osobny rodzaj cyklu.

Kopia JSON zawiera cały stan. CSV zawiera wyłącznie rekordy widoczne po filtrach i bez niepotwierdzonych wartości kontaktowych. Pola mogące rozpoczynać formuły w arkuszu są neutralizowane prefiksem apostrofu. HTML źródłowy z importu jest kodowany przy wyświetlaniu; nie może wykonywać skryptów. Dane strony nie są instrukcjami dla aplikacji.
