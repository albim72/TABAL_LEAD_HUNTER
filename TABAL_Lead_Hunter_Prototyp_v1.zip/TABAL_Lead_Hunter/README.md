# TABAL Lead Hunter — prototyp do pierwszych testów

Wersja 1.0.0, przygotowana 13.09.2026 przez SYNAPSE X / Marcin Albiniak. Punkt odniesienia: załączona oferta „TABAL Autonomous Lead Hunter MVP”, v3 z 28.08.2026. To uruchamialny prototyp Etapu 0: research w ChatGPT Work oraz lokalny rejestr oceny i obsługi leadów. Nie wymaga budowy backendu.

## Uruchomienie na spotkanie

1. Rozpakuj cały ZIP do jednego folderu, np. `Dokumenty/TABAL_Lead_Hunter`.
2. Otwórz **START.html** w przeglądarce. Nie uruchamiaj pliku wewnątrz podglądu ZIP.
3. Wybierz „Próbka publiczna” i kliknij „Oceń wszystkie”.
4. Otwórz kartę Depenbrock Polska. Pokaż źródło, uzasadnienie oceny, kontakt i projekt wiadomości.
5. Przełącz na DEMO, żeby przećwiczyć statusy. Rzeczywiste kontakty zapisuj dopiero po ich wykonaniu.
6. Po sesji kliknij **Kopia JSON**. To pełny zapis pracy, przydatny także do przeniesienia na inny komputer.

**Nie trzeba instalować Pythona, Node.js, Dockera ani bibliotek. Panel działa bez internetu; internet jest potrzebny do researchu w Work i otwierania źródeł.** Przetestowano Chromium 153 na Linux. Nie wykonano osobnego testu na fizycznym komputerze z Windows ani w Firefox; zastosowano standardowy HTML, CSS i JavaScript, bez zależności sieciowych.

Rozbudowana instrukcja: `INSTRUKCJA.html`. Raport techniczny: `docs/RAPORT_WYKONANIA.md`.

## Co działa

- Cztery sygnały sprawdzone w publicznych źródłach 13.09.2026 i 10 fikcyjnych scenariuszy DEMO.
- Trzy oddzielne zbiory: Próbka publiczna, DEMO, Mój pilot.
- Edytowalny profil klienta, region, produkt, progi i lista dozwolonych domen.
- Zadanie dla agenta Work generowane z aktualnego profilu i listy istniejących projektów.
- Import JSON z pliku lub schowka, walidacja rekordów, deduplikacja firma–projekt i raport błędów.
- Ręczne dodanie sygnału, edycja źródeł i uzupełnienie kontaktu.
- Scoring 0–100, jawne składowe i obowiązkowe kryteria kwalifikacji.
- Kontakty tylko z potwierdzonym źródłem, fragmentem dowodu i aktualną datą sprawdzenia; brak danych pozostaje pusty.
- Projekt wiadomości dopasowany do firmy i inwestycji, kopiowanie i pobieranie tekstu.
- Ocena handlowca, notatki, blokada „nie kontaktować”, rejestr statusów i historia zmian.
- Ręczny zapis wykonanego kontaktu, odpowiedzi i okazji: CONTACTED → REPLIED → OPPORTUNITY.
- Metryki lejka, zapis cykli researchu i feedbacku, czas operatora, raport Markdown.
- CSV do Excela / CRM oraz pełna kopia JSON z przywracaniem.

## Pełny cykl w Work

1. Przełącz panel na **Mój pilot**.
2. Uzgodnij z TABAL profil w **Profil i źródła**. Startowo: inwestorzy i wykonawcy przemysłowi w Polsce, ogrodzenia Techfence. Profil nie jest przedstawiany jako wcześniej zaakceptowany przez klienta.
3. Przejdź do **Odkrywanie**, wybierz **Kopiuj zadanie do Work**.
4. Otwórz rozmowę Work i wklej zadanie. Pozwól agentowi wykonać publiczny research. Agent ma zwrócić plik `leady_work.json` lub kompletny JSON.
5. Zaimportuj wynik do panelu i uruchom **Oceń wszystkie**. Import pomija istniejące pary firma–projekt, nie nadpisuje notatek ani statusów. Do uzupełnienia istniejącej karty użyj „Uzupełnij dane / sprawdź źródło”.
6. Otwórz źródła na 3–5 kartach, sprawdź trafność i zapisz ocenę handlowca. Potwierdzenie adresu firmy nie potwierdza osoby decyzyjnej ani bieżącej potrzeby zakupu.
7. Po uzgodnieniu zasad kontaktu i faktycznie wykonanym działaniu zapisz jego datę, kanał i wynik. Panel nie wysyła wiadomości.
8. Zapisz cykl, czas pracy i kopię JSON. Powtórz na rzeczywistych danych w trzech cyklach feedbacku.

Gdy Work nie ma w danym środowisku narzędzia wyszukiwania, użyj ręcznego dodawania potwierdzonych sygnałów. Gotowa instrukcja jawnie zabrania fikcyjnych wyników w miejsce nieudanego researchu. Nie zakłada automatycznego uruchomienia zadań cyklicznych ani dostępności konkretnego konektora.

## Ważne granice prototypu

Panel jest aplikacją lokalną. Nie ma wbudowanej wyszukiwarki internetu, automatycznego pobierania źródeł, logowania zespołowego, wspólnej bazy, synchronizacji CRM ani automatycznej wysyłki. Przeniesienie danych Work → panel jest ręczne. LLM analizuje źródła w Work; scoring i wiadomości w panelu są regułowe. Nie ma generowania brakujących telefonów, maili ani nazwisk.

Zamknięcie karty nie uruchamia pracy w tle. Dane przeglądarki nie zastępują plikowej kopii zapasowej; mogą zostać usunięte lub zależeć od ścieżki pliku. Historia w lokalnym JSON służy odtwarzaniu pracy, nie jest zabezpieczonym przed zmianą audytem produkcyjnym. Import i kopia są ograniczone do 5 MB, cały zbiór i pojedynczy import do 1000 rekordów. Prototyp przeznaczono dla jednego operatora i małego wolumenu pilota.

Status ENRICHED oznacza znaleziony, sprawdzony kanał kontaktu firmowego. Może nadal brakować osoby decyzyjnej. Qualification rate jest udziałem aktualnie kwalifikowanych wśród ocenionych, a actionable rate udziałem akceptacji TABAL wśród ocen handlowca. „Gotowe do kontaktu” dodatkowo wymaga zgodności z ICP i dostępnego kanału. Nieznany mianownik jest prezentowany jako „—”.

## Struktura paczki

| Plik / folder | Przeznaczenie |
|---|---|
| START.html | Samodzielna aplikacja, cały kod i dane startowe w jednym pliku |
| INSTRUKCJA.html | Instrukcja uruchomienia i wdrożenia do pilota |
| WORKFLOW_WORK.md | Pełne instrukcje badawcze i kontrakt JSON dla Work |
| data/ | Próbka publiczna, scenariusze DEMO, profil startowy |
| docs/ | Raport wykonania, zgodność z ofertą, opis modelu danych |
| src/ | Czytelny kod źródłowy aplikacji |
| scripts/ | Składanie START.html i danych testowych |
| tests/ | Testy reguł i scenariusze w przeglądarce |
| test-results/ | Wyniki testów końcowej wersji |
| assets/ | Zrzuty interfejsu z testów |

## Dla osoby technicznej

Aplikacja nie wymaga serwera; w MVP nie konfigurujemy hostingu. Opcjonalny lokalny serwer statyczny: w folderze projektu uruchom `python -m http.server 8765 --bind 127.0.0.1`, następnie otwórz `http://127.0.0.1:8765/START.html`. To osobne miejsce przechowywania danych niż adres `file://`; przenieś sesję przez kopię JSON. Serwer jest związany tylko z interfejsem lokalnym. Zatrzymaj go Ctrl+C.

Po zmianie źródeł:

```bash
python scripts/make_data.py
python scripts/build.py
node --test tests/core.test.js
```

Sam test reguł wymaga Node.js 20 lub nowszego i nie potrzebuje dodatkowych pakietów. `scripts/build.py` wymaga Pythona 3. `make_data.py` odtwarza historyczną próbkę z 13.09.2026, nie pobiera nowych danych. Aktualizując prawdziwą próbkę, ponownie sprawdź źródła i zachowaj rozróżnienie między publikacją a wykryciem.

Test przeglądarkowy wymaga osobno Playwright i Chromium. Po zainstalowaniu środowiska testowego uruchom `node tests/ui.cjs`. Opcjonalne zmienne: `LH_PLAYWRIGHT_ROOT` — ścieżka modułu Playwright, `LH_CHROMIUM_PATH` — ścieżka Chromium. Zależności te służą tylko testom; nie są częścią aplikacji.

Przy ewentualnym wdrożeniu zespołowym trzeba dodać backend, kontrolę dostępu, trwałą bazę, kolejkę zadań, monitoring źródeł, integrację zatwierdzonego kanału i rzeczywisty audyt. To zakres do odrębnej decyzji po pilocie, zgodnie z ofertą.
